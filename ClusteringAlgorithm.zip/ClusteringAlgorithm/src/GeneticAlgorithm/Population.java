package GeneticAlgorithm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import ModularityPairs.ApplicationClasses;
import ModularityPairs.ApplicationPackages;

public class Population {
	
	public static List<String> notToBeMovedClasses = new ArrayList<>();
	public static HashMap<Integer, List<String>> baseClusters = new HashMap<>();
	List<Integer> staticIndexes = new ArrayList<>();
	
	
	public List<List<Integer>> generateInitialPopulation(int nbOfClasses, int populSize, Random rnd) throws IOException
	{   
		
		List<List<Integer>> population = new ArrayList<>();
		int j = 0;
		
		int minClusters = 0;
		int maxClusters = 20;
		
		File populationFile = new File("./population.txt");
		FileOutputStream fos = new FileOutputStream(populationFile);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		
		
		
		HashMap<Integer, List<String>> temp = compositionBasedClusters("/home/soumia/Documents/DropBoxMontreal/Results2/JHotDraw/JHotDrawClassesThatShouldBeTogether.txt");
		baseClusters = temp;
		
		while(j < 200)
		{       ArrayList<Integer> gene = new ArrayList<Integer>(nbOfClasses);
		        for(int k=0; k<nbOfClasses; k++)
				{
					gene.add(k, Integer.MAX_VALUE);
				}
				int snIndex = 0;
				for(String simpleName : ApplicationClasses.simpleNames)
				{   
					Iterator ig = temp.keySet().iterator();
					while(ig.hasNext())
					{
						int clusterNum = (int)ig.next();
						if(temp.get(clusterNum).contains(simpleName))
						{   
							gene.set(snIndex, clusterNum);
							staticIndexes.add(snIndex);
							break;
						}
					}
					snIndex++;
				}
				
				
			    int nbOfClusters ;
			
				nbOfClusters =  (int) rnd.nextInt(maxClusters - minClusters + 1) + minClusters;
			    
				for(int i=0; i<nbOfClasses; i++)
				{  
				   if(!staticIndexes.contains(i))
				   { 
					   //gene.set(i, 5);
					   gene.set(i, (int) rnd.nextInt(nbOfClusters+1));
				   }
				}
				
				
				
				population.add(gene);
				
				//add the initial organization
				
				
				
				bw.write(gene.toString());
				bw.newLine();
			    j++;
		}
		
		bw.close();
		return population;
	}
	
	public HashMap<Integer, List<String>> compositionBasedClusters(String path) throws IOException
	{
		FileReader file = new FileReader(path);
		BufferedReader br = new BufferedReader(file);
		HashMap<Integer, List<String>> clustOfClasses = new HashMap<>(); 
		
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		String list = new String(encoded, StandardCharsets.UTF_8);
		
		String[] groups = list.split(" # "); 
		int k = 0;
		
		for(String group : groups)
		{
			String[] classes = group.split(",");
			List<String> classesNames = new ArrayList<>();
			for(String claz : classes)
			{
				String trimedClaz = claz.trim();
				classesNames.add(trimedClaz);
				notToBeMovedClasses.add(trimedClaz);
			}
			
			clustOfClasses.put(k, classesNames);
			k++;
		}
		
		return clustOfClasses;
	}
	
	
}

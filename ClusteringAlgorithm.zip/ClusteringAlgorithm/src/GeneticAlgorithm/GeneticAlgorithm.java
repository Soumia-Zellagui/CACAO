package GeneticAlgorithm;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import KMeans.AlgoKMeans;
import ModularityPairs.ApplicationClasses;
import ModularityPairs.ClasseRelationShips;
import ModularityPairs.CohesionAndCoupling;
import ModularityPairs.CollectingRelationships;
import spoon.reflect.reference.CtTypeReference;


public class GeneticAlgorithm {
	
	static List<List<Integer>> population = new ArrayList<>();
	
	public static CohesionAndCoupling cohCoupl;
	
	static LinkedHashMap<List<Integer>, Float> populationFitnessPair = new LinkedHashMap<>();
	
	static float crossoverProbability = (float) 0.4;
	
	static float mutationProbability = (float) 0.8;
	
	List<Integer> bestCluster;
	
	public static int bestSolutionClusters;
	
	
	
	private HashMap<String, List<String>> generateClusters(List<Integer> individual) 
	{   
		//getting the number of clusters in each individual
		List<Integer> diffClusters = new ArrayList<>();
		
		for(int i = 0; i < individual.size(); i++)
		{
			if(!diffClusters.contains(individual.get(i)))
			{
				diffClusters.add(individual.get(i));
			}
		}
		
		
		//once the number of clusters is with us, we get the classes of each cluster
		HashMap<String, List<String>> clusters = new HashMap<>();
		
		for(int j = 0; j < diffClusters.size(); j++)
		{   
			if(!clusters.keySet().contains(diffClusters.get(j)))
			{  
				List<String> classes = new ArrayList<>();
				for(int k = 0; k<individual.size(); k++)
				{
					if(diffClusters.get(j) == individual.get(k))
					{   
						String className = ApplicationClasses.appClasses.get(k);
					    classes.add(className);						    
					}
				}
				clusters.put(diffClusters.get(j).toString(), classes);
			}
		}
		
		return clusters;
	}
	
	
	
	public List<Integer> getClusterClassesNames(List<List<Integer>> population)
	{  
		for(List<Integer> individual : population)
		{   
			HashMap<String, List<String>> clusters = generateClusters(individual);
			//once we have classes of each cluster, we can calculate the fitness function
			float fitnessFuncValue = calculateFitnessFunction(clusters);
			System.out.println("Fitness value: "+fitnessFuncValue);
			populationFitnessPair.put(individual, fitnessFuncValue);			
		}
		return GAClustering(populationFitnessPair);
	}
	
	

	public List<Integer> GAClustering(LinkedHashMap<List<Integer>, Float> pairsPopFitness)
	{   //System.out.println("In GAClustering");
		// get the best and the worst fitness values
		List<Float> l = new ArrayList<Float>(pairsPopFitness.values());
		
		int iFbest = 0 ; 
		int iFworst = 0;
		float F_best = l.get(0);
		float F_worst = l.get(0);
		
		for(Map.Entry<List<Integer>, Float> key : pairsPopFitness.entrySet())
		{
			List<Integer> pairr = key.getKey();
			float valcc = key.getValue();
			

	        if(valcc > F_best)
	        {
	        	F_best = valcc;
	        	iFbest = new ArrayList<>(pairsPopFitness.keySet()).indexOf(pairr);
	        }
	        
	        if(valcc < F_worst)
	        {
	        	F_worst = valcc;
	        	iFworst = new ArrayList<>(pairsPopFitness.keySet()).indexOf(pairr);
	        }
		}
		
		
	    int numberOfFitEvaluation = 0;//pairsPopFitness.size();
	     int maxNbOfEval = 1000;
	    float absoluteValue = Math.abs(F_best - F_worst);
	    
	    while((numberOfFitEvaluation < maxNbOfEval) )//&& (absoluteValue >= Math.exp(-20)))
	    {  
			    	float newFitnessFuncValue = 0;
			    	System.out.println("Iteration:"+numberOfFitEvaluation);
			    	//System.out.println("Starting Roulette Wheel Selection ...");
			    	//select two different individuals using rouletteWheelSelection
			    	List<List<Integer>> selectedIndividuals = rouletteWheelSelection(pairsPopFitness, 2);
			    	
			    	
			    	
			    	//crossover
			    	//if(randomNumberGenerator() <= crossoverProbability)
			    	//{   //System.out.println("Starting Crossover ...");
			    		List<Integer> offspring = onePointCrossover(selectedIndividuals);
			    		HashMap<String, List<String>> clusters = generateClusters(offspring);
						
						//once we have classes of each cluster, we can calculate the fitness function
						newFitnessFuncValue = calculateFitnessFunction(clusters);
			    		     
						//if(newFitnessFuncValue > F_worst)
						//{    //System.out.println("Crossover Removes worst");
							//replace the worst individual by the new offspring
							//pairsPopFitness.remove((List<Integer>) (pairsPopFitness.keySet().toArray())[iFworst], F_worst);
							pairsPopFitness.put(offspring, newFitnessFuncValue);
							
						//}
					System.out.println("CrossOver Offspring: "+offspring);
					System.out.println("Fitness value: "+newFitnessFuncValue);
					//numberOfFitEvaluation++;
			    	//}
			    	
			    	
			       //mutation using k-menas
			    	//if(randomNumberGenerator() <= mutationProbability)
			    	//{   //System.out.println("Starting Mutation ...");	
			    		List<List<Integer>> selectedIndividual = rouletteWheelSelection(pairsPopFitness, 1);
			    		
			    		List<Integer> temp = new ArrayList<>();
			    		int nbClusters = 0;
			    		for(int i = 0; i < selectedIndividual.get(0).size(); i++)
			    		{
			    			if(!temp.contains(selectedIndividual.get(0).get(i)))
			    			{  
			    				temp.add(selectedIndividual.get(0).get(i));
			    			}
			    		}
			    		
			    		nbClusters = temp.size();    		
			    		AlgoKMeans algok = new AlgoKMeans(); 
			    		List<Integer> offspringg = algok.KmeansClustering(nbClusters, selectedIndividual.get(0));
			    		//System.out.println("Offspring: "+offspring);
		               HashMap<String, List<String>> clusterss = generateClusters(offspringg);
		               System.out.println("KMeans Offspring: "+offspringg);
					//once we have classes of each cluster, we can calculate the fitness function
					newFitnessFuncValue = calculateFitnessFunction(clusterss);
					System.out.println("Fitness value: "+newFitnessFuncValue);	
					//if(newFitnessFuncValue > F_worst)
					//{
							//replace the worst individual by the new offspring
							//pairsPopFitness.remove((List<Integer>) (pairsPopFitness.keySet().toArray())[iFworst], F_worst);
							pairsPopFitness.put(offspringg, newFitnessFuncValue);
							
					//}
						
					numberOfFitEvaluation++;
		
			    //	}  	
			  
	   }
	  	
          LinkedHashMap<List<Integer>, Float> bestClustering =  updateBest(pairsPopFitness);
	    	bestCluster = new ArrayList<>(bestClustering.keySet()).get(0);
	    	F_best = bestClustering.get(bestCluster);
	    	
	    	Iterator it = populationFitnessPair.keySet().iterator();
	    	while(it.hasNext())
	    	{
	    		List<Integer> solution = (List<Integer>) it.next();
	    		if(populationFitnessPair.get(solution)==F_best)
	    		{
	    			bestCluster = solution;
	    		}
	    	}
	    	System.out.println("#########################################################################################################");
	    	System.out.println("////////////: "+bestClustering.size());
	    	System.out.println("Best Fitness value: "+F_best);
	    return bestCluster;
	}
	
	public LinkedHashMap<List<Integer>, Float> updateBest(LinkedHashMap<List<Integer>, Float> pairsPopFitness)
	{    //System.out.println("Updating Best: ");
		Iterator iterator = pairsPopFitness.entrySet().iterator();
		LinkedHashMap<List<Integer>, Float> bestClustering = null;
		Map.Entry newpair = (Map.Entry)iterator.next();
          float newvalc = ((Float) newpair.getValue()).floatValue();
        
		float Fit_best = newvalc;
		
		int iFitbest = new ArrayList<>(pairsPopFitness.keySet()).indexOf(newpair);
		
	     while (iterator.hasNext()) {
	        Map.Entry newpairr = (Map.Entry)iterator.next();
	        float newvalcc = ((Float) newpairr.getValue()).floatValue();
	        bestClustering = new LinkedHashMap<>();
	        if(newvalcc > Fit_best)
	        {  
	        	Fit_best = newvalcc;
	        	iFitbest = new ArrayList<>(pairsPopFitness.keySet()).indexOf(newpairr);
	        }
	        bestClustering.put((List<Integer>) newpairr.getKey(), Fit_best);   
	     }
	   
	    return bestClustering;
	}
	
	public List<Integer> onePointCrossover(List<List<Integer>> selection)
	{     //System.out.println("In onePointCrossover ...");
		  List<Integer> offspring = new ArrayList<>(selection.get(0).size());
		  List<Integer> indexes = new ArrayList<>();
		  
		  for(int k=0; k<selection.get(0).size(); k++)
		  {
			  offspring.add(k, 1000);
		  }
		  
		  int crossPoint = (int) (Math.random()*selection.get(0).size());//make a crossover point
		  
		  for(String sn : Population.notToBeMovedClasses)
		  { // System.out.println(sn);
		     if(ApplicationClasses.simpleNames.contains(sn))
			{
		    	 int j = ApplicationClasses.simpleNames.indexOf(sn);
			 //System.out.println(j);
			 int nv = selection.get(0).get(j);
			 offspring.set(j, nv);
			 indexes.add(j);
			}
		   }   
		  
		  for (int i=0;i<selection.get(0).size();i++)
	       {    if(!indexes.contains(i))
			  {
			    if (i < crossPoint)
			    	{ 
			    	  int v = selection.get(0).get(i);
			    	  offspring.set(i, v);
			    	}
			    else
			    	{
			    	  int vl = selection.get(1).get(i);
			    	  offspring.set(i, vl);
			    	}
			  }
		  }
		 return offspring;
	}
	
	public List<List<Integer>> rouletteWheelSelection(LinkedHashMap<List<Integer>, Float> pairsPopFitness, int selectionSize)
	{
		
		float m = 0;
		float[] sumFitness = calculateSumFit(pairsPopFitness);
		List<List<Integer>> selection = new ArrayList<>(selectionSize);
		 
		 
		 while (selection.size() < selectionSize)
		 {  
			float r = randomNumberGenerator();
			float randomFitness = r * sumFitness[sumFitness.length-1];
			//float randomFitness =  sumFitness[sumFitness.length-1];
			int index = Arrays.binarySearch(sumFitness, randomFitness);
			
			if (index < 0)
			{
			 index = Math.abs(index + 1);
			}
			
			List<Integer> iemeIndividual = (List<Integer>) (pairsPopFitness.keySet().toArray())[index];
			
			if(!selection.contains(iemeIndividual))
			{
			  selection.add(iemeIndividual);
			}
		 }
		return selection;
	}
	
	
	
	public float[] calculateSumFit(HashMap<List<Integer>, Float> pairsPopFitness)
	{   
		float[] sum = new float[pairsPopFitness.size()];
		
		Iterator itt = pairsPopFitness.entrySet().iterator();
		Map.Entry first = (Map.Entry)itt.next();
		sum[0] = (((Float) first.getValue()).floatValue());
		int i = 1;
		while (itt.hasNext() && i<pairsPopFitness.size()) {
	        Map.Entry pair = (Map.Entry)itt.next();
	        sum[i] = sum[i-1] + (((Float) pair.getValue()).floatValue());
	        i++;
	    }
		
       return sum;
	}
	
	public static float randomNumberGenerator()
	{
		float rangeMin = 0.0f;
		float rangeMax = 1.0f;
	    Random r = new Random();
	    float createdRanNum = (float) (rangeMin + (rangeMax - rangeMin) * r.nextDouble());
	    return (createdRanNum);
	}
	
	
	private float calculateFitnessFunction(HashMap<String, List<String>> clusters) {
		// Calculate modularity
		cohCoupl.cohesionCalculation(clusters, cohCoupl.allRefinedRelationShips);
		cohCoupl.couplingCalculation(clusters, cohCoupl.allRefinedRelationShips);
		
		float sumcoh = 0;
		Iterator it = cohCoupl.packageCohesion.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        float val = ((Float) pair.getValue()).floatValue();
	        sumcoh = sumcoh + val;
	    }
		
		float sumcoup = 0;
		Iterator itt = cohCoupl.packageCoupling.entrySet().iterator();
	    while (itt.hasNext()) {
	        Map.Entry pair = (Map.Entry)itt.next();
	        float valc = ((Float) pair.getValue()).floatValue();
	        sumcoup = sumcoup + valc;
	    }
	   
	    float modularity = (float) (sumcoh)/(sumcoh+sumcoup);
	    
	    // Calculate package organization
	    // 1- Calculate SB
	    float sb = 0;
	    if(clusters.size()<=8)
	    {
	    	sb = (float)((clusters.size()-1)/7);
	    }
	    else
	    {
	    	if(clusters.size()> 8 && clusters.size()<16)
	    	{
	    		sb = 1 - ((clusters.size()-8)/8);
	    	}
	    	else
	    	{
	    		if(clusters.size()>16)
	    		{
	    			sb = 0;
	    		}
	    	}
	    }
	    
	    //2- Calculate CSU
	    // the Gini coefficient
	    Gini gini = new Gini();
	    int [] values = new int[clusters.size()];
	    int [] sortedValues;
	    
	    int i = 0;
	    for(String key : clusters.keySet())
	    {
	    	values[i] = clusters.get(key).size();
	    	i++;
	    }
	    Arrays.sort(values);
	   
	    float x = (float)(2 * gini.calculateBST(values));
	    float y = (float)(values.length * gini.calculateMKM(values));
	    
	    float z = (float)((float) (values.length + 1)/values.length);
	    float giniCoef = (float)(x/y) - z;
	    
	    float CSU = 1-giniCoef;
	    
	    // 3- Calculate CB
	    
	    float CB = sb * CSU;
	    
	    // Calculate aggregated modularity
	    float u = (float) 1;
	    float v = (float) 1;
	    
	    float uModularity = (float) Math.pow(modularity, 1);
	    float vCB = (float) Math.pow(CB, 1);
	    
	    float AModularity = uModularity * vCB;
	    
	    //System.out.println("Modularity: "+modularity);
	    //System.out.println("CB: "+CB);
	    
	    System.out.println("uModularity: "+uModularity);
	    System.out.println("vCB: "+vCB);
	    
	    return AModularity;
	}


	public static void main(String[] args)throws Exception {
		spoon.Launcher.main(new String[]
	    		 {"-p", "ModularityPairs.NestedClasses:"
		    		   +"ModularityPairs.ApplicationClasses:"
	    		 	   +"ModularityPairs.ApplicationInterfaces:"
	    			   +"ModularityPairs.CollectingRelationships:",
	              "-i", "/home/soumia/Documents/OSGiWorkspace/JHotDraw6.0/src/",
	              "--source-classpath","/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/Spoon-5.1.0/spoon-core-5.1.0-jar-with-dependencies.jar:"
	              //jhotdraw
	              +"/home/soumia/Téléchargements/jdo.jar:"
	              +"/home/soumia/Téléchargements/batik-svggen-1.7.jar:"
	              +"/home/soumia/Téléchargements/batik-dom-1.7.jar:"
	              //jdk8
	              +"/home//soumia/Bureau/jarFiles/activation-1.1.jar:"
	              +"/home//soumia/Bureau/jarFiles/ae-awt.jar:"
	              +"/home//soumia/Bureau/jarFiles/a-javabeans-1.0.4.jar:"
	              +"/home//soumia/Bureau/jarFiles/asm-debug-all-5.0_BETA.jar:"
	              +"/home//soumia/Bureau/jarFiles/bytecoder.api-2018-04-10.jar:"
	              +"/home//soumia/Bureau/jarFiles/bytecoder.api-2018-12-19.jar:"
	              +"/home//soumia/Bureau/jarFiles/client-0.7.3.jar:"
	              +"/home//soumia/Bureau/jarFiles/compiler-2.4.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/corba-api-5.0.0-sources.jar:"
	              +"/home//soumia/Bureau/jarFiles/java.base-2018-04-10.jar:"
	              +"/home//soumia/Bureau/jarFiles/java.base-2018-12-19.jar:"
	              +"/home//soumia/Bureau/jarFiles/javalib_native0.2_2.11-0.2.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/jboss-rmi-api_1.0_spec-1.0.1.final-sources.jar:"
	              +"/home//soumia/Bureau/jarFiles/jboss-rmi-api_1.0_spec-1.0.2.final-sources.jar:"
	              +"/home//soumia/Bureau/jarFiles/jdk7-2.1.13.jar:"
	              +"/home//soumia/Bureau/jarFiles/jdk-misc-1.Final.jar:"
	              +"/home//soumia/Bureau/jarFiles/jsdg-stubs-jre1.4.jar:"
	              +"/home//soumia/Bureau/jarFiles/jsdg-stubs-jre1.5.jar:"
	              +"/home//soumia/Bureau/jarFiles/jsr223-api-1.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/jsr292-mock-1.1.jar:"
	              +"/home//soumia/Bureau/jarFiles/nativelib_native0.2_2.11-0.2.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/openjdk-orb-jdk9-supplement-1.0.1.Final.jar:"
	              +"/home//soumia/Bureau/jarFiles/openjfx-78-backport-compat-1.8.0.1.jar:"
	              +"/home//soumia/Bureau/jarFiles/orb-9.1-sources.jar:"
	              +"/home//soumia/Bureau/jarFiles/org.apache.servicemix.bundles.saaj-impl-1.4.0_1.jar:"
	              +"/home//soumia/Bureau/jarFiles/org.apache.servicemix.specs.saaj-api-1.3-2.2.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/org.liveSense.fragment.com.sun.image.codec.jpeg-1.0.5.jar:"
	              +"/home//soumia/Bureau/jarFiles/reflectutils-0.9.20.jar:"
	              +"/home//soumia/Bureau/jarFiles/rhino-1.7.7.1.jar:"
	              +"/home//soumia/Bureau/jarFiles/rhino-android-1.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/rt.jar:"
	              +"/home//soumia/Bureau/jarFiles/scala-library-2.11.11.jar:"
	              +"/home//soumia/Bureau/jarFiles/security-4.0.jar:"
	              +"/home//soumia/Bureau/jarFiles/sjsxp.jar:"
	              +"/home//soumia/Bureau/jarFiles/sjsxp-1.0.2-sources.jar:"
	              +"/home//soumia/Bureau/jarFiles/slf4j-api-1.7.25.jar:"
	              +"/home//soumia/Bureau/jarFiles/stax-api-1.0-2.jar:"
	              +"/home//soumia/Bureau/jarFiles/stax-ex-1.7.4.jar:"
	              //jext
	              +"/home/soumia/Documents/jextJarFiles/ant-contrib-0.1.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jgoodies-looks-2.4.0.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jgoodies-plastic.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jSDG-stubs-jre1.5.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jython.jar:"
	              +"/home/soumia/Documents/jextJarFiles/looks-2.0.4-sources.jar:"
	             
	        });
		
		
		// create a new population for a new system or
		Population initialPopulation = new Population();
		population = initialPopulation.generateInitialPopulation(ApplicationClasses.appClasses.size(), ApplicationClasses.appClasses.size(), new Random());
		
		// use a population in a file
		/*FileReader file = new FileReader("./population.txt");
		BufferedReader br = new BufferedReader(file);
		String line;
		while ((line = br.readLine()) != null) {
		     // create a individual of the population and add it to the population 
			String lineWithoutLeftBracets = line.replace("[", "");
			String lineWithoutRightBracets = lineWithoutLeftBracets.replaceAll("]", "");
			
			String splittedLine[] = lineWithoutRightBracets.split(",");
			List<Integer> individual = new ArrayList<>(splittedLine.length);
			for(int k = 0; k<splittedLine.length; k++)
			{
				int gene = Integer.parseInt(splittedLine[k].trim());
				individual.add(gene);
			}
			
			population.add(individual);
		  }*/
		for(List<Integer> li:population)
		{
		System.out.println(li);
		}
          cohCoupl = new CohesionAndCoupling();
		  cohCoupl.SCSValueCalculation(CollectingRelationships.allRelationShips);

       
        
        float max = calculateMax(cohCoupl.allRefinedRelationShips);
        
        List<ClasseRelationShips> toBeAdd = new ArrayList<>();
		for(ClasseRelationShips t : cohCoupl.allRefinedRelationShips)
		{
			ClasseRelationShips rel = new ClasseRelationShips();
			rel.source = t.target;
			rel.target = t.source;
			rel.couplingValue = t.couplingValue;
			
			toBeAdd.add(rel);
		}
		//cohCoupl.allRefinedRelationShips.addAll(toBeAdd);
        cohCoupl.allRefRel.addAll(cohCoupl.allRefinedRelationShips);
        cohCoupl.allRefRel.addAll(toBeAdd);
		
        for(CtTypeReference clazz : ApplicationClasses.appClassesReferences)
        {
        	ClasseRelationShips rel = new ClasseRelationShips();
        	rel.source = clazz.getDeclaration();
        	rel.target = clazz.getDeclaration();
        	
        	
        	rel.couplingValue = max*10;
        	
        	cohCoupl.allRefRel.add(rel);
        }
        
        
      /* for(ClasseRelationShips re : cohCoupl.allRefinedRelationShips)
		{
			System.out.println(re.source.getQualifiedName()+" -> "+re.target.getQualifiedName()+ " : "+(1/re.couplingValue));
		}*/
		
		GeneticAlgorithm ga = new GeneticAlgorithm();
		List<Integer> bestStructure = ga.getClusterClassesNames(population);
		
          List<Integer> diffClusters = new ArrayList<>();
		
		for(int i = 0; i < bestStructure.size(); i++)
		{
			if(!diffClusters.contains(bestStructure.get(i)))
			{
				diffClusters.add(bestStructure.get(i));
			}
		}
		
		//System.out.println(populationFitnessPair);
		System.out.println("Best Solution: "+bestStructure);
		System.out.println("Number of clusters in this solution: "+diffClusters.size());
         // System.out.println("Existing classes: "+ApplicationClasses.simpleNames);
		
	}
	
	
	public static float calculateMax(List<ClasseRelationShips> input)
	{   
		float max = input.get(0).couplingValue;
		
		for(int i=1; i<input.size(); i++)
		{
			if(input.get(i).couplingValue > max)
			{
				max = input.get(i).couplingValue;
			}
		}
		return max;
	}
	
	public static List<Integer> modularize(String systemSourcePath, String populationPath) throws Exception
	{   
		
        
		spoon.Launcher.main(new String[]
	    		 {"-p", "ModularityPairs.ApplicationClasses:"
	    		 	   +"ModularityPairs.ApplicationInterfaces:"
	    			   +"ModularityPairs.CollectingRelationships:",
	              "-i", systemSourcePath,
	              "--source-classpath","/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/Spoon-5.1.0/spoon-core-5.1.0-jar-with-dependencies.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE-sources.jar:"
	              +"/home/soumia/Bureau/PMDLibs/apache-ant-1.8.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/asm-5.1.jar:"
	              +"/home/soumia/Bureau/PMDLibs/com.springsource.org.objectweb.asm_2.2.3.jar:"
	              +"/home/soumia/Bureau/PMDLibs/commons-io-2.4.jar:"
	              +"/home/soumia/Bureau/PMDLibs/commons-lang3-3.0.jar:"
	              +"/home/soumia/Bureau/PMDLibs/gson-2.2.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/jaxen-1.1.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/jcommander-1.30.jar:"
	              +"/home/soumia/Bureau/PMDLibs/org.apache.commons.io.jar:"
	              +"/home/soumia/Bureau/PMDLibs/org.objectweb.asm-3.2.0.jar:"
	              +"/home/soumia/Bureau/PMDLibs/saxon-9.1.0.8.jar:"
	              +"/home/soumia/Bureau/PMDLibs/saxon-he-9.3.0.5.jar:"
	              //jhotdraw
	              +"/home/soumia/Téléchargements/jdo.jar:"
	              +"/home/soumia/Téléchargements/batik-svggen-1.7.jar:"
	              +"/home/soumia/Téléchargements/batik-dom-1.7.jar:"
	        });
		
		
		FileReader file = new FileReader(populationPath);
		BufferedReader br = new BufferedReader(file);
		String line;
		while ((line = br.readLine()) != null) {
		     // create a individual of the population and add it to the population 
			String lineWithoutLeftBracets = line.replace("[", "");
			String lineWithoutRightBracets = lineWithoutLeftBracets.replaceAll("]", "");
			
			String splittedLine[] = lineWithoutRightBracets.split(",");
			List<Integer> individual = new ArrayList<>(splittedLine.length);
			for(int k = 0; k<splittedLine.length; k++)
			{
				int gene = Integer.parseInt(splittedLine[k].trim());
				individual.add(gene);
			}
			
			population.add(individual);
		  }
		
        cohCoupl = new CohesionAndCoupling();
		cohCoupl.SCSValueCalculation(CollectingRelationships.allRelationShips);

       
        
        float max = calculateMax(cohCoupl.allRefinedRelationShips);
        
        List<ClasseRelationShips> toBeAdd = new ArrayList<>();
		for(ClasseRelationShips t : cohCoupl.allRefinedRelationShips)
		{
			ClasseRelationShips rel = new ClasseRelationShips();
			rel.source = t.target;
			rel.target = t.source;
			rel.couplingValue = t.couplingValue;
			
			toBeAdd.add(rel);
		}
		cohCoupl.allRefinedRelationShips.addAll(toBeAdd);
        
		
        for(CtTypeReference clazz : ApplicationClasses.appClassesReferences)
        {
        	ClasseRelationShips rel = new ClasseRelationShips();
        	rel.source = clazz.getDeclaration();
        	rel.target = clazz.getDeclaration();
        	
        	
        	rel.couplingValue = max*10;
        	
        	cohCoupl.allRefinedRelationShips.add(rel);
        }
        
        
       for(ClasseRelationShips re : cohCoupl.allRefinedRelationShips)
		{
			System.out.println(re.source.getQualifiedName()+" -> "+re.target.getQualifiedName()+ " : "+(1/re.couplingValue));
		}
		
		GeneticAlgorithm ga = new GeneticAlgorithm();
		List<Integer> bestStructure = ga.getClusterClassesNames(population);
		System.out.println("The best structure is: ");
		System.out.println(bestStructure);
		
        List<Integer> diffClusters = new ArrayList<>();
		
		for(int i = 0; i < bestStructure.size(); i++)
		{
			if(!diffClusters.contains(bestStructure.get(i)))
			{
				diffClusters.add(bestStructure.get(i));
			}
		}
		bestSolutionClusters = diffClusters.size();
		System.out.println("Number of clusters in this solution: "+diffClusters.size());
		
		return bestStructure;
	}

}

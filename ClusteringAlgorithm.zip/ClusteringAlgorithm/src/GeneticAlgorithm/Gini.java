package GeneticAlgorithm;

import java.util.List;

public class Gini {

    public int calculateBST(int[] values)
    {   int sum = 0;
        int j = 1;
    	for(int i=0; i<values.length; i++)
    	{   sum = sum + (j*values[i]);
    		j++;
    	}
    	
    	return sum;
    }
    
    public int calculateMKM(int[] values)
    {   int sum = 0;
    	for(int i=0; i<values.length; i++)
    	{   
    		sum = sum + values[i];
    	}
    	return sum;
    }
	
}

package CompositionInferrence;

public class Node {

	String name;
	int identifier;
}

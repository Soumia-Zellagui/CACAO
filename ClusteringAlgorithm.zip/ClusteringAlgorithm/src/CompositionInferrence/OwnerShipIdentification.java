package CompositionInferrence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class OwnerShipIdentification {


	public  HashMap<Edge, List<Edge>> closure ;
	public  HashMap<Edge, List<Edge>> parent;
	public  List<Edge> markedEdges = new ArrayList<>();
	
	OwnerShipIdentification()
	{
		closure = new HashMap<>();
		parent = new HashMap<>();
		markedEdges = new ArrayList<>();
		//validClosures = new ArrayList<>();
	}
	
	
	public List<Edge> calculateReachability(Node node, List<Edge> edges, List<Edge> reachableEdges)
	{   //System.out.println("Calculating reachability ...");
		for(Edge e: edges)
		{  if(!reachableEdges.contains(e))
	       {
			if(e.source.name.equals(node.name))
			{     reachableEdges.add(e);
				   calculateReachability(e.target, edges, reachableEdges);
			}
		   }
		}
		//System.out.println("Reachability calculated :)");
		return reachableEdges;
	}
	
	public List<Node> ReachableNodes(Node node, List<Edge> reachableEdges)
	{   
		List<Node> reachableNodes = new ArrayList<>();
		//reachableNodes.add(node);
		for(Edge e : reachableEdges)
		{  
			if(e.source != node && !reachableNodes.contains(e.source))
			{
				reachableNodes.add(e.source);
			}
			
			if(e.target!= node && !reachableNodes.contains(e.target))
			{
				reachableNodes.add(e.target);
			}
		}
		/*System.out.println("Reachable nodes from "+node.name+" are: ");
		for(Node n : reachableNodes)
		{
			System.out.println(n.name);
		}*/
		return reachableNodes;
	}
	
	
	public void calculateClosure(Node node, Edge edge, List<Edge> reachableEdges)
	{ //System.out.println("Calculating closures ...");
	  Queue<Edge> w  = new LinkedList<>();
	  List<Edge> parent = new ArrayList<>();
	  List<Edge> closure = new ArrayList<>();	
	  	
	  
	  w.add(edge);
	  closure.add(edge);
	  markedEdges.add(edge);
	  
	  while(!w.isEmpty())
	  {   Edge ee = w.peek(); 
		  Node edgeTarget = ee.target;
		  Node edgeSource = ee.source;
		  w.poll();
		  
		  for(Edge e: JSONParse.graph.edges)
		  {  
			  if(e.target == edgeTarget && e.source != edgeSource)
			  {   // case 01
				  if(containEdge(e.source, edgeSource)==true && ReachableNodes(node, reachableEdges).contains(e.source))
				  {  
					  if(!markedEdges.contains(e))
					  {
						  w.add(e);
						  closure.add(e);
						  markedEdges.add(e);
						  
						  Edge ne = new Edge();
						  ne.source = e.source;
						  ne.target = edgeSource;
						  
						  parent.add(ne);
						  
					  }
				  }
				  
				  //case 02
				  if(containEdge(edgeSource, e.source)==true)
				  {  
					  if(!markedEdges.contains(e))
					  {
						  w.add(e);
						  closure.add(e);
						  markedEdges.add(e);
						  
						  Edge ne = new Edge();
						  ne.source = edgeSource;
						  ne.target = e.source;
						  parent.add(ne);
						  
					  }
				  }
			   }
			  
		    
		  }
		   
	  }
	  this.closure.put(edge, closure);
	  this.parent.put(edge, parent);
	 
	  System.out.print("Closure of [ "+edge.source.name+" -> "+edge.target.name+" ] is : ");
	  
	  for(Edge m:closure)
	  {
	  System.out.print("{ "+m.source.name + " -> "+m.target.name+" }, ");
	  }
	  System.out.println();
	   // all the following is for printing
	  
	  System.out.print("Parent of [ "+edge.source.name+" -> "+edge.target.name+" ] is : ");
		  if(!parent.isEmpty())
		  {
			  for(Edge p : parent)
			  {
			  System.out.print("{ "+p.source.name+" -> "+p.target.name+" }, ");
			  } 
		  }
		  else
		  {
			  System.out.print("{ }");
		  }
		 System.out.println();
	}
	
	public boolean containEdge(Node source, Node target)
	{   boolean cont = false;
		for(Edge e: JSONParse.graph.edges)
		{
		  if(e.source == source && e.target == target)
		  {
			  cont = true;
		  }
		}
		
		return cont;
	}
	
	
	public List<Edge> boundary(Node node)
	{   List<Edge> boundary = new ArrayList<>();
		List<Edge> tempReachableEdges = new ArrayList<>();
		List<Edge> reachableEdges = calculateReachability(node, JSONParse.graph.edges,tempReachableEdges);
		//this.nodeParent.put(node, new ArrayList<>());
		
		System.out.println("reachable nodes: ");
		for(Edge rEdge : reachableEdges)
		{   
			if(!markedEdges.contains(rEdge))
		    { 
			  
			  calculateClosure(node, rEdge, reachableEdges);
			  
		    }
		}
		
		//classify closures
		List<Edge> nonvalidClosures = new ArrayList<>();
		for(Edge givenEdge : reachableEdges)
		{
			nonvalidClosures.addAll(classifyClosure(givenEdge, node));
		}
		
		
		//boundary calculation
	    HashMap<Edge, List<Edge>> tempParent = new HashMap<>();
	    
	    for(Edge ed: reachableEdges)
	    {   if(parent.containsKey(ed))
	       {
	    	tempParent.put(ed, parent.get(ed));
	       }
	       //else
	       //{
	    	//   break;
	       //}
	    }
	    		//parent;
	    System.out.println("parent is empty ?"+tempParent.isEmpty());
		boundary = calculateBoundary(node, parent, nonvalidClosures, closure);
		markedEdges.clear();
		closure.clear();
		parent.clear();
		return boundary;
		
	}
	
	public List<Edge> classifyClosure(Edge givenEdge, Node node)
	{  List<Edge> nonvalidClosures = new ArrayList<>();
		if(givenEdge.source == node)
	    {
	    	for(Node n : JSONParse.graph.nodes)
			{ 
	    	  if(n != node) 
			  {
	    		int i = 0;
	    		for(Edge rr : JSONParse.graph.edges)
	    		{ 
	    			if((rr.source == n) && (rr.target == node))
	    			{
	    				i++;
	    			}
	    		}
	    		
	    		for(Edge rr : JSONParse.graph.edges)
	    		{  
	    			if((rr.source == n) && (rr.target == givenEdge.target))
	    			{
	    				i++;
	    			}
	    		}
	    		
	    		if(i == 2)
	    		{   
	    			if(!nonvalidClosures.contains(givenEdge))
	    				{ System.out.println("Non valid");
	    				  nonvalidClosures.add(givenEdge);		
	    				}
	    		}
			  }	
			}
	    
	    }
		
		return nonvalidClosures;
	}
	
	public List<Edge> calculateBoundary(Node node, HashMap<Edge, List<Edge>> parents, List<Edge> nonValidClosures, HashMap<Edge, List<Edge>> closures)
	{   
		// il faut selectionner que les closes valides d'abbord 
		List<Edge> boundary = new ArrayList<>();
		while(!parents.isEmpty())
		{   //to print which parent
		    Iterator in = parents.keySet().iterator();
		    while(in.hasNext())
		    	
		    {
		    	
		    	Edge e = (Edge) (in.next());
		    	System.out.println("non empty parent: "+e.source.name+" -> "+e.target.name);
		    }
		    		
		
			List<Edge> toRemove = new ArrayList<>();
			Iterator it = parents.keySet().iterator();
			while(it.hasNext())
			{   Edge key = (Edge) it.next();
			    if(parents.get(key).isEmpty())
				{  
					if(!nonValidClosures.contains(key))
					{  
						for(Edge cl:closures.get(key))
						{  
							// add it the boundary
							boundary.add(cl);
							
							// remove it from parent set
							Iterator iter = parents.keySet().iterator();
							HashMap<Edge, List<Edge>> toR = new HashMap<>();
							while(iter.hasNext())
							{   
								Edge keyy = (Edge) iter.next();
								
								for(Edge ooo: parents.get(keyy))
								{
									if((ooo.source.name.equals(cl.source.name)) && (ooo.target.name.equals(cl.target.name)))
									{
										
										if(toR.containsKey(keyy))
										{
											toR.get(keyy).add(ooo);
										}
										else
										{   List<Edge> l = new ArrayList<>();
										     l.add(ooo);
											toR.put(keyy, l);
										}
									}
								}
								
							}
							Iterator iii = toR.keySet().iterator();
							while(iii.hasNext())
							{   Edge p = (Edge) iii.next();
								List<Edge> ed = toR.get(p);
								parents.get(p).removeAll(ed);
							}
							
						}
						
					}
					toRemove.add(key);
				  }
				
			  }
			for(Edge re:toRemove)
			{
				parents.remove(re);
			}
		}
		
		
		return boundary;
	}
}

package CompositionInferrence;

public class Edge {
	
	Node source;
	Node target;
	String name;

}

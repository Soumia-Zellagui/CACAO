package CompositionInferrence;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.json.simple.parser.ParseException;

public class CompositionIdentification {
	
	public static  String jsonFile = "/home/soumia/Documents/ThesisDifferentTemplates/Thesis/Experimentations/C3/ObjectGraphs/Jext.json";
	public static  List<Reachability> reachabilityRelationShip = new ArrayList<>();
	public static  HashMap<Node, List<Edge>> boundarySets = new HashMap<>();
	public static  HashMap<Node, List<Edge>> compositionRelationships = new HashMap<>();
	
	public static  HashMap<String, List<String>> compositionbetweenClasses = new HashMap<>();
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException
	{  
		
		// parse the json file
		JSONParse.parse(jsonFile);
		/*List<Node> nodes = new ArrayList<>();
		List<Edge> edges = new ArrayList<>();
		
		Node a = new Node();
		a.name = "A";
		nodes.add(a);
		
		Node b = new Node();
		b.name = "B";
		nodes.add(b);
		
		Node c = new Node();
		c.name = "C";
		nodes.add(c);
		
		Node d = new Node();
		d.name = "D";
		nodes.add(d);
		
		Node e = new Node();
		e.name = "E";
		nodes.add(e);
		
		Edge e1 = new Edge();
		e1.source = a;
		e1.target = b;
		edges.add(e1);
		
		Edge e2 = new Edge();
		e2.source = a;
		e2.target = d;
		edges.add(e2);
		
		Edge e3 = new Edge();
		e3.source = a;
		e3.target = c;
		edges.add(e3);
		
		Edge e4 = new Edge();
		e4.source = c;
		e4.target = d;
		edges.add(e4);
		
		Edge e5 = new Edge();
		e5.source = d;
		e5.target = e;
		edges.add(e5);
		
		/*Edge e6 = new Edge();
		e6.source = e;
		e6.target = d;
		edges.add(e6);
		
		Graph graph = new Graph();
		JSONParse.graph = graph;
		JSONParse.graph.nodes = nodes;
		JSONParse.graph.edges = edges;
		*/
		
	   System.out.println("The graph: ");
	   System.out.println("********************************************");
	   
	   int i = 0;
	   for(Edge e:JSONParse.graph.edges)
	   {  i++;
	      
		   System.out.println(e.source.name+" -> "+e.target.name);
	   }
	   
	   System.out.println("********************************************");
		
		
		OwnerShipIdentification ident = new OwnerShipIdentification();
		for(Node node: JSONParse.graph.nodes)
		{   System.out.println("#######################  "+node.name+"    #############################");
		    
		    List<Edge> boundarySet = ident.boundary(node);
			boundarySets.put(node, boundarySet);
		}
		
	
		System.out.println("Composition relationShips");
		
		Iterator iter = boundarySets.keySet().iterator();
		while(iter.hasNext())
		{   Node n = (Node) iter.next();
		    compositionRelationships.put(n, new ArrayList<>());
		    if(!boundarySets.get(n).isEmpty()){
				
			    for(Edge bb : boundarySets.get(n))
			    { if(bb.source.name.equals(n.name))
			      {
			    	compositionRelationships.get(n).add(bb)		;	    
			    	}
			    }
			    
			   }
		}
		
		System.out.println("&&&&&&&&&&&&&&&&&&&&&&  Composition relationships between objects &&&&&&&&&&&&&&&&&&&&&&&&");
		//print boundary sets
		
		Iterator it = compositionRelationships.keySet().iterator();
		while(it.hasNext())
		{   
			 Node n = (Node) it.next();
			 if(!compositionRelationships.get(n).isEmpty())
			 {
			    System.out.print("node: "+n.name+" ###{");
				 for(Edge bb : compositionRelationships.get(n))
				 {
				   System.out.print(bb.source.name + " -> "+bb.target.name +", ");		
				 }
				 System.out.print("} ");
				 System.out.println();
			 }
			  
		}
		
		System.out.println("&&&&&&&&&&&&&&&&&&&&&&  Composition relationships between classes &&&&&&&&&&&&&&&&&&&&&&&&");
		
		Iterator itt = compositionRelationships.keySet().iterator();
		while(itt.hasNext())
		{
			Node node = (Node) itt.next();
			String nodeName = node.name.replaceAll("\\d","");;
			List<String> classesNames = new ArrayList<>();
			
			for(Edge bb : compositionRelationships.get(node))
			 { 
			   String bbName = bb.target.name.replaceAll("\\d","");;
			   if(!classesNames.contains(bbName))
			   {
				   classesNames.add(bbName);
				}
			 }
			
			
			compositionbetweenClasses.put(nodeName, classesNames);
			Iterator is = compositionRelationships.keySet().iterator();
			while(is.hasNext())
			{
				Node nodee = (Node) is.next();
				String nodeeName = nodee.name.replaceAll("\\d","");;
				
				if(nodeName.equals(nodeeName))
				{ 
					for(Edge bb : compositionRelationships.get(nodee))
					 { 
					   String bbName = bb.target.name.replaceAll("\\d","");;
					   if(!classesNames.contains(bbName))
					   {
						   classesNames.add(bbName);
						}
					 }
				}
			}
		}
		
		 Iterator hs = compositionbetweenClasses.keySet().iterator();
       while(hs.hasNext())
       {  
		   String component = (String)hs.next();
		   if(!compositionbetweenClasses.get(component).isEmpty())
    	   {  System.out.println("****************************************");
			   System.out.println("Class: "+component+" is composed of: ");
    	   
	    	   for(String composite : compositionbetweenClasses.get(component))
	    	   {
	    		   System.out.println(composite);
	    	   }
    	   }
       }
       
      
		
	}

}

package CompositionInferrence;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSONParse {
	
	static Graph graph = new Graph();
	static List<Reachability> reachabilityRelationShip = new ArrayList<>();
	
	public static void parse(String jsonfile) throws FileNotFoundException, IOException, ParseException
	{
		Object obj = new JSONParser().parse(new FileReader(jsonfile)); 
		JSONObject jo = (JSONObject) obj; 
		
		
		JSONArray nodes = (JSONArray) jo.get("nodes");

		Iterator iter = nodes.iterator();
		List<Node> graphNodes = new ArrayList<>();
		while(iter.hasNext())
        {          
			  Object node =  iter.next(); 
			  JSONObject jNode = (JSONObject) node;
              
			  Node newNode = new Node();
			  newNode.name = jNode.get("name").toString(); 
			  newNode.identifier =  Integer.valueOf(jNode.get("id").toString());
			  
			  graphNodes.add(newNode);
            
        }
		
		for(Node no : graphNodes)
		{
			graph.nodes.add(no);
		}
		
		
		
		JSONArray links = (JSONArray) jo.get("links");
		List<Edge> graphEdges = new ArrayList<>();
		Iterator it = links.iterator();
		
		while(it.hasNext())
        {          
			  Object pair =  it.next(); 
			  JSONObject job = (JSONObject) pair;
			  
			  
              Edge newEdge = new Edge();
              for(Node n : graph.nodes)
              {
            	  if(n.identifier == Integer.valueOf(job.get("source").toString()))
            	  {
            		  newEdge.source = n;
            	  }
            	  
            	  if(n.identifier == Integer.valueOf(job.get("target").toString()))
            	  {
            		  newEdge.target = n;
            	  }
            	  
              }
              
              newEdge.name = job.get("type").toString();
              graphEdges.add(newEdge);
        }
		for(Edge ed : graphEdges)
		{
		  graph.edges.add(ed);
		}
		
		
		//testing calcultae reachability
		/*
		OwnerShipIdentification i = new OwnerShipIdentification();
		for(Node n: graph.nodes)
		{   Reachability r = new Reachability();
		    r.node = n;
		    r.reachableEdges = i.calculateReachability(n, graph.edges, new ArrayList<>());
		    reachabilityRelationShip.add(r);
		}
		
		for(Reachability r: reachabilityRelationShip)
		{System.out.println("#################");
		System.out.println(r.node.name);
		for(Edge e:r.reachableEdges)
		{
			System.out.println(e.source.name +" -> "+ e.target.name);
		}
		}*/
	
	}
	
	

}

package CompositionInferrence;

import java.util.ArrayList;
import java.util.List;

public class Reachability {
	
	Node node;
	List<Edge> reachableEdges = new ArrayList<>();

}

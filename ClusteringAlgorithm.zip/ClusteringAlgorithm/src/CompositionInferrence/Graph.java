package CompositionInferrence;

import java.util.ArrayList;
import java.util.List;

public class Graph {
	
	public static List<Node> nodes = new ArrayList<>();
	public static List<Edge> edges = new ArrayList<>();

}

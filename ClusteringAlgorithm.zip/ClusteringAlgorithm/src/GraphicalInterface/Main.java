package GraphicalInterface;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;

import GeneticAlgorithm.GeneticAlgorithm;
import ModularityPairs.ApplicationClasses;

public class Main extends JFrame implements ActionListener{
	
	String systemSRCPath;
	String initialPopulationPath;
	
	JButton button;
	JButton population;
	JButton modularize;
	
	JTextField status;
	JTextField populationstatus;
	
	JPanel pan;
	
	  Main()
	  {     
		    
		    this.setVisible(true);
		    this.setTitle(" GrANulAR Tool");
		    this.setSize(1200, 1000);
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		  
		    pan = new JPanel();
		   
		    pan.setBackground(Color.BLACK);  
		    pan.setLayout(null);
		    
		    // to get the system source code
		    button = new JButton("System code");
		    button.setBackground(Color.CYAN);
		    button.setBounds(400, 260, 200, 40);
		    button.addActionListener((ActionListener) this);
		    status = new JTextField("file not uploaded!"); 
		    status.setBounds(600, 260, 200, 40);
		    
		   
		    // to get the population file
		    population = new JButton("Initial population");
		    population.setBackground(Color.CYAN);
		    population.setBounds(400, 320, 200, 40);
		    population.addActionListener((ActionListener) this);
		    populationstatus = new JTextField("file not uploaded!"); 
		    populationstatus.setBounds(600, 320, 200, 40);
		    
		    // logo
		    JLabel image = new JLabel(
		    		new ImageIcon("/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/WsE/ClusteringAlgorithm/images/granular.png")); 
		    image.setBounds(100, 200, 200, 200);
		    
		    // modularize button
		    modularize = new JButton("Modularize");
		    modularize.setBackground(Color.CYAN);
		    modularize.setBounds(900, 290, 200, 40);
		    modularize.addActionListener((ActionListener) this);
		    
		    
		    pan.add(image); 
		    pan.add(createVerticalSeparator());
		    pan.add(status);
		    pan.add(button);
		    pan.add(populationstatus);
		    pan.add(population);
		    pan.add(createVerticalSeparatorTwo());
		    pan.add(modularize);
		    
		    this.add(pan);        
		   
		    this.setVisible(true);

	  }
	  
	  
	  public static void main(String[] args){
		  
		  Main mainWindow = new Main();

	  }   
	  
	 
	  public void actionPerformed(ActionEvent evt) {	
			if(evt.getSource() == button)
			{
			    JFileChooser chooser = new JFileChooser();
			    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setApproveButtonText("Upload"); 
				chooser.showOpenDialog(null); 
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			     {	
				   status.setText(chooser.getSelectedFile().getName());
				   systemSRCPath = chooser.getSelectedFile().getAbsolutePath();
				 }
			}
			
			if(evt.getSource() == population)
			{
				JFileChooser chooser = new JFileChooser();
				chooser.setApproveButtonText("Upload"); 
				chooser.showOpenDialog(null); 
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			     {	
				   populationstatus.setText(chooser.getSelectedFile().getName());
				   initialPopulationPath = chooser.getSelectedFile().getAbsolutePath();
				 }
			}
			
			if(evt.getSource() == modularize)
			{
				try {
						
					    JFrame frame = new JFrame();
					    frame.setTitle("Modularizing ...");
				        frame.setBounds(700, 850, 600, 500);
				        frame.setBackground(Color.CYAN);
				        frame.setVisible(true);
					    /*
						JTextField result = new JTextField("Modularizing ..."); 
						result.setBounds(300, 450, 600, 400);
						result.setBackground(Color.CYAN);
				        result.setVisible(true);
				        pan.add(result);
				       */
			            
				        List<Integer> solution = GeneticAlgorithm.modularize(systemSRCPath, initialPopulationPath);
				       
				        Path path = Paths.get("/home/soumia/Bureau/index.html");
				        List<String> fileContent = new ArrayList<>(Files.readAllLines(path, StandardCharsets.UTF_8));

				        for (int i = 0; i < fileContent.size(); i++) {
				        	if(i == 12)
							{   String newLine = "var n = "+solution.size()+";";
							    fileContent.set(i, newLine);
							}
							if(i == 13)
							{   String newLine = "var m = "+GeneticAlgorithm.bestSolutionClusters+";";
							    fileContent.set(i, newLine);
							}
							if(i == 14)
							{   String newLine = "var clusterNumbers = "+solution.toString()+";";
							    fileContent.set(i, newLine);
							}
							if(i == 15)
							{   
								ArrayList<String> newNames = new ArrayList<>();
								int s = 0;
								for(String name:ApplicationClasses.simpleNames)
								{
									String nn = "\""+name+"\"";
									ApplicationClasses.simpleNames.set(s, nn);
									s++;
								}
								String newLine = "var clusterNames = "+ApplicationClasses.simpleNames+";";
								fileContent.set(i, newLine);
								break;
							}
				        }

				        Files.write(path, fileContent, StandardCharsets.UTF_8);
				        
				        FileReader file = new FileReader("/home/soumia/Bureau/index.html");
						BufferedReader br = new BufferedReader(file);
						String line;
						int k = 0;
						
						while ((line = br.readLine()) != null) {
							
							k++;
						}
				        
				        Browser browser = new Browser();
				        BrowserView browserView = new BrowserView(browser); 
				       
				       
				       frame.add(browserView, BorderLayout.CENTER);
				       frame.setTitle("Best Solution ...");
				       browser.loadURL("file:///home/soumia/Bureau/index.html");
				        //this.add(frame);
				        
				        
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		  }
	  
	  
	  static JComponent createVerticalSeparator() {
		    System.out.println("Vertical Separator");
	        JSeparator x = new JSeparator(SwingConstants.VERTICAL);
	        x.setBounds(350, 200, 50, 200);;
	        x.setBackground(Color.ORANGE);
	        return x;
	    }
	  
	  static JComponent createVerticalSeparatorTwo() {
		    System.out.println("Vertical Separator");
	        JSeparator x = new JSeparator(SwingConstants.VERTICAL);
	        x.setBounds(850, 200, 50, 200);;
	        x.setBackground(Color.ORANGE);
	        return x;
	    }

}

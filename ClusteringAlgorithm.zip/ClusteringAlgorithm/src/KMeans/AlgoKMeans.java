package KMeans;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;


import GeneticAlgorithm.GeneticAlgorithm;
import GeneticAlgorithm.Population;
import ModularityPairs.ApplicationClasses;
import ModularityPairs.ClasseRelationShips;
import ModularityPairs.CollectingRelationships;

public class AlgoKMeans
{
	/**samples of values*/
	private static  double samples[][];
	/**list of the data*/
	private static ArrayList<Data> dataSet;
	/**list of the clusters*/
	private static ArrayList<Cluster> clusters;
	
	static List<String> centroidsNames = new ArrayList<>();


	// cree des clusters les plus eloignées
	private static void createClusters(int _nbClusters, List<Integer> individual) {
		
		clusters = new ArrayList<>();
		int centroidIndex = 0;//(int) ((individual.size())*Math.random());
		
		// get the class name which correponds to the centroid;
		String centroidName = ApplicationClasses.appClasses.get(centroidIndex);
		String centroidSimpleName = ApplicationClasses.simpleNames.get(centroidIndex);
		Data d = new Data();
		d.index = centroidIndex;
		d.name = centroidName;
		
		List<Integer> indexesList = new ArrayList<>();
		indexesList.add(centroidIndex);
		
		
		centroidsNames.add(centroidName);
		
		Cluster firstCluster = new Cluster(d);
		firstCluster.identifier = individual.get(centroidIndex);
		
		int clusOfCentroid = Integer.MAX_VALUE;
		Iterator it = Population.baseClusters.keySet().iterator();
		while (it.hasNext())
		{
			int key = (int) it.next();
			if(Population.baseClusters.get(key).contains(centroidSimpleName))
			{
				clusOfCentroid = key;
				break;
			}
		}
		
		clusters.add(firstCluster);
		
		for(int c = 1; c < _nbClusters; c++) {
			
			Data fd = null;
			int farData;
			String farDataName = null;
			
			float maxDist = Float.NEGATIVE_INFINITY;
			
			for(int y = 0; y < individual.size();y++)
			{   
				// il faut ajouter la condition que le calcul de distance maximale 
				// doit etre uniquement avec les classes qui n'appartiennent pas au meme cluster
				
				String geneSimpleName = ApplicationClasses.simpleNames.get(y); 
				int clusOfgene = Integer.MAX_VALUE;
				Iterator itt = Population.baseClusters.keySet().iterator();
				while (itt.hasNext())
				{
					int key = (int) itt.next();
					if(Population.baseClusters.get(key).contains(geneSimpleName))
					{
						clusOfgene = key;
						break;
					}
				}
				
				if((clusOfgene != clusOfCentroid) || (clusOfgene == Integer.MAX_VALUE && clusOfCentroid == Integer.MAX_VALUE))
				{
					if(!indexesList.contains(y))
				    {       
					        String geneName = ApplicationClasses.appClasses.get(y);
							float minDist =  Float.POSITIVE_INFINITY;
							for(Cluster cluster:clusters) 
							{
								// la distance entre le centroid et le gene actuel
								
								float dist;
								
								for(ClasseRelationShips relations : GeneticAlgorithm.cohCoupl.allRefRel)
								{   
									  if((relations.source.getQualifiedName().equals(centroidName) && relations.target.getQualifiedName().equals(geneName)) || 
										   (relations.source.getQualifiedName().equals(geneName) && relations.target.getQualifiedName().equals(centroidName)))
									   { 
										 dist = (float) (1/relations.couplingValue);
										 if(minDist > dist) {minDist = dist; }
										 break;
									   }
								}
								
							}
							
							if (maxDist < minDist) {
								Data dt = new Data();
								farDataName = ApplicationClasses.appClasses.get(y);
								dt.name = farDataName;
								dt.index = y;
								fd = dt;
								maxDist  = minDist; 
							}
					 }
				}
			}
			
			if(fd == null)
			{   for(int y = 0; y < individual.size();y++)
			    {   if(!indexesList.contains(y))
		           {   
			    	   String newgeneName = ApplicationClasses.appClasses.get(y);
		               Data dfd = new Data();
		               dfd.name = newgeneName;
		               dfd.index = y;
		               fd = dfd;
		               break;
		           }
			    }
			}
			
			centroidsNames.add(fd.name);
			Cluster cluster = new Cluster(fd);
			indexesList.add(fd.index);
			cluster.identifier = individual.get(fd.index);
			clusters.add(cluster);
		}
		
	}
	
	
	//distribution des données sur des clusters
	private static void kMeanClustering(List<Integer> individual)
	{    dataSet = new ArrayList<>();
		
		for(int s = 0; s < individual.size(); s++)
	    {
		   Data d = new Data();
		   d.index = s;
		   d.name = ApplicationClasses.appClasses.get(s);
		   dataSet.add(d);
	    }
		
		
		for(Data data:dataSet)
		{  
		   Cluster dataCluster = searchCluster(data, individual);
		  
		   dataCluster.add(data);
		}
		
		boolean moving = true;
		while(moving)
		{  
			moving = false;
			//clusters.forEach(c -> c.centralize());
			for(Cluster c : clusters)
			{
				c.centralize();
			}
			
			for(Data data:dataSet)
			{
				Cluster bestCluster = searchCluster(data, individual);
				String datas[] = data.name.split("\\.");
				String dataSimpleName = datas[datas.length-1];
				if(!Population.notToBeMovedClasses.contains(dataSimpleName)){
				if(data.getCluster() != bestCluster ){
					moving = true;
					data.getCluster().remove(data);
					bestCluster.add(data);
				}
				}
			}
		}
		
		System.out.println("End KMeansClustering");
	}



	/**search the best cluster for a data
	 * @param data the data to place in a cluster
	 * @return the cluster whose the centroid is the closest from the data*/
	private static Cluster searchCluster(Data data, List<Integer> individual) {
		
		Cluster bestCluster = null;
		float minimum =  Float.POSITIVE_INFINITY;
		float distance=0;
		
		// si la donnée existe dans les classes qui ne doivent pas etre modifiées
		// son bestCluster est le cluster de base
		
			String[] datas = data.name.split("\\.");
			String dataSimpleName = datas[datas.length-1];
			if(Population.notToBeMovedClasses.contains(dataSimpleName))
			{   int i = ApplicationClasses.simpleNames.indexOf(dataSimpleName);
			    int clusNum = individual.get(i);
				for(Cluster cluster:clusters)
				{
					if(cluster.identifier == clusNum)
					{
						bestCluster = cluster;
					}
				}
			}
			else
			{
				for(Cluster cluster:clusters)
				{  
				   for(ClasseRelationShips relations : GeneticAlgorithm.cohCoupl.allRefRel)
				   {   
						if((relations.source.getQualifiedName().equals(cluster.getCentroid().name) && relations.target.getQualifiedName().equals(data.name)) || 
								   (relations.source.getQualifiedName().equals(data.name) && relations.target.getQualifiedName().equals(cluster.getCentroid().name)))
				     {  
						distance = (float) (1/(relations.couplingValue));
						
						if(distance < minimum)
						{ 
						  minimum = distance; 
						  bestCluster = cluster;
						}
						
				     }
				   }
				}
			}
			if(bestCluster == null)
			{
				bestCluster = clusters.get(0);
			}
		
		
		return bestCluster;
	}

	
	public List<Integer> KmeansClustering(int nbClusters, List<Integer> individual)
	{  
	    createClusters(nbClusters, individual);
	   
		kMeanClustering(individual);
		
		List<Integer> springoff = new ArrayList<>(individual.size());
		
		//in order to illiminate outofboundsexception
		for(int k=0; k<individual.size();k++)
		{
			springoff.add(0);
		}
		
		int i = 0;
		for(Cluster cluster: clusters)
		{   
		    ArrayList<Data> data = cluster.dataSet;
		    for(Data dt : data){
		    	String className = dt.name;
				int index = ApplicationClasses.appClasses.indexOf(className);
				
				springoff.set(index, i);
				
			}
			i++;
		}
       // System.out.println("Kmeans Springoff: "+springoff);
		return springoff;
	}	
}
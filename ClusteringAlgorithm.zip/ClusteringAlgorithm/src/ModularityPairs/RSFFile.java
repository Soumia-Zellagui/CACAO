package ModularityPairs;

public class RSFFile {
	
	String source;
		
	String target;

}

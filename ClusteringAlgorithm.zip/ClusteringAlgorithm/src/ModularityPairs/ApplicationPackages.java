package ModularityPairs;

import java.util.ArrayList;

import spoon.processing.AbstractProcessor;
import spoon.reflect.declaration.CtPackage;
import spoon.reflect.declaration.CtType;

public class ApplicationPackages extends AbstractProcessor<CtPackage>{
	
	public static  ArrayList<String> appPackages = new ArrayList<String>();

	
	public void process(CtPackage packagee)
	{
		if(!packagee.getQualifiedName().equals(""))
		{
		   appPackages.add(packagee.getQualifiedName());	
		}
	}

}

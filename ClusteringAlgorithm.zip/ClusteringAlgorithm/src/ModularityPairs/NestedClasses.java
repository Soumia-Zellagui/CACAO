package ModularityPairs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

import spoon.processing.AbstractProcessor;
import spoon.reflect.declaration.CtType;
import spoon.reflect.reference.CtTypeReference;

public class NestedClasses extends AbstractProcessor<CtType>{
	
	public static  ArrayList<String> nestedClassesNames = new ArrayList<String>();
	
	public void process(CtType e)
	{       
			if(!e.equals(null) && !e.isAnonymous() && e.isTopLevel())
			{   if(!nestedClassesNames.contains(e.getQualifiedName()))
			    {  if(!e.getNestedTypes().isEmpty())
					 { 
					     Set<CtType> nes = e.getNestedTypes();
						 for(CtType t : nes)
						 {
							 this.nestedClassesNames.add(e.getQualifiedName());

						 }
					 }
				}
             }	
	}	

}

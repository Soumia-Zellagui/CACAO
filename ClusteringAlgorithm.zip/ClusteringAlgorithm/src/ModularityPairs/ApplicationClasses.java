package ModularityPairs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

import spoon.processing.AbstractProcessor;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.declaration.CtPackage;
import spoon.reflect.declaration.CtType;
import spoon.reflect.declaration.ModifierKind;
import spoon.reflect.reference.CtExecutableReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.visitor.filter.TypeFilter;

public class ApplicationClasses extends AbstractProcessor<CtType>{
	
	public static  ArrayList<String> appClasses = new ArrayList<String>();
	public static  ArrayList<String> simpleNames = new ArrayList<>();
	public static  Collection<CtTypeReference> appClassesReferences = new ArrayList<CtTypeReference>();
	public static  HashMap <String, CtTypeReference> classNameReference = new HashMap<>();
	
	public void process(CtType e)
	{       
			if(!e.equals(null) && !e.isAnonymous() && e.isTopLevel())
			{   if(!appClasses.contains(e.getQualifiedName()) && !NestedClasses.nestedClassesNames.contains(e.getQualifiedName()))
			    {
				 this.appClasses.add(e.getQualifiedName());
				 simpleNames.add(e.getSimpleName());
				 appClassesReferences.add(e.getReference());
				 classNameReference.put(e.getQualifiedName(), e.getReference());
				}
            }
	}	
	
	
	/*public static void main(String[] args) throws Exception{
		spoon.Launcher.main(new String[]
	    		 {"-p", "ModularityPairs.ApplicationClasses:",
	    			   "-i", "/home/soumia/Documents/OSGiWorkspace/JHotDraw6.0/src/",
	 	               "--source-classpath","/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/Spoon-5.1.0/spoon-core-5.1.0-jar-with-dependencies.jar:"	  
	              //jhotdraw
	              +"/home/soumia/Téléchargements/jdo.jar:"
	              +"/home/soumia/Téléchargements/batik-svggen-1.7.jar:"
	              +"/home/soumia/Téléchargements/batik-dom-1.7.jar:"
	        });
   }*/
}

package RSFGeneration;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ModularityPairs.ApplicationClasses;

public class GenerateRSFFile {
	
	
	public static void generateRSFFile(List<Integer> solution, ArrayList<String> systemClasses) throws IOException
	{   
		File populationFile = new File("./solutionRSF.rsf");
	    FileOutputStream fos = new FileOutputStream(populationFile);
	    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
	    for(int i=0; i<solution.size(); i++)
		{
			String line = "contain Cluster"+solution.get(i)+" "+systemClasses.get(i);
			bw.write(line);
			bw.newLine();
		}
	    
	    bw.close();
	}
	
	public static void main(String[] args) throws Exception{
		spoon.Launcher.main(new String[]
	    		 {"-p", "ModularityPairs.NestedClasses:"
	    			   +"ModularityPairs.ApplicationClasses:"
	    		 	   +"ModularityPairs.ApplicationInterfaces:",
	    			   "-i", "/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/WsE/JHotDrawAfterThirdStep/src/",
	 	               "--source-classpath","/home/soumia/Bureau/Dropbox/Dossier de l'équipe Equipe MAREL/Thèse ZELLAGUI Soumia/Spoon-5.1.0/spoon-core-5.1.0-jar-with-dependencies.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aop-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-aspects-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-beans-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-indexer-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-context-support-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-core-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-expression-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-instrument-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jcl-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jdbc-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-jms-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-messaging-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-orm-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-oxm-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-test-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-tx-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-web-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webflux-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-webmvc-5.0.2.RELEASE-sources.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE-javadoc.jar:"
	            		  +"/home/soumia/Documents/spring-framework-5.0.2.RELEASE/libs/spring-websocket-5.0.2.RELEASE-sources.jar:"
	              +"/home/soumia/Bureau/PMDLibs/apache-ant-1.8.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/asm-5.1.jar:"
	              +"/home/soumia/Bureau/PMDLibs/com.springsource.org.objectweb.asm_2.2.3.jar:"
	              +"/home/soumia/Bureau/PMDLibs/commons-io-2.4.jar:"
	              +"/home/soumia/Bureau/PMDLibs/commons-lang3-3.0.jar:"
	              +"/home/soumia/Bureau/PMDLibs/gson-2.2.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/jaxen-1.1.2.jar:"
	              +"/home/soumia/Bureau/PMDLibs/jcommander-1.30.jar:"
	              +"/home/soumia/Bureau/PMDLibs/org.apache.commons.io.jar:"
	              +"/home/soumia/Bureau/PMDLibs/org.objectweb.asm-3.2.0.jar:"
	              +"/home/soumia/Bureau/PMDLibs/saxon-9.1.0.8.jar:"
	              +"/home/soumia/Bureau/PMDLibs/saxon-he-9.3.0.5.jar:"
	              //jhotdraw
	              +"/home/soumia/Téléchargements/jdo.jar:"
	              +"/home/soumia/Téléchargements/batik-svggen-1.7.jar:"
	              +"/home/soumia/Téléchargements/batik-dom-1.7.jar:"
	              //jext
	              +"/home/soumia/Documents/jextJarFiles/ant-contrib-0.1.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jgoodies-looks-2.4.0.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jgoodies-plastic.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jSDG-stubs-jre1.5.jar:"
	              +"/home/soumia/Documents/jextJarFiles/jython.jar:"
	              +"/home/soumia/Documents/jextJarFiles/looks-2.0.4-sources.jar:"
	        });
		
		   List<Integer> solution = Arrays.asList(0, 4, 4, 6, 4, 6, 6, 7, 8, 9, 0, 4, 0, 0, 0, 0, 0, 8, 0, 4, 0, 4, 4, 0, 8, 0, 0, 0, 0, 8, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 9, 0, 4, 0, 0, 0, 0, 0, 9, 9, 4, 0, 0, 0, 0, 0, 0, 4, 0, 4, 0, 0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 4, 0, 4, 4, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 6, 0, 0, 0, 0, 0, 4, 6, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 4, 0, 4, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 6, 0, 0, 6, 0, 0, 0, 0, 6, 0, 0, 0, 0, 4, 0, 0, 6, 0, 0, 0, 0, 6, 6, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 6, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0);
		   generateRSFFile(solution, ApplicationClasses.appClasses);
		
		}
		
}

## Jdk 8.0 Source Code
Needless to say
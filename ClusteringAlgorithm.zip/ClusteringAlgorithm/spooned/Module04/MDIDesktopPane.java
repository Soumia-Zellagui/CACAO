package Module04;


public class MDIDesktopPane extends javax.swing.JDesktopPane implements Module04.Desktop {
    private static int FRAME_OFFSET = 20;

    private Module04.MDIDesktopManager manager;

    private Module01.DrawApplication myDrawApplication;

    private Module04.DesktopEventService myDesktopEventService;

    private Module03.DrawingView selectedView;

    public MDIDesktopPane(Module01.DrawApplication newDrawApplication) {
        setDesktopEventService(createDesktopEventService());
        setDrawApplication(newDrawApplication);
        manager = new Module04.MDIDesktopManager(Module04.MDIDesktopPane.this);
        setDesktopManager(manager);
        setDragMode(javax.swing.JDesktopPane.OUTLINE_DRAG_MODE);
        setAlignmentX(javax.swing.JComponent.LEFT_ALIGNMENT);
    }

    protected javax.swing.event.InternalFrameListener internalFrameListener = new javax.swing.event.InternalFrameAdapter() {
        public void internalFrameOpened(javax.swing.event.InternalFrameEvent e) {
            Module03.DrawingView dv = Module06.Helper.getDrawingView(e.getInternalFrame());
            fireDrawingViewAddedEvent(dv);
        }

        public void internalFrameClosed(javax.swing.event.InternalFrameEvent e) {
            Module03.DrawingView dv = Module06.Helper.getDrawingView(e.getInternalFrame());
            if ((getComponentCount()) == 0) {
                Module03.DrawingView oldView = getActiveDrawingView();
                setActiveDrawingView(Module03.NullDrawingView.getManagedDrawingView(oldView.editor()));
                fireDrawingViewSelectedEvent(oldView, getActiveDrawingView());
            } 
            fireDrawingViewRemovedEvent(dv);
        }

        public void internalFrameActivated(javax.swing.event.InternalFrameEvent e) {
            Module03.DrawingView dv = Module06.Helper.getDrawingView(e.getInternalFrame());
            Module03.DrawingView oldView = getActiveDrawingView();
            setActiveDrawingView(dv);
            fireDrawingViewSelectedEvent(oldView, getActiveDrawingView());
        }
    };

    protected void fireDrawingViewAddedEvent(final Module03.DrawingView dv) {
        getDesktopEventService().fireDrawingViewAddedEvent(dv);
    }

    protected void fireDrawingViewRemovedEvent(final Module03.DrawingView dv) {
        getDesktopEventService().fireDrawingViewRemovedEvent(dv);
    }

    protected void fireDrawingViewSelectedEvent(final Module03.DrawingView oldView, final Module03.DrawingView newView) {
        getDesktopEventService().fireDrawingViewSelectedEvent(oldView, newView);
    }

    protected java.awt.Component createContents(Module03.DrawingView dv) {
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(((java.awt.Component)(dv)));
        sp.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        sp.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        sp.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        java.lang.String applicationTitle;
        if ((dv.drawing().getTitle()) == null) {
            applicationTitle = ((getDrawApplication().getApplicationName()) + " - ") + (getDrawApplication().getDefaultDrawingTitle());
        } else {
            applicationTitle = ((getDrawApplication().getApplicationName()) + " - ") + (dv.drawing().getTitle());
        }
        javax.swing.JInternalFrame internalFrame = new javax.swing.JInternalFrame(applicationTitle , true , true , true , true);
        internalFrame.setName(applicationTitle);
        internalFrame.getContentPane().add(sp);
        internalFrame.setSize(200, 200);
        return internalFrame;
    }

    public Module03.DrawingView getActiveDrawingView() {
        return selectedView;
    }

    protected void setActiveDrawingView(Module03.DrawingView newSelectedView) {
        selectedView = newSelectedView;
    }

    public void updateTitle(java.lang.String newDrawingTitle) {
        getSelectedFrame().setTitle(newDrawingTitle);
    }

    public void addToDesktop(Module03.DrawingView dv, int location) {
        javax.swing.JInternalFrame frame = ((javax.swing.JInternalFrame)(createContents(dv)));
        javax.swing.JInternalFrame[] array = getAllFrames();
        java.awt.Point p = null;
        int w;
        int h;
        frame.addInternalFrameListener(internalFrameListener);
        super.add(frame);
        checkDesktopSize();
        if ((array.length) > 0) {
            p = array[0].getLocation();
            p.x = (p.x) + (Module04.MDIDesktopPane.FRAME_OFFSET);
            p.y = (p.y) + (Module04.MDIDesktopPane.FRAME_OFFSET);
        } else {
            p = new java.awt.Point(0 , 0);
        }
        frame.setLocation(p.x, p.y);
        if (frame.isResizable()) {
            w = (getWidth()) - ((getWidth()) / 3);
            h = (getHeight()) - ((getHeight()) / 3);
            if (w < (frame.getMinimumSize().getWidth())) {
                w = ((int)(frame.getMinimumSize().getWidth()));
            } 
            if (h < (frame.getMinimumSize().getHeight())) {
                h = ((int)(frame.getMinimumSize().getHeight()));
            } 
            frame.setSize(w, h);
        } 
        moveToFront(frame);
        frame.setVisible(true);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {
            frame.toBack();
        }
    }

    public void removeFromDesktop(Module03.DrawingView dv, int location) {
        java.awt.Component[] comps = getComponents();
        for (int x = 0 ; x < (comps.length) ; x++) {
            if (dv == (Module06.Helper.getDrawingView(comps[x]))) {
                ((javax.swing.JInternalFrame)(comps[x])).dispose();
                break;
            } 
        }
        checkDesktopSize();
    }

    public void removeAllFromDesktop(int location) {
        javax.swing.JInternalFrame[] jifs = getAllFrames();
        for (int x = 0 ; x < (jifs.length) ; x++) {
            jifs[x].dispose();
        }
    }

    public Module03.DrawingView[] getAllFromDesktop(int location) {
        java.awt.Component[] comps = getComponents();
        java.util.ArrayList al = new java.util.ArrayList();
        for (int x = 0 ; x < (comps.length) ; x++) {
            Module03.DrawingView dv = Module06.Helper.getDrawingView(comps[x]);
            if (dv != null) {
                al.add(dv);
            } 
        }
        Module03.DrawingView[] dvs = new Module03.DrawingView[al.size()];
        al.toArray(dvs);
        return dvs;
    }

    protected Module04.DesktopEventService getDesktopEventService() {
        return myDesktopEventService;
    }

    private void setDesktopEventService(Module04.DesktopEventService newDesktopEventService) {
        myDesktopEventService = newDesktopEventService;
    }

    protected Module04.DesktopEventService createDesktopEventService() {
        Module04.DesktopEventService desktopEventService = new Module04.DesktopEventService(Module04.MDIDesktopPane.this , Module04.MDIDesktopPane.this);
        return desktopEventService;
    }

    public void addDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().addDesktopListener(dpl);
    }

    public void removeDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().removeDesktopListener(dpl);
    }

    public void cascadeFrames() {
        int x = 0;
        int y = 0;
        javax.swing.JInternalFrame[] allFrames = getAllFrames();
        if ((allFrames.length) == 0) {
            return ;
        } 
        manager.setNormalSize();
        int frameHeight = ((getBounds().height) - 5) - ((allFrames.length) * (Module04.MDIDesktopPane.FRAME_OFFSET));
        int frameWidth = ((getBounds().width) - 5) - ((allFrames.length) * (Module04.MDIDesktopPane.FRAME_OFFSET));
        for (int i = (allFrames.length) - 1 ; i >= 0 ; i--) {
            try {
                allFrames[i].setMaximum(false);
            } catch (java.beans.PropertyVetoException e) {
                e.printStackTrace();
            }
            allFrames[i].setBounds(x, y, frameWidth, frameHeight);
            x = x + (Module04.MDIDesktopPane.FRAME_OFFSET);
            y = y + (Module04.MDIDesktopPane.FRAME_OFFSET);
        }
        checkDesktopSize();
    }

    public void tileFrames() {
        tileFramesHorizontally();
    }

    public void tileFramesHorizontally() {
        java.awt.Component[] allFrames = getAllFrames();
        if ((allFrames.length) == 0) {
            return ;
        } 
        manager.setNormalSize();
        int frameHeight = (getBounds().height) / (allFrames.length);
        int y = 0;
        for (int i = 0 ; i < (allFrames.length) ; i++) {
            try {
                ((javax.swing.JInternalFrame)(allFrames[i])).setMaximum(false);
            } catch (java.beans.PropertyVetoException e) {
                e.printStackTrace();
            }
            allFrames[i].setBounds(0, y, getBounds().width, frameHeight);
            y = y + frameHeight;
        }
        checkDesktopSize();
    }

    public void tileFramesVertically() {
        java.awt.Component[] allFrames = getAllFrames();
        if ((allFrames.length) == 0) {
            return ;
        } 
        manager.setNormalSize();
        int frameWidth = (getBounds().width) / (allFrames.length);
        int x = 0;
        for (int i = 0 ; i < (allFrames.length) ; i++) {
            try {
                ((javax.swing.JInternalFrame)(allFrames[i])).setMaximum(false);
            } catch (java.beans.PropertyVetoException e) {
                e.printStackTrace();
            }
            allFrames[i].setBounds(x, 0, frameWidth, getBounds().height);
            x = x + frameWidth;
        }
        checkDesktopSize();
    }

    public void arrangeFramesVertically() {
        java.awt.Component[] allFrames = getAllFrames();
        if ((allFrames.length) == 0) {
            return ;
        } 
        manager.setNormalSize();
        int vertFrames = ((int)(java.lang.Math.floor(java.lang.Math.sqrt(allFrames.length))));
        int horFrames = ((int)(java.lang.Math.ceil(java.lang.Math.sqrt(allFrames.length))));
        int frameWidth = (getBounds().width) / horFrames;
        int frameHeight = (getBounds().height) / vertFrames;
        int x = 0;
        int y = 0;
        int frameIdx = 0;
        for (int horCnt = 0 ; horCnt < (horFrames - 1) ; horCnt++) {
            y = 0;
            for (int vertCnt = 0 ; vertCnt < vertFrames ; vertCnt++) {
                try {
                    ((javax.swing.JInternalFrame)(allFrames[frameIdx])).setMaximum(false);
                } catch (java.beans.PropertyVetoException e) {
                    e.printStackTrace();
                }
                allFrames[frameIdx].setBounds(x, y, frameWidth, frameHeight);
                frameIdx++;
                y = y + frameHeight;
            }
            x = x + frameWidth;
        }
        frameHeight = (getBounds().height) / ((allFrames.length) - frameIdx);
        y = 0;
        for ( ; frameIdx < (allFrames.length) ; frameIdx++) {
            try {
                ((javax.swing.JInternalFrame)(allFrames[frameIdx])).setMaximum(false);
            } catch (java.beans.PropertyVetoException e) {
                e.printStackTrace();
            }
            allFrames[frameIdx].setBounds(x, y, frameWidth, frameHeight);
            y = y + frameHeight;
        }
        checkDesktopSize();
    }

    public void arrangeFramesHorizontally() {
        java.awt.Component[] allFrames = getAllFrames();
        if ((allFrames.length) == 0) {
            return ;
        } 
        manager.setNormalSize();
        int vertFrames = ((int)(java.lang.Math.ceil(java.lang.Math.sqrt(allFrames.length))));
        int horFrames = ((int)(java.lang.Math.floor(java.lang.Math.sqrt(allFrames.length))));
        int frameWidth = (getBounds().width) / horFrames;
        int frameHeight = (getBounds().height) / vertFrames;
        int x = 0;
        int y = 0;
        int frameIdx = 0;
        for (int vertCnt = 0 ; vertCnt < (vertFrames - 1) ; vertCnt++) {
            x = 0;
            for (int horCnt = 0 ; horCnt < horFrames ; horCnt++) {
                try {
                    ((javax.swing.JInternalFrame)(allFrames[frameIdx])).setMaximum(false);
                } catch (java.beans.PropertyVetoException e) {
                    e.printStackTrace();
                }
                allFrames[frameIdx].setBounds(x, y, frameWidth, frameHeight);
                frameIdx++;
                x = x + frameWidth;
            }
            y = y + frameHeight;
        }
        frameWidth = (getBounds().width) / ((allFrames.length) - frameIdx);
        x = 0;
        for ( ; frameIdx < (allFrames.length) ; frameIdx++) {
            try {
                ((javax.swing.JInternalFrame)(allFrames[frameIdx])).setMaximum(false);
            } catch (java.beans.PropertyVetoException e) {
                e.printStackTrace();
            }
            allFrames[frameIdx].setBounds(x, y, frameWidth, frameHeight);
            x = x + frameWidth;
        }
        checkDesktopSize();
    }

    public void setAllSize(java.awt.Dimension d) {
        setMinimumSize(d);
        setMaximumSize(d);
        setPreferredSize(d);
        setBounds(0, 0, d.width, d.height);
    }

    public void setAllSize(int width, int height) {
        setAllSize(new java.awt.Dimension(width , height));
    }

    private void checkDesktopSize() {
        if (((getParent()) != null) && (isVisible())) {
            manager.resizeDesktop();
        } 
    }

    private void setDrawApplication(Module01.DrawApplication newDrawApplication) {
        myDrawApplication = newDrawApplication;
    }

    protected Module01.DrawApplication getDrawApplication() {
        return myDrawApplication;
    }
}


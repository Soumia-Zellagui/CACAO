package Module04;


public interface DesktopListener {
    public void drawingViewAdded(Module04.DesktopEvent dpe);

    public void drawingViewRemoved(Module04.DesktopEvent dpe);

    public void drawingViewSelected(Module04.DesktopEvent dpe);
}


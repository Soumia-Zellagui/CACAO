package Module04;


public interface Desktop {
    public static final int PRIMARY = 0;

    public static final int SECONDARY = 1;

    public static final int TERTIARY = 2;

    public Module03.DrawingView getActiveDrawingView();

    public void addToDesktop(Module03.DrawingView dv, int location);

    public void removeFromDesktop(Module03.DrawingView dv, int location);

    public void removeAllFromDesktop(int location);

    public Module03.DrawingView[] getAllFromDesktop(int location);

    public void updateTitle(java.lang.String newDrawingTitle);

    public void addDesktopListener(Module04.DesktopListener dpl);

    public void removeDesktopListener(Module04.DesktopListener dpl);
}


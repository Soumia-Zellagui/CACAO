package Module04;


public class DesktopEvent extends java.util.EventObject {
    private Module03.DrawingView myDrawingView;

    private Module03.DrawingView myPreviousDrawingView;

    public DesktopEvent(Module04.Desktop newSource ,Module03.DrawingView newDrawingView) {
        this(newSource, newDrawingView, null);
    }

    public DesktopEvent(Module04.Desktop newSource ,Module03.DrawingView newDrawingView ,Module03.DrawingView newPreviousDV) {
        super(newSource);
        setDrawingView(newDrawingView);
        setPreviousDrawingView(newPreviousDV);
    }

    private void setDrawingView(Module03.DrawingView newDrawingView) {
        myDrawingView = newDrawingView;
    }

    public Module03.DrawingView getDrawingView() {
        return myDrawingView;
    }

    private void setPreviousDrawingView(Module03.DrawingView newPreviousDrawingView) {
        myPreviousDrawingView = newPreviousDrawingView;
    }

    public Module03.DrawingView getPreviousDrawingView() {
        return myPreviousDrawingView;
    }
}


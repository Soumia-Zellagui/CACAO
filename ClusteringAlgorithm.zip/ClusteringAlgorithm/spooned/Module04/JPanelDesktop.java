package Module04;


public class JPanelDesktop extends javax.swing.JPanel implements Module04.Desktop {
    private Module04.DesktopEventService myDesktopEventService;

    private Module01.DrawApplication myDrawApplication;

    public JPanelDesktop(Module01.DrawApplication newDrawApplication) {
        setDrawApplication(newDrawApplication);
        setDesktopEventService(createDesktopEventService());
        setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        setLayout(new java.awt.BorderLayout());
    }

    protected java.awt.Component createContents(Module03.DrawingView dv) {
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(((java.awt.Component)(dv)));
        sp.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        sp.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        sp.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        java.lang.String applicationTitle;
        if ((dv.drawing().getTitle()) == null) {
            applicationTitle = ((getDrawApplication().getApplicationName()) + " - ") + (getDrawApplication().getDefaultDrawingTitle());
        } else {
            applicationTitle = ((getDrawApplication().getApplicationName()) + " - ") + (dv.drawing().getTitle());
        }
        sp.setName(applicationTitle);
        return sp;
    }

    public Module03.DrawingView getActiveDrawingView() {
        return getDesktopEventService().getActiveDrawingView();
    }

    public void addToDesktop(Module03.DrawingView dv, int location) {
        getDesktopEventService().addComponent(createContents(dv));
        getContainer().validate();
    }

    public void removeFromDesktop(Module03.DrawingView dv, int location) {
        getDesktopEventService().removeComponent(dv);
        getContainer().validate();
    }

    public void removeAllFromDesktop(int location) {
        getDesktopEventService().removeAllComponents();
        getContainer().validate();
    }

    public Module03.DrawingView[] getAllFromDesktop(int location) {
        return getDesktopEventService().getDrawingViews(getComponents());
    }

    public void addDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().addDesktopListener(dpl);
    }

    public void removeDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().removeDesktopListener(dpl);
    }

    private java.awt.Container getContainer() {
        return Module04.JPanelDesktop.this;
    }

    protected Module04.DesktopEventService getDesktopEventService() {
        return myDesktopEventService;
    }

    private void setDesktopEventService(Module04.DesktopEventService newDesktopEventService) {
        myDesktopEventService = newDesktopEventService;
    }

    protected Module04.DesktopEventService createDesktopEventService() {
        java.awt.Container container = getContainer();
        Module04.DesktopEventService desktopEventService = new Module04.DesktopEventService(Module04.JPanelDesktop.this , container);
        return desktopEventService;
    }

    private void setDrawApplication(Module01.DrawApplication newDrawApplication) {
        myDrawApplication = newDrawApplication;
    }

    protected Module01.DrawApplication getDrawApplication() {
        return myDrawApplication;
    }

    public void updateTitle(java.lang.String newDrawingTitle) {
        setName(newDrawingTitle);
    }
}


package Module04;


public class JScrollPaneDesktop extends javax.swing.JScrollPane implements Module04.Desktop {
    private Module04.DesktopEventService myDesktopEventService;

    public JScrollPaneDesktop() {
        setDesktopEventService(createDesktopEventService());
        setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    }

    protected java.awt.Component createContents(Module03.DrawingView dv) {
        return ((java.awt.Component)(dv));
    }

    public Module03.DrawingView getActiveDrawingView() {
        return getDesktopEventService().getActiveDrawingView();
    }

    public void addToDesktop(Module03.DrawingView dv, int location) {
        getContainer().add(createContents(dv));
    }

    public void removeFromDesktop(Module03.DrawingView dv, int location) {
        getDesktopEventService().removeComponent(dv);
    }

    public void removeAllFromDesktop(int location) {
        getDesktopEventService().removeAllComponents();
    }

    public Module03.DrawingView[] getAllFromDesktop(int location) {
        return getDesktopEventService().getDrawingViews(getComponents());
    }

    public void addDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().addDesktopListener(dpl);
    }

    public void removeDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().removeDesktopListener(dpl);
    }

    private java.awt.Container getContainer() {
        return getViewport();
    }

    protected Module04.DesktopEventService getDesktopEventService() {
        return myDesktopEventService;
    }

    private void setDesktopEventService(Module04.DesktopEventService newDesktopEventService) {
        myDesktopEventService = newDesktopEventService;
    }

    protected Module04.DesktopEventService createDesktopEventService() {
        java.awt.Container cont = getContainer();
        Module04.DesktopEventService desktopEventService = new Module04.DesktopEventService(Module04.JScrollPaneDesktop.this , cont);
        return desktopEventService;
    }

    public void updateTitle(java.lang.String newDrawingTitle) {
        setName(newDrawingTitle);
    }
}


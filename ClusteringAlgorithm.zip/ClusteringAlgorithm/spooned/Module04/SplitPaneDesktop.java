package Module04;


public class SplitPaneDesktop extends javax.swing.JSplitPane implements Module04.Desktop {
    private Module04.DesktopEventService myDesktopEventService;

    public SplitPaneDesktop() {
        setDesktopEventService(createDesktopEventService());
        setAlignmentX(javax.swing.JSplitPane.LEFT_ALIGNMENT);
        setOneTouchExpandable(true);
        addPropertyChangeListener(createPropertyChangeListener());
    }

    protected java.beans.PropertyChangeListener createPropertyChangeListener() {
        return new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                if ((getRightComponent()) != null) {
                    getRightComponent().repaint();
                } 
                if ((getLeftComponent()) != null) {
                    getLeftComponent().repaint();
                } 
            }
        };
    }

    protected java.awt.Component createContents(Module03.DrawingView dv, int location) {
        setRightComponent(createRightComponent(dv));
        setLeftComponent(createLeftComponent(dv));
        switch (location) {
            case Module04.Desktop.PRIMARY :
                {
                    return getLeftComponent();
                }
            case Module04.Desktop.SECONDARY :
                {
                    return getRightComponent();
                }
            default :
                {
                    return null;
                }
        }
    }

    protected java.awt.Component createRightComponent(Module03.DrawingView dv) {
        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(((java.awt.Component)(dv)));
        sp.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        sp.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        sp.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return sp;
    }

    protected java.awt.Component createLeftComponent(Module03.DrawingView dv) {
        return new javax.swing.JScrollPane(new javax.swing.JList());
    }

    public Module03.DrawingView getActiveDrawingView() {
        return getDesktopEventService().getActiveDrawingView();
    }

    public void addToDesktop(Module03.DrawingView dv, int location) {
        createContents(dv, Module04.Desktop.PRIMARY);
        setDividerLocation(getInitDividerLocation());
    }

    protected int getInitDividerLocation() {
        return 150;
    }

    public void removeFromDesktop(Module03.DrawingView dv, int location) {
        java.awt.Component[] comps = getContainer().getComponents();
        for (int x = 0 ; x < (comps.length) ; x++) {
            if (dv == (Module06.Helper.getDrawingView(comps[x]))) {
                getContainer().remove(comps[x]);
                break;
            } 
        }
    }

    public void removeAllFromDesktop(int location) {
        getContainer().removeAll();
    }

    public Module03.DrawingView[] getAllFromDesktop(int location) {
        return getDesktopEventService().getDrawingViews(getComponents());
    }

    public void addDesktopListener(Module04.DesktopListener dpl) {
        getDesktopEventService().addDesktopListener(dpl);
    }

    public void removeDesktopListener(Module04.DesktopListener dpl) {
        Module04.DesktopEventService des = getDesktopEventService();
        des.removeDesktopListener(dpl);
    }

    private java.awt.Container getContainer() {
        return Module04.SplitPaneDesktop.this;
    }

    protected Module04.DesktopEventService getDesktopEventService() {
        return myDesktopEventService;
    }

    private void setDesktopEventService(Module04.DesktopEventService newDesktopEventService) {
        myDesktopEventService = newDesktopEventService;
    }

    protected Module04.DesktopEventService createDesktopEventService() {
        Module04.DesktopEventService desktopEventService = new Module04.DesktopEventService(Module04.SplitPaneDesktop.this , getContainer());
        return desktopEventService;
    }

    public void updateTitle(java.lang.String newDrawingTitle) {
        setName(newDrawingTitle);
    }
}


package Module04;


public class DesktopEventService {
    private java.util.List listeners;

    private Module03.DrawingView mySelectedView;

    private java.awt.Container myContainer;

    private Module04.Desktop myDesktop;

    public DesktopEventService(Module04.Desktop newDesktop ,java.awt.Container newContainer) {
        listeners = Module06.CollectionsFactory.current().createList();
        setDesktop(newDesktop);
        setContainer(newContainer);
        getContainer().addContainerListener(createComponentListener());
    }

    private void setDesktop(Module04.Desktop newDesktop) {
        myDesktop = newDesktop;
    }

    protected Module04.Desktop getDesktop() {
        return myDesktop;
    }

    private void setContainer(java.awt.Container newContainer) {
        myContainer = newContainer;
    }

    protected java.awt.Container getContainer() {
        return myContainer;
    }

    public void addComponent(java.awt.Component newComponent) {
        getContainer().add(newComponent);
    }

    public void removeComponent(Module03.DrawingView dv) {
        java.awt.Component[] comps = getContainer().getComponents();
        for (int x = 0 ; x < (comps.length) ; x++) {
            if (dv == (Module06.Helper.getDrawingView(comps[x]))) {
                getContainer().remove(comps[x]);
                break;
            } 
        }
    }

    public void removeAllComponents() {
        getContainer().removeAll();
    }

    public void addDesktopListener(Module04.DesktopListener dpl) {
        listeners.add(dpl);
    }

    public void removeDesktopListener(Module04.DesktopListener dpl) {
        listeners.remove(dpl);
    }

    public void fireDrawingViewAddedEvent(final Module03.DrawingView dv) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        Module04.DesktopEvent dpe = createDesktopEvent(getActiveDrawingView(), dv);
        while (li.hasPrevious()) {
            Module04.DesktopListener dpl = ((Module04.DesktopListener)(li.previous()));
            dpl.drawingViewAdded(dpe);
        }
    }

    public void fireDrawingViewRemovedEvent(final Module03.DrawingView dv) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        Module04.DesktopEvent dpe = createDesktopEvent(getActiveDrawingView(), dv);
        while (li.hasPrevious()) {
            Module04.DesktopListener dpl = ((Module04.DesktopListener)(li.previous()));
            dpl.drawingViewRemoved(dpe);
        }
    }

    public void fireDrawingViewSelectedEvent(final Module03.DrawingView oldView, final Module03.DrawingView newView) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        Module04.DesktopEvent dpe = createDesktopEvent(oldView, newView);
        while (li.hasPrevious()) {
            Module04.DesktopListener dpl = ((Module04.DesktopListener)(li.previous()));
            dpl.drawingViewSelected(dpe);
        }
    }

    protected Module04.DesktopEvent createDesktopEvent(Module03.DrawingView oldView, Module03.DrawingView newView) {
        Module04.DesktopEvent desktopEvent = new Module04.DesktopEvent(getDesktop() , newView , oldView);
        return desktopEvent;
    }

    public Module03.DrawingView[] getDrawingViews(java.awt.Component[] comps) {
        java.util.List al = Module06.CollectionsFactory.current().createList();
        for (int x = 0 ; x < (comps.length) ; x++) {
            Module03.DrawingView dv = Module06.Helper.getDrawingView(comps[x]);
            if (dv != null) {
                al.add(dv);
            } 
        }
        Module03.DrawingView[] dvs = new Module03.DrawingView[al.size()];
        al.toArray(dvs);
        return dvs;
    }

    public Module03.DrawingView getActiveDrawingView() {
        return mySelectedView;
    }

    protected void setActiveDrawingView(Module03.DrawingView newActiveDrawingView) {
        mySelectedView = newActiveDrawingView;
    }

    protected java.awt.event.ContainerListener createComponentListener() {
        return new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent e) {
                Module03.DrawingView dv = Module06.Helper.getDrawingView(((java.awt.Container)(e.getChild())));
                Module03.DrawingView oldView = getActiveDrawingView();
                if (dv != null) {
                    fireDrawingViewAddedEvent(dv);
                    setActiveDrawingView(dv);
                    fireDrawingViewSelectedEvent(oldView, getActiveDrawingView());
                } 
            }

            public void componentRemoved(java.awt.event.ContainerEvent e) {
                Module03.DrawingView dv = Module06.Helper.getDrawingView(((java.awt.Container)(e.getChild())));
                if (dv != null) {
                    Module03.DrawingView oldView = getActiveDrawingView();
                    setActiveDrawingView(Module03.NullDrawingView.getManagedDrawingView(oldView.editor()));
                    fireDrawingViewSelectedEvent(oldView, getActiveDrawingView());
                    fireDrawingViewRemovedEvent(dv);
                } 
            }
        };
    }
}


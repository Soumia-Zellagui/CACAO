package Module03;


public class HTMLTextAreaFigure extends Module03.TextAreaFigure implements Module03.FigureChangeListener , Module03.HTMLContentProducerContext {
    public static final char START_ENTITY_CHAR = '&';

    public static final char END_ENTITY_CHAR = ';';

    public static final char ESCAPE_CHAR = '\\';

    private transient Module06.DisposableResourceHolder fImageHolder;

    private transient javax.swing.JLabel fDisplayDelegate;

    private boolean fUseDirectDraw = false;

    private boolean fIsImageDirty = true;

    private boolean fRawHTML = false;

    private transient Module03.ContentProducer fIntrinsicContentProducer;

    private static Module03.ContentProducerRegistry fDefaultContentProducers = new Module03.ContentProducerRegistry();

    static {
        Module03.TextHolderContentProducer textHolderContentProducer = new Module03.TextHolderContentProducer();
        Module03.HTMLTextAreaFigure.fDefaultContentProducers.registerContentProducer(Module03.TextAreaFigure.class, textHolderContentProducer);
        Module03.HTMLColorContentProducer htmlColorContentProducer = new Module03.HTMLColorContentProducer();
        Module03.HTMLTextAreaFigure.fDefaultContentProducers.registerContentProducer(java.awt.Color.class, htmlColorContentProducer);
    }

    private transient Module03.ContentProducerRegistry fContentProducers = null;

    private Module03.Figure fFrameFigure = null;

    static {
        Module03.AttributeFigure.initDefaultAttribute("XAlignment", new java.lang.Integer(javax.swing.SwingConstants.LEFT));
        Module03.AttributeFigure.initDefaultAttribute("YAlignment", new java.lang.Integer(javax.swing.SwingConstants.TOP));
        Module03.AttributeFigure.initDefaultAttribute("LeftMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("RightMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("TopMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("BottomMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("TabSize", new java.lang.Float(8));
    }

    public HTMLTextAreaFigure() {
        initialize();
    }

    public java.lang.Object clone() {
        java.lang.Object cloneObject = super.clone();
        ((Module03.HTMLTextAreaFigure)(cloneObject)).initialize();
        return cloneObject;
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        super.basicDisplayBox(origin, corner);
        getFrameFigure().displayBox(displayBox());
    }

    public Module06.HandleEnumeration handles() {
        return getFrameFigure().handles();
    }

    public boolean containsPoint(int x, int y) {
        return getFrameFigure().containsPoint(x, y);
    }

    public void moveBy(int dx, int dy) {
        super.moveBy(dx, dy);
        getFrameFigure().moveBy(dx, dy);
    }

    protected void initialize() {
        Module03.RectangleFigure rectangleFigure = new Module03.RectangleFigure();
        setFrameFigure(rectangleFigure);
        Module03.HTMLContentProducer htmlContentProducer = new Module03.HTMLContentProducer();
        setIntrinsicContentProducer(htmlContentProducer);
        fContentProducers = new Module03.ContentProducerRegistry(Module03.HTMLTextAreaFigure.fDefaultContentProducers);
        markSizeDirty();
        markImageDirty();
        markTextDirty();
        markFontDirty();
        setAttribute(Module06.FigureAttributeConstant.POPUP_MENU, createPopupMenu());
    }

    protected void markSizeDirty() {
        markImageDirty();
        super.markSizeDirty();
    }

    protected void markTextDirty() {
        markImageDirty();
        super.markTextDirty();
    }

    protected void markFontDirty() {
        markImageDirty();
        super.markFontDirty();
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Color fill = getFillColor();
        g.setColor(fill);
        drawBackground(g);
        drawText(g, displayBox());
        java.awt.Color frame = getFrameColor();
        g.setColor(frame);
        drawFrame(g);
    }

    public void drawFrame(java.awt.Graphics g) {
        ((java.awt.Graphics2D)(g)).draw(getClippingShape());
    }

    public void drawBackground(java.awt.Graphics g) {
        ((java.awt.Graphics2D)(g)).fill(getClippingShape());
    }

    protected float drawText(java.awt.Graphics g, java.awt.Rectangle displayBox) {
        java.awt.Graphics2D g2 = null;
        java.awt.Shape savedClip = null;
        if (g != null) {
            g2 = ((java.awt.Graphics2D)(g));
            savedClip = g2.getClip();
        } 
        java.awt.Rectangle drawingBox = makeDrawingBox(displayBox);
        if (drawingBox.isEmpty()) {
            return drawingBox.height;
        } 
        if (g != null) {
            g2.clip(getClippingShape());
        } 
        if (usesDirectDraw()) {
            drawTextDirect(g2, drawingBox);
        } else {
            fImageHolder.lock();
            if (isImageDirty()) {
                generateImage(drawingBox);
                setSizeDirty(false);
            } 
            if (g2 != null) {
                g2.drawImage(getImage(), drawingBox.x, drawingBox.y, null);
            } 
            fImageHolder.unlock();
        }
        if (g != null) {
            g2.setClip(savedClip);
        } 
        drawFrame(g);
        return displayBox.height;
    }

    protected void generateImage(java.awt.Rectangle drawingBox) {
        createImage(drawingBox.width, drawingBox.height);
        java.awt.Graphics2D g2 = ((java.awt.Graphics2D)(getImage().getGraphics()));
        java.awt.Rectangle finalBox = new java.awt.Rectangle(drawingBox);
        finalBox.setLocation(0, 0);
        renderText(g2, finalBox);
        g2.dispose();
    }

    protected void drawTextDirect(java.awt.Graphics2D g2, java.awt.Rectangle drawingBox) {
        java.awt.Shape savedClipArea = null;
        java.awt.Color savedFontColor = null;
        java.awt.RenderingHints savedRenderingHints = null;
        if (g2 != null) {
            savedRenderingHints = g2.getRenderingHints();
            savedClipArea = g2.getClip();
            savedFontColor = g2.getColor();
            g2.clip(drawingBox);
        } 
        if (g2 != null) {
            g2.setClip(savedClipArea);
            g2.setColor(savedFontColor);
            g2.setRenderingHints(savedRenderingHints);
        } 
    }

    protected float renderText(java.awt.Graphics2D g2, java.awt.Rectangle drawingBox) {
        g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(java.awt.RenderingHints.KEY_RENDERING, java.awt.RenderingHints.VALUE_RENDER_QUALITY);
        g2.setBackground(getFillColor());
        g2.setColor(getFillColor());
        g2.clearRect(drawingBox.x, drawingBox.y, drawingBox.width, drawingBox.height);
        g2.fillRect(drawingBox.x, drawingBox.y, drawingBox.width, drawingBox.height);
        java.lang.String text;
        if (isRawHTML()) {
            text = getText();
        } else {
            text = getHTMLText(getText(), getFont(), ((java.lang.String)(getContentProducer(java.awt.Color.class).getContent(Module03.HTMLTextAreaFigure.this, Module06.FigureAttributeConstant.TEXT_COLOR_STR, getTextColor()))), ((java.lang.String)(getContentProducer(java.awt.Color.class).getContent(Module03.HTMLTextAreaFigure.this, Module06.FigureAttributeConstant.FILL_COLOR_STR, getFillColor()))), drawingBox);
        }
        text = substituteEntityKeywords(text);
        javax.swing.JLabel displayDelegate = getDisplayDelegate();
        displayDelegate.setText(text);
        displayDelegate.setBackground(getFillColor());
        displayDelegate.setLocation(0, 0);
        displayDelegate.setSize(drawingBox.width, drawingBox.height);
        displayDelegate.setHorizontalAlignment(((java.lang.Integer)(getAttribute(Module06.FigureAttributeConstant.XALIGNMENT))).intValue());
        displayDelegate.setVerticalAlignment(((java.lang.Integer)(getAttribute(Module06.FigureAttributeConstant.YALIGNMENT))).intValue());
        javax.swing.SwingUtilities.paintComponent(g2, displayDelegate, getContainerPanel(displayDelegate, drawingBox), drawingBox.x, drawingBox.y, drawingBox.width, drawingBox.height);
        return drawingBox.height;
    }

    protected java.awt.Rectangle makeDrawingBox(java.awt.Rectangle displayBox) {
        float leftMargin = ((java.lang.Float)(getAttribute(Module06.FigureAttributeConstant.LEFT_MARGIN))).floatValue();
        float rightMargin = ((java.lang.Float)(getAttribute(Module06.FigureAttributeConstant.RIGHT_MARGIN))).floatValue();
        float topMargin = ((java.lang.Float)(getAttribute(Module06.FigureAttributeConstant.TOP_MARGIN))).floatValue();
        float bottomMargin = ((java.lang.Float)(getAttribute(Module06.FigureAttributeConstant.BOTTOM_MARGIN))).floatValue();
        java.awt.Rectangle drawingBox = new java.awt.Rectangle(displayBox);
        drawingBox.grow((-1), (-1));
        drawingBox.x += leftMargin;
        drawingBox.width -= leftMargin + rightMargin;
        drawingBox.y += topMargin;
        drawingBox.height -= topMargin + bottomMargin;
        return drawingBox;
    }

    protected javax.swing.JLabel getDisplayDelegate() {
        if ((fDisplayDelegate) == null) {
            fDisplayDelegate = new javax.swing.JLabel();
            fDisplayDelegate.setBorder(null);
        } 
        return fDisplayDelegate;
    }

    protected void createImage(int width, int height) {
        fImageHolder.lock();
        if (((!(fImageHolder.isAvailable())) || ((((java.awt.image.BufferedImage)(fImageHolder.getResource())).getWidth()) != width)) || ((((java.awt.image.BufferedImage)(fImageHolder.getResource())).getHeight()) != height)) {
            fImageHolder.setResource(new java.awt.image.BufferedImage(width , height , java.awt.image.BufferedImage.TYPE_INT_RGB));
        } 
    }

    protected javax.swing.JPanel getContainerPanel(java.awt.Component drawingDelegate, java.awt.Rectangle displayBox) {
        javax.swing.JPanel panel = new javax.swing.JPanel();
        return panel;
    }

    protected java.lang.String getHTMLText(java.lang.String text, java.awt.Font font, java.lang.String textColor, java.lang.String backColor, java.awt.Rectangle displayBox) {
        java.lang.StringBuffer htmlText = new java.lang.StringBuffer();
        htmlText.append("<html>");
        htmlText.append(((((("<table border='0' width='" + (displayBox.width)) + "' height='") + (displayBox.height)) + "' cellpadding='0' cellspacing='0'") + "bgcolor='&FillColor;'>"));
        htmlText.append("<tr><td width='100%'>");
        htmlText.append("<font face='&FontName;' color='&TextColor;' size='&FontSize;'>");
        if ((((java.lang.Integer)(getAttribute(Module06.FigureAttributeConstant.XALIGNMENT))).intValue()) == (javax.swing.SwingConstants.CENTER)) {
            htmlText.append("<center>");
        } 
        if (font.isItalic()) {
            htmlText.append("<i>");
        } 
        if (font.isBold()) {
            htmlText.append("<b>");
        } 
        htmlText.append(text);
        if (font.isBold()) {
            htmlText.append("</b>");
        } 
        if (font.isItalic()) {
            htmlText.append("</i>");
        } 
        if ((((java.lang.Integer)(getAttribute(Module06.FigureAttributeConstant.XALIGNMENT))).intValue()) == (javax.swing.SwingConstants.CENTER)) {
            htmlText.append("</center>");
        } 
        htmlText.append("</font>");
        htmlText.append("</td></tr></table>");
        htmlText.append("</html>");
        return htmlText.toString();
    }

    protected java.lang.String substituteEntityKeywords(java.lang.String template) {
        int endPos;
        java.lang.StringBuffer finalText = new java.lang.StringBuffer();
        int startPos = 0;
        int chunkEnd = startPos;
        try {
            while ((startPos = template.indexOf(Module03.HTMLTextAreaFigure.START_ENTITY_CHAR, startPos)) != (-1)) {
                if ((startPos != 0) && ((template.charAt((startPos - 1))) == (Module03.HTMLTextAreaFigure.ESCAPE_CHAR))) {
                    startPos++;
                    continue;
                } 
                endPos = startPos + 1;
                while ((endPos = template.indexOf(Module03.HTMLTextAreaFigure.END_ENTITY_CHAR, endPos)) != (-1)) {
                    if ((endPos == 0) || ((template.charAt((endPos - 1))) != (Module03.HTMLTextAreaFigure.ESCAPE_CHAR))) {
                        break;
                    } 
                    throw new Module03.HTMLTextAreaFigure.InvalidAttributeMarker();
                }
                java.lang.String attrName = template.substring((startPos + 1), endPos);
                java.lang.String attrValue = getEntityHTMLRepresentation(attrName);
                if (attrValue != null) {
                    finalText.append(template.substring(chunkEnd, startPos));
                    finalText.append(substituteEntityKeywords(attrValue));
                    startPos = endPos + 1;
                    chunkEnd = startPos;
                } else {
                    startPos++;
                }
            }
        } catch (Module03.HTMLTextAreaFigure.InvalidAttributeMarker ex) {
        }
        finalText.append(template.substring(chunkEnd));
        return finalText.toString();
    }

    protected java.lang.String getEntityHTMLRepresentation(java.lang.String attrName) {
        java.lang.Object attrValue = getIntrinsicContentProducer().getContent(Module03.HTMLTextAreaFigure.this, attrName, null);
        if (attrValue == null) {
            return null;
        } 
        while ((attrValue != null) && (!(attrValue instanceof java.lang.String))) {
            if (attrValue instanceof Module03.ContentProducer) {
                attrValue = ((Module03.ContentProducer)(attrValue)).getContent(Module03.HTMLTextAreaFigure.this, attrName, attrValue);
                continue;
            } 
            Module03.ContentProducer defaultProducer = getContentProducer(attrValue.getClass());
            if (defaultProducer != null) {
                attrValue = defaultProducer.getContent(Module03.HTMLTextAreaFigure.this, attrName, attrValue);
                continue;
            } 
            attrValue = attrValue.toString();
        }
        return ((java.lang.String)(attrValue));
    }

    protected java.awt.image.BufferedImage getImage() {
        if (fImageHolder.isAvailable()) {
            return ((java.awt.image.BufferedImage)(fImageHolder.getResource()));
        } 
        return null;
    }

    protected void setImage(java.awt.image.BufferedImage newImage) {
        fImageHolder.setResource(newImage);
    }

    protected javax.swing.JPopupMenu createPopupMenu() {
        javax.swing.JPopupMenu popupMenu = new javax.swing.JPopupMenu();
        addPopupMenuItems(popupMenu);
        popupMenu.setLightWeightPopupEnabled(true);
        return popupMenu;
    }

    protected void addPopupMenuItems(javax.swing.JPopupMenu popupMenu) {
        javax.swing.ButtonGroup drawingPopupGroup;
        javax.swing.JRadioButtonMenuItem rbOption;
        drawingPopupGroup = new javax.swing.ButtonGroup();
        rbOption = new javax.swing.JRadioButtonMenuItem(new javax.swing.AbstractAction("Direct drawing") {
            public void actionPerformed(java.awt.event.ActionEvent event) {
                setUseDirectDraw(true);
            }
        });
        drawingPopupGroup.add(rbOption);
        if (usesDirectDraw()) {
            drawingPopupGroup.setSelected(rbOption.getModel(), true);
        } 
        popupMenu.add(rbOption);
        rbOption = new javax.swing.JRadioButtonMenuItem(new javax.swing.AbstractAction("Buffered drawing") {
            public void actionPerformed(java.awt.event.ActionEvent event) {
                setUseDirectDraw(false);
            }
        });
        drawingPopupGroup.add(rbOption);
        if (usesBufferedDraw()) {
            drawingPopupGroup.setSelected(rbOption.getModel(), true);
        } 
        popupMenu.add(rbOption);
        popupMenu.addSeparator();
        drawingPopupGroup = new javax.swing.ButtonGroup();
        rbOption = new javax.swing.JRadioButtonMenuItem(new javax.swing.AbstractAction("Normal HTML") {
            public void actionPerformed(java.awt.event.ActionEvent event) {
                setRawHTML(false);
            }
        });
        drawingPopupGroup.add(rbOption);
        drawingPopupGroup.setSelected(rbOption.getModel(), true);
        popupMenu.add(rbOption);
        rbOption = new javax.swing.JRadioButtonMenuItem(new javax.swing.AbstractAction("Raw HTML") {
            public void actionPerformed(java.awt.event.ActionEvent event) {
                setRawHTML(true);
            }
        });
        drawingPopupGroup.add(rbOption);
        popupMenu.add(rbOption);
    }

    public boolean usesDirectDraw() {
        return fUseDirectDraw;
    }

    public void setUseDirectDraw(boolean newUseDirectDraw) {
        fUseDirectDraw = newUseDirectDraw;
        setAttribute(Module06.FigureAttributeConstant.POPUP_MENU, createPopupMenu());
        markSizeDirty();
    }

    public void setUseBufferedDraw(boolean newUseBufferedDraw) {
        setUseDirectDraw((!newUseBufferedDraw));
    }

    public boolean usesBufferedDraw() {
        return !(usesDirectDraw());
    }

    protected void markImageDirty() {
        fImageHolder.dispose();
    }

    protected boolean isImageDirty() {
        return !(fImageHolder.isAvailable());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        setFrameFigure(((Module03.Figure)(dr.readStorable())));
        setUseDirectDraw(dr.readBoolean());
        setRawHTML(dr.readBoolean());
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getFrameFigure());
        dw.writeBoolean(usesDirectDraw());
        dw.writeBoolean(isRawHTML());
    }

    public void setAttribute(Module06.FigureAttributeConstant name, java.lang.Object value) {
        super.setAttribute(name, value);
        markImageDirty();
    }

    public boolean isRawHTML() {
        return fRawHTML;
    }

    public void setRawHTML(boolean newRawHTML) {
        fRawHTML = newRawHTML;
        setAttribute(Module06.FigureAttributeConstant.POPUP_MENU, createPopupMenu());
    }

    protected Module03.ContentProducer getIntrinsicContentProducer() {
        return fIntrinsicContentProducer;
    }

    public void setIntrinsicContentProducer(Module03.ContentProducer newIntrinsicContentProducer) {
        fIntrinsicContentProducer = newIntrinsicContentProducer;
    }

    public Module03.ContentProducer registerContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        return fContentProducers.registerContentProducer(targetClass, producer);
    }

    public void unregisterContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        fContentProducers.unregisterContentProducer(targetClass, producer);
    }

    protected Module03.ContentProducer getContentProducer(java.lang.Class targetClass) {
        return fContentProducers.getContentProducer(targetClass);
    }

    public java.awt.Polygon getPolygon() {
        java.awt.Polygon polygon = new java.awt.Polygon();
        java.awt.geom.AffineTransform at = java.awt.geom.AffineTransform.getScaleInstance(1, 1);
        java.awt.geom.FlatteningPathIterator pIter = new java.awt.geom.FlatteningPathIterator(getClippingShape().getPathIterator(at) , 1);
        double[] coords = new double[6];
        while (!(pIter.isDone())) {
            pIter.currentSegment(coords);
            polygon.addPoint(((int)(coords[0])), ((int)(coords[1])));
            pIter.next();
        }
        return polygon;
    }

    protected Module03.Figure getFrameFigure() {
        return fFrameFigure;
    }

    public void setFrameFigure(Module03.Figure newFrameFigure) {
        if ((fFrameFigure) != null) {
            fFrameFigure.removeFigureChangeListener(Module03.HTMLTextAreaFigure.this);
        } 
        fFrameFigure = newFrameFigure;
        fFrameFigure.addFigureChangeListener(Module03.HTMLTextAreaFigure.this);
    }

    protected java.awt.Shape getClippingShape() {
        Module03.Figure frame = getFrameFigure();
        if (frame instanceof Module03.GeometricFigure) {
            return ((Module03.GeometricFigure)(frame)).getShape();
        } 
        return frame.displayBox();
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        willChange();
        super.basicDisplayBox(e.getFigure().displayBox().getLocation(), Module06.Geom.corner(e.getFigure().displayBox()));
        changed();
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
    }

    private class InvalidAttributeMarker extends java.lang.Exception {    }

    public Module03.Figure getRepresentingFigure() {
        return Module03.HTMLTextAreaFigure.this;
    }
}


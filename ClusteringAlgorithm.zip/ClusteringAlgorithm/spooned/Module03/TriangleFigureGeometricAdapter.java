package Module03;


public class TriangleFigureGeometricAdapter extends Module03.TriangleFigure implements Module03.GeometricFigure {
    public TriangleFigureGeometricAdapter() {
        super();
    }

    public TriangleFigureGeometricAdapter(java.awt.Point origin ,java.awt.Point corner) {
        super(origin, corner);
    }

    public java.awt.Shape getShape() {
        return getPolygon();
    }
}


package Module03;


public class ColorContentProducer extends Module03.FigureDataContentProducer implements java.io.Serializable {
    private java.awt.Color fColor = null;

    public ColorContentProducer() {
    }

    public ColorContentProducer(java.awt.Color color) {
        setColor(color);
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        java.awt.Color color = (getColor()) != null ? getColor() : ((java.awt.Color)(ctxAttrValue));
        java.lang.String colorCode = java.lang.Integer.toHexString(color.getRGB());
        return "0x" + (colorCode.substring(((colorCode.length()) - 6)));
    }

    public void setColor(java.awt.Color color) {
        fColor = color;
    }

    public java.awt.Color getColor() {
        return fColor;
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeBoolean(((getColor()) != null));
        if ((getColor()) != null) {
            dw.writeInt(getColor().getRGB());
        } 
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        boolean hasColor = dr.readBoolean();
        if (hasColor) {
            setColor(new java.awt.Color(dr.readInt()));
        } else {
            setColor(null);
        }
    }
}


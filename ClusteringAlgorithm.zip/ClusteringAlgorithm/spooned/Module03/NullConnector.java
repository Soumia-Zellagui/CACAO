package Module03;


public class NullConnector extends Module03.AbstractConnector {
    private NullConnector() {
    }

    public NullConnector(Module03.Figure owner) {
        super(owner);
    }
}


package Module03;


public class UndoableTool implements Module03.Tool , Module03.ToolListener {
    private Module03.Tool myWrappedTool;

    private Module03.AbstractTool.EventDispatcher myEventDispatcher;

    public UndoableTool(Module03.Tool newWrappedTool) {
        Module03.AbstractTool.EventDispatcher evt = createEventDispatcher();
        setEventDispatcher(evt);
        setWrappedTool(newWrappedTool);
        Module03.Tool t = getWrappedTool();
        t.addToolListener(Module03.UndoableTool.this);
    }

    public void activate() {
        Module03.Tool t = getWrappedTool();
        t.activate();
    }

    public void deactivate() {
        Module03.Tool t = getWrappedTool();
        t.deactivate();
        Module06.Undoable undoActivity = t.getUndoActivity();
        if ((undoActivity != null) && (undoActivity.isUndoable())) {
            Module01.DrawingEditor edi = editor();
            Module01.UndoManager um = edi.getUndoManager();
            um.pushUndo(undoActivity);
            um.clearRedos();
            Module03.DrawingView v = getActiveView();
            edi.figureSelectionChanged(v);
        } 
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Tool t = getWrappedTool();
        t.mouseDown(e, x, y);
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Tool t = getWrappedTool();
        t.mouseDrag(e, x, y);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Tool t = getWrappedTool();
        t.mouseUp(e, x, y);
    }

    public void mouseMove(java.awt.event.MouseEvent evt, int x, int y) {
        Module03.Tool t = getWrappedTool();
        t.mouseMove(evt, x, y);
    }

    public void keyDown(java.awt.event.KeyEvent evt, int key) {
        Module03.Tool t = getWrappedTool();
        t.keyDown(evt, key);
    }

    public boolean isUsable() {
        Module03.Tool t = getWrappedTool();
        return t.isUsable();
    }

    public boolean isActive() {
        Module01.DrawingEditor edi = editor();
        Module03.Tool t = edi.tool();
        return t == (Module03.UndoableTool.this);
    }

    public boolean isEnabled() {
        Module03.Tool t = getWrappedTool();
        return t.isEnabled();
    }

    public void setUsable(boolean newIsUsable) {
        Module03.Tool t = getWrappedTool();
        t.setUsable(newIsUsable);
    }

    public void setEnabled(boolean newIsEnabled) {
        Module03.Tool t = getWrappedTool();
        t.setEnabled(newIsEnabled);
    }

    protected void setWrappedTool(Module03.Tool newWrappedTool) {
        myWrappedTool = newWrappedTool;
    }

    protected Module03.Tool getWrappedTool() {
        return myWrappedTool;
    }

    public Module01.DrawingEditor editor() {
        Module03.Tool t = getWrappedTool();
        Module01.DrawingEditor edi = t.editor();
        return edi;
    }

    public Module03.DrawingView view() {
        Module01.DrawingEditor editor = editor();
        Module03.DrawingView dv = editor.view();
        return dv;
    }

    public Module06.Undoable getUndoActivity() {
        Module03.DrawingView v = view();
        Module06.Undoable undoableAdapter = new Module06.UndoableAdapter(v);
        return undoableAdapter;
    }

    public void setUndoActivity(Module06.Undoable newUndoableActivity) {
    }

    public void toolUsable(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolUsableEvent();
    }

    public void toolUnusable(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolUnusableEvent();
    }

    public void toolActivated(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolActivatedEvent();
    }

    public void toolDeactivated(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolDeactivatedEvent();
    }

    public void toolEnabled(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolEnabledEvent();
    }

    public void toolDisabled(java.util.EventObject toolEvent) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.fireToolDisabledEvent();
    }

    public void addToolListener(Module03.ToolListener newToolListener) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.addToolListener(newToolListener);
    }

    public void removeToolListener(Module03.ToolListener oldToolListener) {
        Module03.AbstractTool.EventDispatcher ed = getEventDispatcher();
        ed.removeToolListener(oldToolListener);
    }

    private void setEventDispatcher(Module03.AbstractTool.EventDispatcher newEventDispatcher) {
        myEventDispatcher = newEventDispatcher;
    }

    protected Module03.AbstractTool.EventDispatcher getEventDispatcher() {
        return myEventDispatcher;
    }

    public Module03.AbstractTool.EventDispatcher createEventDispatcher() {
        Module03.AbstractTool.EventDispatcher ae = new Module03.AbstractTool.EventDispatcher(Module03.UndoableTool.this);
        return ae;
    }

    public Module03.DrawingView getActiveView() {
        Module01.DrawingEditor editor = editor();
        Module03.DrawingView dv = editor.view();
        return dv;
    }
}


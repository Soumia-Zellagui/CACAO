package Module03;


public class TextHolderContentProducer extends Module03.AbstractContentProducer implements java.io.Serializable {
    private Module03.TextHolder myTextHolder;

    public TextHolderContentProducer() {
    }

    public TextHolderContentProducer(Module03.TextHolder figure) {
        setTextHolder(figure);
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        Module03.TextHolder figure = (getTextHolder()) != null ? getTextHolder() : ((Module03.TextHolder)(ctxAttrValue));
        return figure.getText();
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getTextHolder().getRepresentingFigure());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        setTextHolder(((Module03.TextHolder)(dr.readStorable())));
    }

    protected Module03.TextHolder getTextHolder() {
        return myTextHolder;
    }

    public void setTextHolder(Module03.TextHolder newFigure) {
        myTextHolder = newFigure;
    }
}


package Module03;


public class FigureDataContentProducer extends Module03.AbstractContentProducer implements java.io.Serializable {
    public FigureDataContentProducer() {
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        if ((ctxAttrName.compareTo(Module03.ContentProducer.ENTITY_FIGURE_WIDTH)) == 0) {
            return java.lang.Integer.toString(((Module03.FigureContentProducerContext)(context)).displayBox().width);
        } 
        if ((ctxAttrName.compareTo(Module03.ContentProducer.ENTITY_FIGURE_HEIGHT)) == 0) {
            return java.lang.Integer.toString(((Module03.FigureContentProducerContext)(context)).displayBox().height);
        } 
        if ((ctxAttrName.compareTo(Module03.ContentProducer.ENTITY_FIGURE_POSX)) == 0) {
            return java.lang.Integer.toString(((Module03.FigureContentProducerContext)(context)).displayBox().x);
        } 
        if ((ctxAttrName.compareTo(Module03.ContentProducer.ENTITY_FIGURE_POSY)) == 0) {
            return java.lang.Integer.toString(((Module03.FigureContentProducerContext)(context)).displayBox().y);
        } 
        return null;
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
    }
}


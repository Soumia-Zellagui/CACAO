package Module03;


public class StandardDrawing extends Module03.CompositeFigure implements Module03.Drawing {
    private transient java.util.List fListeners;

    private transient java.lang.Thread fDrawingLockHolder = null;

    private java.lang.String myTitle;

    private static final long serialVersionUID = -2602151437447962046L;

    private int drawingSerializedDataVersion = 1;

    public StandardDrawing() {
        super();
        fListeners = Module06.CollectionsFactory.current().createList(2);
        init(new java.awt.Rectangle((-500) , (-500) , 2000 , 2000));
    }

    public void addDrawingChangeListener(Module03.DrawingChangeListener listener) {
        if ((fListeners) == null) {
            fListeners = Module06.CollectionsFactory.current().createList(2);
        } 
        fListeners.add(listener);
    }

    public void removeDrawingChangeListener(Module03.DrawingChangeListener listener) {
        fListeners.remove(listener);
    }

    public java.util.Iterator drawingChangeListeners() {
        return fListeners.iterator();
    }

    public synchronized Module03.Figure orphan(Module03.Figure figure) {
        Module03.Figure orphanedFigure = super.orphan(figure);
        if ((orphanedFigure.listener()) != null) {
            java.awt.Rectangle rect = invalidateRectangle(displayBox());
            Module03.FigureChangeEvent fce = new Module03.FigureChangeEvent(orphanedFigure , rect);
            orphanedFigure.listener().figureRequestRemove(fce);
        } 
        return orphanedFigure;
    }

    public synchronized Module03.Figure add(Module03.Figure figure) {
        Module03.Figure addedFigure = super.add(figure);
        if ((addedFigure.listener()) != null) {
            java.awt.Rectangle rect = invalidateRectangle(displayBox());
            Module03.FigureChangeEvent fce = new Module03.FigureChangeEvent(figure , rect);
            addedFigure.listener().figureRequestUpdate(fce);
            return addedFigure;
        } 
        return addedFigure;
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
        if ((fListeners) != null) {
            for (int i = 0 ; i < (fListeners.size()) ; i++) {
                Module03.DrawingChangeListener l = ((Module03.DrawingChangeListener)(fListeners.get(i)));
                Module06.DrawingChangeEvent dce = new Module06.DrawingChangeEvent(Module03.StandardDrawing.this , e.getInvalidatedRectangle());
                l.drawingInvalidated(dce);
            }
        } 
    }

    public void fireDrawingTitleChanged() {
        if ((fListeners) != null) {
            for (int i = 0 ; i < (fListeners.size()) ; i++) {
                Module03.DrawingChangeListener l = ((Module03.DrawingChangeListener)(fListeners.get(i)));
                Module06.DrawingChangeEvent dce = new Module06.DrawingChangeEvent(Module03.StandardDrawing.this , null);
                l.drawingTitleChanged(dce);
            }
        } 
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
        if ((fListeners) != null) {
            for (int i = 0 ; i < (fListeners.size()) ; i++) {
                Module03.DrawingChangeListener l = ((Module03.DrawingChangeListener)(fListeners.get(i)));
                Module06.DrawingChangeEvent dce = new Module06.DrawingChangeEvent(Module03.StandardDrawing.this , null);
                l.drawingRequestUpdate(dce);
            }
        } 
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module05.NullHandle nhnw = new Module05.NullHandle(Module03.StandardDrawing.this , Module03.RelativeLocator.northWest());
        handles.add(nhnw);
        Module05.NullHandle nhne = new Module05.NullHandle(Module03.StandardDrawing.this , Module03.RelativeLocator.northEast());
        handles.add(nhne);
        Module05.NullHandle nhsw = new Module05.NullHandle(Module03.StandardDrawing.this , Module03.RelativeLocator.southWest());
        handles.add(nhsw);
        Module05.NullHandle nhse = new Module05.NullHandle(Module03.StandardDrawing.this , Module03.RelativeLocator.southEast());
        handles.add(nhse);
        Module06.HandleEnumerator he = new Module06.HandleEnumerator(handles);
        return he;
    }

    public java.awt.Rectangle displayBox() {
        if ((fFigures.size()) > 0) {
            Module03.FigureEnumeration fe = figures();
            java.awt.Rectangle r = fe.nextFigure().displayBox();
            while (fe.hasNextFigure()) {
                r.add(fe.nextFigure().displayBox());
            }
            return r;
        } 
        return new java.awt.Rectangle(0 , 0 , 0 , 0);
    }

    public void basicDisplayBox(java.awt.Point p1, java.awt.Point p2) {
    }

    public synchronized void lock() {
        java.lang.Thread current = java.lang.Thread.currentThread();
        if ((fDrawingLockHolder) == current) {
            return ;
        } 
        while ((fDrawingLockHolder) != null) {
            try {
                wait();
            } catch (java.lang.InterruptedException ex) {
            }
        }
        fDrawingLockHolder = current;
    }

    public synchronized void unlock() {
        if ((fDrawingLockHolder) != null) {
            fDrawingLockHolder = null;
            notify();
        } 
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        fListeners = Module06.CollectionsFactory.current().createList(2);
    }

    public java.lang.String getTitle() {
        return myTitle;
    }

    public void setTitle(java.lang.String newTitle) {
        myTitle = newTitle;
    }
}


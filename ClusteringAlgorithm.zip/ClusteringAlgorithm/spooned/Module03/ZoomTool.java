package Module03;


public class ZoomTool extends Module03.AbstractTool {
    private Module03.Tool child;

    public ZoomTool(Module01.DrawingEditor editor) {
        super(editor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        if (((e.getModifiers()) & (java.awt.event.InputEvent.BUTTON1_MASK)) != 0) {
            if ((child) != null) {
                return ;
            } 
            view().freezeView();
            child = new Module03.ZoomAreaTracker(editor());
            child.mouseDown(e, x, y);
        } else if (((e.getModifiers()) & (java.awt.event.InputEvent.BUTTON2_MASK)) != 0) {
            ((Module03.ZoomDrawingView)(view())).deZoom(x, y);
        } else if (((e.getModifiers()) & (java.awt.event.InputEvent.BUTTON3_MASK)) != 0) {
            if (((e.getModifiers()) & (java.awt.event.InputEvent.SHIFT_MASK)) != 0) {
                ((Module03.ZoomDrawingView)(view())).zoomIn(x, y);
            } else if (((e.getModifiers()) & (java.awt.event.InputEvent.CTRL_MASK)) != 0) {
                ((Module03.ZoomDrawingView)(view())).deZoom(x, y);
            } else {
                ((Module03.ZoomDrawingView)(view())).zoomOut(x, y);
            }
        } 
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((child) != null) {
            child.mouseDrag(e, x, y);
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((child) != null) {
            view().unfreezeView();
            child.mouseUp(e, x, y);
        } 
        child = null;
    }
}


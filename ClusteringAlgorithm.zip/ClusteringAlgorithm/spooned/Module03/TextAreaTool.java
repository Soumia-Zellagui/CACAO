package Module03;


public class TextAreaTool extends Module03.CreationTool {
    protected Module06.FloatingTextArea fTextField;

    protected Module03.TextHolder fTypingTarget;

    protected Module03.Figure fEditedFigure;

    public TextAreaTool(Module01.DrawingEditor newDrawingEditor ,Module03.Figure prototype) {
        super(newDrawingEditor, prototype);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setView(((Module03.DrawingView)(e.getSource())));
        Module03.Figure pressedFigure = drawing().findFigureInside(x, y);
        Module03.TextHolder textHolder = null;
        if (pressedFigure != null) {
            textHolder = pressedFigure.getTextHolder();
        } 
        if ((textHolder != null) && (textHolder.acceptsTyping())) {
            beginEdit(textHolder, pressedFigure);
            return ;
        } 
        if ((getTypingTarget()) != null) {
            endEdit();
            if (((getCreatedFigure()) != null) && (getCreatedFigure().isEmpty())) {
                drawing().remove(getAddedFigure());
                setUndoActivity(null);
            } else {
            }
            setTypingTarget(null);
            setCreatedFigure(null);
            setEditedFigure(null);
            setAddedFigure(null);
            editor().toolDone();
        } else {
            super.mouseDown(e, x, y);
        }
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((getCreatedFigure()) == null) {
            return ;
        } 
        super.mouseDrag(e, x, y);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((getCreatedFigure()) == null) {
            return ;
        } 
        view().checkDamage();
        Module03.TextHolder textHolder = ((Module03.TextHolder)(getCreatedFigure()));
        if (textHolder.acceptsTyping()) {
            beginEdit(textHolder, getCreatedFigure());
        } else {
            editor().toolDone();
        }
    }

    public void deactivate() {
        endEdit();
        super.deactivate();
    }

    public void activate() {
        super.activate();
        getActiveView().clearSelection();
    }

    public boolean isActivated() {
        return (getTypingTarget()) != null;
    }

    protected void beginEdit(Module03.TextHolder figure, Module03.Figure selectedFigure) {
        if ((fTextField) == null) {
            fTextField = new Module06.FloatingTextArea();
        } 
        if ((figure != (getTypingTarget())) && ((getTypingTarget()) != null)) {
            endEdit();
        } 
        fTextField.createOverlay(((java.awt.Container)(view())), getFont(figure));
        fTextField.setBounds(fieldBounds(figure), figure.getText());
        setTypingTarget(figure);
        setEditedFigure(selectedFigure);
        setUndoActivity(createUndoActivity());
    }

    protected java.awt.Font getFont(Module03.TextHolder figure) {
        return figure.getFont();
    }

    protected void endEdit() {
        if (((getTypingTarget()) != null) && ((fTextField) != null)) {
            if ((fTextField.getText().length()) > 0) {
                getTypingTarget().setText(fTextField.getText());
                getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(getEditedFigure()));
                ((Module03.TextAreaTool.UndoActivity)(getUndoActivity())).setBackupText(getTypingTarget().getText());
            } else {
                drawing().orphan(getAddedFigure());
            }
            fTextField.endOverlay();
            fTextField = null;
        } 
    }

    private java.awt.Rectangle fieldBounds(Module03.TextHolder figure) {
        return figure.textDisplayBox();
    }

    protected void setTypingTarget(Module03.TextHolder newTypingTarget) {
        fTypingTarget = newTypingTarget;
    }

    protected Module03.Figure getEditedFigure() {
        return fEditedFigure;
    }

    protected void setEditedFigure(Module03.Figure figure) {
        fEditedFigure = figure;
    }

    protected Module03.TextHolder getTypingTarget() {
        return fTypingTarget;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module03.TextAreaTool.UndoActivity(view() , getTypingTarget().getText());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.lang.String myOriginalText;

        private java.lang.String myBackupText;

        public UndoActivity(Module03.DrawingView newDrawingView ,java.lang.String newOriginalText) {
            super(newDrawingView);
            setOriginalText(newOriginalText);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            if (!(isValidText(getOriginalText()))) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    getDrawingView().drawing().orphan(fe.nextFigure());
                }
            } else if (!(isValidText(getBackupText()))) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    getDrawingView().add(fe.nextFigure());
                }
                setText(getOriginalText());
            } else {
                setText(getOriginalText());
            }
            return true;
        }

        public boolean redo() {
            if (!(super.redo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            if (!(isValidText(getBackupText()))) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    getDrawingView().drawing().orphan(fe.nextFigure());
                }
            } else if (!(isValidText(getOriginalText()))) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    getDrawingView().drawing().add(fe.nextFigure());
                    setText(getBackupText());
                }
            } else {
                setText(getBackupText());
            }
            return true;
        }

        protected boolean isValidText(java.lang.String toBeChecked) {
            return (toBeChecked != null) && ((toBeChecked.length()) > 0);
        }

        protected void setText(java.lang.String newText) {
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                if ((currentFigure.getTextHolder()) != null) {
                    currentFigure.getTextHolder().setText(newText);
                } 
            }
        }

        public void setBackupText(java.lang.String newBackupText) {
            myBackupText = newBackupText;
        }

        public java.lang.String getBackupText() {
            return myBackupText;
        }

        public void setOriginalText(java.lang.String newOriginalText) {
            myOriginalText = newOriginalText;
        }

        public java.lang.String getOriginalText() {
            return myOriginalText;
        }
    }
}


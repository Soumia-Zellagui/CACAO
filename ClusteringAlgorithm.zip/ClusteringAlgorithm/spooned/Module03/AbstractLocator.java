package Module03;


public abstract class AbstractLocator implements Module03.Locator , Module03.Storable , java.lang.Cloneable {
    private static final long serialVersionUID = -7742023180844048409L;

    protected AbstractLocator() {
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError();
        }
    }

    public void write(Module06.StorableOutput dw) {
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
    }
}


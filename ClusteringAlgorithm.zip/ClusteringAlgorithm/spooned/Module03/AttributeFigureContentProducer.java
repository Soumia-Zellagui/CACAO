package Module03;


public class AttributeFigureContentProducer extends Module03.FigureDataContentProducer implements java.io.Serializable {
    public AttributeFigureContentProducer() {
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        java.lang.Object attrValue = super.getContent(context, ctxAttrName, ctxAttrValue);
        if (attrValue != null) {
            return attrValue;
        } 
        return ((Module03.AttributeContentProducerContext)(context)).getAttribute(ctxAttrName);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
    }
}


package Module03;


public interface Animatable {
    void animationStep();
}


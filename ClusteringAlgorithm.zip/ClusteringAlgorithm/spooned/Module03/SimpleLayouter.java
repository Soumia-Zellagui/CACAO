package Module03;


public class SimpleLayouter implements Module03.Layouter {
    private Module03.Layoutable myLayoutable;

    private java.awt.Insets myInsets;

    static final long serialVersionUID = 2928651014089117493L;

    private SimpleLayouter() {
    }

    public SimpleLayouter(Module03.Layoutable newLayoutable) {
        setLayoutable(newLayoutable);
        setInsets(new java.awt.Insets(0 , 0 , 0 , 0));
    }

    public Module03.Layoutable getLayoutable() {
        return myLayoutable;
    }

    public void setLayoutable(Module03.Layoutable newLayoutable) {
        myLayoutable = newLayoutable;
    }

    public void setInsets(java.awt.Insets newInsets) {
        myInsets = newInsets;
    }

    public java.awt.Insets getInsets() {
        return myInsets;
    }

    public Module03.Layouter create(Module03.Layoutable newLayoutable) {
        Module03.SimpleLayouter newLayouter = new Module03.SimpleLayouter(newLayoutable);
        newLayouter.setInsets(((java.awt.Insets)(getInsets().clone())));
        return newLayouter;
    }

    public java.awt.Rectangle calculateLayout(java.awt.Point origin, java.awt.Point corner) {
        java.awt.Rectangle maxRect = new java.awt.Rectangle(origin);
        maxRect.add(corner);
        Module03.FigureEnumeration fe = getLayoutable().figures();
        while (fe.hasNextFigure()) {
            Module03.Figure currentFigure = fe.nextFigure();
            maxRect.union(currentFigure.displayBox());
        }
        maxRect.width += (getInsets().left) + (getInsets().right);
        maxRect.height += (getInsets().top) + (getInsets().bottom);
        return maxRect;
    }

    public java.awt.Rectangle layout(java.awt.Point origin, java.awt.Point corner) {
        return calculateLayout(origin, corner);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        setLayoutable(((Module03.Layoutable)(dr.readStorable())));
        setInsets(new java.awt.Insets(dr.readInt() , dr.readInt() , dr.readInt() , dr.readInt()));
    }

    public void write(Module06.StorableOutput dw) {
        dw.writeStorable(getLayoutable());
        java.awt.Insets i = getInsets();
        dw.writeInt(i.top);
        dw.writeInt(i.left);
        dw.writeInt(i.bottom);
        dw.writeInt(i.right);
    }
}


package Module03;


public interface Figure extends Module03.Storable , java.io.Serializable , java.lang.Cloneable {
    public static java.lang.String POPUP_MENU = "POPUP_MENU";

    public void moveBy(int dx, int dy);

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner);

    public void displayBox(java.awt.Point origin, java.awt.Point corner);

    public java.awt.Rectangle displayBox();

    public void draw(java.awt.Graphics g);

    public Module06.HandleEnumeration handles();

    public java.awt.Dimension size();

    public java.awt.Point center();

    public boolean isEmpty();

    public Module03.FigureEnumeration figures();

    public Module03.Figure findFigureInside(int x, int y);

    public boolean containsPoint(int x, int y);

    public java.lang.Object clone();

    public void displayBox(java.awt.Rectangle r);

    public boolean includes(Module03.Figure figure);

    public Module03.FigureEnumeration decompose();

    public void addToContainer(Module03.FigureChangeListener c);

    public void removeFromContainer(Module03.FigureChangeListener c);

    public void addDependendFigure(Module03.Figure newDependendFigure);

    public void removeDependendFigure(Module03.Figure oldDependendFigure);

    public Module03.FigureEnumeration getDependendFigures();

    public Module03.FigureChangeListener listener();

    public void addFigureChangeListener(Module03.FigureChangeListener l);

    public void removeFigureChangeListener(Module03.FigureChangeListener l);

    public void release();

    public void invalidate();

    public void willChange();

    public void changed();

    public boolean canConnect();

    public Module03.Connector connectorAt(int x, int y);

    public void connectorVisibility(boolean isVisible, Module03.ConnectionFigure connection);

    public java.awt.Insets connectionInsets();

    public Module03.Locator connectedTextLocator(Module03.Figure text);

    public java.lang.Object getAttribute(java.lang.String name);

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant);

    public void setAttribute(java.lang.String name, java.lang.Object value);

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value);

    public int getZValue();

    public void setZValue(int z);

    public void visit(Module03.FigureVisitor visitor);

    public Module03.TextHolder getTextHolder();

    public Module03.Figure getDecoratedFigure();
}


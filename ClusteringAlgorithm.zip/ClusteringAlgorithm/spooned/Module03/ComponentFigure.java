package Module03;


public class ComponentFigure extends Module03.AttributeFigure {
    private java.awt.Rectangle bounds;

    private java.awt.Component component;

    private ComponentFigure() {
        bounds = new java.awt.Rectangle();
    }

    public ComponentFigure(java.awt.Component newComponent) {
        this();
        setComponent(newComponent);
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        bounds = new java.awt.Rectangle(origin);
        bounds.add(corner);
    }

    protected void basicMoveBy(int dx, int dy) {
        bounds.translate(dx, dy);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(bounds);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.ComponentFigure.this, handles);
        Module06.HandleEnumerator handleEnumerator = new Module06.HandleEnumerator(handles);
        return handleEnumerator;
    }

    public java.awt.Component getComponent() {
        return Module03.ComponentFigure.this.component;
    }

    protected void setComponent(java.awt.Component newComponent) {
        Module03.ComponentFigure.this.component = newComponent;
    }

    public void draw(java.awt.Graphics g) {
        getComponent().setBounds(displayBox());
        java.awt.Graphics componentG = g.create(bounds.x, bounds.y, bounds.width, bounds.height);
        getComponent().paint(componentG);
    }
}


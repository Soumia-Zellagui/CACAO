package Module03;


class GraphNode {
    double x = 0.0;

    double y = 0.0;

    double dx = 0.0;

    double dy = 0.0;

    final Module03.Figure node;

    GraphNode(Module03.Figure newNode) {
        node = newNode;
        update();
    }

    void update() {
        java.awt.Point p = node.center();
        if (((java.lang.Math.abs(((p.x) - (java.lang.Math.round(x))))) > 1) || ((java.lang.Math.abs(((p.y) - (java.lang.Math.round(y))))) > 1)) {
            x = p.x;
            y = p.y;
        } 
    }
}


package Module03;


public class ArrowTip extends Module03.AbstractLineDecoration {
    private double fAngle;

    private double fOuterRadius;

    private double fInnerRadius;

    private static final long serialVersionUID = -3459171428373823638L;

    private int arrowTipSerializedDataVersion = 1;

    public ArrowTip() {
        this(0.4, 8, 8);
    }

    public ArrowTip(double angle ,double outerRadius ,double innerRadius) {
        setAngle(angle);
        setOuterRadius(outerRadius);
        setInnerRadius(innerRadius);
    }

    public java.awt.Polygon outline(int x1, int y1, int x2, int y2) {
        double dir = ((java.lang.Math.PI) / 2) - (java.lang.Math.atan2((x2 - x1), (y2 - y1)));
        return outline(x1, y1, dir);
    }

    private java.awt.Polygon outline(int x, int y, double direction) {
        java.awt.Polygon shape = new java.awt.Polygon();
        shape.addPoint(x, y);
        addPointRelative(shape, x, y, getOuterRadius(), (direction - (getAngle())));
        addPointRelative(shape, x, y, getInnerRadius(), direction);
        addPointRelative(shape, x, y, getOuterRadius(), (direction + (getAngle())));
        shape.addPoint(x, y);
        return shape;
    }

    private void addPointRelative(java.awt.Polygon shape, int x, int y, double radius, double angle) {
        shape.addPoint((x + ((int)((radius * (java.lang.Math.cos(angle)))))), (y + ((int)((radius * (java.lang.Math.sin(angle)))))));
    }

    public void write(Module06.StorableOutput dw) {
        dw.writeDouble(getAngle());
        dw.writeDouble(getOuterRadius());
        dw.writeDouble(getInnerRadius());
        super.write(dw);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        setAngle(dr.readDouble());
        setOuterRadius(dr.readDouble());
        setInnerRadius(dr.readDouble());
        super.read(dr);
    }

    protected void setAngle(double newAngle) {
        fAngle = newAngle;
    }

    protected double getAngle() {
        return fAngle;
    }

    protected void setInnerRadius(double newInnerRadius) {
        fInnerRadius = newInnerRadius;
    }

    protected double getInnerRadius() {
        return fInnerRadius;
    }

    protected void setOuterRadius(double newOuterRadius) {
        fOuterRadius = newOuterRadius;
    }

    protected double getOuterRadius() {
        return fOuterRadius;
    }
}


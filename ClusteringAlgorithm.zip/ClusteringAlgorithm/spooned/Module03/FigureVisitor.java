package Module03;


public interface FigureVisitor {
    public void visitFigure(Module03.Figure hostFigure);

    public void visitHandle(Module05.Handle hostHandle);

    public void visitFigureChangeListener(Module03.FigureChangeListener hostFigureChangeListener);
}


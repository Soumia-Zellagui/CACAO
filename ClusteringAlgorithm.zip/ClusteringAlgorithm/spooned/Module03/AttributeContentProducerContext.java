package Module03;


public interface AttributeContentProducerContext extends Module03.FigureContentProducerContext {
    public java.lang.Object getAttribute(java.lang.String name);
}


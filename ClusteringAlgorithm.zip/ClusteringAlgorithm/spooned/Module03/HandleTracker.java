package Module03;


public class HandleTracker extends Module03.AbstractTool {
    private Module05.Handle fAnchorHandle;

    public HandleTracker(Module01.DrawingEditor newDrawingEditor ,Module05.Handle anchorHandle) {
        super(newDrawingEditor);
        fAnchorHandle = anchorHandle;
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        fAnchorHandle.invokeStart(x, y, view());
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDrag(e, x, y);
        fAnchorHandle.invokeStep(x, y, getAnchorX(), getAnchorY(), view());
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseUp(e, x, y);
        fAnchorHandle.invokeEnd(x, y, getAnchorX(), getAnchorY(), view());
    }

    public void activate() {
    }
}


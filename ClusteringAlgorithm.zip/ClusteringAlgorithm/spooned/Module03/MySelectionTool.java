package Module03;


public class MySelectionTool extends Module03.SelectionTool {
    public MySelectionTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setView(((Module03.DrawingView)(e.getSource())));
        if ((e.getClickCount()) == 2) {
            Module03.Figure figure = drawing().findFigure(e.getX(), e.getY());
            if (figure != null) {
                inspectFigure(figure);
                return ;
            } 
        } 
        super.mouseDown(e, x, y);
    }

    protected void inspectFigure(Module03.Figure f) {
        java.lang.System.out.println(("inspect figure" + f));
    }
}


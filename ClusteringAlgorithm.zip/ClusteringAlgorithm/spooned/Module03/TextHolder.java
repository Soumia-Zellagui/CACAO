package Module03;


public interface TextHolder {
    public java.awt.Rectangle textDisplayBox();

    public java.lang.String getText();

    public void setText(java.lang.String newText);

    public boolean acceptsTyping();

    public int overlayColumns();

    public void connect(Module03.Figure connectedFigure);

    public void disconnect(Module03.Figure disconnectFigure);

    public java.awt.Font getFont();

    public Module03.Figure getRepresentingFigure();
}


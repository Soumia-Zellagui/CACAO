package Module03;


public class TextFigure extends Module03.AttributeFigure implements Module03.FigureChangeListener , Module03.TextHolder {
    private int fOriginX;

    private int fOriginY;

    private transient boolean fSizeIsDirty = true;

    private transient int fWidth;

    private transient int fHeight;

    private java.lang.String fText;

    private java.awt.Font fFont;

    private boolean fIsReadOnly;

    private Module03.Figure fObservedFigure = null;

    private Module03.OffsetLocator fLocator = null;

    private static java.lang.String fgCurrentFontName = "Helvetica";

    private static int fgCurrentFontSize = 12;

    private static int fgCurrentFontStyle = java.awt.Font.PLAIN;

    private static final long serialVersionUID = 4599820785949456124L;

    private int textFigureSerializedDataVersion = 1;

    public TextFigure() {
        fOriginX = 0;
        fOriginY = 0;
        fFont = Module03.TextFigure.createCurrentFont();
        setAttribute(Module06.FigureAttributeConstant.FILL_COLOR, Module06.ColorMap.color("None"));
        fText = "";
        fSizeIsDirty = true;
    }

    public void moveBy(int x, int y) {
        willChange();
        basicMoveBy(x, y);
        if ((getLocator()) != null) {
            getLocator().moveBy(x, y);
        } 
        changed();
    }

    protected void basicMoveBy(int x, int y) {
        fOriginX += x;
        fOriginY += y;
    }

    public void basicDisplayBox(java.awt.Point newOrigin, java.awt.Point newCorner) {
        fOriginX = newOrigin.x;
        fOriginY = newOrigin.y;
    }

    public java.awt.Rectangle displayBox() {
        java.awt.Dimension extent = textExtent();
        return new java.awt.Rectangle(fOriginX , fOriginY , extent.width , extent.height);
    }

    public java.awt.Rectangle textDisplayBox() {
        return displayBox();
    }

    public boolean readOnly() {
        return fIsReadOnly;
    }

    public void setReadOnly(boolean isReadOnly) {
        fIsReadOnly = isReadOnly;
    }

    public java.awt.Font getFont() {
        return fFont;
    }

    public Module03.Figure getRepresentingFigure() {
        return Module03.TextFigure.this;
    }

    public void setFont(java.awt.Font newFont) {
        willChange();
        fFont = newFont;
        markDirty();
        changed();
    }

    public void changed() {
        super.changed();
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return getAttribute(Module06.FigureAttributeConstant.getConstant(name));
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        java.awt.Font font = getFont();
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_SIZE)) {
            return new java.lang.Integer(font.getSize());
        } 
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_STYLE)) {
            return new java.lang.Integer(font.getStyle());
        } 
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_NAME)) {
            return font.getName();
        } 
        return super.getAttribute(attributeConstant);
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        setAttribute(Module06.FigureAttributeConstant.getConstant(name), value);
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        java.awt.Font font = getFont();
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_SIZE)) {
            java.lang.Integer s = ((java.lang.Integer)(value));
            setFont(new java.awt.Font(font.getName() , font.getStyle() , s.intValue()));
        } else if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_STYLE)) {
            java.lang.Integer s = ((java.lang.Integer)(value));
            int style = font.getStyle();
            if ((s.intValue()) == (java.awt.Font.PLAIN)) {
                style = java.awt.Font.PLAIN;
            } else {
                style = style ^ (s.intValue());
            }
            setFont(new java.awt.Font(font.getName() , style , font.getSize()));
        } else if (attributeConstant.equals(Module06.FigureAttributeConstant.FONT_NAME)) {
            java.lang.String n = ((java.lang.String)(value));
            setFont(new java.awt.Font(n , font.getStyle() , font.getSize()));
        } else {
            super.setAttribute(attributeConstant, value);
        }
    }

    public java.lang.String getText() {
        return fText;
    }

    public void setText(java.lang.String newText) {
        if ((newText == null) || (!(newText.equals(fText)))) {
            willChange();
            fText = newText;
            markDirty();
            changed();
        } 
    }

    public boolean acceptsTyping() {
        return !(fIsReadOnly);
    }

    public void drawBackground(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.fillRect(r.x, r.y, r.width, r.height);
    }

    public void drawFrame(java.awt.Graphics g) {
        g.setFont(fFont);
        g.setColor(((java.awt.Color)(getAttribute(Module06.FigureAttributeConstant.TEXT_COLOR))));
        java.awt.FontMetrics metrics = java.awt.Toolkit.getDefaultToolkit().getFontMetrics(fFont);
        java.awt.Rectangle r = displayBox();
        g.drawString(getText(), r.x, ((r.y) + (metrics.getAscent())));
    }

    protected java.awt.Dimension textExtent() {
        if (!(fSizeIsDirty)) {
            return new java.awt.Dimension(fWidth , fHeight);
        } 
        java.awt.FontMetrics metrics = java.awt.Toolkit.getDefaultToolkit().getFontMetrics(fFont);
        fWidth = metrics.stringWidth(getText());
        fHeight = metrics.getHeight();
        fSizeIsDirty = false;
        return new java.awt.Dimension(fWidth , fHeight);
    }

    protected void markDirty() {
        fSizeIsDirty = true;
    }

    public int overlayColumns() {
        int length = getText().length();
        int columns = 20;
        if (length != 0) {
            columns = (getText().length()) + 3;
        } 
        return columns;
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        handles.add(new Module05.NullHandle(Module03.TextFigure.this , Module03.RelativeLocator.northWest()));
        handles.add(new Module05.NullHandle(Module03.TextFigure.this , Module03.RelativeLocator.northEast()));
        handles.add(new Module05.NullHandle(Module03.TextFigure.this , Module03.RelativeLocator.southEast()));
        handles.add(new Module05.FontSizeHandle(Module03.TextFigure.this , Module03.RelativeLocator.southWest()));
        return new Module06.HandleEnumerator(handles);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        java.awt.Rectangle r = displayBox();
        dw.writeInt(r.x);
        dw.writeInt(r.y);
        dw.writeString(getText());
        dw.writeString(fFont.getName());
        dw.writeInt(fFont.getStyle());
        dw.writeInt(fFont.getSize());
        dw.writeBoolean(fIsReadOnly);
        dw.writeStorable(getObservedFigure());
        dw.writeStorable(getLocator());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        markDirty();
        basicDisplayBox(new java.awt.Point(dr.readInt() , dr.readInt()), null);
        setText(dr.readString());
        fFont = new java.awt.Font(dr.readString() , dr.readInt() , dr.readInt());
        fIsReadOnly = dr.readBoolean();
        setObservedFigure(((Module03.Figure)(dr.readStorable())));
        if ((getObservedFigure()) != null) {
            getObservedFigure().addFigureChangeListener(Module03.TextFigure.this);
        } 
        setLocator(((Module03.OffsetLocator)(dr.readStorable())));
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((getObservedFigure()) != null) {
            getObservedFigure().addFigureChangeListener(Module03.TextFigure.this);
        } 
        markDirty();
    }

    public void connect(Module03.Figure figure) {
        if ((getObservedFigure()) != null) {
            getObservedFigure().removeFigureChangeListener(Module03.TextFigure.this);
        } 
        setObservedFigure(figure);
        setLocator(new Module03.OffsetLocator(getObservedFigure().connectedTextLocator(Module03.TextFigure.this)));
        getObservedFigure().addFigureChangeListener(Module03.TextFigure.this);
        willChange();
        updateLocation();
        changed();
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        willChange();
        updateLocation();
        changed();
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            java.awt.Rectangle rect = invalidateRectangle(displayBox());
            listener().figureRemoved(new Module03.FigureChangeEvent(Module03.TextFigure.this , rect , e));
        } 
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
    }

    protected void updateLocation() {
        if ((getLocator()) != null) {
            java.awt.Point p = getLocator().locate(getObservedFigure());
            p.x -= ((size().width) / 2) + (fOriginX);
            p.y -= ((size().height) / 2) + (fOriginY);
            if (((p.x) != 0) || ((p.y) != 0)) {
                basicMoveBy(p.x, p.y);
            } 
        } 
    }

    public void release() {
        super.release();
        disconnect(getObservedFigure());
    }

    public void disconnect(Module03.Figure disconnectFigure) {
        if (disconnectFigure != null) {
            disconnectFigure.removeFigureChangeListener(Module03.TextFigure.this);
        } 
        setLocator(null);
        setObservedFigure(null);
    }

    protected void setObservedFigure(Module03.Figure newObservedFigure) {
        fObservedFigure = newObservedFigure;
    }

    public Module03.Figure getObservedFigure() {
        return fObservedFigure;
    }

    protected void setLocator(Module03.OffsetLocator newLocator) {
        fLocator = newLocator;
    }

    protected Module03.OffsetLocator getLocator() {
        return fLocator;
    }

    public Module03.TextHolder getTextHolder() {
        return Module03.TextFigure.this;
    }

    public static java.awt.Font createCurrentFont() {
        return new java.awt.Font(Module03.TextFigure.fgCurrentFontName , Module03.TextFigure.fgCurrentFontStyle , Module03.TextFigure.fgCurrentFontSize);
    }

    public static void setCurrentFontName(java.lang.String name) {
        Module03.TextFigure.fgCurrentFontName = name;
    }

    public static void setCurrentFontSize(int size) {
        Module03.TextFigure.fgCurrentFontSize = size;
    }

    public static void setCurrentFontStyle(int style) {
        Module03.TextFigure.fgCurrentFontStyle = style;
    }
}


package Module03;


public class PolygonTool extends Module03.AbstractTool {
    private Module03.PolygonFigure fPolygon;

    private int fLastX;

    private int fLastY;

    private Module03.Figure myAddedFigure;

    public PolygonTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void activate() {
        super.activate();
        fPolygon = null;
    }

    public void deactivate() {
        if ((fPolygon) != null) {
            fPolygon.smoothPoints();
            if ((((fPolygon.pointCount()) < 3) || ((fPolygon.size().width) < 4)) || ((fPolygon.size().height) < 4)) {
                getActiveView().drawing().remove(fPolygon);
                setUndoActivity(null);
            } 
        } 
        fPolygon = null;
        super.deactivate();
    }

    private void addPoint(int x, int y) {
        if ((fPolygon) == null) {
            fPolygon = new Module03.PolygonFigure(x , y);
            setAddedFigure(view().add(fPolygon));
            fPolygon.addPoint(x, y);
        } else if (((fLastX) != x) || ((fLastY) != y)) {
            fPolygon.addPoint(x, y);
        } 
        fLastX = x;
        fLastY = y;
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        x = e.getX();
        y = e.getY();
        if ((e.getClickCount()) >= 2) {
            if ((fPolygon) != null) {
                fPolygon.smoothPoints();
                setUndoActivity(createUndoActivity());
                Module03.Figure figure = getAddedFigure();
                Module03.SingleFigureEnumerator singleFigureEnumerator = new Module03.SingleFigureEnumerator(figure);
                getUndoActivity().setAffectedFigures(singleFigureEnumerator);
                Module01.DrawingEditor editor = editor();
                editor.toolDone();
            } 
            fPolygon = null;
        } else {
            addPoint(e.getX(), e.getY());
        }
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
        if ((e.getSource()) == (getActiveView())) {
            if ((fPolygon) != null) {
                if ((fPolygon.pointCount()) > 1) {
                    fPolygon.setPointAt(new java.awt.Point(x , y), ((fPolygon.pointCount()) - 1));
                    getActiveView().checkDamage();
                } 
            } 
        } 
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        x = e.getX();
        y = e.getY();
        addPoint(x, y);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
    }

    protected Module03.Figure getAddedFigure() {
        return myAddedFigure;
    }

    private void setAddedFigure(Module03.Figure newAddedFigure) {
        myAddedFigure = newAddedFigure;
    }

    protected Module06.Undoable createUndoActivity() {
        Module03.DrawingView view = view();
        Module01.PasteCommand.UndoActivity pu = new Module01.PasteCommand.UndoActivity(view);
        return pu;
    }
}


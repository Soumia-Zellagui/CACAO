package Module03;


public interface DNDInterface {
    public void DNDInitialize(java.awt.dnd.DragGestureListener dgl);

    public void DNDDeinitialize();

    public java.awt.dnd.DragSourceListener getDragSourceListener();
}


package Module03;


public class DiamondFigure extends Module03.RectangleFigure {
    public DiamondFigure() {
        super(new java.awt.Point(0 , 0), new java.awt.Point(0 , 0));
    }

    public DiamondFigure(java.awt.Point origin ,java.awt.Point corner) {
        super(origin, corner);
    }

    protected java.awt.Polygon getPolygon() {
        java.awt.Rectangle r = displayBox();
        java.awt.Polygon p = new java.awt.Polygon();
        p.addPoint(r.x, ((r.y) + ((r.height) / 2)));
        p.addPoint(((r.x) + ((r.width) / 2)), r.y);
        p.addPoint(((r.x) + (r.width)), ((r.y) + ((r.height) / 2)));
        p.addPoint(((r.x) + ((r.width) / 2)), ((r.y) + (r.height)));
        return p;
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Polygon p = getPolygon();
        g.setColor(getFillColor());
        g.fillPolygon(p);
        g.setColor(getFrameColor());
        g.drawPolygon(p);
    }

    public java.awt.Insets connectionInsets() {
        java.awt.Rectangle r = displayBox();
        return new java.awt.Insets(((r.height) / 2) , ((r.width) / 2) , ((r.height) / 2) , ((r.width) / 2));
    }

    public boolean containsPoint(int x, int y) {
        return getPolygon().contains(x, y);
    }

    public java.awt.Point chop(java.awt.Point p) {
        return Module03.PolygonFigure.chop(getPolygon(), p);
    }

    public Module03.Connector connectorAt(int x, int y) {
        Module03.ChopDiamondConnector chopDiamondConnector = new Module03.ChopDiamondConnector(Module03.DiamondFigure.this);
        return chopDiamondConnector;
    }
}


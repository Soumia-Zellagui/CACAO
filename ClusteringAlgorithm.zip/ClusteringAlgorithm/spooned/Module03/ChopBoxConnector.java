package Module03;


public class ChopBoxConnector extends Module03.AbstractConnector {
    private static final long serialVersionUID = -1461450322712345462L;

    public ChopBoxConnector() {
    }

    public ChopBoxConnector(Module03.Figure owner) {
        super(owner);
    }

    public java.awt.Point findStart(Module03.ConnectionFigure connection) {
        Module03.Figure startFigure = connection.getStartConnector().owner();
        java.awt.Rectangle r2 = connection.getEndConnector().displayBox();
        java.awt.Point r2c = null;
        if ((connection.pointCount()) == 2) {
            r2c = new java.awt.Point(((r2.x) + ((r2.width) / 2)) , ((r2.y) + ((r2.height) / 2)));
        } else {
            r2c = connection.pointAt(1);
        }
        return chop(startFigure, r2c);
    }

    public java.awt.Point findEnd(Module03.ConnectionFigure connection) {
        Module03.Figure endFigure = connection.getEndConnector().owner();
        java.awt.Rectangle r1 = connection.getStartConnector().displayBox();
        java.awt.Point r1c = null;
        if ((connection.pointCount()) == 2) {
            r1c = new java.awt.Point(((r1.x) + ((r1.width) / 2)) , ((r1.y) + ((r1.height) / 2)));
        } else {
            r1c = connection.pointAt(((connection.pointCount()) - 2));
        }
        return chop(endFigure, r1c);
    }

    protected java.awt.Point chop(Module03.Figure target, java.awt.Point from) {
        java.awt.Rectangle r = target.displayBox();
        return Module06.Geom.angleToPoint(r, Module06.Geom.pointToAngle(r, from));
    }
}


package Module03;


public class GraphLayout extends Module03.FigureChangeAdapter {
    public double LENGTH_FACTOR = 1.0;

    public double REPULSION_STRENGTH = 0.5;

    public double REPULSION_LIMIT = 200.0;

    int REPULSION_TYPE = 0;

    public double SPRING_STRENGTH = 0.1;

    public double TORQUE_STRENGTH = 0.25;

    public double FRICTION_FACTOR = 0.75;

    private java.util.Hashtable nodes = new java.util.Hashtable();

    private java.util.Hashtable edges = new java.util.Hashtable();

    public GraphLayout() {
    }

    private Module03.GraphNode getGraphNode(Module03.Figure node) {
        return ((Module03.GraphNode)(nodes.get(node)));
    }

    private double len(Module03.Figure edge) {
        return (((java.lang.Double)(edges.get(edge))).doubleValue()) * (LENGTH_FACTOR);
    }

    public void addNode(Module03.Figure node) {
        Module03.GraphNode n = new Module03.GraphNode(node);
        nodes.put(node, n);
        node.addFigureChangeListener(Module03.GraphLayout.this);
    }

    public void addEdge(Module03.ConnectionFigure edge, int addlen) {
        java.awt.Dimension d1 = edge.getStartConnector().owner().size();
        java.awt.Dimension d2 = edge.getEndConnector().owner().size();
        int len = (((java.lang.Math.max(d1.width, d1.height)) / 2) + ((java.lang.Math.max(d2.width, d2.height)) / 2)) + addlen;
        edges.put(edge, new java.lang.Double(len));
    }

    public synchronized void relax() {
        if ((nodes) == null)
            return ;
        
        java.util.Enumeration edgeEnum = edges.keys();
        while (edgeEnum.hasMoreElements()) {
            Module03.ConnectionFigure e = ((Module03.ConnectionFigure)(edgeEnum.nextElement()));
            double targetlen = len(e);
            Module03.GraphNode from = getGraphNode(e.getStartConnector().owner());
            Module03.GraphNode to = getGraphNode(e.getEndConnector().owner());
            double vx = (to.x) - (from.x);
            double vy = (to.y) - (from.y);
            double len = java.lang.Math.sqrt(((vx * vx) + (vy * vy)));
            if (len > 0) {
                double f = ((SPRING_STRENGTH) * (targetlen - len)) / len;
                double dx = f * vx;
                double dy = f * vy;
                double phi = java.lang.Math.atan2(vx, vy);
                double dir = -(java.lang.Math.sin((4 * phi)));
                dx += (((TORQUE_STRENGTH) * vy) * dir) / len;
                dy += (((-(TORQUE_STRENGTH)) * vx) * dir) / len;
                to.dx += dx;
                to.dy += dy;
                from.dx += -dx;
                from.dy += -dy;
            } 
        }
        java.util.Enumeration nodeEnum1 = nodes.elements();
        while (nodeEnum1.hasMoreElements()) {
            Module03.GraphNode n1 = ((Module03.GraphNode)(nodeEnum1.nextElement()));
            double dx = 0;
            double dy = 0;
            java.util.Enumeration nodeEnum2 = nodes.elements();
            while (nodeEnum2.hasMoreElements()) {
                Module03.GraphNode n2 = ((Module03.GraphNode)(nodeEnum2.nextElement()));
                if (n1 == n2) {
                    continue;
                } 
                double vx = (n1.x) - (n2.x);
                double vy = (n1.y) - (n2.y);
                double lensqr = (vx * vx) + (vy * vy);
                double len = java.lang.Math.sqrt(lensqr);
                if (len == 0) {
                    dx += (REPULSION_STRENGTH) * (java.lang.Math.random());
                    dy += (REPULSION_STRENGTH) * (java.lang.Math.random());
                } else if (len < (REPULSION_LIMIT)) {
                    vx = vx / (REPULSION_LIMIT);
                    vy = vy / (REPULSION_LIMIT);
                    len = len / (REPULSION_LIMIT);
                    double f = 0;
                    switch (REPULSION_TYPE) {
                        case 0 :
                            f = (0.5 * (1 - len)) / len;
                            break;
                        case 1 :
                            f = 1 - len;
                            break;
                        case 2 :
                            f = (2 * (1 - len)) * (1 - len);
                            break;
                    }
                    f *= REPULSION_STRENGTH;
                    dx += f * vx;
                    dy += f * vy;
                } 
            }
            n1.dx += dx;
            n1.dy += dy;
        }
        java.util.Enumeration nodeEnum = nodes.keys();
        while (nodeEnum.hasMoreElements()) {
            Module03.Figure node = ((Module03.Figure)(nodeEnum.nextElement()));
            Module03.GraphNode n = getGraphNode(node);
            if (!(java.lang.Boolean.TRUE.equals(node.getAttribute(Module06.FigureAttributeConstant.LOCATION)))) {
                n.x += java.lang.Math.max((-5), java.lang.Math.min(5, n.dx));
                n.y += java.lang.Math.max((-5), java.lang.Math.min(5, n.dy));
                java.awt.Point c = node.center();
                node.moveBy((((int)(java.lang.Math.round(n.x))) - (c.x)), (((int)(java.lang.Math.round(n.y))) - (c.y)));
                if ((n.x) < 0) {
                    n.x = 0;
                } 
                if ((n.y) < 0) {
                    n.y = 0;
                } 
            } 
            n.dx *= FRICTION_FACTOR;
            n.dy *= FRICTION_FACTOR;
        }
    }

    public synchronized void figureChanged(Module03.FigureChangeEvent e) {
        if ((nodes) != null) {
            Module03.Figure node = e.getFigure();
            if (nodes.containsKey(node)) {
                getGraphNode(node).update();
            } 
        } 
    }

    public void remove() {
        if ((nodes) != null) {
            java.util.Enumeration nodeEnum = nodes.keys();
            while (nodeEnum.hasMoreElements()) {
                Module03.Figure node = ((Module03.Figure)(nodeEnum.nextElement()));
                node.removeFigureChangeListener(Module03.GraphLayout.this);
            }
            nodes = null;
            edges = null;
        } 
    }
}


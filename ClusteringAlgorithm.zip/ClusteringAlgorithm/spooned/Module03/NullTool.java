package Module03;


public class NullTool extends Module03.AbstractTool {
    public NullTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void activate() {
    }

    public void deactivate() {
    }

    protected void checkUsable() {
    }
}


package Module03;


public class EllipseFigure extends Module03.AttributeFigure {
    private java.awt.Rectangle fDisplayBox;

    private static final long serialVersionUID = -6856203289355118951L;

    private int ellipseFigureSerializedDataVersion = 1;

    public EllipseFigure() {
        this(new java.awt.Point(0 , 0), new java.awt.Point(0 , 0));
    }

    public EllipseFigure(java.awt.Point origin ,java.awt.Point corner) {
        basicDisplayBox(origin, corner);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.EllipseFigure.this, handles);
        return new Module06.HandleEnumerator(handles);
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        fDisplayBox = new java.awt.Rectangle(origin);
        fDisplayBox.add(corner);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(fDisplayBox.x , fDisplayBox.y , fDisplayBox.width , fDisplayBox.height);
    }

    protected void basicMoveBy(int x, int y) {
        fDisplayBox.translate(x, y);
    }

    public void drawBackground(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.fillOval(r.x, r.y, r.width, r.height);
    }

    public void drawFrame(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.drawOval(r.x, r.y, ((r.width) - 1), ((r.height) - 1));
    }

    public java.awt.Insets connectionInsets() {
        java.awt.Rectangle r = fDisplayBox;
        int cx = (r.width) / 2;
        int cy = (r.height) / 2;
        return new java.awt.Insets(cy , cx , cy , cx);
    }

    public Module03.Connector connectorAt(int x, int y) {
        return new Module03.ChopEllipseConnector(Module03.EllipseFigure.this);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fDisplayBox.x);
        dw.writeInt(fDisplayBox.y);
        dw.writeInt(fDisplayBox.width);
        dw.writeInt(fDisplayBox.height);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fDisplayBox = new java.awt.Rectangle(dr.readInt() , dr.readInt() , dr.readInt() , dr.readInt());
    }
}


package Module03;


public class NullPainter implements Module03.Painter {
    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
    }
}


package Module03;


public interface Connector extends Module03.Storable , java.io.Serializable {
    public abstract java.awt.Point findStart(Module03.ConnectionFigure connection);

    public abstract java.awt.Point findEnd(Module03.ConnectionFigure connection);

    public abstract Module03.Figure owner();

    public abstract java.awt.Rectangle displayBox();

    public abstract boolean containsPoint(int x, int y);

    public abstract void draw(java.awt.Graphics g);

    public void connectorVisibility(boolean isVisible, Module03.ConnectionFigure courtingConnection);
}


package Module03;


public final class FigureEnumerator implements Module03.FigureEnumeration {
    private java.util.Iterator myIterator;

    private java.util.Collection myInitialCollection;

    private static Module03.FigureEnumerator singletonEmptyEnumerator = new Module03.FigureEnumerator(Module06.CollectionsFactory.current().createList());

    public FigureEnumerator(java.util.Collection c) {
        myInitialCollection = c;
        reset();
    }

    public boolean hasNextFigure() {
        return myIterator.hasNext();
    }

    public Module03.Figure nextFigure() {
        return ((Module03.Figure)(myIterator.next()));
    }

    public static Module03.FigureEnumeration getEmptyEnumeration() {
        return Module03.FigureEnumerator.singletonEmptyEnumerator;
    }

    public void reset() {
        myIterator = myInitialCollection.iterator();
    }
}


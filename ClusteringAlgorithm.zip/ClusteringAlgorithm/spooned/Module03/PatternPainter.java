package Module03;


public class PatternPainter implements Module03.Painter {
    private java.awt.Image fImage;

    public PatternPainter(java.awt.Image image) {
        fImage = image;
    }

    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
        drawPattern(g, fImage, view);
    }

    private void drawPattern(java.awt.Graphics g, java.awt.Image image, Module03.DrawingView view) {
        int iwidth = image.getWidth(view);
        int iheight = image.getHeight(view);
        java.awt.Dimension d = view.getSize();
        int x = 0;
        int y = 0;
        while (y < (d.height)) {
            while (x < (d.width)) {
                g.drawImage(image, x, y, view);
                x += iwidth;
            }
            y += iheight;
            x = 0;
        }
    }
}


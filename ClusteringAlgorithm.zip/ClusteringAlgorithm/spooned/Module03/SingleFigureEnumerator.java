package Module03;


public final class SingleFigureEnumerator implements Module03.FigureEnumeration {
    private Module03.Figure mySingleFigure;

    private Module03.Figure myInitialFigure;

    public SingleFigureEnumerator(Module03.Figure newSingleFigure) {
        myInitialFigure = newSingleFigure;
        reset();
    }

    public boolean hasNextFigure() {
        return (mySingleFigure) != null;
    }

    public Module03.Figure nextFigure() {
        Module03.Figure returnFigure = mySingleFigure;
        mySingleFigure = null;
        return returnFigure;
    }

    public void reset() {
        mySingleFigure = myInitialFigure;
    }
}


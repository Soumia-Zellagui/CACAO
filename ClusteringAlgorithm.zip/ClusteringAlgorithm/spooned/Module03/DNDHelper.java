package Module03;


public abstract class DNDHelper {
    public static java.awt.datatransfer.DataFlavor ASCIIFlavor = new java.awt.datatransfer.DataFlavor("text/plain; charset=ascii" , "ASCII text");

    private java.awt.dnd.DragGestureRecognizer dgr;

    private java.awt.dnd.DragGestureListener dragGestureListener;

    private java.awt.dnd.DropTarget dropTarget;

    private java.awt.dnd.DragSourceListener dragSourceListener;

    private java.awt.dnd.DropTargetListener dropTargetListener;

    private boolean isDragSource = false;

    private boolean isDropTarget = false;

    public DNDHelper(boolean newIsDragSource ,boolean newIsDropTarget) {
        isDragSource = newIsDragSource;
        isDropTarget = newIsDropTarget;
    }

    public void initialize(java.awt.dnd.DragGestureListener dgl) {
        if (isDragSource) {
            setDragGestureListener(dgl);
            setDragSourceListener(createDragSourceListener());
            setDragGestureRecognizer(createDragGestureRecognizer(getDragGestureListener()));
        } 
        if (isDropTarget) {
            setDropTargetListener(createDropTargetListener());
            setDropTarget(createDropTarget());
        } 
    }

    public void deinitialize() {
        if ((getDragSourceListener()) != null) {
            destroyDragGestreRecognizer();
            setDragSourceListener(null);
        } 
        if ((getDropTargetListener()) != null) {
            setDropTarget(null);
            setDropTargetListener(null);
        } 
    }

    protected abstract Module03.DrawingView view();

    protected abstract Module01.DrawingEditor editor();

    public static java.lang.Object processReceivedData(java.awt.datatransfer.DataFlavor flavor, java.awt.datatransfer.Transferable transferable) {
        java.lang.Object receivedData = null;
        if (transferable == null) {
            return null;
        } 
        try {
            if (flavor.equals(java.awt.datatransfer.DataFlavor.stringFlavor)) {
                receivedData = transferable.getTransferData(java.awt.datatransfer.DataFlavor.stringFlavor);
            } else if (flavor.equals(java.awt.datatransfer.DataFlavor.javaFileListFlavor)) {
                java.util.List aList = ((java.util.List)(transferable.getTransferData(java.awt.datatransfer.DataFlavor.javaFileListFlavor)));
                java.io.File[] fList = new java.io.File[aList.size()];
                aList.toArray(fList);
                receivedData = fList;
            } else if (flavor.equals(Module03.DNDHelper.ASCIIFlavor)) {
                java.io.InputStream is = ((java.io.InputStream)(transferable.getTransferData(Module03.DNDHelper.ASCIIFlavor)));
                int length = is.available();
                byte[] bytes = new byte[length];
                int n = is.read(bytes);
                if (n > 0) {
                    receivedData = new java.lang.String(bytes , 0 , n);
                } 
            } else if (flavor.equals(Module03.DNDFiguresTransferable.DNDFiguresFlavor)) {
                receivedData = transferable.getTransferData(Module03.DNDFiguresTransferable.DNDFiguresFlavor);
            } 
        } catch (java.io.IOException ioe) {
            java.lang.System.err.println(ioe);
        } catch (java.awt.datatransfer.UnsupportedFlavorException ufe) {
            java.lang.System.err.println(ufe);
        } catch (java.lang.ClassCastException cce) {
            java.lang.System.err.println(cce);
        }
        return receivedData;
    }

    protected int getDragSourceActions() {
        return java.awt.dnd.DnDConstants.ACTION_COPY_OR_MOVE;
    }

    protected int getDropTargetActions() {
        return java.awt.dnd.DnDConstants.ACTION_COPY_OR_MOVE;
    }

    protected void setDragGestureListener(java.awt.dnd.DragGestureListener dragGestureListener) {
        Module03.DNDHelper.this.dragGestureListener = dragGestureListener;
    }

    protected java.awt.dnd.DragGestureListener getDragGestureListener() {
        return dragGestureListener;
    }

    protected void setDragGestureRecognizer(java.awt.dnd.DragGestureRecognizer dragGestureRecognizer) {
        dgr = dragGestureRecognizer;
    }

    protected java.awt.dnd.DragGestureRecognizer getDragGestureRecognizer() {
        return dgr;
    }

    protected void setDropTarget(java.awt.dnd.DropTarget newDropTarget) {
        if ((newDropTarget == null) && ((dropTarget) != null)) {
            dropTarget.setComponent(null);
            dropTarget.removeDropTargetListener(getDropTargetListener());
        } 
        dropTarget = newDropTarget;
    }

    protected java.awt.dnd.DropTarget createDropTarget() {
        java.awt.dnd.DropTarget dt = null;
        if (java.awt.Component.class.isInstance(view())) {
            try {
                dt = new java.awt.dnd.DropTarget(((java.awt.Component)(view())) , getDropTargetActions() , getDropTargetListener());
            } catch (java.lang.NullPointerException npe) {
                java.lang.System.err.println("View Failed to initialize to DND.");
                java.lang.System.err.println("Container likely did not have peer before the DropTarget was added");
                java.lang.System.err.println(npe);
                npe.printStackTrace();
            }
        } 
        return dt;
    }

    protected java.awt.dnd.DragGestureRecognizer createDragGestureRecognizer(java.awt.dnd.DragGestureListener dgl) {
        java.awt.dnd.DragGestureRecognizer aDgr = null;
        if (java.awt.Component.class.isInstance(view())) {
            java.awt.Component c = ((java.awt.Component)(view()));
            aDgr = java.awt.dnd.DragSource.getDefaultDragSource().createDefaultDragGestureRecognizer(c, getDragSourceActions(), dgl);
        } 
        return aDgr;
    }

    protected void destroyDragGestreRecognizer() {
        if ((getDragGestureRecognizer()) != null) {
            getDragGestureRecognizer().removeDragGestureListener(getDragGestureListener());
            getDragGestureRecognizer().setComponent(null);
            setDragGestureRecognizer(null);
        } 
    }

    protected void setDropTargetListener(java.awt.dnd.DropTargetListener dropTargetListener) {
        Module03.DNDHelper.this.dropTargetListener = dropTargetListener;
    }

    protected java.awt.dnd.DropTargetListener getDropTargetListener() {
        return dropTargetListener;
    }

    protected java.awt.dnd.DropTargetListener createDropTargetListener() {
        Module01.DrawingEditor editor = editor();
        Module03.DrawingView view = view();
        Module06.JHDDropTargetListener jhdDropTargetListener = new Module06.JHDDropTargetListener(editor , view);
        return jhdDropTargetListener;
    }

    public java.awt.dnd.DragSourceListener getDragSourceListener() {
        return dragSourceListener;
    }

    protected void setDragSourceListener(java.awt.dnd.DragSourceListener dragSourceListener) {
        Module03.DNDHelper.this.dragSourceListener = dragSourceListener;
    }

    protected java.awt.dnd.DragSourceListener createDragSourceListener() {
        Module01.DrawingEditor editor = editor();
        Module03.DrawingView view = view();
        Module06.JHDDragSourceListener jhdDragSourceListener = new Module06.JHDDragSourceListener(editor , view);
        return jhdDragSourceListener;
    }
}


package Module03;


public interface Layouter extends Module03.Storable , java.io.Serializable {
    public java.awt.Rectangle calculateLayout(java.awt.Point origin, java.awt.Point corner);

    public java.awt.Rectangle layout(java.awt.Point origin, java.awt.Point corner);

    public void setInsets(java.awt.Insets newInsets);

    public java.awt.Insets getInsets();

    public Module03.Layouter create(Module03.Layoutable newLayoutable);
}


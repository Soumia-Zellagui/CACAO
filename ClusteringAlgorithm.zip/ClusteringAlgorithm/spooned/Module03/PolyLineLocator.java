package Module03;


public class PolyLineLocator extends Module03.AbstractLocator {
    int fIndex;

    public PolyLineLocator(int index) {
        fIndex = index;
    }

    public java.awt.Point locate(Module03.Figure owner) {
        Module03.PolyLineFigure plf = ((Module03.PolyLineFigure)(owner));
        if ((fIndex) < (plf.pointCount())) {
            return ((Module03.PolyLineFigure)(owner)).pointAt(fIndex);
        } 
        return new java.awt.Point(0 , 0);
    }
}


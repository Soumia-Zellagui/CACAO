package Module03;


public interface Painter extends java.io.Serializable {
    public void draw(java.awt.Graphics g, Module03.DrawingView view);
}


package Module03;


public class SimpleUpdateStrategy implements Module03.Painter {
    private static final long serialVersionUID = -7539925820692134566L;

    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
        view.drawAll(g);
    }
}


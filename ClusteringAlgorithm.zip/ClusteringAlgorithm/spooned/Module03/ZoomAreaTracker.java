package Module03;


public class ZoomAreaTracker extends Module03.AreaTracker {
    public ZoomAreaTracker(Module01.DrawingEditor editor) {
        super(editor);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        java.awt.Rectangle zoomArea = getArea();
        super.mouseUp(e, x, y);
        if (((zoomArea.width) > 4) && ((zoomArea.height) > 4))
            ((Module03.ZoomDrawingView)(view())).zoom(zoomArea.x, zoomArea.y, zoomArea.width, zoomArea.height);
        
    }
}


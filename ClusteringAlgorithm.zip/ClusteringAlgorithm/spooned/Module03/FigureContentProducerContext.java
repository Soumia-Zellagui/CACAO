package Module03;


public interface FigureContentProducerContext extends Module03.ContentProducerContext {
    public java.awt.Rectangle displayBox();

    public java.awt.Font getFont();
}


package Module03;


public class NestedCreationTool extends Module03.CreationTool {
    private Module03.CompositeFigure myContainerFigure;

    public NestedCreationTool(Module01.DrawingEditor newDrawingEditor ,Module03.Figure prototype) {
        super(newDrawingEditor, prototype);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Figure figure = drawing().findFigure(e.getX(), e.getY());
        if (figure != null) {
            figure = figure.getDecoratedFigure();
            if (figure instanceof Module03.CompositeFigure) {
                setContainerFigure(((Module03.CompositeFigure)(figure)));
                super.mouseDown(e, x, y);
            } else {
                toolDone();
            }
        } else {
            toolDone();
        }
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
        if (((getContainerFigure()) != null) && (!(getContainerFigure().containsPoint(e.getX(), e.getY())))) {
            toolDone();
        } else {
            super.mouseMove(e, x, y);
        }
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((((getContainerFigure()) != null) && ((getCreatedFigure()) != null)) && (getContainerFigure().containsPoint(e.getX(), e.getY()))) {
            getContainerFigure().add(getCreatedFigure());
        } 
        toolDone();
    }

    protected void setContainerFigure(Module03.CompositeFigure newContainerFigure) {
        myContainerFigure = newContainerFigure;
    }

    public Module03.CompositeFigure getContainerFigure() {
        return myContainerFigure;
    }

    protected void toolDone() {
        setCreatedFigure(null);
        setAddedFigure(null);
        setContainerFigure(null);
        editor().toolDone();
    }
}


package Module03;


public class FigureChangeEventMulticaster extends java.awt.AWTEventMulticaster implements Module03.FigureChangeListener {
    public FigureChangeEventMulticaster(java.util.EventListener newListenerA ,java.util.EventListener newListenerB) {
        super(newListenerA, newListenerB);
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
        ((Module03.FigureChangeListener)(a)).figureInvalidated(e);
        ((Module03.FigureChangeListener)(b)).figureInvalidated(e);
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
        ((Module03.FigureChangeListener)(a)).figureRequestRemove(e);
        ((Module03.FigureChangeListener)(b)).figureRequestRemove(e);
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
        ((Module03.FigureChangeListener)(a)).figureRequestUpdate(e);
        ((Module03.FigureChangeListener)(b)).figureRequestUpdate(e);
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        ((Module03.FigureChangeListener)(a)).figureChanged(e);
        ((Module03.FigureChangeListener)(b)).figureChanged(e);
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
        ((Module03.FigureChangeListener)(a)).figureRemoved(e);
        ((Module03.FigureChangeListener)(b)).figureRemoved(e);
    }

    public static Module03.FigureChangeListener add(Module03.FigureChangeListener a, Module03.FigureChangeListener b) {
        return ((Module03.FigureChangeListener)(Module03.FigureChangeEventMulticaster.addInternal(a, b)));
    }

    public static Module03.FigureChangeListener remove(Module03.FigureChangeListener l, Module03.FigureChangeListener oldl) {
        return ((Module03.FigureChangeListener)(Module03.FigureChangeEventMulticaster.removeInternal(l, oldl)));
    }

    protected java.util.EventListener remove(java.util.EventListener oldl) {
        if (oldl == (a)) {
            return b;
        } 
        if (oldl == (b)) {
            return a;
        } 
        java.util.EventListener a2 = Module03.FigureChangeEventMulticaster.removeInternal(a, oldl);
        java.util.EventListener b2 = Module03.FigureChangeEventMulticaster.removeInternal(b, oldl);
        if ((a2 == (a)) && (b2 == (b))) {
            return Module03.FigureChangeEventMulticaster.this;
        } else {
            return Module03.FigureChangeEventMulticaster.addInternal(((Module03.FigureChangeListener)(a2)), ((Module03.FigureChangeListener)(b2)));
        }
    }

    protected static java.util.EventListener addInternal(Module03.FigureChangeListener a, Module03.FigureChangeListener b) {
        if (a == null) {
            return b;
        } 
        if (b == null) {
            return a;
        } 
        return new Module03.FigureChangeEventMulticaster(a , b);
    }

    protected static java.util.EventListener removeInternal(java.util.EventListener l, java.util.EventListener oldl) {
        if ((l == oldl) || (l == null)) {
            return null;
        } else if (l instanceof Module03.FigureChangeEventMulticaster) {
            return ((Module03.FigureChangeEventMulticaster)(l)).remove(oldl);
        } else {
            return l;
        }
    }
}


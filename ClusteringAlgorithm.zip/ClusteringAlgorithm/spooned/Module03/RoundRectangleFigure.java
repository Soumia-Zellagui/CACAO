package Module03;


public class RoundRectangleFigure extends Module03.AttributeFigure {
    private java.awt.Rectangle fDisplayBox;

    private int fArcWidth;

    private int fArcHeight;

    private static final int DEFAULT_ARC = 8;

    private static final long serialVersionUID = 7907900248924036885L;

    private int roundRectangleSerializedDataVersion = 1;

    public RoundRectangleFigure() {
        this(new java.awt.Point(0 , 0), new java.awt.Point(0 , 0));
        fArcWidth = fArcHeight = Module03.RoundRectangleFigure.DEFAULT_ARC;
    }

    public RoundRectangleFigure(java.awt.Point origin ,java.awt.Point corner) {
        basicDisplayBox(origin, corner);
        fArcWidth = fArcHeight = Module03.RoundRectangleFigure.DEFAULT_ARC;
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        fDisplayBox = new java.awt.Rectangle(origin);
        fDisplayBox.add(corner);
    }

    public void setArc(int width, int height) {
        willChange();
        fArcWidth = width;
        fArcHeight = height;
        changed();
    }

    public java.awt.Point getArc() {
        return new java.awt.Point(fArcWidth , fArcHeight);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.RoundRectangleFigure.this, handles);
        handles.add(new Module05.RadiusHandle(Module03.RoundRectangleFigure.this));
        return new Module06.HandleEnumerator(handles);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(fDisplayBox.x , fDisplayBox.y , fDisplayBox.width , fDisplayBox.height);
    }

    protected void basicMoveBy(int x, int y) {
        fDisplayBox.translate(x, y);
    }

    public void drawBackground(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.fillRoundRect(r.x, r.y, r.width, r.height, fArcWidth, fArcHeight);
    }

    public void drawFrame(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.drawRoundRect(r.x, r.y, ((r.width) - 1), ((r.height) - 1), fArcWidth, fArcHeight);
    }

    public java.awt.Insets connectionInsets() {
        return new java.awt.Insets(((fArcHeight) / 2) , ((fArcWidth) / 2) , ((fArcHeight) / 2) , ((fArcWidth) / 2));
    }

    public Module03.Connector connectorAt(int x, int y) {
        return new Module03.ShortestDistanceConnector(Module03.RoundRectangleFigure.this);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fDisplayBox.x);
        dw.writeInt(fDisplayBox.y);
        dw.writeInt(fDisplayBox.width);
        dw.writeInt(fDisplayBox.height);
        dw.writeInt(fArcWidth);
        dw.writeInt(fArcHeight);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fDisplayBox = new java.awt.Rectangle(dr.readInt() , dr.readInt() , dr.readInt() , dr.readInt());
        fArcWidth = dr.readInt();
        fArcHeight = dr.readInt();
    }
}


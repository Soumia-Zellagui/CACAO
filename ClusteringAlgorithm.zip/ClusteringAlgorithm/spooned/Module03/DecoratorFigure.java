package Module03;


public abstract class DecoratorFigure extends Module03.AbstractFigure implements Module03.FigureChangeListener {
    private Module03.Figure myDecoratedFigure;

    private static final long serialVersionUID = 8993011151564573288L;

    private int decoratorFigureSerializedDataVersion = 1;

    public DecoratorFigure() {
        initialize();
    }

    public DecoratorFigure(Module03.Figure figure) {
        initialize();
        decorate(figure);
    }

    protected void initialize() {
    }

    public java.awt.Insets connectionInsets() {
        return getDecoratedFigure().connectionInsets();
    }

    public boolean canConnect() {
        return getDecoratedFigure().canConnect();
    }

    public boolean containsPoint(int x, int y) {
        return getDecoratedFigure().containsPoint(x, y);
    }

    public void decorate(Module03.Figure figure) {
        setDecoratedFigure(figure);
        getDecoratedFigure().addToContainer(Module03.DecoratorFigure.this);
    }

    public Module03.Figure peelDecoration() {
        getDecoratedFigure().removeFromContainer(Module03.DecoratorFigure.this);
        removeDependendFigure(getDecoratedFigure());
        return getDecoratedFigure();
    }

    public void setDecoratedFigure(Module03.Figure newDecoratedFigure) {
        myDecoratedFigure = newDecoratedFigure;
    }

    public Module03.Figure getDecoratedFigure() {
        return myDecoratedFigure;
    }

    public java.awt.Rectangle displayBox() {
        return getDecoratedFigure().displayBox();
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        getDecoratedFigure().basicDisplayBox(origin, corner);
    }

    public void draw(java.awt.Graphics g) {
        getDecoratedFigure().draw(g);
    }

    public Module03.Figure findFigureInside(int x, int y) {
        Module03.Figure foundFigure = getDecoratedFigure().findFigureInside(x, y);
        if ((foundFigure != null) && (foundFigure == (getDecoratedFigure()))) {
            return Module03.DecoratorFigure.this;
        } else {
            return foundFigure;
        }
    }

    public Module06.HandleEnumeration handles() {
        return getDecoratedFigure().handles();
    }

    public boolean includes(Module03.Figure figure) {
        return (super.includes(figure)) || (getDecoratedFigure().includes(figure));
    }

    public void moveBy(int x, int y) {
        getDecoratedFigure().moveBy(x, y);
    }

    protected void basicMoveBy(int x, int y) {
    }

    public void release() {
        super.release();
        getDecoratedFigure().removeFromContainer(Module03.DecoratorFigure.this);
        getDecoratedFigure().release();
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            listener().figureInvalidated(e);
        } 
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            listener().figureRequestUpdate(e);
        } 
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            listener().figureRequestRemove(new Module03.FigureChangeEvent(Module03.DecoratorFigure.this));
        } 
    }

    public Module03.FigureEnumeration figures() {
        return getDecoratedFigure().figures();
    }

    public Module03.FigureEnumeration decompose() {
        return getDecoratedFigure().decompose();
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        getDecoratedFigure().setAttribute(name, value);
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        getDecoratedFigure().setAttribute(attributeConstant, value);
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return getDecoratedFigure().getAttribute(name);
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        return getDecoratedFigure().getAttribute(attributeConstant);
    }

    public Module03.Locator connectedTextLocator(Module03.Figure text) {
        return getDecoratedFigure().connectedTextLocator(text);
    }

    public Module03.Connector connectorAt(int x, int y) {
        return getDecoratedFigure().connectorAt(x, y);
    }

    public void connectorVisibility(boolean isVisible, Module03.ConnectionFigure courtingConnection) {
        getDecoratedFigure().connectorVisibility(isVisible, null);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getDecoratedFigure());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        decorate(((Module03.Figure)(dr.readStorable())));
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        getDecoratedFigure().addToContainer(Module03.DecoratorFigure.this);
    }

    public Module03.TextHolder getTextHolder() {
        return getDecoratedFigure().getTextHolder();
    }

    public synchronized Module03.FigureEnumeration getDependendFigures() {
        return getDecoratedFigure().getDependendFigures();
    }

    public synchronized void addDependendFigure(Module03.Figure newDependendFigure) {
        getDecoratedFigure().addDependendFigure(newDependendFigure);
    }

    public synchronized void removeDependendFigure(Module03.Figure oldDependendFigure) {
        getDecoratedFigure().removeDependendFigure(oldDependendFigure);
    }
}


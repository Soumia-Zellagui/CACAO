package Module03;


public class CompositeFigureCreationTool extends Module03.CreationTool {
    private Module03.CompositeFigure myContainerFigure;

    public CompositeFigureCreationTool(Module01.DrawingEditor newDrawingEditor ,Module03.Figure prototype) {
        super(newDrawingEditor, prototype);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setView(((Module03.DrawingView)(e.getSource())));
        Module03.Figure figure = drawing().findFigure(e.getX(), e.getY());
        if (figure != null) {
            figure = figure.getDecoratedFigure();
            if (figure instanceof Module03.CompositeFigure) {
                setContainerFigure(((Module03.CompositeFigure)(figure)));
                setCreatedFigure(createFigure());
                setAddedFigure(getContainerFigure().add(getCreatedFigure()));
                getAddedFigure().displayBox(new java.awt.Point(x , y), new java.awt.Point(x , y));
            } else {
                toolDone();
            }
        } else {
            toolDone();
        }
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
        if (((getContainerFigure()) != null) && (!(getContainerFigure().containsPoint(e.getX(), e.getY())))) {
            toolDone();
        } else {
            super.mouseMove(e, x, y);
        }
    }

    protected void setContainerFigure(Module03.CompositeFigure newContainerFigure) {
        myContainerFigure = newContainerFigure;
    }

    public Module03.CompositeFigure getContainerFigure() {
        return myContainerFigure;
    }

    protected void toolDone() {
        setCreatedFigure(null);
        setAddedFigure(null);
        setContainerFigure(null);
        editor().toolDone();
    }
}


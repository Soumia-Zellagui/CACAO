package Module03;


public class OffsetLocator extends Module03.AbstractLocator {
    private static final long serialVersionUID = 2679950024611847621L;

    private int offsetLocatorSerializedDataVersion = 1;

    private Module03.Locator fBase;

    private int fOffsetX;

    private int fOffsetY;

    public OffsetLocator() {
        fBase = null;
        fOffsetX = 0;
        fOffsetY = 0;
    }

    public OffsetLocator(Module03.Locator base) {
        this();
        fBase = base;
    }

    public OffsetLocator(Module03.Locator base ,int offsetX ,int offsetY) {
        this(base);
        fOffsetX = offsetX;
        fOffsetY = offsetY;
    }

    public java.awt.Point locate(Module03.Figure owner) {
        java.awt.Point p = fBase.locate(owner);
        p.x += fOffsetX;
        p.y += fOffsetY;
        return p;
    }

    public void moveBy(int dx, int dy) {
        fOffsetX += dx;
        fOffsetY += dy;
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fOffsetX);
        dw.writeInt(fOffsetY);
        dw.writeStorable(fBase);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fOffsetX = dr.readInt();
        fOffsetY = dr.readInt();
        fBase = ((Module03.Locator)(dr.readStorable()));
    }
}


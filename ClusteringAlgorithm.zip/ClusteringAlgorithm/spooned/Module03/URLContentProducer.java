package Module03;


public class URLContentProducer extends Module03.FigureDataContentProducer implements java.io.Serializable {
    private java.net.URL fURL;

    public URLContentProducer() {
    }

    public URLContentProducer(java.net.URL url) {
        setURL(url);
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        try {
            java.net.URL url = (getURL()) != null ? new java.net.URL(getURL().toExternalForm()) : new java.net.URL(((java.net.URL)(ctxAttrValue)).toExternalForm());
            java.io.InputStream reader = url.openStream();
            int available = reader.available();
            byte[] contents = new byte[available];
            reader.read(contents, 0, available);
            reader.close();
            return new java.lang.String(contents);
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeBoolean(((getURL()) != null));
        if ((getURL()) != null) {
            dw.writeString(getURL().toExternalForm());
        } 
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        boolean hasURL = dr.readBoolean();
        if (hasURL) {
            setURL(new java.net.URL(dr.readString()));
        } 
    }

    public java.net.URL getURL() {
        return fURL;
    }

    protected void setURL(java.net.URL newURL) {
        fURL = newURL;
    }
}


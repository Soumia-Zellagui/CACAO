package Module03;


public class PolyLineConnector extends Module03.ChopBoxConnector {
    private static final long serialVersionUID = 6018435940519102865L;

    public PolyLineConnector() {
        super();
    }

    public PolyLineConnector(Module03.Figure owner) {
        super(owner);
    }

    protected java.awt.Point chop(Module03.Figure target, java.awt.Point from) {
        Module03.PolyLineFigure p = ((Module03.PolyLineFigure)(owner()));
        java.awt.Point ctr = p.center();
        int cx = -1;
        int cy = -1;
        long len = java.lang.Long.MAX_VALUE;
        for (int i = 0 ; i < ((p.pointCount()) - 1) ; i++) {
            java.awt.Point p1 = p.pointAt(i);
            java.awt.Point p2 = p.pointAt((i + 1));
            java.awt.Point chop = Module06.Geom.intersect(p1.x, p1.y, p2.x, p2.y, from.x, from.y, ctr.x, ctr.y);
            if (chop != null) {
                long cl = Module06.Geom.length2(chop.x, chop.y, from.x, from.y);
                if (cl < len) {
                    len = cl;
                    cx = chop.x;
                    cy = chop.y;
                } 
            } 
        }
        {
            for (int i = 0 ; i < (p.pointCount()) ; i++) {
                java.awt.Point pp = p.pointAt(i);
                long l = Module06.Geom.length2(pp.x, pp.y, from.x, from.y);
                if (l < len) {
                    len = l;
                    cx = pp.x;
                    cy = pp.y;
                } 
            }
        }
        return new java.awt.Point(cx , cy);
    }
}


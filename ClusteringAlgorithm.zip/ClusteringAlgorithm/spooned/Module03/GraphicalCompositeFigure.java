package Module03;


public class GraphicalCompositeFigure extends Module03.CompositeFigure implements Module03.Layoutable {
    private Module03.Figure myPresentationFigure;

    private Module03.Layouter myLayouter;

    private static final long serialVersionUID = 1265742491024232713L;

    public GraphicalCompositeFigure() {
        Module03.RectangleFigure rf = new Module03.RectangleFigure();
    }

    public GraphicalCompositeFigure(Module03.Figure newPresentationFigure) {
        super();
        setPresentationFigure(newPresentationFigure);
        initialize();
    }

    protected void initialize() {
        if ((getLayouter()) != null) {
            setLayouter(getLayouter().create(Module03.GraphicalCompositeFigure.this));
        } else {
            Module03.StandardLayouter standardLayouter = new Module03.StandardLayouter(Module03.GraphicalCompositeFigure.this);
            setLayouter(standardLayouter);
        }
    }

    public java.lang.Object clone() {
        java.lang.Object cloneObject = super.clone();
        ((Module03.GraphicalCompositeFigure)(cloneObject)).initialize();
        return cloneObject;
    }

    public java.awt.Rectangle displayBox() {
        return getPresentationFigure().displayBox();
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        java.awt.Rectangle r = getLayouter().layout(origin, corner);
        getPresentationFigure().basicDisplayBox(r.getLocation(), new java.awt.Point(((int)(r.getMaxX())) , ((int)(r.getMaxY()))));
    }

    protected void basicMoveBy(int dx, int dy) {
        super.basicMoveBy(dx, dy);
        getPresentationFigure().moveBy(dx, dy);
    }

    public void update() {
        willChange();
        layout();
        change();
        changed();
    }

    public void draw(java.awt.Graphics g) {
        getPresentationFigure().draw(g);
        super.draw(g);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.GraphicalCompositeFigure.this, handles);
        Module06.HandleEnumerator handleEnumerator = new Module06.HandleEnumerator(handles);
        return handleEnumerator;
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        if ((getPresentationFigure()) != null) {
            return getPresentationFigure().getAttribute(name);
        } else {
            return super.getAttribute(name);
        }
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        if ((getPresentationFigure()) != null) {
            return getPresentationFigure().getAttribute(attributeConstant);
        } else {
            return super.getAttribute(attributeConstant);
        }
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        if ((getPresentationFigure()) != null) {
            getPresentationFigure().setAttribute(name, value);
        } else {
            super.setAttribute(name, value);
        }
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        if ((getPresentationFigure()) != null) {
            getPresentationFigure().setAttribute(attributeConstant, value);
        } else {
            super.setAttribute(attributeConstant, value);
        }
    }

    public void setPresentationFigure(Module03.Figure newPresentationFigure) {
        myPresentationFigure = newPresentationFigure;
    }

    public Module03.Figure getPresentationFigure() {
        return myPresentationFigure;
    }

    public void layout() {
        if ((getLayouter()) != null) {
            java.awt.Rectangle r = getLayouter().calculateLayout(displayBox().getLocation(), displayBox().getLocation());
            displayBox(r.getLocation(), new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height))));
        } 
    }

    public void setLayouter(Module03.Layouter newLayouter) {
        myLayouter = newLayouter;
    }

    public Module03.Layouter getLayouter() {
        return myLayouter;
    }

    protected void change() {
        if ((listener()) != null) {
            Module03.FigureChangeEvent figureChangeEvent = new Module03.FigureChangeEvent(Module03.GraphicalCompositeFigure.this);
            listener().figureRequestUpdate(figureChangeEvent);
        } 
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            if (includes(e.getFigure())) {
                java.awt.Rectangle r = invalidateRectangle(displayBox());
                Module03.FigureChangeEvent fche = new Module03.FigureChangeEvent(Module03.GraphicalCompositeFigure.this , r , e);
                listener().figureRequestRemove(fche);
            } else {
                super.figureRequestRemove(e);
            }
        } 
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        setPresentationFigure(((Module03.Figure)(dr.readStorable())));
        setLayouter(((Module03.Layouter)(dr.readStorable())));
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getPresentationFigure());
        dw.writeStorable(getLayouter());
    }
}


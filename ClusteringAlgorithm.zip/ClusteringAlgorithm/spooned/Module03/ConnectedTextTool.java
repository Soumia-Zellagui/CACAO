package Module03;


public class ConnectedTextTool extends Module03.TextTool {
    private Module03.Figure myConnectedFigure;

    public ConnectedTextTool(Module01.DrawingEditor editor ,Module03.Figure prototype) {
        super(editor, prototype);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        if ((getTypingTarget()) != null) {
            Module03.TextHolder textHolder = getTypingTarget();
            setConnectedFigure(drawing().findFigureInsideWithout(x, y, textHolder.getRepresentingFigure()));
            if ((((getConnectedFigure()) != null) && (textHolder != null)) && ((getConnectedFigure().getTextHolder()) != textHolder)) {
                textHolder.connect(getConnectedFigure().getDecoratedFigure());
                getConnectedFigure().addDependendFigure(getAddedFigure());
            } 
        } 
    }

    protected void endEdit() {
        super.endEdit();
        if (((getUndoActivity()) != null) && ((getUndoActivity()) instanceof Module03.ConnectedTextTool.UndoActivity)) {
            ((Module03.ConnectedTextTool.UndoActivity)(getUndoActivity())).setConnectedFigure(getConnectedFigure());
        } else if (((getConnectedFigure()) != null) && (isDeleteTextFigure())) {
            getConnectedFigure().removeDependendFigure(getAddedFigure());
        } 
    }

    protected void setConnectedFigure(Module03.Figure pressedFigure) {
        myConnectedFigure = pressedFigure;
    }

    public Module03.Figure getConnectedFigure() {
        return myConnectedFigure;
    }

    public void activate() {
        super.activate();
        setConnectedFigure(null);
    }

    protected Module06.Undoable createDeleteUndoActivity() {
        Module01.FigureTransferCommand cmd = new Module01.DeleteCommand("Delete" , editor());
        return new Module03.ConnectedTextTool.DeleteUndoActivity(cmd , getConnectedFigure());
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module03.ConnectedTextTool.UndoActivity(view() , getTypingTarget().getText());
    }

    public static class UndoActivity extends Module03.TextTool.UndoActivity {
        private Module03.Figure myConnectedFigure;

        public UndoActivity(Module03.DrawingView newDrawingView ,java.lang.String newOriginalText) {
            super(newDrawingView, newOriginalText);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                if ((currentFigure.getTextHolder()) != null) {
                    if (!(isValidText(getOriginalText()))) {
                        currentFigure.getTextHolder().disconnect(getConnectedFigure());
                    } else if (!(isValidText(getBackupText()))) {
                        currentFigure.getTextHolder().connect(getConnectedFigure());
                    } 
                } 
            }
            return true;
        }

        public boolean redo() {
            if (!(super.redo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                if ((currentFigure.getTextHolder()) != null) {
                    if (!(isValidText(getBackupText()))) {
                        currentFigure.getTextHolder().disconnect(getConnectedFigure());
                    } else if (!(isValidText(getOriginalText()))) {
                        currentFigure.getTextHolder().connect(getConnectedFigure());
                    } 
                } 
            }
            return true;
        }

        public void setConnectedFigure(Module03.Figure newConnectedFigure) {
            myConnectedFigure = newConnectedFigure;
        }

        public Module03.Figure getConnectedFigure() {
            return myConnectedFigure;
        }
    }

    public static class DeleteUndoActivity extends Module01.DeleteCommand.UndoActivity {
        private Module03.Figure myConnectedFigure;

        public DeleteUndoActivity(Module01.FigureTransferCommand cmd ,Module03.Figure newConnectedFigure) {
            super(cmd);
            setConnectedFigure(newConnectedFigure);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                if ((currentFigure.getTextHolder()) != null) {
                    currentFigure.getTextHolder().connect(getConnectedFigure().getDecoratedFigure());
                } 
            }
            return true;
        }

        public boolean redo() {
            if (!(super.redo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                if ((currentFigure.getTextHolder()) != null) {
                    currentFigure.getTextHolder().disconnect(getConnectedFigure().getDecoratedFigure());
                } 
            }
            return true;
        }

        public void setConnectedFigure(Module03.Figure newConnectedFigure) {
            myConnectedFigure = newConnectedFigure;
        }

        public Module03.Figure getConnectedFigure() {
            return myConnectedFigure;
        }
    }
}


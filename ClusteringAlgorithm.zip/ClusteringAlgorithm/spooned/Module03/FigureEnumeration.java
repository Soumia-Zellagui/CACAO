package Module03;


public interface FigureEnumeration {
    public Module03.Figure nextFigure();

    public boolean hasNextFigure();

    public void reset();
}


package Module03;


public class DNDFigures implements java.io.Serializable {
    private java.util.List figures;

    private java.awt.Point origin;

    public DNDFigures(Module03.FigureEnumeration fe ,java.awt.Point newOrigin) {
        Module03.DNDFigures.this.figures = Module06.CollectionsFactory.current().createList();
        while (fe.hasNextFigure()) {
            figures.add(fe.nextFigure());
        }
        origin = newOrigin;
    }

    public Module03.FigureEnumeration getFigures() {
        Module03.FigureEnumerator figureEnumerator = new Module03.FigureEnumerator(figures);
        return figureEnumerator;
    }

    public java.awt.Point getOrigin() {
        return origin;
    }
}


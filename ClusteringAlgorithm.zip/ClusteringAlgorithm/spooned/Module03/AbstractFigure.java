package Module03;


public abstract class AbstractFigure implements Module03.Figure {
    private transient Module03.FigureChangeListener fListener;

    private java.util.List myDependendFigures;

    private static final long serialVersionUID = -10857585979273442L;

    private int abstractFigureSerializedDataVersion = 1;

    private int _nZ;

    protected AbstractFigure() {
        myDependendFigures = Module06.CollectionsFactory.current().createList();
    }

    public void moveBy(int dx, int dy) {
        willChange();
        basicMoveBy(dx, dy);
        changed();
    }

    protected abstract void basicMoveBy(int dx, int dy);

    public void displayBox(java.awt.Point origin, java.awt.Point corner) {
        willChange();
        basicDisplayBox(origin, corner);
        changed();
    }

    public abstract void basicDisplayBox(java.awt.Point origin, java.awt.Point corner);

    public abstract java.awt.Rectangle displayBox();

    public abstract Module06.HandleEnumeration handles();

    public Module03.FigureEnumeration figures() {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public java.awt.Dimension size() {
        return new java.awt.Dimension(displayBox().width , displayBox().height);
    }

    public boolean isEmpty() {
        return ((size().width) < 3) || ((size().height) < 3);
    }

    public Module03.Figure findFigureInside(int x, int y) {
        if (containsPoint(x, y)) {
            return Module03.AbstractFigure.this;
        } 
        return null;
    }

    public boolean containsPoint(int x, int y) {
        return displayBox().contains(x, y);
    }

    public void displayBox(java.awt.Rectangle r) {
        displayBox(new java.awt.Point(r.x , r.y), new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height))));
    }

    public boolean includes(Module03.Figure figure) {
        return figure == (Module03.AbstractFigure.this);
    }

    public Module03.FigureEnumeration decompose() {
        java.util.List figures = Module06.CollectionsFactory.current().createList(1);
        figures.add(Module03.AbstractFigure.this);
        Module03.FigureEnumerator fe = new Module03.FigureEnumerator(figures);
        return fe;
    }

    public void addToContainer(Module03.FigureChangeListener c) {
        addFigureChangeListener(c);
        invalidate();
    }

    public void removeFromContainer(Module03.FigureChangeListener c) {
        invalidate();
        removeFigureChangeListener(c);
    }

    public synchronized void addFigureChangeListener(Module03.FigureChangeListener l) {
        fListener = Module03.FigureChangeEventMulticaster.add(listener(), l);
    }

    public synchronized void removeFigureChangeListener(Module03.FigureChangeListener l) {
        fListener = Module03.FigureChangeEventMulticaster.remove(listener(), l);
    }

    public synchronized Module03.FigureChangeListener listener() {
        return fListener;
    }

    public void release() {
        if ((listener()) != null) {
            listener().figureRemoved(new Module03.FigureChangeEvent(Module03.AbstractFigure.this));
        } 
    }

    public void invalidate() {
        if ((listener()) != null) {
            java.awt.Rectangle r = invalidateRectangle(displayBox());
            Module03.FigureChangeEvent fce = new Module03.FigureChangeEvent(Module03.AbstractFigure.this , r);
            listener().figureInvalidated(fce);
        } 
    }

    protected java.awt.Rectangle invalidateRectangle(java.awt.Rectangle r) {
        r.grow(Module05.Handle.HANDLESIZE, Module05.Handle.HANDLESIZE);
        return r;
    }

    public void willChange() {
        invalidate();
    }

    public void changed() {
        invalidate();
        if ((listener()) != null) {
            Module03.FigureChangeEvent fce = new Module03.FigureChangeEvent(Module03.AbstractFigure.this);
            listener().figureChanged(fce);
        } 
    }

    public java.awt.Point center() {
        return Module06.Geom.center(displayBox());
    }

    public boolean canConnect() {
        return true;
    }

    public java.awt.Insets connectionInsets() {
        return new java.awt.Insets(0 , 0 , 0 , 0);
    }

    public Module03.Connector connectorAt(int x, int y) {
        Module03.ChopBoxConnector chbc = new Module03.ChopBoxConnector(Module03.AbstractFigure.this);
        return chbc;
    }

    public void connectorVisibility(boolean isVisible, Module03.ConnectionFigure connector) {
    }

    public Module03.Locator connectedTextLocator(Module03.Figure text) {
        return Module03.RelativeLocator.center();
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return null;
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        return null;
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
    }

    public java.lang.Object clone() {
        java.lang.Object clone = null;
        java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream(200);
        try {
            java.io.ObjectOutput writer = new java.io.ObjectOutputStream(output);
            writer.writeObject(Module03.AbstractFigure.this);
            writer.close();
        } catch (java.io.IOException e) {
            java.lang.System.err.println(("Class not found: " + e));
        }
        java.io.InputStream input = new java.io.ByteArrayInputStream(output.toByteArray());
        try {
            java.io.ObjectInput reader = new java.io.ObjectInputStream(input);
            clone = reader.readObject();
        } catch (java.io.IOException e) {
            java.lang.System.err.println(e.toString());
        } catch (java.lang.ClassNotFoundException e) {
            java.lang.System.err.println(("Class not found: " + e));
        }
        return clone;
    }

    public void write(Module06.StorableOutput dw) {
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
    }

    public int getZValue() {
        return _nZ;
    }

    public void setZValue(int z) {
        _nZ = z;
    }

    public void visit(Module03.FigureVisitor visitor) {
        Module03.FigureEnumeration fe = getDependendFigures();
        visitor.visitFigure(Module03.AbstractFigure.this);
        Module03.FigureEnumeration visitFigures = figures();
        while (visitFigures.hasNextFigure()) {
            visitFigures.nextFigure().visit(visitor);
        }
        Module06.HandleEnumeration visitHandles = handles();
        while (visitHandles.hasNextHandle()) {
            visitor.visitHandle(visitHandles.nextHandle());
        }
        while (fe.hasNextFigure()) {
            fe.nextFigure().visit(visitor);
        }
    }

    public synchronized Module03.FigureEnumeration getDependendFigures() {
        return new Module03.FigureEnumerator(myDependendFigures);
    }

    public synchronized void addDependendFigure(Module03.Figure newDependendFigure) {
        myDependendFigures.add(newDependendFigure);
    }

    public synchronized void removeDependendFigure(Module03.Figure oldDependendFigure) {
        myDependendFigures.remove(oldDependendFigure);
    }

    public Module03.TextHolder getTextHolder() {
        return null;
    }

    public Module03.Figure getDecoratedFigure() {
        return Module03.AbstractFigure.this;
    }
}


package Module03;


public class ImageFigure extends Module03.AttributeFigure implements java.awt.image.ImageObserver {
    private java.lang.String fFileName;

    private transient java.awt.Image fImage;

    private java.awt.Rectangle fDisplayBox;

    private static final long serialVersionUID = 148012030121282439L;

    private int imageFigureSerializedDataVersion = 1;

    public ImageFigure() {
        fFileName = null;
        fImage = null;
        fDisplayBox = null;
    }

    public ImageFigure(java.awt.Image image ,java.lang.String fileName ,java.awt.Point origin) {
        fFileName = fileName;
        fImage = image;
        basicDisplayBox(origin, new java.awt.Point(((origin.x) + (fImage.getWidth(Module03.ImageFigure.this))) , ((origin.y) + (fImage.getHeight(Module03.ImageFigure.this)))));
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        fDisplayBox = new java.awt.Rectangle(origin);
        fDisplayBox.add(corner);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.ImageFigure.this, handles);
        return new Module06.HandleEnumerator(handles);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(fDisplayBox.x , fDisplayBox.y , fDisplayBox.width , fDisplayBox.height);
    }

    protected void basicMoveBy(int x, int y) {
        fDisplayBox.translate(x, y);
    }

    public void draw(java.awt.Graphics g) {
        if ((fImage) == null) {
            fImage = Module01.Iconkit.instance().getImage(fFileName);
        } 
        if ((fImage) != null) {
            g.drawImage(fImage, fDisplayBox.x, fDisplayBox.y, fDisplayBox.width, fDisplayBox.height, Module03.ImageFigure.this);
        } else {
            drawGhost(g);
        }
    }

    private void drawGhost(java.awt.Graphics g) {
        g.setColor(java.awt.Color.gray);
        g.fillRect(fDisplayBox.x, fDisplayBox.y, fDisplayBox.width, fDisplayBox.height);
    }

    public boolean imageUpdate(java.awt.Image img, int flags, int x, int y, int w, int h) {
        if ((flags & ((java.awt.image.ImageObserver.FRAMEBITS) | (java.awt.image.ImageObserver.ALLBITS))) != 0) {
            invalidate();
            if ((listener()) != null) {
                listener().figureRequestUpdate(new Module03.FigureChangeEvent(Module03.ImageFigure.this));
            } 
        } 
        return (flags & ((java.awt.image.ImageObserver.ALLBITS) | (java.awt.image.ImageObserver.ABORT))) == 0;
    }

    public void release() {
        fImage.flush();
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fDisplayBox.x);
        dw.writeInt(fDisplayBox.y);
        dw.writeInt(fDisplayBox.width);
        dw.writeInt(fDisplayBox.height);
        dw.writeString(fFileName);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fDisplayBox = new java.awt.Rectangle(dr.readInt() , dr.readInt() , dr.readInt() , dr.readInt());
        fFileName = dr.readString();
        Module01.Iconkit.instance().registerImage(fFileName);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        Module01.Iconkit.instance().registerImage(fFileName);
        fImage = null;
    }
}


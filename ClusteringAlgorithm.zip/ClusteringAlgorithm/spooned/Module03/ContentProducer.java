package Module03;


public interface ContentProducer extends Module03.Storable {
    public static final java.lang.String ENTITY_FIGURE_POSX = "FigurePosX";

    public static final java.lang.String ENTITY_FIGURE_POSY = "FigurePosY";

    public static final java.lang.String ENTITY_FIGURE_WIDTH = "FigureWidth";

    public static final java.lang.String ENTITY_FIGURE_HEIGHT = "FigureHeight";

    public static final java.lang.String ENTITY_FRAME_COLOR = "FrameColor";

    public static final java.lang.String ENTITY_FILL_COLOR = "FillColor";

    public static final java.lang.String ENTITY_ARROW_MODE = "ArrowMode";

    public static final java.lang.String ENTITY_FONT_NAME = "FontName";

    public static final java.lang.String ENTITY_FONT_SIZE = "FontSize";

    public static final java.lang.String ENTITY_FONT_STYLE = "FontStyle";

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue);
}


package Module03;


public interface Locator extends Module03.Storable , java.io.Serializable , java.lang.Cloneable {
    public java.awt.Point locate(Module03.Figure owner);
}


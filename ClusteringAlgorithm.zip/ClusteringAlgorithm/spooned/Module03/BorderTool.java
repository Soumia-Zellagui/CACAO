package Module03;


public class BorderTool extends Module03.ActionTool {
    public BorderTool(Module01.DrawingEditor editor) {
        super(editor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setView(((Module03.DrawingView)(e.getSource())));
        if (((e.getModifiers()) & (java.awt.event.InputEvent.CTRL_MASK)) == 0) {
            super.mouseDown(e, x, y);
        } else {
            Module03.Figure target = drawing().findFigure(x, y);
            if ((target != null) && (target != (target.getDecoratedFigure()))) {
                view().addToSelection(target);
                reverseAction(target);
            } 
        }
    }

    public void action(Module03.Figure figure) {
        setUndoActivity(createUndoActivity());
        java.util.List l = Module06.CollectionsFactory.current().createList();
        l.add(figure);
        l.add(new Module03.BorderDecorator(figure));
        getUndoActivity().setAffectedFigures(new Module03.FigureEnumerator(l));
        ((Module03.BorderTool.UndoActivity)(getUndoActivity())).replaceAffectedFigures();
    }

    public void reverseAction(Module03.Figure figure) {
        setUndoActivity(createUndoActivity());
        java.util.List l = Module06.CollectionsFactory.current().createList();
        l.add(figure);
        l.add(((Module03.DecoratorFigure)(figure)).peelDecoration());
        getUndoActivity().setAffectedFigures(new Module03.FigureEnumerator(l));
        ((Module03.BorderTool.UndoActivity)(getUndoActivity())).replaceAffectedFigures();
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module03.BorderTool.UndoActivity(view());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            return replaceAffectedFigures();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            getDrawingView().clearSelection();
            return replaceAffectedFigures();
        }

        public boolean replaceAffectedFigures() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.Figure oldFigure = fe.nextFigure();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.Figure replaceFigure = fe.nextFigure();
            replaceFigure = getDrawingView().drawing().replace(oldFigure, replaceFigure);
            java.util.List l = Module06.CollectionsFactory.current().createList();
            l.add(replaceFigure);
            l.add(oldFigure);
            setAffectedFigures(new Module03.FigureEnumerator(l));
            return true;
        }
    }
}


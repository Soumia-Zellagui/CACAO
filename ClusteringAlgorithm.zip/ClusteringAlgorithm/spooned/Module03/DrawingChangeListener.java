package Module03;


public interface DrawingChangeListener {
    public void drawingInvalidated(Module06.DrawingChangeEvent e);

    public void drawingTitleChanged(Module06.DrawingChangeEvent e);

    public void drawingRequestUpdate(Module06.DrawingChangeEvent e);
}


package Module03;


public interface Layoutable extends Module03.Figure {
    public void layout();

    public void setLayouter(Module03.Layouter newLayouter);

    public Module03.Layouter getLayouter();
}


package Module03;


public class HTMLLayouter implements Module03.Layouter {
    public HTMLLayouter() {
    }

    public HTMLLayouter(Module03.Layoutable newLayoutable) {
        this();
    }

    public java.awt.Rectangle calculateLayout(java.awt.Point origin, java.awt.Point corner) {
        throw new java.lang.UnsupportedOperationException("Method calculateLayout() not yet implemented.");
    }

    public java.awt.Rectangle layout(java.awt.Point origin, java.awt.Point corner) {
        throw new java.lang.UnsupportedOperationException("Method layout() not yet implemented.");
    }

    public void setInsets(java.awt.Insets newInsets) {
        throw new java.lang.UnsupportedOperationException("Method setInsets() not yet implemented.");
    }

    public java.awt.Insets getInsets() {
        throw new java.lang.UnsupportedOperationException("Method getInsets() not yet implemented.");
    }

    public void write(Module06.StorableOutput dw) {
        throw new java.lang.UnsupportedOperationException("Method write() not yet implemented.");
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        throw new java.lang.UnsupportedOperationException("Method read() not yet implemented.");
    }

    public Module03.Layouter create(Module03.Layoutable newLayoutable) {
        Module03.HTMLLayouter htmlLayouter = new Module03.HTMLLayouter(newLayoutable);
        return htmlLayouter;
    }
}


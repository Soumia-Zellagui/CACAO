package Module03;


public class FigureAndEnumerator implements Module03.FigureEnumeration {
    private Module03.FigureEnumeration myFE1;

    private Module03.FigureEnumeration myFE2;

    public FigureAndEnumerator(Module03.FigureEnumeration newFE1 ,Module03.FigureEnumeration newFE2) {
        myFE1 = newFE1;
        myFE2 = newFE2;
    }

    public Module03.Figure nextFigure() {
        if (myFE1.hasNextFigure()) {
            return myFE1.nextFigure();
        } else if (myFE2.hasNextFigure()) {
            return myFE2.nextFigure();
        } else {
            return null;
        }
    }

    public boolean hasNextFigure() {
        return (myFE1.hasNextFigure()) || (myFE2.hasNextFigure());
    }

    public void reset() {
        myFE1.reset();
        myFE2.reset();
    }
}


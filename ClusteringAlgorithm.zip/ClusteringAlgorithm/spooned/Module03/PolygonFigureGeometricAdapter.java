package Module03;


public class PolygonFigureGeometricAdapter extends Module03.PolygonFigure implements Module03.GeometricFigure {
    public PolygonFigureGeometricAdapter() {
        super();
    }

    public PolygonFigureGeometricAdapter(int x ,int y) {
        super(x, y);
    }

    public PolygonFigureGeometricAdapter(java.awt.Polygon p) {
        super(p);
    }

    public java.awt.Shape getShape() {
        return getInternalPolygon();
    }
}


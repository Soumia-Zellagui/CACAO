package Module03;


public class DNDFiguresTransferable implements java.awt.datatransfer.Transferable , java.io.Serializable {
    public static java.awt.datatransfer.DataFlavor DNDFiguresFlavor = new java.awt.datatransfer.DataFlavor(Module03.DNDFigures.class , "DNDFigures");

    private java.lang.Object o;

    public DNDFiguresTransferable(java.lang.Object newObject) {
        o = newObject;
    }

    public java.awt.datatransfer.DataFlavor[] getTransferDataFlavors() {
        return new java.awt.datatransfer.DataFlavor[]{ Module03.DNDFiguresTransferable.DNDFiguresFlavor };
    }

    public boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor flavor) {
        return flavor.equals(Module03.DNDFiguresTransferable.DNDFiguresFlavor);
    }

    public java.lang.Object getTransferData(java.awt.datatransfer.DataFlavor flavor) throws java.awt.datatransfer.UnsupportedFlavorException, java.io.IOException {
        if ((isDataFlavorSupported(flavor)) == false) {
            throw new java.awt.datatransfer.UnsupportedFlavorException(flavor);
        } 
        return o;
    }
}


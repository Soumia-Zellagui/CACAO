package Module03;


public class ChopDiamondConnector extends Module03.ChopBoxConnector {
    private static final long serialVersionUID = -1461450322512395462L;

    public ChopDiamondConnector() {
    }

    public ChopDiamondConnector(Module03.Figure owner) {
        super(owner);
    }

    protected java.awt.Point chop(Module03.Figure target, java.awt.Point from) {
        java.awt.Rectangle r = target.displayBox();
        java.awt.Point c1 = new java.awt.Point(((r.x) + ((r.width) / 2)) , ((r.y) + ((r.height) / 2)));
        java.awt.Point p2 = new java.awt.Point(((r.x) + ((r.width) / 2)) , ((r.y) + (r.height)));
        java.awt.Point p4 = new java.awt.Point(((r.x) + ((r.width) / 2)) , r.y);
        if (r.contains(from)) {
            if (((from.y) > (r.y)) && ((from.y) < ((r.y) + ((r.height) / 2)))) {
                return p2;
            } else {
                return p4;
            }
        } 
        double ang = Module06.Geom.pointToAngle(r, from);
        java.awt.Point p1 = new java.awt.Point(((r.x) + (r.width)) , ((r.y) + ((r.height) / 2)));
        java.awt.Point p3 = new java.awt.Point(r.x , ((r.y) + ((r.height) / 2)));
        java.awt.Point rp = null;
        if ((ang > 0) && (ang < 1.57)) {
            rp = Module06.Geom.intersect(p1.x, p1.y, p2.x, p2.y, c1.x, c1.y, from.x, from.y);
        } else if ((ang > 1.575) && (ang < 3.14)) {
            rp = Module06.Geom.intersect(p2.x, p2.y, p3.x, p3.y, c1.x, c1.y, from.x, from.y);
        } else if ((ang > (-3.14)) && (ang < (-1.575))) {
            rp = Module06.Geom.intersect(p3.x, p3.y, p4.x, p4.y, c1.x, c1.y, from.x, from.y);
        } else if ((ang > (-1.57)) && (ang < 0)) {
            rp = Module06.Geom.intersect(p4.x, p4.y, p1.x, p1.y, c1.x, c1.y, from.x, from.y);
        } 
        if (rp == null) {
            rp = Module06.Geom.angleToPoint(r, ang);
        } 
        return rp;
    }
}


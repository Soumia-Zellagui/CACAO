package Module03;


public final class ReverseFigureEnumerator implements Module03.FigureEnumeration {
    private java.util.Iterator myIterator;

    private java.util.List myInitialList;

    public ReverseFigureEnumerator(java.util.List l) {
        myInitialList = l;
        reset();
    }

    public boolean hasNextFigure() {
        return myIterator.hasNext();
    }

    public Module03.Figure nextFigure() {
        return ((Module03.Figure)(myIterator.next()));
    }

    public void reset() {
        myIterator = new Module06.ReverseListEnumerator(myInitialList);
    }
}


package Module03;


public class LineConnection extends Module03.PolyLineFigure implements Module03.ConnectionFigure {
    protected Module03.Connector myStartConnector;

    protected Module03.Connector myEndConnector;

    private static final long serialVersionUID = 6883731614578414801L;

    private int lineConnectionSerializedDataVersion = 1;

    public LineConnection() {
        super(4);
        setStartDecoration(new Module03.ArrowTip());
        setEndDecoration(new Module03.ArrowTip());
    }

    public boolean canConnect() {
        return false;
    }

    protected void basicMoveBy(int dx, int dy) {
        for (int i = 1 ; i < ((fPoints.size()) - 1) ; i++) {
            pointAt(i).translate(dx, dy);
        }
        updateConnection();
    }

    public void connectStart(Module03.Connector newStartConnector) {
        setStartConnector(newStartConnector);
        if (newStartConnector != null) {
            startFigure().addDependendFigure(Module03.LineConnection.this);
            startFigure().addFigureChangeListener(Module03.LineConnection.this);
        } 
    }

    public void connectEnd(Module03.Connector newEndConnector) {
        setEndConnector(newEndConnector);
        if (newEndConnector != null) {
            endFigure().addDependendFigure(Module03.LineConnection.this);
            endFigure().addFigureChangeListener(Module03.LineConnection.this);
            handleConnect(startFigure(), endFigure());
        } 
    }

    public void disconnectStart() {
        startFigure().removeFigureChangeListener(Module03.LineConnection.this);
        startFigure().removeDependendFigure(Module03.LineConnection.this);
        setStartConnector(null);
    }

    public void disconnectEnd() {
        handleDisconnect(startFigure(), endFigure());
        endFigure().removeFigureChangeListener(Module03.LineConnection.this);
        endFigure().removeDependendFigure(Module03.LineConnection.this);
        setEndConnector(null);
    }

    public boolean connectsSame(Module03.ConnectionFigure other) {
        return ((other.getStartConnector()) == (getStartConnector())) && ((other.getEndConnector()) == (getEndConnector()));
    }

    protected void handleDisconnect(Module03.Figure start, Module03.Figure end) {
    }

    protected void handleConnect(Module03.Figure start, Module03.Figure end) {
    }

    public Module03.Figure startFigure() {
        if ((getStartConnector()) != null) {
            return getStartConnector().owner();
        } 
        return null;
    }

    public Module03.Figure endFigure() {
        if ((getEndConnector()) != null) {
            return getEndConnector().owner();
        } 
        return null;
    }

    protected void setStartConnector(Module03.Connector newStartConnector) {
        myStartConnector = newStartConnector;
    }

    public Module03.Connector getStartConnector() {
        return myStartConnector;
    }

    protected void setEndConnector(Module03.Connector newEndConnector) {
        myEndConnector = newEndConnector;
    }

    public Module03.Connector getEndConnector() {
        return myEndConnector;
    }

    public boolean canConnect(Module03.Figure start, Module03.Figure end) {
        return true;
    }

    public void startPoint(int x, int y) {
        willChange();
        if ((fPoints.size()) == 0) {
            fPoints.add(new java.awt.Point(x , y));
        } else {
            fPoints.set(0, new java.awt.Point(x , y));
        }
        changed();
    }

    public void endPoint(int x, int y) {
        willChange();
        if ((fPoints.size()) < 2) {
            fPoints.add(new java.awt.Point(x , y));
        } else {
            fPoints.set(((fPoints.size()) - 1), new java.awt.Point(x , y));
        }
        changed();
    }

    public java.awt.Point startPoint() {
        java.awt.Point p = pointAt(0);
        return new java.awt.Point(p.x , p.y);
    }

    public java.awt.Point endPoint() {
        if ((fPoints.size()) > 0) {
            java.awt.Point p = pointAt(((fPoints.size()) - 1));
            return new java.awt.Point(p.x , p.y);
        } else {
            return null;
        }
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList(fPoints.size());
        handles.add(new Module05.ChangeConnectionStartHandle(Module03.LineConnection.this));
        for (int i = 1 ; i < ((fPoints.size()) - 1) ; i++) {
            handles.add(new Module05.PolyLineHandle(Module03.LineConnection.this , Module03.PolyLineFigure.locator(i) , i));
        }
        handles.add(new Module05.ChangeConnectionEndHandle(Module03.LineConnection.this));
        return new Module06.HandleEnumerator(handles);
    }

    public void setPointAt(java.awt.Point p, int i) {
        super.setPointAt(p, i);
        layoutConnection();
    }

    public void insertPointAt(java.awt.Point p, int i) {
        super.insertPointAt(p, i);
        layoutConnection();
    }

    public void removePointAt(int i) {
        super.removePointAt(i);
        layoutConnection();
    }

    public void updateConnection() {
        if ((getStartConnector()) != null) {
            java.awt.Point start = getStartConnector().findStart(Module03.LineConnection.this);
            if (start != null) {
                startPoint(start.x, start.y);
            } 
        } 
        if ((getEndConnector()) != null) {
            java.awt.Point end = getEndConnector().findEnd(Module03.LineConnection.this);
            if (end != null) {
                endPoint(end.x, end.y);
            } 
        } 
    }

    public void layoutConnection() {
        updateConnection();
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        updateConnection();
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
    }

    public void release() {
        super.release();
        handleDisconnect(startFigure(), endFigure());
        if ((getStartConnector()) != null) {
            startFigure().removeFigureChangeListener(Module03.LineConnection.this);
            startFigure().removeDependendFigure(Module03.LineConnection.this);
        } 
        if ((getEndConnector()) != null) {
            endFigure().removeFigureChangeListener(Module03.LineConnection.this);
            endFigure().removeDependendFigure(Module03.LineConnection.this);
        } 
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getStartConnector());
        dw.writeStorable(getEndConnector());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        Module03.Connector start = ((Module03.Connector)(dr.readStorable()));
        if (start != null) {
            connectStart(start);
        } 
        Module03.Connector end = ((Module03.Connector)(dr.readStorable()));
        if (end != null) {
            connectEnd(end);
        } 
        if ((start != null) && (end != null)) {
            updateConnection();
        } 
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((getStartConnector()) != null) {
            connectStart(getStartConnector());
        } 
        if ((getEndConnector()) != null) {
            connectEnd(getEndConnector());
        } 
    }

    public void visit(Module03.FigureVisitor visitor) {
        visitor.visitFigure(Module03.LineConnection.this);
    }

    public void removeFromContainer(Module03.FigureChangeListener c) {
        super.removeFromContainer(c);
        release();
    }
}


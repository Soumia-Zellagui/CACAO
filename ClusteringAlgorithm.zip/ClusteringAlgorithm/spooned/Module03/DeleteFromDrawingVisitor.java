package Module03;


public class DeleteFromDrawingVisitor implements Module03.FigureVisitor {
    private java.util.Set myDeletedFigures;

    private Module03.Drawing myDrawing;

    public DeleteFromDrawingVisitor(Module03.Drawing newDrawing) {
        myDeletedFigures = Module06.CollectionsFactory.current().createSet();
        setDrawing(newDrawing);
    }

    private void setDrawing(Module03.Drawing newDrawing) {
        myDrawing = newDrawing;
    }

    protected Module03.Drawing getDrawing() {
        return myDrawing;
    }

    public void visitFigure(Module03.Figure hostFigure) {
        if ((!(myDeletedFigures.contains(hostFigure))) && (getDrawing().containsFigure(hostFigure))) {
            Module03.Figure orphanedFigure = getDrawing().orphan(hostFigure);
            myDeletedFigures.add(orphanedFigure);
        } 
    }

    public void visitHandle(Module05.Handle hostHandle) {
    }

    public void visitFigureChangeListener(Module03.FigureChangeListener hostFigureChangeListener) {
    }

    public Module03.FigureEnumeration getDeletedFigures() {
        Module03.FigureEnumerator fr = new Module03.FigureEnumerator(myDeletedFigures);
        return fr;
    }
}


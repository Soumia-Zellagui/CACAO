package Module03;


public class EllipseFigureGeometricAdapter extends Module03.EllipseFigure implements Module03.GeometricFigure {
    public EllipseFigureGeometricAdapter() {
        super();
    }

    public EllipseFigureGeometricAdapter(java.awt.Point origin ,java.awt.Point corner) {
        super(origin, corner);
    }

    public java.awt.Shape getShape() {
        java.awt.Rectangle rect = displayBox();
        java.awt.geom.Ellipse2D.Float ellipse = new java.awt.geom.Ellipse2D.Float(rect.x , rect.y , rect.width , rect.height);
        return ellipse;
    }
}


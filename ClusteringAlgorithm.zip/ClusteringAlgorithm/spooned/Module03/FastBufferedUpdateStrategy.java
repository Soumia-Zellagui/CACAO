package Module03;


public class FastBufferedUpdateStrategy implements Module03.Painter {
    private java.awt.image.BufferedImage _doubleBufferedImage;

    private java.awt.image.BufferedImage _scratchPadBufferedImage;

    private int _nImageWidth = 0;

    private int _nImageHeight = 0;

    private boolean _bRedrawAll = true;

    public FastBufferedUpdateStrategy() {
    }

    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
        _checkCaches(view);
        if ((_bRedrawAll) == true) {
            java.awt.Graphics imageGraphics = _doubleBufferedImage.getGraphics();
            view.drawAll(imageGraphics);
        } else {
            java.awt.Rectangle viewClipRectangle = g.getClipBounds();
            int nX1 = viewClipRectangle.x;
            int nY1 = viewClipRectangle.y;
            int nX2 = (viewClipRectangle.x) + (viewClipRectangle.width);
            int nY2 = (viewClipRectangle.y) + (viewClipRectangle.height);
            if (nX1 < 0) {
                nX1 = 0;
            } 
            if (nY1 < 0) {
                nY1 = 0;
            } 
            if (nX2 < 0) {
                nX2 = 0;
            } 
            if (nY2 < 0) {
                nY2 = 0;
            } 
            java.awt.Rectangle viewClipRectangle2 = new java.awt.Rectangle(nX1 , nY1 , (nX2 - nX1) , (nY2 - nY1));
            Module03.Drawing theDrawing = view.drawing();
            Module03.FigureEnumeration fe = theDrawing.figures(viewClipRectangle2);
            java.awt.Graphics imageGraphics = _scratchPadBufferedImage.getGraphics();
            imageGraphics.setColor(view.getBackground());
            imageGraphics.fillRect(nX1, nY1, (nX2 - nX1), (nY2 - nY1));
            view.draw(imageGraphics, fe);
            java.awt.Graphics dbGraphics = _doubleBufferedImage.getGraphics();
            dbGraphics.drawImage(_scratchPadBufferedImage, nX1, nY1, nX2, nY2, nX1, nY1, nX2, nY2, view);
        }
        g.drawImage(_doubleBufferedImage, 0, 0, view);
        _bRedrawAll = false;
    }

    private void _checkCaches(Module03.DrawingView view) {
        java.awt.Dimension d = view.getSize();
        if ((((_doubleBufferedImage) == null) || ((_nImageWidth) != (d.width))) || ((_nImageHeight) != (d.height))) {
            _doubleBufferedImage = new java.awt.image.BufferedImage(d.width , d.height , java.awt.image.BufferedImage.TYPE_INT_RGB);
            _bRedrawAll = true;
        } 
        if ((((_scratchPadBufferedImage) == null) || ((_nImageWidth) != (d.width))) || ((_nImageHeight) != (d.height))) {
            _scratchPadBufferedImage = new java.awt.image.BufferedImage(d.width , d.height , java.awt.image.BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics imageGraphics = _scratchPadBufferedImage.getGraphics();
            view.drawBackground(imageGraphics);
            _bRedrawAll = true;
        } 
        _nImageWidth = d.width;
        _nImageHeight = d.height;
    }
}


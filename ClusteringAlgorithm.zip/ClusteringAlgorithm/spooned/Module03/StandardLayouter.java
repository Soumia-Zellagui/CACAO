package Module03;


public class StandardLayouter extends Module03.SimpleLayouter {
    public StandardLayouter() {
        this(null);
    }

    public StandardLayouter(Module03.Layoutable newLayoutable) {
        super(newLayoutable);
    }

    public Module03.Layouter create(Module03.Layoutable newLayoutable) {
        return new Module03.StandardLayouter(newLayoutable);
    }

    public java.awt.Rectangle calculateLayout(java.awt.Point origin, java.awt.Point corner) {
        int maxWidth = java.lang.Math.abs(((corner.x) - (origin.x)));
        int maxHeight = getInsets().top;
        Module03.FigureEnumeration fe = getLayoutable().figures();
        while (fe.hasNextFigure()) {
            Module03.Figure currentFigure = fe.nextFigure();
            java.awt.Rectangle r = null;
            if (currentFigure instanceof Module03.Layoutable) {
                Module03.Layouter layoutStrategy = ((Module03.Layoutable)(currentFigure)).getLayouter();
                r = layoutStrategy.calculateLayout(new java.awt.Point(0 , 0), new java.awt.Point(0 , 0));
            } else {
                r = new java.awt.Rectangle(currentFigure.displayBox().getBounds());
            }
            maxWidth = java.lang.Math.max(maxWidth, (((r.width) + (getInsets().left)) + (getInsets().right)));
            maxHeight += r.height;
        }
        maxHeight += getInsets().bottom;
        return new java.awt.Rectangle(origin.x , origin.y , maxWidth , maxHeight);
    }

    public java.awt.Rectangle layout(java.awt.Point origin, java.awt.Point corner) {
        java.awt.Rectangle r = calculateLayout(origin, corner);
        int maxHeight = getInsets().top;
        Module03.FigureEnumeration fe = getLayoutable().figures();
        while (fe.hasNextFigure()) {
            Module03.Figure currentFigure = fe.nextFigure();
            java.awt.Point partOrigin = new java.awt.Point(((r.x) + (getInsets().left)) , ((r.y) + maxHeight));
            java.awt.Point partCorner = new java.awt.Point((((r.x) + (r.width)) - (getInsets().right)) , (((r.y) + maxHeight) + (currentFigure.displayBox().height)));
            currentFigure.displayBox(partOrigin, partCorner);
            maxHeight += currentFigure.displayBox().height;
        }
        return new java.awt.Rectangle(r.x , r.y , r.width , (maxHeight + (getInsets().bottom)));
    }
}


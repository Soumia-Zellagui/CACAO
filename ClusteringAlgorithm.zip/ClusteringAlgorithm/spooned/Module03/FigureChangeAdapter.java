package Module03;


public class FigureChangeAdapter implements Module03.FigureChangeListener {
    public void figureInvalidated(Module03.FigureChangeEvent e) {
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
    }
}


package Module03;


public interface DrawingView extends Module03.DrawingChangeListener , java.awt.image.ImageObserver {
    public void setEditor(Module01.DrawingEditor editor);

    public Module03.Tool tool();

    public Module03.Drawing drawing();

    public void setDrawing(Module03.Drawing d);

    public Module01.DrawingEditor editor();

    public Module03.Figure add(Module03.Figure figure);

    public Module03.Figure remove(Module03.Figure figure);

    public void addAll(java.util.Collection figures);

    public java.awt.Dimension getSize();

    public java.awt.Dimension getMinimumSize();

    public java.awt.Dimension getPreferredSize();

    public void setDisplayUpdate(Module03.Painter updateStrategy);

    public Module03.Painter getDisplayUpdate();

    public Module03.FigureEnumeration selection();

    public Module03.FigureEnumeration selectionZOrdered();

    public int selectionCount();

    public boolean isFigureSelected(Module03.Figure checkFigure);

    public void addToSelection(Module03.Figure figure);

    public void addToSelectionAll(java.util.Collection figures);

    public void addToSelectionAll(Module03.FigureEnumeration fe);

    public void removeFromSelection(Module03.Figure figure);

    public void toggleSelection(Module03.Figure figure);

    public void clearSelection();

    public Module03.FigureSelection getFigureSelection();

    public Module05.Handle findHandle(int x, int y);

    public java.awt.Point lastClick();

    public void setConstrainer(Module06.PointConstrainer p);

    public Module06.PointConstrainer getConstrainer();

    public void checkDamage();

    public void repairDamage();

    public void paint(java.awt.Graphics g);

    public java.awt.Image createImage(int width, int height);

    public java.awt.Graphics getGraphics();

    public java.awt.Color getBackground();

    public void setBackground(java.awt.Color c);

    public void drawAll(java.awt.Graphics g);

    public void draw(java.awt.Graphics g, Module03.FigureEnumeration fe);

    public void drawHandles(java.awt.Graphics g);

    public void drawDrawing(java.awt.Graphics g);

    public void drawBackground(java.awt.Graphics g);

    public void setCursor(Module06.Cursor c);

    public void freezeView();

    public void unfreezeView();

    public void addFigureSelectionListener(Module01.FigureSelectionListener fsl);

    public void removeFigureSelectionListener(Module01.FigureSelectionListener fsl);

    public Module03.FigureEnumeration getConnectionFigures(Module03.Figure inFigure);

    public Module03.FigureEnumeration insertFigures(Module03.FigureEnumeration inFigures, int dx, int dy, boolean bCheck);

    public boolean isInteractive();
}


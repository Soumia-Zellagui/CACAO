package Module03;


public abstract class AttributeFigure extends Module03.AbstractFigure {
    private Module06.FigureAttributes fAttributes;

    private static Module06.FigureAttributes fgDefaultAttributes = null;

    private static final long serialVersionUID = -10857585979273442L;

    private int attributeFigureSerializedDataVersion = 1;

    protected AttributeFigure() {
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Color fill = getFillColor();
        if (!(Module06.ColorMap.isTransparent(fill))) {
            g.setColor(fill);
            drawBackground(g);
        } 
        java.awt.Color frame = getFrameColor();
        if (!(Module06.ColorMap.isTransparent(frame))) {
            g.setColor(frame);
            drawFrame(g);
        } 
    }

    protected void drawBackground(java.awt.Graphics g) {
    }

    protected void drawFrame(java.awt.Graphics g) {
    }

    public java.awt.Color getFillColor() {
        return ((java.awt.Color)(getAttribute(Module06.FigureAttributeConstant.FILL_COLOR)));
    }

    public java.awt.Color getFrameColor() {
        return ((java.awt.Color)(getAttribute(Module06.FigureAttributeConstant.FRAME_COLOR)));
    }

    private static void initializeAttributes() {
        Module03.AttributeFigure.fgDefaultAttributes = new Module06.FigureAttributes();
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.FRAME_COLOR, java.awt.Color.black);
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.FILL_COLOR, new java.awt.Color(7396243));
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.TEXT_COLOR, java.awt.Color.black);
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.ARROW_MODE, new java.lang.Integer(0));
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.FONT_NAME, "Helvetica");
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.FONT_SIZE, new java.lang.Integer(12));
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.FONT_STYLE, new java.lang.Integer(java.awt.Font.PLAIN));
    }

    public static java.lang.Object setDefaultAttribute(java.lang.String name, java.lang.Object value) {
        java.lang.Object currentValue = Module03.AttributeFigure.getDefaultAttribute(name);
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.getConstant(name), value);
        return currentValue;
    }

    public static java.lang.Object initDefaultAttribute(java.lang.String name, java.lang.Object value) {
        java.lang.Object currentValue = Module03.AttributeFigure.getDefaultAttribute(name);
        if (currentValue != null) {
            return currentValue;
        } 
        Module03.AttributeFigure.fgDefaultAttributes.set(Module06.FigureAttributeConstant.getConstant(name), value);
        return null;
    }

    public static java.lang.Object getDefaultAttribute(java.lang.String name) {
        if ((Module03.AttributeFigure.fgDefaultAttributes) == null) {
            Module03.AttributeFigure.initializeAttributes();
        } 
        return Module03.AttributeFigure.fgDefaultAttributes.get(Module06.FigureAttributeConstant.getConstant(name));
    }

    public static java.lang.Object getDefaultAttribute(Module06.FigureAttributeConstant attributeConstant) {
        if ((Module03.AttributeFigure.fgDefaultAttributes) == null) {
            Module03.AttributeFigure.initializeAttributes();
        } 
        return Module03.AttributeFigure.fgDefaultAttributes.get(attributeConstant);
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return getAttribute(Module06.FigureAttributeConstant.getConstant(name));
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        if ((fAttributes) != null) {
            if (fAttributes.hasDefined(attributeConstant)) {
                return fAttributes.get(attributeConstant);
            } 
        } 
        return Module03.AttributeFigure.getDefaultAttribute(attributeConstant);
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        setAttribute(Module06.FigureAttributeConstant.getConstant(name), value);
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        if ((fAttributes) == null) {
            fAttributes = new Module06.FigureAttributes();
        } 
        fAttributes.set(attributeConstant, value);
        changed();
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        if ((fAttributes) == null) {
            dw.writeString("no_attributes");
        } else {
            dw.writeString("attributes");
            fAttributes.write(dw);
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        java.lang.String s = dr.readString();
        if (s.toLowerCase().equals("attributes")) {
            fAttributes = new Module06.FigureAttributes();
            fAttributes.read(dr);
        } 
    }

    private void writeObject(java.io.ObjectOutputStream o) throws java.io.IOException {
        java.lang.Object associatedMenu = getAttribute(Module03.Figure.POPUP_MENU);
        if (associatedMenu != null) {
            setAttribute(Module03.Figure.POPUP_MENU, null);
        } 
        o.defaultWriteObject();
        if (associatedMenu != null) {
            setAttribute(Module03.Figure.POPUP_MENU, associatedMenu);
        } 
    }
}


package Module03;


public class ResourceContentProducer extends Module03.AbstractContentProducer implements java.io.Serializable {
    private java.lang.String fResourceName;

    public ResourceContentProducer() {
    }

    public ResourceContentProducer(java.lang.String resourceName) {
        setResourceName(resourceName);
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        try {
            java.lang.String resourceName = (getResourceName()) != null ? getResourceName() : ((java.lang.String)(ctxAttrValue));
            java.io.InputStream reader = Module03.ResourceContentProducer.this.getClass().getResourceAsStream(resourceName);
            int available = reader.available();
            byte[] contents = new byte[available];
            reader.read(contents, 0, available);
            reader.close();
            return new java.lang.String(contents);
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            return ex.toString();
        }
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeString(getResourceName());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        setResourceName(dr.readString());
    }

    public java.lang.String getResourceName() {
        return fResourceName;
    }

    protected void setResourceName(java.lang.String newResourceName) {
        fResourceName = newResourceName;
    }
}


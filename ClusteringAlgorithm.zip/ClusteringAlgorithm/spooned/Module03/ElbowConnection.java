package Module03;


public class ElbowConnection extends Module03.LineConnection {
    private static final long serialVersionUID = 2193968743082078559L;

    private int elbowConnectionSerializedDataVersion = 1;

    public ElbowConnection() {
        super();
    }

    public void updateConnection() {
        super.updateConnection();
        updatePoints();
    }

    public void layoutConnection() {
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList(((fPoints.size()) * 2));
        handles.add(new Module05.ChangeConnectionStartHandle(Module03.ElbowConnection.this));
        for (int i = 1 ; i < ((fPoints.size()) - 1) ; i++) {
            handles.add(new Module05.NullHandle(Module03.ElbowConnection.this , Module03.PolyLineFigure.locator(i)));
        }
        handles.add(new Module05.ChangeConnectionEndHandle(Module03.ElbowConnection.this));
        for (int i = 0 ; i < ((fPoints.size()) - 1) ; i++) {
            handles.add(new Module05.ElbowHandle(Module03.ElbowConnection.this , i));
        }
        return new Module06.HandleEnumerator(handles);
    }

    public Module03.Locator connectedTextLocator(Module03.Figure f) {
        return new Module03.ElbowTextLocator();
    }

    protected void updatePoints() {
        willChange();
        java.awt.Point start = startPoint();
        java.awt.Point end = endPoint();
        fPoints.clear();
        fPoints.add(start);
        if (((start.x) == (end.x)) || ((start.y) == (end.y))) {
            fPoints.add(end);
        } else {
            java.awt.Rectangle r1 = getStartConnector().owner().displayBox();
            java.awt.Rectangle r2 = getEndConnector().owner().displayBox();
            int dir = Module06.Geom.direction(((r1.x) + ((r1.width) / 2)), ((r1.y) + ((r1.height) / 2)), ((r2.x) + ((r2.width) / 2)), ((r2.y) + ((r2.height) / 2)));
            if ((dir == (Module06.Geom.NORTH)) || (dir == (Module06.Geom.SOUTH))) {
                fPoints.add(new java.awt.Point(start.x , (((start.y) + (end.y)) / 2)));
                fPoints.add(new java.awt.Point(end.x , (((start.y) + (end.y)) / 2)));
            } else {
                fPoints.add(new java.awt.Point((((start.x) + (end.x)) / 2) , start.y));
                fPoints.add(new java.awt.Point((((start.x) + (end.x)) / 2) , end.y));
            }
            fPoints.add(end);
        }
        changed();
    }
}


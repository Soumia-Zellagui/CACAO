package Module03;


public interface ConnectionFigure extends Module03.Figure , Module03.FigureChangeListener {
    public void connectStart(Module03.Connector start);

    public void connectEnd(Module03.Connector end);

    public void updateConnection();

    public void disconnectStart();

    public void disconnectEnd();

    public Module03.Connector getStartConnector();

    public Module03.Connector getEndConnector();

    public boolean canConnect(Module03.Figure start, Module03.Figure end);

    public boolean connectsSame(Module03.ConnectionFigure other);

    public void startPoint(int x, int y);

    public void endPoint(int x, int y);

    public java.awt.Point startPoint();

    public java.awt.Point endPoint();

    public void setPointAt(java.awt.Point p, int index);

    public java.awt.Point pointAt(int index);

    public int pointCount();

    public int splitSegment(int x, int y);

    public boolean joinSegments(int x, int y);

    public Module03.Figure startFigure();

    public Module03.Figure endFigure();
}


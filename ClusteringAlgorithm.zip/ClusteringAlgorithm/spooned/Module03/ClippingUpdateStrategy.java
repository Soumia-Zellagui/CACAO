package Module03;


public class ClippingUpdateStrategy implements Module03.Painter {
    public ClippingUpdateStrategy() {
        super();
    }

    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
        java.awt.Rectangle viewClipRectangle = g.getClipBounds();
        if (viewClipRectangle == null) {
            view.drawAll(g);
            return ;
        } 
        Module03.FigureEnumeration fe = view.drawing().figures();
        java.util.Vector v = new java.util.Vector(1000);
        while (fe.hasNextFigure()) {
            Module03.Figure fig = fe.nextFigure();
            java.awt.Rectangle r = fig.displayBox();
            if ((r.width) <= 0) {
                r.width = 1;
            } 
            if ((r.height) <= 0) {
                r.height = 1;
            } 
            if (r.intersects(viewClipRectangle)) {
                v.add(fig);
            } 
        }
        Module03.FigureEnumeration clippedFE = new Module03.FigureEnumerator(v);
        view.draw(g, clippedFE);
    }
}


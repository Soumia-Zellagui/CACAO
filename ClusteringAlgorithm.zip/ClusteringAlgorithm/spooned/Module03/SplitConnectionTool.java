package Module03;


public class SplitConnectionTool extends Module03.ConnectionTool {
    public SplitConnectionTool(Module01.DrawingEditor newDrawingEditor ,Module03.ConnectionFigure newPrototype) {
        super(newDrawingEditor, newPrototype);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setView(((Module03.DrawingView)(e.getSource())));
        int ex = e.getX();
        int ey = e.getY();
        if ((getTargetFigure()) == null) {
            setTargetFigure(findConnectableFigure(ex, ey, drawing()));
        } else {
            if ((getAddedFigure()) == null) {
                setConnection(createConnection());
                setStartConnector(findConnector(ex, ey, getTargetFigure()));
                getConnection().connectStart(getStartConnector());
                getConnection().startPoint(ex, ey);
                setAddedFigure(view().add(getConnection()));
            } 
            Module03.Figure c = findTarget(ex, ey, drawing());
            if (c != null) {
                setEndConnector(findConnector(ex, ex, c));
                Module03.ConnectionFigure config = getConnection();
                config.connectEnd(getEndConnector());
                config.endPoint(ex, ey);
                Module06.Undoable undoActivity = createUndoActivity();
                setUndoActivity(undoActivity);
                Module03.Figure fig = getAddedFigure();
                Module03.SingleFigureEnumerator singleFigureEnumerator = new Module03.SingleFigureEnumerator(fig);
                getUndoActivity().setAffectedFigures(singleFigureEnumerator);
                getConnection().updateConnection();
                init();
                editor().toolDone();
            } else {
                if ((getEndConnector()) == null) {
                    Module03.Figure tempEndFigure = new Module03.NullFigure();
                    tempEndFigure.basicDisplayBox(new java.awt.Point(ex , ey), new java.awt.Point(ex , ey));
                    Module03.NullConnector nullConnector = new Module03.NullConnector(tempEndFigure);
                    setEndConnector(nullConnector);
                    Module03.ConnectionFigure config = getConnection();
                    config.connectEnd(getEndConnector());
                    config.endPoint(ex, ey);
                    config.updateConnection();
                } else {
                    ((Module03.PolyLineFigure)(getConnection())).addPoint(ex, ey);
                }
            }
        }
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((e.getClickCount()) == 2) {
            init();
            editor().toolDone();
        } 
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
    }

    public void deactivate() {
        if ((getConnection()) != null) {
            view().remove(getConnection());
        } 
        super.deactivate();
        init();
    }

    protected void init() {
        setConnection(null);
        setStartConnector(null);
        setEndConnector(null);
        setAddedFigure(null);
        setTargetFigure(null);
    }
}


package Module03;


public class ChopPolygonConnector extends Module03.ChopBoxConnector {
    private static final long serialVersionUID = -156024908227796826L;

    public ChopPolygonConnector() {
    }

    public ChopPolygonConnector(Module03.Figure owner) {
        super(owner);
    }

    protected java.awt.Point chop(Module03.Figure target, java.awt.Point from) {
        return ((Module03.PolygonFigure)(target)).chop(from);
    }
}


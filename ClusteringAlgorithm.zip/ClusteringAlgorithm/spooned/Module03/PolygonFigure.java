package Module03;


public class PolygonFigure extends Module03.AttributeFigure {
    static final int TOO_CLOSE = 2;

    private static final long serialVersionUID = 6254089689239215026L;

    private int polygonFigureSerializedDataVersion = 1;

    private java.awt.Polygon fPoly;

    public PolygonFigure() {
        super();
        setInternalPolygon(new java.awt.Polygon());
    }

    public PolygonFigure(int x ,int y) {
        this();
        getInternalPolygon().addPoint(x, y);
    }

    public PolygonFigure(java.awt.Polygon p) {
        setInternalPolygon(new java.awt.Polygon(p.xpoints , p.ypoints , p.npoints));
    }

    public java.awt.Rectangle displayBox() {
        return Module03.PolygonFigure.bounds(getInternalPolygon());
    }

    public boolean isEmpty() {
        return ((pointCount()) < 3) || (((size().width) < (Module03.PolygonFigure.TOO_CLOSE)) && ((size().height) < (Module03.PolygonFigure.TOO_CLOSE)));
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList(pointCount());
        for (int i = 0 ; i < (pointCount()) ; i++) {
            Module05.PolygonHandle polygoneHandle = new Module05.PolygonHandle(Module03.PolygonFigure.this , Module03.PolygonFigure.locator(i) , i);
            handles.add(polygoneHandle);
        }
        Module05.PolygonScaleHandle polygonScaleHandle = new Module05.PolygonScaleHandle(Module03.PolygonFigure.this);
        handles.add(polygonScaleHandle);
        Module06.HandleEnumerator handleEnumerator = new Module06.HandleEnumerator(handles);
        return handleEnumerator;
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        java.awt.Rectangle r = displayBox();
        int dx = (origin.x) - (r.x);
        int dy = (origin.y) - (r.y);
        getInternalPolygon().translate(dx, dy);
        r = displayBox();
        java.awt.Point oldCorner = new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height)));
        scaleRotate(oldCorner, getInternalPolygon(), corner);
    }

    public java.awt.Polygon getPolygon() {
        return new java.awt.Polygon(fPoly.xpoints , fPoly.ypoints , fPoly.npoints);
    }

    public void setInternalPolygon(java.awt.Polygon newPolygon) {
        fPoly = newPolygon;
    }

    public java.awt.Polygon getInternalPolygon() {
        return fPoly;
    }

    public java.awt.Point center() {
        return Module03.PolygonFigure.center(getInternalPolygon());
    }

    public java.util.Iterator points() {
        java.util.List pts = Module06.CollectionsFactory.current().createList(pointCount());
        for (int i = 0 ; i < (pointCount()) ; ++i) {
            pts.add(new java.awt.Point(getInternalPolygon().xpoints[i] , getInternalPolygon().ypoints[i]));
        }
        return pts.iterator();
    }

    public int pointCount() {
        return getInternalPolygon().npoints;
    }

    public void basicMoveBy(int dx, int dy) {
        getInternalPolygon().translate(dx, dy);
    }

    public void drawBackground(java.awt.Graphics g) {
        g.fillPolygon(getInternalPolygon());
    }

    public void drawFrame(java.awt.Graphics g) {
        g.drawPolygon(getInternalPolygon());
    }

    public boolean containsPoint(int x, int y) {
        return getInternalPolygon().contains(x, y);
    }

    public Module03.Connector connectorAt(int x, int y) {
        Module03.ChopPolygonConnector chopPolygonConnector = new Module03.ChopPolygonConnector(Module03.PolygonFigure.this);
        return chopPolygonConnector;
    }

    public void addPoint(int x, int y) {
        getInternalPolygon().addPoint(x, y);
        changed();
    }

    public void setPointAt(java.awt.Point p, int i) {
        willChange();
        getInternalPolygon().xpoints[i] = p.x;
        getInternalPolygon().ypoints[i] = p.y;
        changed();
    }

    public void insertPointAt(java.awt.Point p, int i) {
        willChange();
        int n = (pointCount()) + 1;
        int[] xs = new int[n];
        int[] ys = new int[n];
        for (int j = 0 ; j < i ; ++j) {
            xs[j] = getInternalPolygon().xpoints[j];
            ys[j] = getInternalPolygon().ypoints[j];
        }
        xs[i] = p.x;
        ys[i] = p.y;
        for (int j = i ; j < (pointCount()) ; ++j) {
            xs[(j + 1)] = getInternalPolygon().xpoints[j];
            ys[(j + 1)] = getInternalPolygon().ypoints[j];
        }
        setInternalPolygon(new java.awt.Polygon(xs , ys , n));
        changed();
    }

    public void removePointAt(int i) {
        willChange();
        int n = (pointCount()) - 1;
        int[] xs = new int[n];
        int[] ys = new int[n];
        for (int j = 0 ; j < i ; ++j) {
            xs[j] = getInternalPolygon().xpoints[j];
            ys[j] = getInternalPolygon().ypoints[j];
        }
        for (int j = i ; j < n ; ++j) {
            xs[j] = getInternalPolygon().xpoints[(j + 1)];
            ys[j] = getInternalPolygon().ypoints[(j + 1)];
        }
        setInternalPolygon(new java.awt.Polygon(xs , ys , n));
        changed();
    }

    public void scaleRotate(java.awt.Point anchor, java.awt.Polygon originalPolygon, java.awt.Point p) {
        willChange();
        java.awt.Point ctr = Module03.PolygonFigure.center(originalPolygon);
        double anchorLen = Module06.Geom.length(ctr.x, ctr.y, anchor.x, anchor.y);
        if (anchorLen > 0.0) {
            double newLen = Module06.Geom.length(ctr.x, ctr.y, p.x, p.y);
            double ratio = newLen / anchorLen;
            double anchorAngle = java.lang.Math.atan2(((anchor.y) - (ctr.y)), ((anchor.x) - (ctr.x)));
            double newAngle = java.lang.Math.atan2(((p.y) - (ctr.y)), ((p.x) - (ctr.x)));
            double rotation = newAngle - anchorAngle;
            int n = originalPolygon.npoints;
            int[] xs = new int[n];
            int[] ys = new int[n];
            for (int i = 0 ; i < n ; ++i) {
                int x = originalPolygon.xpoints[i];
                int y = originalPolygon.ypoints[i];
                double l = (Module06.Geom.length(ctr.x, ctr.y, x, y)) * ratio;
                double a = (java.lang.Math.atan2((y - (ctr.y)), (x - (ctr.x)))) + rotation;
                xs[i] = ((int)(((ctr.x) + (l * (java.lang.Math.cos(a)))) + 0.5));
                ys[i] = ((int)(((ctr.y) + (l * (java.lang.Math.sin(a)))) + 0.5));
            }
            setInternalPolygon(new java.awt.Polygon(xs , ys , n));
        } 
        changed();
    }

    public void smoothPoints() {
        willChange();
        boolean removed = false;
        int n = pointCount();
        do {
            removed = false;
            int i = 0;
            while ((i < n) && (n >= 3)) {
                int nxt = (i + 1) % n;
                int prv = ((i - 1) + n) % n;
                if ((Module06.Geom.distanceFromLine(getInternalPolygon().xpoints[prv], getInternalPolygon().ypoints[prv], getInternalPolygon().xpoints[nxt], getInternalPolygon().ypoints[nxt], getInternalPolygon().xpoints[i], getInternalPolygon().ypoints[i])) < (Module03.PolygonFigure.TOO_CLOSE)) {
                    removed = true;
                    --n;
                    for (int j = i ; j < n ; ++j) {
                        getInternalPolygon().xpoints[j] = getInternalPolygon().xpoints[(j + 1)];
                        getInternalPolygon().ypoints[j] = getInternalPolygon().ypoints[(j + 1)];
                    }
                } else {
                    ++i;
                }
            }
        } while (removed );
        if (n != (pointCount())) {
            setInternalPolygon(new java.awt.Polygon(getInternalPolygon().xpoints , getInternalPolygon().ypoints , n));
        } 
        changed();
    }

    public int splitSegment(int x, int y) {
        int i = findSegment(x, y);
        if (i != (-1)) {
            insertPointAt(new java.awt.Point(x , y), (i + 1));
            return i + 1;
        } else {
            return -1;
        }
    }

    public java.awt.Point pointAt(int i) {
        return new java.awt.Point(getInternalPolygon().xpoints[i] , getInternalPolygon().ypoints[i]);
    }

    public java.awt.Point outermostPoint() {
        java.awt.Point ctr = center();
        int outer = 0;
        long dist = 0;
        for (int i = 0 ; i < (pointCount()) ; ++i) {
            long d = Module06.Geom.length2(ctr.x, ctr.y, getInternalPolygon().xpoints[i], getInternalPolygon().ypoints[i]);
            if (d > dist) {
                dist = d;
                outer = i;
            } 
        }
        return new java.awt.Point(getInternalPolygon().xpoints[outer] , getInternalPolygon().ypoints[outer]);
    }

    public int findSegment(int x, int y) {
        double dist = Module03.PolygonFigure.TOO_CLOSE;
        int best = -1;
        for (int i = 0 ; i < (pointCount()) ; i++) {
            int n = (i + 1) % (pointCount());
            double d = Module06.Geom.distanceFromLine(getInternalPolygon().xpoints[i], getInternalPolygon().ypoints[i], getInternalPolygon().xpoints[n], getInternalPolygon().ypoints[n], x, y);
            if (d < dist) {
                dist = d;
                best = i;
            } 
        }
        return best;
    }

    public java.awt.Point chop(java.awt.Point p) {
        return Module03.PolygonFigure.chop(getInternalPolygon(), p);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(pointCount());
        for (int i = 0 ; i < (pointCount()) ; ++i) {
            dw.writeInt(getInternalPolygon().xpoints[i]);
            dw.writeInt(getInternalPolygon().ypoints[i]);
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        int size = dr.readInt();
        int[] xs = new int[size];
        int[] ys = new int[size];
        for (int i = 0 ; i < size ; i++) {
            xs[i] = dr.readInt();
            ys[i] = dr.readInt();
        }
        setInternalPolygon(new java.awt.Polygon(xs , ys , size));
    }

    public static Module03.Locator locator(final int pointIndex) {
        Module03.AbstractLocator abstractLocator = new Module03.AbstractLocator() {
            public java.awt.Point locate(Module03.Figure owner) {
                Module03.PolygonFigure plf = ((Module03.PolygonFigure)(owner));
                if (pointIndex < (plf.pointCount())) {
                    return ((Module03.PolygonFigure)(owner)).pointAt(pointIndex);
                } 
                return new java.awt.Point((-1) , (-1));
            }
        };
        return abstractLocator;
    }

    public static java.awt.Rectangle bounds(java.awt.Polygon p) {
        int minx = java.lang.Integer.MAX_VALUE;
        int miny = java.lang.Integer.MAX_VALUE;
        int maxx = java.lang.Integer.MIN_VALUE;
        int maxy = java.lang.Integer.MIN_VALUE;
        int n = p.npoints;
        for (int i = 0 ; i < n ; i++) {
            int x = p.xpoints[i];
            int y = p.ypoints[i];
            if (x > maxx) {
                maxx = x;
            } 
            if (x < minx) {
                minx = x;
            } 
            if (y > maxy) {
                maxy = y;
            } 
            if (y < miny) {
                miny = y;
            } 
        }
        return new java.awt.Rectangle(minx , miny , (maxx - minx) , (maxy - miny));
    }

    public static java.awt.Point center(java.awt.Polygon p) {
        long sx = 0;
        long sy = 0;
        int n = p.npoints;
        for (int i = 0 ; i < n ; i++) {
            sx += p.xpoints[i];
            sy += p.ypoints[i];
        }
        return new java.awt.Point(((int)(sx / n)) , ((int)(sy / n)));
    }

    public static java.awt.Point chop(java.awt.Polygon poly, java.awt.Point p) {
        java.awt.Point ctr = Module03.PolygonFigure.center(poly);
        int cx = -1;
        int cy = -1;
        long len = java.lang.Long.MAX_VALUE;
        for (int i = 0 ; i < (poly.npoints) ; ++i) {
            int nxt = (i + 1) % (poly.npoints);
            java.awt.Point chop = Module06.Geom.intersect(poly.xpoints[i], poly.ypoints[i], poly.xpoints[nxt], poly.ypoints[nxt], p.x, p.y, ctr.x, ctr.y);
            if (chop != null) {
                long cl = Module06.Geom.length2(chop.x, chop.y, p.x, p.y);
                if (cl < len) {
                    len = cl;
                    cx = chop.x;
                    cy = chop.y;
                } 
            } 
        }
        {
            for (int i = 0 ; i < (poly.npoints) ; ++i) {
                long l = Module06.Geom.length2(poly.xpoints[i], poly.ypoints[i], p.x, p.y);
                if (l < len) {
                    len = l;
                    cx = poly.xpoints[i];
                    cy = poly.ypoints[i];
                } 
            }
        }
        return new java.awt.Point(cx , cy);
    }
}


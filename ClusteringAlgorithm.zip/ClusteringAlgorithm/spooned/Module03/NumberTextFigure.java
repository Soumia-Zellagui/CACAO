package Module03;


public class NumberTextFigure extends Module03.TextFigure {
    private static final long serialVersionUID = -4056859232918336475L;

    private int numberTextFigureSerializedDataVersion = 1;

    public int overlayColumns() {
        return java.lang.Math.max(4, getText().length());
    }

    public int getValue() {
        int value = 0;
        try {
            value = java.lang.Integer.parseInt(getText());
        } catch (java.lang.NumberFormatException e) {
            value = 0;
        }
        return value;
    }

    public void setValue(int value) {
        setText(java.lang.Integer.toString(value));
    }

    public Module03.Figure getRepresentingFigure() {
        return Module03.NumberTextFigure.this;
    }
}


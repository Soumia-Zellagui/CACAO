package Module03;


public class LocatorConnector extends Module03.AbstractConnector {
    public static final int SIZE = 8;

    private Module03.Locator myLocator;

    private static final long serialVersionUID = 5062833203337604181L;

    private int locatorConnectorSerializedDataVersion = 1;

    public LocatorConnector() {
        setLocator(null);
    }

    public LocatorConnector(Module03.Figure owner ,Module03.Locator l) {
        super(owner);
        setLocator(l);
    }

    public boolean containsPoint(int x, int y) {
        return displayBox().contains(x, y);
    }

    public java.awt.Rectangle displayBox() {
        java.awt.Point p = getLocator().locate(owner());
        return new java.awt.Rectangle(((p.x) - ((Module03.LocatorConnector.SIZE) / 2)) , ((p.y) - ((Module03.LocatorConnector.SIZE) / 2)) , Module03.LocatorConnector.SIZE , Module03.LocatorConnector.SIZE);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.blue);
        g.fillOval(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeStorable(getLocator());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        setLocator(((Module03.Locator)(dr.readStorable())));
    }

    protected void setLocator(Module03.Locator newLocator) {
        myLocator = newLocator;
    }

    public Module03.Locator getLocator() {
        return myLocator;
    }
}


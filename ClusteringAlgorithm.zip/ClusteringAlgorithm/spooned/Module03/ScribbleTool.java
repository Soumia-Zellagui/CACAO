package Module03;


public class ScribbleTool extends Module03.AbstractTool {
    private Module03.PolyLineFigure fScribble;

    private int fLastX;

    private int fLastY;

    private Module03.Figure myAddedFigure;

    public ScribbleTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void activate() {
        super.activate();
    }

    public void deactivate() {
        super.deactivate();
        if ((fScribble) != null) {
            if (((fScribble.size().width) < 4) || ((fScribble.size().height) < 4)) {
                getActiveDrawing().remove(fScribble);
                setUndoActivity(null);
            } 
            fScribble = null;
        } 
    }

    private void point(int x, int y) {
        if ((fScribble) == null) {
            fScribble = new Module03.PolyLineFigure(x , y);
            setAddedFigure(view().add(fScribble));
        } else if (((fLastX) != x) || ((fLastY) != y)) {
            fScribble.addPoint(x, y);
        } 
        fLastX = x;
        fLastY = y;
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        if ((e.getClickCount()) >= 2) {
            setUndoActivity(createUndoActivity());
            getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(getAddedFigure()));
        } else {
            point(e.getX(), e.getY());
        }
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((fScribble) != null) {
            point(e.getX(), e.getY());
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseUp(e, x, y);
        if ((e.getClickCount()) >= 2) {
            editor().toolDone();
        } 
    }

    protected Module03.Figure getAddedFigure() {
        return myAddedFigure;
    }

    private void setAddedFigure(Module03.Figure newAddedFigure) {
        myAddedFigure = newAddedFigure;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.PasteCommand.UndoActivity(view());
    }
}


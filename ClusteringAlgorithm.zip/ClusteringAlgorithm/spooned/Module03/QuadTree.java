package Module03;


class QuadTree implements java.io.Serializable {
    private java.awt.geom.Rectangle2D _absoluteBoundingRectangle2D = new java.awt.geom.Rectangle2D.Double();

    private int _nMaxTreeDepth;

    private java.util.Hashtable _theHashtable = new java.util.Hashtable();

    private java.util.Hashtable _outsideHashtable = new java.util.Hashtable();

    private Module03.QuadTree _nwQuadTree;

    private Module03.QuadTree _neQuadTree;

    private Module03.QuadTree _swQuadTree;

    private Module03.QuadTree _seQuadTree;

    public QuadTree(java.awt.geom.Rectangle2D absoluteBoundingRectangle2D) {
        _init(2, absoluteBoundingRectangle2D);
    }

    public QuadTree(int nMaxTreeDepth ,java.awt.geom.Rectangle2D absoluteBoundingRectangle2D) {
        _init(nMaxTreeDepth, absoluteBoundingRectangle2D);
    }

    public void add(java.lang.Object anObject, java.awt.geom.Rectangle2D absoluteBoundingRectangle2D) {
    }

    public java.lang.Object remove(java.lang.Object anObject) {
        java.lang.Object returnObject = _theHashtable.remove(anObject);
        if (returnObject != null) {
            return returnObject;
        } 
        if ((_nMaxTreeDepth) > 1) {
            returnObject = _nwQuadTree.remove(anObject);
            if (returnObject != null) {
                return returnObject;
            } 
            returnObject = _neQuadTree.remove(anObject);
            if (returnObject != null) {
                return returnObject;
            } 
            returnObject = _swQuadTree.remove(anObject);
            if (returnObject != null) {
                return returnObject;
            } 
            returnObject = _seQuadTree.remove(anObject);
            if (returnObject != null) {
                return returnObject;
            } 
        } 
        returnObject = _outsideHashtable.remove(anObject);
        if (returnObject != null) {
            return returnObject;
        } 
        return null;
    }

    public void clear() {
        _theHashtable.clear();
        _outsideHashtable.clear();
        if ((_nMaxTreeDepth) > 1) {
            _nwQuadTree.clear();
            _neQuadTree.clear();
            _swQuadTree.clear();
            _seQuadTree.clear();
        } 
    }

    public int getMaxTreeDepth() {
        return _nMaxTreeDepth;
    }

    public Module03.FigureEnumeration getAllWithin(java.awt.geom.Rectangle2D r) {
        java.util.List l = Module06.CollectionsFactory.current().createList();
        for (java.util.Iterator ii = _outsideHashtable.keySet().iterator() ; ii.hasNext() ; ) {
            java.lang.Object anObject = ii.next();
            java.awt.geom.Rectangle2D itsAbsoluteBoundingRectangle2D = ((java.awt.geom.Rectangle2D)(_outsideHashtable.get(anObject)));
            if (itsAbsoluteBoundingRectangle2D.intersects(r)) {
                l.add(anObject);
            } 
        }
        if (_absoluteBoundingRectangle2D.intersects(r)) {
            for (java.util.Iterator i = _theHashtable.keySet().iterator() ; i.hasNext() ; ) {
                java.lang.Object anObject = i.next();
                java.awt.geom.Rectangle2D itsAbsoluteBoundingRectangle2D = ((java.awt.geom.Rectangle2D)(_theHashtable.get(anObject)));
                if (itsAbsoluteBoundingRectangle2D.intersects(r)) {
                    l.add(anObject);
                } 
            }
            if ((_nMaxTreeDepth) > 1) {
                l.add(_nwQuadTree.getAllWithin(r));
                l.add(_neQuadTree.getAllWithin(r));
                l.add(_swQuadTree.getAllWithin(r));
                l.add(_seQuadTree.getAllWithin(r));
            } 
        } 
        return new Module03.FigureEnumerator(l);
    }

    public java.awt.geom.Rectangle2D getAbsoluteBoundingRectangle2D() {
        return _absoluteBoundingRectangle2D;
    }

    private void _init(int nMaxTreeDepth, java.awt.geom.Rectangle2D absoluteBoundingRectangle2D) {
        if ((_nMaxTreeDepth) > 1) {
        } 
    }

    private java.awt.geom.Rectangle2D _makeNorthwest(java.awt.geom.Rectangle2D r) {
        return new java.awt.geom.Rectangle2D.Double(r.getX() , r.getY() , ((r.getWidth()) / 2.0) , ((r.getHeight()) / 2.0));
    }

    private java.awt.geom.Rectangle2D _makeNortheast(java.awt.geom.Rectangle2D r) {
        return new java.awt.geom.Rectangle2D.Double(((r.getX()) + ((r.getWidth()) / 2.0)) , r.getY() , ((r.getWidth()) / 2.0) , ((r.getHeight()) / 2.0));
    }

    private java.awt.geom.Rectangle2D _makeSouthwest(java.awt.geom.Rectangle2D r) {
        return new java.awt.geom.Rectangle2D.Double(r.getX() , ((r.getY()) + ((r.getHeight()) / 2.0)) , ((r.getWidth()) / 2.0) , ((r.getHeight()) / 2.0));
    }

    private java.awt.geom.Rectangle2D _makeSoutheast(java.awt.geom.Rectangle2D r) {
        return new java.awt.geom.Rectangle2D.Double(((r.getX()) + ((r.getWidth()) / 2.0)) , ((r.getY()) + ((r.getHeight()) / 2.0)) , ((r.getWidth()) / 2.0) , ((r.getHeight()) / 2.0));
    }
}


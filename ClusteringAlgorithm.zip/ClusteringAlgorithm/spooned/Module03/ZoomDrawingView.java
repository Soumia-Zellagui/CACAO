package Module03;


public class ZoomDrawingView extends Module03.StandardDrawingView {
    private double scale = 1.0;

    private double zoomSpeed = 2.0;

    public ZoomDrawingView(Module01.DrawingEditor editor) {
        this(editor, Module03.StandardDrawingView.MINIMUM_WIDTH, Module03.StandardDrawingView.MINIMUM_HEIGHT);
    }

    public ZoomDrawingView(Module01.DrawingEditor editor ,int width ,int height) {
        super(editor, width, height);
    }

    public final double getScale() {
        return scale;
    }

    private void setScale(double newScale) {
        java.awt.Dimension oldSize = getUserSize();
        scale = newScale;
        setUserSize(oldSize.width, oldSize.height);
        centralize(drawing());
        forceRedraw();
    }

    private void forceRedraw() {
        Module03.Drawing drawing = drawing();
        Module06.DrawingChangeEvent drawingChangeEvent = new Module06.DrawingChangeEvent(drawing , new java.awt.Rectangle(getSize()));
        drawingInvalidated(drawingChangeEvent);
        repairDamage();
    }

    public void setUserSize(int width, int height) {
        setSize(((int)(width * (getScale()))), ((int)(height * (getScale()))));
    }

    public void setUserSize(java.awt.Dimension d) {
        setUserSize(d.width, d.height);
    }

    public java.awt.Dimension getSize() {
        return super.getSize();
    }

    public java.awt.Dimension getViewportSize() {
        return getParent().getSize();
    }

    protected boolean hasZoomSupport() {
        return (getParent()) instanceof javax.swing.JViewport;
    }

    public void setOriginPosition(java.awt.Point newOrigin) {
        setViewPosition(newOrigin);
        forceRedraw();
    }

    protected void setViewPosition(java.awt.Point newPosition) {
        ((javax.swing.JViewport)(getParent())).setViewPosition(newPosition);
    }

    public java.awt.Dimension getUserSize() {
        java.awt.Dimension screenSize = getSize();
        return new java.awt.Dimension(((int)((screenSize.width) / (getScale()))) , ((int)((screenSize.height) / (getScale()))));
    }

    public void zoom(int x, int y, int width, int height) {
        if (hasZoomSupport()) {
            java.awt.Dimension viewportSize = getViewportSize();
            double xScale = ((double)(viewportSize.width)) / ((double)(width));
            double yScale = ((double)(viewportSize.height)) / ((double)(height));
            double newScale = java.lang.Math.min(xScale, yScale);
            java.awt.Dimension userSize = getUserSize();
            Module03.ZoomDrawingView.this.scale = newScale;
            setUserSize(userSize);
            revalidate();
            setViewPosition(new java.awt.Point(((int)(x * (getScale()))) , ((int)(y * (getScale())))));
            forceRedraw();
        } else {
            throw new java.lang.RuntimeException("zooming only works if this view is contained in a ScrollPane");
        }
    }

    public void zoom(float newScale) {
        if (hasZoomSupport()) {
            javax.swing.JViewport viewport = ((javax.swing.JViewport)(getParent()));
            java.awt.Dimension viewportSize = viewport.getSize();
            java.awt.Dimension userSize = getUserSize();
            scale = newScale;
            java.awt.Point viewOrg = viewport.getViewPosition();
            viewOrg.x = (viewOrg.x) + ((viewportSize.width) / 2);
            viewOrg.y = (viewOrg.y) + ((viewportSize.height) / 2);
            int xScreen = ((int)((viewOrg.x) * (scale)));
            int yScreen = ((int)((viewOrg.y) * (scale)));
            int xOrigin = xScreen - ((viewportSize.width) / 2);
            int yOrigin = yScreen - ((viewportSize.height) / 2);
            if (xOrigin < 0)
                xOrigin = 0;
            
            if (yOrigin < 0)
                yOrigin = 0;
            
            setUserSize(userSize);
            revalidate();
            viewport.setViewPosition(new java.awt.Point(xOrigin , yOrigin));
            forceRedraw();
        } else {
            throw new java.lang.RuntimeException("zooming only works if this view is contained in a ScrollPane");
        }
    }

    public void zoomOut(int x, int y) {
        if (hasZoomSupport()) {
            java.awt.Dimension viewportSize = getViewportSize();
            java.awt.Dimension userSize = getUserSize();
            Module03.ZoomDrawingView.this.scale = (getScale()) / (getZoomSpeed());
            int xScreen = ((int)(x * (getScale())));
            int yScreen = ((int)(y * (getScale())));
            int xOrigin = xScreen - ((viewportSize.width) / 2);
            int yOrigin = yScreen - ((viewportSize.height) / 2);
            if (xOrigin < 0)
                xOrigin = 0;
            
            if (yOrigin < 0)
                yOrigin = 0;
            
            setUserSize(userSize);
            revalidate();
            setViewPosition(new java.awt.Point(xOrigin , yOrigin));
            forceRedraw();
        } else {
            throw new java.lang.RuntimeException("zooming only works if this view is contained in a ScrollPane");
        }
    }

    public void zoomIn(int x, int y) {
        if (hasZoomSupport()) {
            javax.swing.JViewport viewport = ((javax.swing.JViewport)(getParent()));
            java.awt.Dimension viewportSize = viewport.getSize();
            java.awt.Dimension userSize = getUserSize();
            Module03.ZoomDrawingView.this.scale = (getScale()) * (getZoomSpeed());
            int xScreen = ((int)(x * (getScale())));
            int yScreen = ((int)(y * (getScale())));
            int xOrigin = xScreen - ((viewportSize.width) / 2);
            int yOrigin = yScreen - ((viewportSize.height) / 2);
            if (xOrigin < 0)
                xOrigin = 0;
            
            if (yOrigin < 0)
                yOrigin = 0;
            
            setUserSize(userSize);
            revalidate();
            viewport.setViewPosition(new java.awt.Point(xOrigin , yOrigin));
            forceRedraw();
        } else {
            throw new java.lang.RuntimeException("zooming only works if this view is contained in a ScrollPane");
        }
    }

    public void deZoom(int x, int y) {
        if (hasZoomSupport()) {
            java.awt.Dimension viewportSize = getViewportSize();
            java.awt.Dimension userSize = getUserSize();
            int xOrigin = x - ((viewportSize.width) / 2);
            int yOrigin = y - ((viewportSize.height) / 2);
            if (xOrigin < 0)
                xOrigin = 0;
            
            if (yOrigin < 0)
                yOrigin = 0;
            
            Module03.ZoomDrawingView.this.scale = 1.0;
            setUserSize(userSize);
            revalidate();
            setViewPosition(new java.awt.Point(((int)(xOrigin)) , ((int)(yOrigin))));
            forceRedraw();
        } else {
            throw new java.lang.RuntimeException("zooming only works if this view is contained in a ScrollPane");
        }
    }

    public void paint(java.awt.Graphics g) {
        super.paint(transformGraphics(g, getScale()));
    }

    public java.awt.Graphics getGraphics() {
        return transformGraphics(super.getGraphics(), getScale());
    }

    private final java.awt.Graphics transformGraphics(java.awt.Graphics g, double currentScale) {
        if (currentScale != 1.0) {
            java.awt.Graphics2D g2 = ((java.awt.Graphics2D)(g));
            g2.transform(java.awt.geom.AffineTransform.getScaleInstance(currentScale, currentScale));
        } 
        return g;
    }

    protected java.awt.Point constrainPoint(java.awt.Point p) {
        java.awt.Dimension size = getSize();
        p.x = Module06.Geom.range(1, ((int)((size.width) / (getScale()))), p.x);
        p.y = Module06.Geom.range(1, ((int)((size.height) / (getScale()))), p.y);
        if ((getConstrainer()) != null) {
            return getConstrainer().constrainPoint(p);
        } 
        return p;
    }

    public void drawBackground(java.awt.Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0, 0, ((int)((getBounds().width) / (getScale()))), ((int)((getBounds().height) / (getScale()))));
    }

    private void centralize(Module03.Drawing d, java.awt.Dimension bounds) {
        java.awt.Point boundsCenter = new java.awt.Point(((bounds.width) / 2) , ((bounds.height) / 2));
        java.awt.Rectangle r = ((Module03.StandardDrawing)(d)).displayBox();
        java.awt.Point drawingCenter = new java.awt.Point(((r.x) + ((r.width) / 2)) , ((r.y) + ((r.height) / 2)));
        int diffX = (boundsCenter.x) - (drawingCenter.x);
        int diffY = (boundsCenter.y) - (drawingCenter.y);
        if ((diffX != 0) || (diffY != 0)) {
            for (Module03.FigureEnumeration fe = d.figures() ; fe.hasNextFigure() ; ) {
                fe.nextFigure().moveBy(diffX, diffY);
            }
        } 
    }

    private void centralize(Module03.Drawing d) {
        centralize(d, getUserSize());
    }

    public void setDrawing(Module03.Drawing d) {
        super.setDrawing(d);
        java.awt.Rectangle r = ((Module03.StandardDrawing)(d)).displayBox();
        java.awt.Dimension viewportSize = new java.awt.Dimension(r.width , r.height);
        if ((getParent()) != null) {
            viewportSize = getViewportSize();
        } 
        super.setPreferredSize(viewportSize);
        super.setSize(viewportSize);
        revalidate();
    }

    public java.awt.Dimension getMinimumSize() {
        return super.getSize();
    }

    public java.awt.Dimension getPreferredSize() {
        return getMinimumSize();
    }

    public void repairDamage() {
        java.awt.Rectangle damagedArea = getDamage();
        if (damagedArea != null) {
            repaint(((int)((damagedArea.x) * (getScale()))), ((int)((damagedArea.y) * (getScale()))), ((int)((damagedArea.width) * (getScale()))), ((int)((damagedArea.height) * (getScale()))));
            setDamage(null);
        } 
    }

    public void drawingInvalidated(Module06.DrawingChangeEvent e) {
        java.awt.Rectangle r = e.getInvalidatedRectangle();
        if ((getDamage()) == null) {
            setDamage(r);
        } else {
            java.awt.Rectangle damagedArea = getDamage();
            damagedArea.add(r);
            setDamage(damagedArea);
        }
    }

    private java.awt.event.MouseEvent createScaledEvent(java.awt.event.MouseEvent e) {
        return new java.awt.event.MouseEvent(e.getComponent() , e.getID() , e.getWhen() , e.getModifiers() , ((int)((e.getX()) / (getScale()))) , ((int)((e.getY()) / (getScale()))) , e.getClickCount() , e.isPopupTrigger());
    }

    protected Module03.StandardDrawingView.DrawingViewMouseListener createMouseListener() {
        Module03.StandardDrawingView.DrawingViewMouseListener rr = new Module03.StandardDrawingView.DrawingViewMouseListener() {
            public void mousePressed(java.awt.event.MouseEvent e) {
                super.mousePressed(createScaledEvent(e));
            }

            public void mouseReleased(java.awt.event.MouseEvent e) {
                super.mouseReleased(createScaledEvent(e));
            }
        };
        return rr;
    }

    protected Module03.StandardDrawingView.DrawingViewMouseMotionListener createMouseMotionListener() {
        Module03.StandardDrawingView.DrawingViewMouseMotionListener rr = new Module03.StandardDrawingView.DrawingViewMouseMotionListener() {
            public void mouseDragged(java.awt.event.MouseEvent e) {
                super.mouseDragged(createScaledEvent(e));
            }

            public void mouseMoved(java.awt.event.MouseEvent e) {
                super.mouseMoved(createScaledEvent(e));
            }
        };
        return rr;
    }

    protected Module03.StandardDrawingView.DrawingViewKeyListener createKeyListener() {
        Module03.StandardDrawingView.DrawingViewKeyListener t = new Module03.StandardDrawingView.DrawingViewKeyListener() {
            public void keyPressed(java.awt.event.KeyEvent e) {
                super.keyPressed(e);
                if ((e.getKeyChar()) == ' ') {
                    forceRedraw();
                } else if ((e.getKeyChar()) == 'o') {
                    setScale(((getScale()) / (getZoomSpeed())));
                } else if ((e.getKeyChar()) == 'i') {
                    setScale(((getScale()) * (getZoomSpeed())));
                } else if ((e.getKeyChar()) == 'c') {
                    centralize(drawing());
                } else {
                    super.keyPressed(e);
                }
            }
        };
        return t;
    }

    public double getZoomSpeed() {
        return zoomSpeed;
    }

    public void setZoomSpeed(double newZoomSpeed) {
        zoomSpeed = java.lang.Math.max(1.1, newZoomSpeed);
    }
}


package Module03;


public class PeripheralLocator extends Module03.AbstractLocator {
    private static int CORNERSPACE = 1;

    private Module03.Figure fOwner;

    private int fPPS;

    private int fIndex;

    private PeripheralLocator() {
    }

    public PeripheralLocator(int pointsPerSide ,int index) {
        fPPS = pointsPerSide;
        fIndex = index;
        if (index >= (pointsPerSide * 4)) {
            throw new java.lang.IllegalArgumentException("Index must be within the range of points starting with index = 0.");
        } 
    }

    public java.awt.Point locate(Module03.Figure parm1) {
        java.awt.Rectangle r = parm1.displayBox();
        float hSpacing = ((float)(r.width)) / ((fPPS) + 1);
        float vSpacing = ((float)(r.height)) / ((fPPS) + 1);
        int x = 0;
        int y = 0;
        if ((fIndex) < (fPPS)) {
            x = java.lang.Math.round((((fIndex) + 1.0F) * hSpacing));
            y = 0;
        } else if ((fIndex) < ((fPPS) * 2)) {
            x = java.lang.Math.round((((fPPS) + 1) * hSpacing));
            y = java.lang.Math.round(((((fIndex) + 1) - (fPPS)) * vSpacing));
        } else if ((fIndex) < ((fPPS) * 3)) {
            x = java.lang.Math.round(((((fPPS) + 1) - (((fIndex) + 1) - ((fPPS) * 2))) * hSpacing));
            y = java.lang.Math.round((((fPPS) + 1) * vSpacing));
        } else {
            x = 0;
            y = java.lang.Math.round(((((fPPS) + 1) - (((fIndex) + 1) - ((fPPS) * 3))) * vSpacing));
        }
        x = x + (r.x);
        y = y + (r.y);
        return new java.awt.Point(((int)(x)) , ((int)(y)));
    }
}


package Module03;


public class SelectionTool extends Module03.AbstractTool {
    private Module03.Tool myDelegationTool = null;

    public SelectionTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        if ((getDelegateTool()) != null) {
            return ;
        } 
        view().freezeView();
        Module05.Handle handle = view().findHandle(e.getX(), e.getY());
        if (handle != null) {
            Module03.DrawingView v = view();
            Module03.Tool ht = createHandleTracker(v, handle);
            setDelegateTool(ht);
        } else {
            Module03.Figure figure = drawing().findFigure(e.getX(), e.getY());
            if (figure != null) {
                Module03.Tool dt = createDragTracker(figure);
                setDelegateTool(dt);
            } else {
                if (!(e.isShiftDown())) {
                    Module03.DrawingView vv = view();
                    vv.clearSelection();
                } 
                Module03.Tool at = createAreaTracker();
                setDelegateTool(at);
            }
        }
        Module03.Tool dt = getDelegateTool();
        dt.activate();
        dt.mouseDown(e, x, y);
    }

    public void mouseMove(java.awt.event.MouseEvent evt, int x, int y) {
        if ((evt.getSource()) == (getActiveView())) {
            Module03.DragNDropTool.setCursor(evt.getX(), evt.getY(), getActiveView());
        } 
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((getDelegateTool()) != null) {
            Module03.Tool delegateTool = getDelegateTool();
            delegateTool.mouseDrag(e, x, y);
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((getDelegateTool()) != null) {
            Module03.Tool delegateTool = getDelegateTool();
            delegateTool.mouseUp(e, x, y);
            delegateTool.deactivate();
            setDelegateTool(null);
        } 
        if ((view()) != null) {
            Module03.DrawingView v = view();
            Module01.DrawingEditor edit = editor();
            v.unfreezeView();
            edit.figureSelectionChanged(v);
        } 
    }

    protected Module03.Tool createHandleTracker(Module03.DrawingView view, Module05.Handle handle) {
        Module05.UndoableHandle unh = new Module05.UndoableHandle(handle);
        Module01.DrawingEditor editor = editor();
        Module03.HandleTracker handletracker = new Module03.HandleTracker(editor , unh);
        return handletracker;
    }

    protected Module03.Tool createDragTracker(Module03.Figure f) {
        Module01.DrawingEditor edi = editor();
        Module03.DragTracker dt = new Module03.DragTracker(edi , f);
        Module03.UndoableTool ut = new Module03.UndoableTool(dt);
        return ut;
    }

    protected Module03.Tool createAreaTracker() {
        Module01.DrawingEditor edi = editor();
        Module03.SelectAreaTracker selectareatracker = new Module03.SelectAreaTracker(edi);
        return selectareatracker;
    }

    protected Module03.Tool getDelegateTool() {
        return myDelegationTool;
    }

    protected final void setDelegateTool(Module03.Tool newDelegateTool) {
        myDelegationTool = newDelegateTool;
    }
}


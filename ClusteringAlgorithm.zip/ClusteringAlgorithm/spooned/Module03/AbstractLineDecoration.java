package Module03;


public abstract class AbstractLineDecoration implements Module03.LineDecoration {
    static final long serialVersionUID = 1577970039258356627L;

    private java.awt.Color fFillColor;

    private java.awt.Color fBorderColor;

    private transient java.awt.Rectangle myBounds;

    public AbstractLineDecoration() {
    }

    public void draw(java.awt.Graphics g, int x1, int y1, int x2, int y2) {
        java.awt.Polygon p = outline(x1, y1, x2, y2);
        myBounds = p.getBounds();
        if ((getFillColor()) == null) {
            g.fillPolygon(p.xpoints, p.ypoints, p.npoints);
        } else {
            java.awt.Color drawColor = g.getColor();
            g.setColor(getFillColor());
            g.fillPolygon(p.xpoints, p.ypoints, p.npoints);
            g.setColor(drawColor);
        }
        if ((getBorderColor()) != (getFillColor())) {
            java.awt.Color drawColor = g.getColor();
            g.setColor(getBorderColor());
            g.drawPolygon(p.xpoints, p.ypoints, p.npoints);
            g.setColor(drawColor);
        } 
    }

    public java.awt.Rectangle displayBox() {
        if ((myBounds) != null) {
            return myBounds;
        } else {
            return new java.awt.Rectangle(0 , 0);
        }
    }

    public abstract java.awt.Polygon outline(int x1, int y1, int x2, int y2);

    public void write(Module06.StorableOutput dw) {
        if ((getFillColor()) != null) {
            Module06.FigureAttributes.writeColor(dw, Module06.FigureAttributeConstant.FILL_COLOR.getName(), getFillColor());
        } else {
            dw.writeString(("no" + (Module06.FigureAttributeConstant.FILL_COLOR.getName())));
        }
        if ((getBorderColor()) != null) {
            Module06.FigureAttributes.writeColor(dw, Module06.FigureAttributeConstant.FRAME_COLOR.getName(), getBorderColor());
        } else {
            dw.writeString(("no" + (Module06.FigureAttributeConstant.FRAME_COLOR.getName())));
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        java.lang.String fillColorId = dr.readString();
        if (fillColorId.equals(Module06.FigureAttributeConstant.FRAME_COLOR.getName())) {
            setFillColor(Module06.FigureAttributes.readColor(dr));
        } 
        java.lang.String borderColorId = dr.readString();
        if ((borderColorId.equals("BorderColor")) || (borderColorId.equals(Module06.FigureAttributeConstant.FRAME_COLOR.getName()))) {
            setBorderColor(Module06.FigureAttributes.readColor(dr));
        } 
    }

    public void setFillColor(java.awt.Color fillColor) {
        fFillColor = fillColor;
    }

    public java.awt.Color getFillColor() {
        return fFillColor;
    }

    public void setBorderColor(java.awt.Color borderColor) {
        fBorderColor = borderColor;
    }

    public java.awt.Color getBorderColor() {
        return fBorderColor;
    }
}


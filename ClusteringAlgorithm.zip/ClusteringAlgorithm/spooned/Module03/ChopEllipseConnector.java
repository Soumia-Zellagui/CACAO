package Module03;


public class ChopEllipseConnector extends Module03.ChopBoxConnector {
    private static final long serialVersionUID = -3165091511154766610L;

    public ChopEllipseConnector() {
    }

    public ChopEllipseConnector(Module03.Figure owner) {
        super(owner);
    }

    protected java.awt.Point chop(Module03.Figure target, java.awt.Point from) {
        java.awt.Rectangle r = target.displayBox();
        double angle = Module06.Geom.pointToAngle(r, from);
        return Module06.Geom.ovalAngleToPoint(r, angle);
    }
}


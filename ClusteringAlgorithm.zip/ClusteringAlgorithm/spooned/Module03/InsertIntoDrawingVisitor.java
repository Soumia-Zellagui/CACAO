package Module03;


public class InsertIntoDrawingVisitor implements Module03.FigureVisitor {
    private java.util.Set myInsertedFigures;

    private Module03.Drawing myDrawing;

    public InsertIntoDrawingVisitor(Module03.Drawing newDrawing) {
        myInsertedFigures = Module06.CollectionsFactory.current().createSet();
        setDrawing(newDrawing);
    }

    private void setDrawing(Module03.Drawing newDrawing) {
        myDrawing = newDrawing;
    }

    protected Module03.Drawing getDrawing() {
        return myDrawing;
    }

    public void visitFigure(Module03.Figure hostFigure) {
        if ((!(myInsertedFigures.contains(hostFigure))) && (!(getDrawing().includes(hostFigure)))) {
            Module03.Figure addedFigure = getDrawing().add(hostFigure);
            myInsertedFigures.add(addedFigure);
        } 
    }

    public void visitHandle(Module05.Handle hostHandle) {
    }

    public void visitFigureChangeListener(Module03.FigureChangeListener hostFigureChangeListener) {
    }

    public Module03.FigureEnumeration getInsertedFigures() {
        Module03.FigureEnumerator fe = new Module03.FigureEnumerator(myInsertedFigures);
        return fe;
    }
}


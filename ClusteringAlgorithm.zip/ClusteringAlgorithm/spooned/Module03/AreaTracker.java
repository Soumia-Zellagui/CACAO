package Module03;


public abstract class AreaTracker extends Module03.AbstractTool {
    private java.awt.Rectangle area;

    protected AreaTracker(Module01.DrawingEditor editor) {
        super(editor);
    }

    public java.awt.Rectangle getArea() {
        return new java.awt.Rectangle(area.x , area.y , area.width , area.height);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, e.getX(), e.getY());
        rubberBand(getAnchorX(), getAnchorY(), getAnchorX(), getAnchorY());
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDrag(e, x, y);
        eraseRubberBand();
        rubberBand(getAnchorX(), getAnchorY(), x, y);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseUp(e, x, y);
        eraseRubberBand();
    }

    private void rubberBand(int x1, int y1, int x2, int y2) {
        area = new java.awt.Rectangle(new java.awt.Point(x1 , y1));
        area.add(new java.awt.Point(x2 , y2));
        drawXORRect(area);
    }

    private void eraseRubberBand() {
        drawXORRect(area);
    }

    private void drawXORRect(java.awt.Rectangle r) {
        java.awt.Graphics g = view().getGraphics();
        g.setXORMode(view().getBackground());
        g.setColor(java.awt.Color.black);
        g.drawRect(r.x, r.y, r.width, r.height);
    }
}


package Module03;


public interface Tool {
    public boolean isActive();

    public void activate();

    public void deactivate();

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y);

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y);

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y);

    public void mouseMove(java.awt.event.MouseEvent evt, int x, int y);

    public void keyDown(java.awt.event.KeyEvent evt, int key);

    public boolean isEnabled();

    public void setEnabled(boolean enableUsableCheck);

    public boolean isUsable();

    public void setUsable(boolean newIsUsable);

    public Module01.DrawingEditor editor();

    public Module06.Undoable getUndoActivity();

    public void setUndoActivity(Module06.Undoable newUndoableActivity);

    public void addToolListener(Module03.ToolListener newToolListener);

    public void removeToolListener(Module03.ToolListener oldToolListener);
}


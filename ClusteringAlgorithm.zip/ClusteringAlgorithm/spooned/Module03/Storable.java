package Module03;


public interface Storable {
    public void write(Module06.StorableOutput dw);

    public void read(Module06.StorableInput dr) throws java.io.IOException;
}


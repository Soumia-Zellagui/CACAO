package Module03;


public interface GeometricFigure extends Module03.Figure {
    public java.awt.Shape getShape();
}


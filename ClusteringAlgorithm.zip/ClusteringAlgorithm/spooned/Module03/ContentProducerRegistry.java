package Module03;


public class ContentProducerRegistry implements Module03.Storable , java.io.Serializable {
    private java.util.Hashtable fContentProducers = new java.util.Hashtable();

    private transient Module03.ContentProducerRegistry fParent;

    private static Module03.ContentProducerRegistry fDefaultRegistry = new Module03.ContentProducerRegistry(null);

    static {
        Module03.URLContentProducer urlContentProducer = new Module03.URLContentProducer();
        Module03.ContentProducerRegistry.fDefaultRegistry.registerContentProducer(java.net.URL.class, urlContentProducer);
    }

    public ContentProducerRegistry() {
        setParent(Module03.ContentProducerRegistry.fDefaultRegistry);
    }

    public ContentProducerRegistry(Module03.ContentProducerRegistry parent) {
        setParent(parent);
    }

    public void setAutonomous() {
        setParent(null);
    }

    public boolean isAutonomous() {
        return (getParent()) == null;
    }

    public void setParent(Module03.ContentProducerRegistry newParent) {
        fParent = newParent;
    }

    public Module03.ContentProducerRegistry getParent() {
        return fParent;
    }

    public static Module03.ContentProducer registerDefaultContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        return Module03.ContentProducerRegistry.fDefaultRegistry.registerContentProducer(targetClass, producer);
    }

    public static void unregisterDefaultContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        Module03.ContentProducerRegistry.fDefaultRegistry.unregisterContentProducer(targetClass, producer);
    }

    public static Module03.ContentProducer getDefaultContentProducer(java.lang.Class targetClass) {
        return Module03.ContentProducerRegistry.fDefaultRegistry.getContentProducer(targetClass);
    }

    public static Module03.ContentProducer getExactDefaultContentProducer(java.lang.Class targetClass) {
        return Module03.ContentProducerRegistry.fDefaultRegistry.getExactContentProducer(targetClass);
    }

    public Module03.ContentProducer registerContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        Module03.ContentProducer previousProducer = getContentProducer(targetClass);
        fContentProducers.put(targetClass, producer);
        return previousProducer;
    }

    public void unregisterContentProducer(java.lang.Class targetClass, Module03.ContentProducer producer) {
        Module03.ContentProducer currentProducer = getContentProducer(targetClass);
        if (currentProducer == producer) {
            fContentProducers.remove(targetClass);
        } 
    }

    public Module03.ContentProducer getContentProducer(java.lang.Class targetClass) {
        Module03.ContentProducer producer = getExactContentProducer(targetClass);
        if (producer != null) {
            return producer;
        } 
        return getSuperClassContentProducer(targetClass, null);
    }

    public Module03.ContentProducer getExactContentProducer(java.lang.Class targetClass) {
        Module03.ContentProducer producer = ((Module03.ContentProducer)(fContentProducers.get(targetClass)));
        if (producer != null) {
            return producer;
        } 
        if (!(Module03.ContentProducerRegistry.this.isAutonomous())) {
            return getParent().getExactContentProducer(targetClass);
        } 
        return null;
    }

    protected Module03.ContentProducer getSuperClassContentProducer(java.lang.Class targetClass, java.lang.Class closestClass) {
        java.util.Map.Entry entry = null;
        java.lang.Class entryClass = null;
        Module03.ContentProducer closestProducer = null;
        java.util.Iterator iter = fContentProducers.entrySet().iterator();
        while (iter.hasNext()) {
            entry = ((java.util.Map.Entry)(iter.next()));
            entryClass = ((java.lang.Class)(entry.getKey()));
            if (entryClass.isAssignableFrom(targetClass)) {
                if ((closestClass != null) && (closestClass.isAssignableFrom(entryClass))) {
                    closestClass = entryClass;
                    closestProducer = ((Module03.ContentProducer)(entry.getValue()));
                } 
            } 
        }
        if (!(Module03.ContentProducerRegistry.this.isAutonomous())) {
            Module03.ContentProducer parentProducer = getParent().getSuperClassContentProducer(targetClass, closestClass);
            if (parentProducer != null) {
                closestProducer = parentProducer;
            } 
        } 
        return closestProducer;
    }

    public void write(Module06.StorableOutput dw) {
        dw.writeInt(fContentProducers.size());
        java.util.Map.Entry producerEntry;
        java.util.Iterator iter = fContentProducers.entrySet().iterator();
        while (iter.hasNext()) {
            producerEntry = ((java.util.Map.Entry)(iter.next()));
            dw.writeString(((java.lang.Class)(producerEntry.getKey())).getName());
            dw.writeStorable(((Module03.Storable)(producerEntry.getKey())));
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        int prodCount = dr.readInt();
        java.lang.String prodClass;
        Module03.ContentProducer producer;
        for (int cnt = 0 ; cnt < prodCount ; cnt++) {
            prodClass = dr.readString();
            producer = ((Module03.ContentProducer)(dr.readStorable()));
            try {
                registerContentProducer(java.lang.Class.forName(prodClass), producer);
            } catch (java.lang.ClassNotFoundException ex) {
            }
        }
    }
}


package Module03;


public class HTMLTextAreaTool extends Module03.TextAreaTool {
    public HTMLTextAreaTool(Module01.DrawingEditor newDrawingEditor ,Module03.Figure prototype) {
        super(newDrawingEditor, prototype);
    }

    protected java.awt.Font getFont(Module03.TextHolder figure) {
        return new java.awt.Font("Helvetica" , java.awt.Font.PLAIN , 12);
    }
}


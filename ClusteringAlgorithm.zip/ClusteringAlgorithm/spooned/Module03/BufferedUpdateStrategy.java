package Module03;


public class BufferedUpdateStrategy implements Module03.Painter {
    private transient java.awt.Image fOffscreen;

    private int fImagewidth = -1;

    private int fImageheight = -1;

    private static final long serialVersionUID = 6489532222954612824L;

    private int bufferedUpdateSerializedDataVersion = 1;

    public void draw(java.awt.Graphics g, Module03.DrawingView view) {
        java.awt.Dimension d = view.getSize();
        if ((((fOffscreen) == null) || ((d.width) != (fImagewidth))) || ((d.height) != (fImageheight))) {
            fOffscreen = view.createImage(d.width, d.height);
            fImagewidth = d.width;
            fImageheight = d.height;
        } 
        java.awt.Graphics g2 = fOffscreen.getGraphics();
        view.drawAll(g2);
        g.drawImage(fOffscreen, 0, 0, view);
    }
}


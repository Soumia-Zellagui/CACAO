package Module03;


public class DragTracker extends Module03.AbstractTool {
    private Module03.Figure fAnchorFigure;

    private int fLastX;

    private int fLastY;

    private boolean fMoved = false;

    public DragTracker(Module01.DrawingEditor newDrawingEditor ,Module03.Figure anchor) {
        super(newDrawingEditor);
        setAnchorFigure(anchor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        setLastMouseX(x);
        setLastMouseY(y);
        if (e.isShiftDown()) {
            Module03.DrawingView view = getActiveView();
            Module03.Figure f = getAnchorFigure();
            view.toggleSelection(f);
            setAnchorFigure(null);
        } else if (!(getActiveView().isFigureSelected(getAnchorFigure()))) {
            Module03.DrawingView view = getActiveView();
            view.clearSelection();
            Module03.Figure f = getAnchorFigure();
            view.addToSelection(f);
        } 
        Module06.Undoable ua = createUndoActivity();
        setUndoActivity(ua);
        Module06.Undoable undac = getUndoActivity();
        Module03.DrawingView view = getActiveView();
        Module03.FigureEnumeration frr = view.selection();
        undac.setAffectedFigures(frr);
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDrag(e, x, y);
        setHasMoved((((java.lang.Math.abs((x - (getAnchorX())))) > 4) || ((java.lang.Math.abs((y - (getAnchorY())))) > 4)));
        if (hasMoved()) {
            Module03.FigureEnumeration figures = getUndoActivity().getAffectedFigures();
            while (figures.hasNextFigure()) {
                figures.nextFigure().moveBy((x - (getLastMouseX())), (y - (getLastMouseY())));
            }
        } 
        setLastMouseX(x);
        setLastMouseY(y);
    }

    protected void setAnchorFigure(Module03.Figure newAnchorFigure) {
        fAnchorFigure = newAnchorFigure;
    }

    public Module03.Figure getAnchorFigure() {
        return fAnchorFigure;
    }

    protected void setLastMouseX(int newLastMouseX) {
        fLastX = newLastMouseX;
    }

    protected int getLastMouseX() {
        return fLastX;
    }

    protected void setLastMouseY(int newLastMouseY) {
        fLastY = newLastMouseY;
    }

    protected int getLastMouseY() {
        return fLastY;
    }

    public boolean hasMoved() {
        return fMoved;
    }

    protected void setHasMoved(boolean newMoved) {
        fMoved = newMoved;
    }

    public void activate() {
    }

    public void deactivate() {
        if (hasMoved()) {
            ((Module03.DragTracker.UndoActivity)(getUndoActivity())).setBackupPoint(new java.awt.Point(getLastMouseX() , getLastMouseY()));
        } else {
            setUndoActivity(null);
        }
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module03.DragTracker.UndoActivity(getActiveView() , new java.awt.Point(getLastMouseX() , getLastMouseY()));
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Point myOriginalPoint;

        private java.awt.Point myBackupPoint;

        public UndoActivity(Module03.DrawingView newDrawingView ,java.awt.Point newOriginalPoint) {
            super(newDrawingView);
            setOriginalPoint(newOriginalPoint);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            moveAffectedFigures(getBackupPoint(), getOriginalPoint());
            return true;
        }

        public boolean redo() {
            if (!(super.redo())) {
                return false;
            } 
            moveAffectedFigures(getOriginalPoint(), getBackupPoint());
            return true;
        }

        public void setBackupPoint(java.awt.Point newBackupPoint) {
            myBackupPoint = newBackupPoint;
        }

        public java.awt.Point getBackupPoint() {
            return myBackupPoint;
        }

        public void setOriginalPoint(java.awt.Point newOriginalPoint) {
            myOriginalPoint = newOriginalPoint;
        }

        public java.awt.Point getOriginalPoint() {
            return myOriginalPoint;
        }

        public void moveAffectedFigures(java.awt.Point startPoint, java.awt.Point endPoint) {
            Module03.FigureEnumeration figures = getAffectedFigures();
            while (figures.hasNextFigure()) {
                figures.nextFigure().moveBy(((endPoint.x) - (startPoint.x)), ((endPoint.y) - (startPoint.y)));
            }
        }
    }
}


package Module03;


public class GroupFigure extends Module03.CompositeFigure {
    private static final long serialVersionUID = 8311226373023297933L;

    private int groupFigureSerializedDataVersion = 1;

    public boolean canConnect() {
        return false;
    }

    public java.awt.Rectangle displayBox() {
        Module03.FigureEnumeration fe = figures();
        java.awt.Rectangle r = fe.nextFigure().displayBox();
        while (fe.hasNextFigure()) {
            r.add(fe.nextFigure().displayBox());
        }
        return r;
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
    }

    public Module03.FigureEnumeration decompose() {
        return new Module03.FigureEnumerator(fFigures);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        handles.add(new Module05.GroupHandle(Module03.GroupFigure.this , Module03.RelativeLocator.northWest()));
        handles.add(new Module05.GroupHandle(Module03.GroupFigure.this , Module03.RelativeLocator.northEast()));
        handles.add(new Module05.GroupHandle(Module03.GroupFigure.this , Module03.RelativeLocator.southWest()));
        handles.add(new Module05.GroupHandle(Module03.GroupFigure.this , Module03.RelativeLocator.southEast()));
        return new Module06.HandleEnumerator(handles);
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        super.setAttribute(name, value);
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            fe.nextFigure().setAttribute(name, value);
        }
    }

    public void setAttribute(Module06.FigureAttributeConstant fac, java.lang.Object object) {
        super.setAttribute(fac, object);
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            fe.nextFigure().setAttribute(fac, object);
        }
    }
}


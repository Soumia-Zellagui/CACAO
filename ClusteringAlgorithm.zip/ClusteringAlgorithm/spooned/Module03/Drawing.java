package Module03;


public interface Drawing extends Module03.FigureChangeListener , Module03.Storable , java.io.Serializable {
    public void release();

    public Module03.FigureEnumeration figures();

    public Module03.FigureEnumeration figures(java.awt.Rectangle viewRectangle);

    public Module03.FigureEnumeration figuresReverse();

    public Module03.Figure findFigure(int x, int y);

    public Module03.Figure findFigure(java.awt.Rectangle r);

    public Module03.Figure findFigureWithout(int x, int y, Module03.Figure without);

    public Module03.Figure findFigure(java.awt.Rectangle r, Module03.Figure without);

    public Module03.Figure findFigureInside(int x, int y);

    public Module03.Figure findFigureInsideWithout(int x, int y, Module03.Figure without);

    public boolean includes(Module03.Figure figure);

    public boolean containsFigure(Module03.Figure figure);

    public void addDrawingChangeListener(Module03.DrawingChangeListener listener);

    public void removeDrawingChangeListener(Module03.DrawingChangeListener listener);

    public java.util.Iterator drawingChangeListeners();

    public Module03.Figure add(Module03.Figure figure);

    public void addAll(java.util.List newFigures);

    public void addAll(Module03.FigureEnumeration fe);

    public Module03.Figure remove(Module03.Figure figure);

    public Module03.Figure orphan(Module03.Figure figure);

    public void orphanAll(java.util.List orphanFigures);

    public void orphanAll(Module03.FigureEnumeration fe);

    public void removeAll(java.util.List figures);

    public void removeAll(Module03.FigureEnumeration fe);

    public Module03.Figure replace(Module03.Figure figure, Module03.Figure replacement);

    public void sendToBack(Module03.Figure figure);

    public void bringToFront(Module03.Figure figure);

    public void sendToLayer(Module03.Figure figure, int layerNr);

    public int getLayer(Module03.Figure figure);

    public Module03.Figure getFigureFromLayer(int layerNr);

    public void draw(java.awt.Graphics g);

    public void draw(java.awt.Graphics g, Module03.FigureEnumeration fe);

    public void lock();

    public void unlock();

    public void init(java.awt.Rectangle viewRectangle);

    public java.lang.String getTitle();

    public void setTitle(java.lang.String name);
}


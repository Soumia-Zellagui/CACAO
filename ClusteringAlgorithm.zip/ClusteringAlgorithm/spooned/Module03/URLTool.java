package Module03;


public class URLTool extends Module03.AbstractTool {
    private Module06.FloatingTextField fTextField;

    private Module03.Figure fURLTarget;

    public URLTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        Module03.Figure pressedFigure = drawing().findFigureInside(x, y);
        if (pressedFigure != null) {
            beginEdit(pressedFigure);
            return ;
        } 
        endEdit();
        editor().toolDone();
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
    }

    public void deactivate(Module03.DrawingView view) {
        super.deactivate();
        endEdit();
    }

    private void beginEdit(Module03.Figure figure) {
        if ((fTextField) == null) {
            fTextField = new Module06.FloatingTextField();
            fTextField.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent event) {
                    endEdit();
                }
            });
        } 
        if ((figure != (fURLTarget)) && ((fURLTarget) != null)) {
            endEdit();
        } 
        if (figure != (fURLTarget)) {
            fTextField.createOverlay(((java.awt.Container)(view())));
            fTextField.setBounds(fieldBounds(figure), getURL(figure));
            fURLTarget = figure;
        } 
    }

    private void endEdit() {
        if ((fURLTarget) != null) {
            setURL(fURLTarget, fTextField.getText());
            fURLTarget = null;
            fTextField.endOverlay();
        } 
    }

    private java.awt.Rectangle fieldBounds(Module03.Figure figure) {
        java.awt.Rectangle box = figure.displayBox();
        int nChars = java.lang.Math.max(20, getURL(figure).length());
        java.awt.Dimension d = fTextField.getPreferredSize(nChars);
        box.x = java.lang.Math.max(0, ((box.x) + (((box.width) - (d.width)) / 2)));
        box.y = java.lang.Math.max(0, ((box.y) + (((box.height) - (d.height)) / 2)));
        return new java.awt.Rectangle(box.x , box.y , d.width , d.height);
    }

    private java.lang.String getURL(Module03.Figure figure) {
        java.lang.String url = ((java.lang.String)(figure.getAttribute(Module06.FigureAttributeConstant.URL)));
        if (url == null) {
            url = "";
        } 
        return url;
    }

    private void setURL(Module03.Figure figure, java.lang.String url) {
        figure.setAttribute(Module06.FigureAttributeConstant.URL, url);
    }
}


package Module03;


public class FollowURLTool extends Module03.AbstractTool {
    private javax.swing.JApplet fApplet;

    public FollowURLTool(Module01.DrawingEditor newDrawingEditor ,javax.swing.JApplet applet) {
        super(newDrawingEditor);
        fApplet = applet;
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
        java.lang.String urlstring = null;
        Module03.Figure figure = drawing().findFigureInside(x, y);
        if (figure != null) {
            urlstring = ((java.lang.String)(figure.getAttribute(Module06.FigureAttributeConstant.URL)));
        } 
        if (urlstring != null) {
            fApplet.showStatus(urlstring);
        } else {
            fApplet.showStatus("");
        }
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Figure figure = getActiveDrawing().findFigureInside(x, y);
        if (figure == null) {
            return ;
        } 
        java.lang.String urlstring = ((java.lang.String)(figure.getAttribute(Module06.FigureAttributeConstant.URL)));
        if (urlstring == null) {
            return ;
        } 
        try {
            java.net.URL url = new java.net.URL(fApplet.getDocumentBase() , urlstring);
            fApplet.getAppletContext().showDocument(url);
        } catch (java.net.MalformedURLException exception) {
            fApplet.showStatus(exception.toString());
        }
    }
}


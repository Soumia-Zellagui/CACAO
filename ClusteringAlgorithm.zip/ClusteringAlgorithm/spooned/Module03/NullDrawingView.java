package Module03;


public class NullDrawingView extends javax.swing.JPanel implements Module03.DrawingView {
    private Module01.DrawingEditor myDrawingEditor;

    private Module03.Drawing myDrawing;

    private Module03.Painter myUpdateStrategy;

    private java.awt.Color myBackgroundColor;

    private static java.util.Hashtable drawingViewManager = new java.util.Hashtable();

    protected NullDrawingView(Module01.DrawingEditor editor) {
        setEditor(editor);
        Module03.StandardDrawing standardDraw = new Module03.StandardDrawing();
        setDrawing(standardDraw);
    }

    public void setEditor(Module01.DrawingEditor editor) {
        myDrawingEditor = editor;
    }

    public Module03.Tool tool() {
        Module01.DrawingEditor editor = editor();
        Module03.Tool t = editor.tool();
        return t;
    }

    public Module03.Drawing drawing() {
        return myDrawing;
    }

    public void setDrawing(Module03.Drawing d) {
        myDrawing = d;
    }

    public Module01.DrawingEditor editor() {
        return myDrawingEditor;
    }

    public Module03.Figure add(Module03.Figure figure) {
        return figure;
    }

    public Module03.Figure remove(Module03.Figure figure) {
        return figure;
    }

    public void addAll(java.util.Collection figures) {
    }

    public java.awt.Dimension getSize() {
        return new java.awt.Dimension();
    }

    public java.awt.Dimension getMinimumSize() {
        return new java.awt.Dimension();
    }

    public java.awt.Dimension getPreferredSize() {
        return new java.awt.Dimension();
    }

    public void setDisplayUpdate(Module03.Painter newUpdateStrategy) {
        myUpdateStrategy = newUpdateStrategy;
    }

    public Module03.Painter getDisplayUpdate() {
        return myUpdateStrategy;
    }

    public Module03.FigureEnumeration selection() {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public Module03.FigureEnumeration selectionZOrdered() {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public int selectionCount() {
        return 0;
    }

    public boolean isFigureSelected(Module03.Figure checkFigure) {
        return false;
    }

    public void addToSelection(Module03.Figure figure) {
    }

    public void addToSelectionAll(java.util.Collection figures) {
    }

    public void addToSelectionAll(Module03.FigureEnumeration fe) {
    }

    public void removeFromSelection(Module03.Figure figure) {
    }

    public void toggleSelection(Module03.Figure figure) {
    }

    public void clearSelection() {
    }

    public Module03.FigureSelection getFigureSelection() {
        Module03.StandardFigureSelection sfs = new Module03.StandardFigureSelection(selection() , 0);
        return sfs;
    }

    public Module05.Handle findHandle(int x, int y) {
        return null;
    }

    public java.awt.Point lastClick() {
        return new java.awt.Point();
    }

    public void setConstrainer(Module06.PointConstrainer p) {
    }

    public Module06.PointConstrainer getConstrainer() {
        return null;
    }

    public void checkDamage() {
    }

    public void repairDamage() {
    }

    public void paint(java.awt.Graphics g) {
    }

    public java.awt.Image createImage(int width, int height) {
        return null;
    }

    public java.awt.Graphics getGraphics() {
        return null;
    }

    public java.awt.Color getBackground() {
        return myBackgroundColor;
    }

    public void setBackground(java.awt.Color c) {
        myBackgroundColor = c;
    }

    public void drawAll(java.awt.Graphics g) {
    }

    public void draw(java.awt.Graphics g, Module03.FigureEnumeration fe) {
    }

    public void drawHandles(java.awt.Graphics g) {
    }

    public void drawDrawing(java.awt.Graphics g) {
    }

    public void drawBackground(java.awt.Graphics g) {
    }

    public void setCursor(Module06.Cursor c) {
    }

    public void freezeView() {
    }

    public void unfreezeView() {
    }

    public void addFigureSelectionListener(Module01.FigureSelectionListener fsl) {
    }

    public void removeFigureSelectionListener(Module01.FigureSelectionListener fsl) {
    }

    public Module03.FigureEnumeration getConnectionFigures(Module03.Figure inFigure) {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public Module03.FigureEnumeration insertFigures(Module03.FigureEnumeration inFigures, int dx, int dy, boolean bCheck) {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public void drawingInvalidated(Module06.DrawingChangeEvent e) {
    }

    public void drawingRequestUpdate(Module06.DrawingChangeEvent e) {
    }

    public void drawingTitleChanged(Module06.DrawingChangeEvent e) {
    }

    public boolean isInteractive() {
        return false;
    }

    public static synchronized Module03.DrawingView getManagedDrawingView(Module01.DrawingEditor editor) {
        if (Module03.NullDrawingView.drawingViewManager.containsKey(editor)) {
            return ((Module03.DrawingView)(Module03.NullDrawingView.drawingViewManager.get(editor)));
        } else {
            Module03.DrawingView newDrawingView = new Module03.NullDrawingView(editor);
            Module03.NullDrawingView.drawingViewManager.put(editor, newDrawingView);
            return newDrawingView;
        }
    }
}


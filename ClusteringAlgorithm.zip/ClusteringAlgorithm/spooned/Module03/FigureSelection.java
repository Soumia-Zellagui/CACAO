package Module03;


public interface FigureSelection {
    public java.lang.String getType();

    public java.lang.Object getData(java.lang.String type);
}


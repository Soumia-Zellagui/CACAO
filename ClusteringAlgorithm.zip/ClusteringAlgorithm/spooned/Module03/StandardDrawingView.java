package Module03;


public class StandardDrawingView extends javax.swing.JPanel implements Module03.DNDInterface , Module03.DrawingView , java.awt.dnd.Autoscroll {
    private transient Module01.DrawingEditor fEditor;

    private transient java.util.List fSelectionListeners;

    private Module03.Drawing fDrawing;

    private transient java.awt.Rectangle fDamage;

    private transient java.util.List fSelection;

    private transient java.util.List fSelectionHandles;

    private java.awt.Point fLastClick;

    private java.util.List fBackgrounds;

    private java.util.List fForegrounds;

    private Module03.Painter fUpdateStrategy;

    private Module06.PointConstrainer fConstrainer;

    public static final int MINIMUM_WIDTH = 400;

    public static final int MINIMUM_HEIGHT = 300;

    public static final int SCROLL_INCR = 100;

    public static final int SCROLL_OFFSET = 10;

    private static int counter;

    private int myCounter = Module03.StandardDrawingView.counter;

    private Module03.DNDHelper dndh;

    private java.awt.event.MouseListener mouseListener;

    private java.awt.event.MouseMotionListener motionListener;

    private java.awt.event.KeyListener keyListener;

    private boolean myIsReadOnly;

    private static final long serialVersionUID = -3878153366174603336L;

    private int drawingViewSerializedDataVersion = 1;

    public StandardDrawingView(Module01.DrawingEditor editor) {
        this(editor, Module03.StandardDrawingView.MINIMUM_WIDTH, Module03.StandardDrawingView.MINIMUM_HEIGHT);
    }

    public StandardDrawingView(Module01.DrawingEditor editor ,int width ,int height) {
        setAutoscrolls(true);
        (Module03.StandardDrawingView.counter)++;
        fEditor = editor;
        setPreferredSize(new java.awt.Dimension(width , height));
        fSelectionListeners = Module06.CollectionsFactory.current().createList();
        Module01.DrawingEditor edit = editor();
        addFigureSelectionListener(edit);
        setLastClick(new java.awt.Point(0 , 0));
        fConstrainer = null;
        fSelection = Module06.CollectionsFactory.current().createList();
        Module03.SimpleUpdateStrategy su = createDisplayUpdate();
        setDisplayUpdate(su);
        setBackground(java.awt.Color.lightGray);
        Module03.StandardDrawingView.DrawingViewMouseListener mouselistener = createMouseListener();
        addMouseListener(mouselistener);
        Module03.StandardDrawingView.DrawingViewMouseMotionListener ml = createMouseMotionListener();
        addMouseMotionListener(ml);
        Module03.StandardDrawingView.DrawingViewKeyListener kl = createKeyListener();
        addKeyListener(kl);
    }

    protected Module03.StandardDrawingView.DrawingViewMouseListener createMouseListener() {
        mouseListener = new Module03.StandardDrawingView.DrawingViewMouseListener();
        return ((Module03.StandardDrawingView.DrawingViewMouseListener)(mouseListener));
    }

    protected Module03.StandardDrawingView.DrawingViewMouseMotionListener createMouseMotionListener() {
        motionListener = new Module03.StandardDrawingView.DrawingViewMouseMotionListener();
        return ((Module03.StandardDrawingView.DrawingViewMouseMotionListener)(motionListener));
    }

    protected Module03.StandardDrawingView.DrawingViewKeyListener createKeyListener() {
        keyListener = new Module03.StandardDrawingView.DrawingViewKeyListener();
        return ((Module03.StandardDrawingView.DrawingViewKeyListener)(keyListener));
    }

    protected Module03.SimpleUpdateStrategy createDisplayUpdate() {
        Module03.SimpleUpdateStrategy su = new Module03.SimpleUpdateStrategy();
        return su;
    }

    public void setEditor(Module01.DrawingEditor editor) {
        fEditor = editor;
    }

    public Module03.Tool tool() {
        return editor().tool();
    }

    public Module03.Drawing drawing() {
        return fDrawing;
    }

    public void setDrawing(Module03.Drawing d) {
        if ((drawing()) != null) {
            clearSelection();
            drawing().removeDrawingChangeListener(Module03.StandardDrawingView.this);
        } 
        fDrawing = d;
        if ((drawing()) != null) {
            drawing().addDrawingChangeListener(Module03.StandardDrawingView.this);
        } 
        checkMinimumSize();
        repaint();
    }

    public Module01.DrawingEditor editor() {
        return fEditor;
    }

    public Module03.Figure add(Module03.Figure figure) {
        return drawing().add(figure);
    }

    public Module03.Figure remove(Module03.Figure figure) {
        return drawing().remove(figure);
    }

    public void addAll(java.util.Collection figures) {
        Module03.FigureEnumeration fe = new Module03.FigureEnumerator(figures);
        while (fe.hasNextFigure()) {
            add(fe.nextFigure());
        }
    }

    public boolean figureExists(Module03.Figure inf, Module03.FigureEnumeration fe) {
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (figure.includes(inf)) {
                return true;
            } 
        }
        return false;
    }

    public Module03.FigureEnumeration insertFigures(Module03.FigureEnumeration fe, int dx, int dy, boolean bCheck) {
        if (fe == null) {
            return Module03.FigureEnumerator.getEmptyEnumeration();
        } 
        java.util.List vCF = Module06.CollectionsFactory.current().createList(10);
        Module03.InsertIntoDrawingVisitor visitor = new Module03.InsertIntoDrawingVisitor(drawing());
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (figure instanceof Module03.ConnectionFigure) {
                vCF.add(figure);
            } else if (figure != null) {
                figure.moveBy(dx, dy);
                figure.visit(visitor);
            } 
        }
        Module03.FigureEnumeration ecf = new Module03.FigureEnumerator(vCF);
        while (ecf.hasNextFigure()) {
            Module03.ConnectionFigure cf = ((Module03.ConnectionFigure)(ecf.nextFigure()));
            Module03.Figure sf = cf.startFigure();
            Module03.Figure ef = cf.endFigure();
            if (((figureExists(sf, drawing().figures())) && (figureExists(ef, drawing().figures()))) && ((!bCheck) || (cf.canConnect(sf, ef)))) {
                if (bCheck) {
                    java.awt.Point sp = sf.center();
                    java.awt.Point ep = ef.center();
                    Module03.Connector fStartConnector = cf.startFigure().connectorAt(ep.x, ep.y);
                    Module03.Connector fEndConnector = cf.endFigure().connectorAt(sp.x, sp.y);
                    if ((fEndConnector != null) && (fStartConnector != null)) {
                        cf.connectStart(fStartConnector);
                        cf.connectEnd(fEndConnector);
                        cf.updateConnection();
                    } 
                } 
                cf.visit(visitor);
            } 
        }
        addToSelectionAll(visitor.getInsertedFigures());
        return visitor.getInsertedFigures();
    }

    public Module03.FigureEnumeration getConnectionFigures(Module03.Figure inFigure) {
        if ((inFigure == null) || (!(inFigure.canConnect()))) {
            return null;
        } 
        java.util.List result = Module06.CollectionsFactory.current().createList(5);
        Module03.FigureEnumeration figures = drawing().figures();
        while (figures.hasNextFigure()) {
            Module03.Figure f = figures.nextFigure();
            if ((f instanceof Module03.ConnectionFigure) && (!(isFigureSelected(f)))) {
                Module03.ConnectionFigure cf = ((Module03.ConnectionFigure)(f));
                if ((cf.startFigure().includes(inFigure)) || (cf.endFigure().includes(inFigure))) {
                    result.add(f);
                } 
            } 
        }
        Module03.FigureEnumerator figureEnum = new Module03.FigureEnumerator(result);
        return figureEnum;
    }

    public void setDisplayUpdate(Module03.Painter updateStrategy) {
        fUpdateStrategy = updateStrategy;
    }

    public Module03.Painter getDisplayUpdate() {
        return fUpdateStrategy;
    }

    public Module03.FigureEnumeration selection() {
        return selectionZOrdered();
    }

    public Module03.FigureEnumeration selectionZOrdered() {
        java.util.List result = Module06.CollectionsFactory.current().createList(selectionCount());
        result.addAll(fSelection);
        Module03.ReverseFigureEnumerator rfe = new Module03.ReverseFigureEnumerator(result);
        return rfe;
    }

    public int selectionCount() {
        return fSelection.size();
    }

    public boolean isFigureSelected(Module03.Figure checkFigure) {
        return fSelection.contains(checkFigure);
    }

    public void addToSelection(Module03.Figure figure) {
        if ((addToSelectionImpl(figure)) == true) {
            fireSelectionChanged();
        } 
    }

    protected boolean addToSelectionImpl(Module03.Figure figure) {
        boolean changed = false;
        if ((!(isFigureSelected(figure))) && (drawing().includes(figure))) {
            fSelection.add(figure);
            fSelectionHandles = null;
            figure.invalidate();
            changed = true;
        } 
        return changed;
    }

    public void addToSelectionAll(java.util.Collection figures) {
        Module03.FigureEnumerator fe = new Module03.FigureEnumerator(figures);
        addToSelectionAll(fe);
    }

    public void addToSelectionAll(Module03.FigureEnumeration fe) {
        boolean changed = false;
        while (fe.hasNextFigure()) {
            changed |= addToSelectionImpl(fe.nextFigure());
        }
        if (changed == true) {
            fireSelectionChanged();
        } 
    }

    public void removeFromSelection(Module03.Figure figure) {
        if (isFigureSelected(figure)) {
            fSelection.remove(figure);
            fSelectionHandles = null;
            figure.invalidate();
            fireSelectionChanged();
        } 
    }

    public void toggleSelection(Module03.Figure figure) {
        if (isFigureSelected(figure)) {
            removeFromSelection(figure);
        } else {
            addToSelection(figure);
        }
        fireSelectionChanged();
    }

    public void clearSelection() {
        if ((selectionCount()) == 0) {
            return ;
        } 
        Module03.FigureEnumeration fe = selection();
        while (fe.hasNextFigure()) {
            fe.nextFigure().invalidate();
        }
        fSelection = Module06.CollectionsFactory.current().createList();
        fSelectionHandles = null;
        fireSelectionChanged();
    }

    protected Module06.HandleEnumeration selectionHandles() {
        if ((fSelectionHandles) == null) {
            fSelectionHandles = Module06.CollectionsFactory.current().createList();
            Module03.FigureEnumeration fe = selection();
            while (fe.hasNextFigure()) {
                Module03.Figure figure = fe.nextFigure();
                Module06.HandleEnumeration kk = figure.handles();
                while (kk.hasNextHandle()) {
                    fSelectionHandles.add(kk.nextHandle());
                }
            }
        } 
        Module06.HandleEnumerator he = new Module06.HandleEnumerator(fSelectionHandles);
        return he;
    }

    public Module03.FigureSelection getFigureSelection() {
        Module03.StandardFigureSelection fs = new Module03.StandardFigureSelection(selectionZOrdered() , selectionCount());
        return fs;
    }

    public Module05.Handle findHandle(int x, int y) {
        Module05.Handle handle;
        Module06.HandleEnumeration he = selectionHandles();
        while (he.hasNextHandle()) {
            handle = he.nextHandle();
            if (handle.containsPoint(x, y)) {
                return handle;
            } 
        }
        return null;
    }

    protected void fireSelectionChanged() {
        if ((fSelectionListeners) != null) {
            for (int i = 0 ; i < (fSelectionListeners.size()) ; i++) {
                Module01.FigureSelectionListener l = ((Module01.FigureSelectionListener)(fSelectionListeners.get(i)));
                l.figureSelectionChanged(Module03.StandardDrawingView.this);
            }
        } 
    }

    protected java.awt.Rectangle getDamage() {
        return fDamage;
    }

    protected void setDamage(java.awt.Rectangle r) {
        fDamage = r;
    }

    public java.awt.Point lastClick() {
        return fLastClick;
    }

    protected void setLastClick(java.awt.Point newLastClick) {
        fLastClick = newLastClick;
    }

    public void setConstrainer(Module06.PointConstrainer c) {
        fConstrainer = c;
    }

    public Module06.PointConstrainer getConstrainer() {
        return fConstrainer;
    }

    protected java.awt.Point constrainPoint(java.awt.Point p) {
        java.awt.Dimension size = getSize();
        p.x = Module06.Geom.range(1, size.width, p.x);
        p.y = Module06.Geom.range(1, size.height, p.y);
        if ((fConstrainer) != null) {
            return fConstrainer.constrainPoint(p);
        } 
        return p;
    }

    private void moveSelection(int dx, int dy) {
        Module03.FigureEnumeration figures = selection();
        while (figures.hasNextFigure()) {
            figures.nextFigure().moveBy(dx, dy);
        }
        checkDamage();
    }

    public synchronized void checkDamage() {
        java.util.Iterator each = drawing().drawingChangeListeners();
        while (each.hasNext()) {
            java.lang.Object l = each.next();
            if (l instanceof Module03.DrawingView) {
                ((Module03.DrawingView)(l)).repairDamage();
            } 
        }
    }

    public void repairDamage() {
        if ((getDamage()) != null) {
            repaint(getDamage().x, getDamage().y, getDamage().width, getDamage().height);
            setDamage(null);
        } 
    }

    public void drawingInvalidated(Module06.DrawingChangeEvent e) {
        java.awt.Rectangle r = e.getInvalidatedRectangle();
        if ((getDamage()) == null) {
            setDamage(r);
        } else {
            java.awt.Rectangle damagedR = getDamage();
            damagedR.add(r);
            setDamage(damagedR);
        }
    }

    public void drawingRequestUpdate(Module06.DrawingChangeEvent e) {
        repairDamage();
    }

    public void drawingTitleChanged(Module06.DrawingChangeEvent e) {
    }

    protected void paintComponent(java.awt.Graphics g) {
        if ((getDisplayUpdate()) != null) {
            Module03.Painter du = getDisplayUpdate();
            du.draw(g, Module03.StandardDrawingView.this);
        } 
    }

    public void drawAll(java.awt.Graphics g) {
        boolean isPrinting = g instanceof java.awt.PrintGraphics;
        drawBackground(g);
        if (((fBackgrounds) != null) && (!isPrinting)) {
            drawPainters(g, fBackgrounds);
        } 
        drawDrawing(g);
        if (((fForegrounds) != null) && (!isPrinting)) {
            drawPainters(g, fForegrounds);
        } 
        if (!isPrinting) {
            drawHandles(g);
        } 
    }

    public void draw(java.awt.Graphics g, Module03.FigureEnumeration fe) {
        boolean isPrinting = g instanceof java.awt.PrintGraphics;
        if (((fBackgrounds) != null) && (!isPrinting)) {
            drawPainters(g, fBackgrounds);
        } 
        drawing().draw(g, fe);
        if (((fForegrounds) != null) && (!isPrinting)) {
            drawPainters(g, fForegrounds);
        } 
        if (!isPrinting) {
            drawHandles(g);
        } 
    }

    public void drawHandles(java.awt.Graphics g) {
        Module06.HandleEnumeration he = selectionHandles();
        while (he.hasNextHandle()) {
            he.nextHandle().draw(g);
        }
    }

    public void drawDrawing(java.awt.Graphics g) {
        Module03.Drawing d = drawing();
        d.draw(g);
    }

    public void drawBackground(java.awt.Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0, 0, getBounds().width, getBounds().height);
    }

    protected void drawPainters(java.awt.Graphics g, java.util.List v) {
        for (int i = 0 ; i < (v.size()) ; i++) {
            ((Module03.Painter)(v.get(i))).draw(g, Module03.StandardDrawingView.this);
        }
    }

    public void addBackground(Module03.Painter painter) {
        if ((fBackgrounds) == null) {
            fBackgrounds = Module06.CollectionsFactory.current().createList(3);
        } 
        fBackgrounds.add(painter);
        repaint();
    }

    public void removeBackground(Module03.Painter painter) {
        if ((fBackgrounds) != null) {
            fBackgrounds.remove(painter);
        } 
        repaint();
    }

    protected java.util.List getBackgrounds() {
        return fBackgrounds;
    }

    public void removeForeground(Module03.Painter painter) {
        if ((fForegrounds) != null) {
            fForegrounds.remove(painter);
        } 
        repaint();
    }

    public void addForeground(Module03.Painter painter) {
        if ((fForegrounds) == null) {
            fForegrounds = Module06.CollectionsFactory.current().createList(3);
        } 
        fForegrounds.add(painter);
        repaint();
    }

    protected java.util.List getForegrounds() {
        return fForegrounds;
    }

    public void freezeView() {
        Module03.Drawing d = drawing();
        d.lock();
    }

    public void unfreezeView() {
        Module03.Drawing d = drawing();
        d.unlock();
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        fSelection = Module06.CollectionsFactory.current().createList();
        if ((drawing()) != null) {
            Module03.Drawing d = drawing();
            d.addDrawingChangeListener(Module03.StandardDrawingView.this);
        } 
        fSelectionListeners = Module06.CollectionsFactory.current().createList();
    }

    protected void checkMinimumSize() {
        java.awt.Dimension d = getDrawingSize();
        java.awt.Dimension v = getPreferredSize();
        if (((v.height) < (d.height)) || ((v.width) < (d.width))) {
            v.height = (d.height) + (Module03.StandardDrawingView.SCROLL_OFFSET);
            v.width = (d.width) + (Module03.StandardDrawingView.SCROLL_OFFSET);
            setPreferredSize(v);
        } 
    }

    protected java.awt.Dimension getDrawingSize() {
        java.awt.Dimension d = new java.awt.Dimension(0 , 0);
        if ((drawing()) != null) {
            Module03.FigureEnumeration fe = drawing().figures();
            while (fe.hasNextFigure()) {
                java.awt.Rectangle r = fe.nextFigure().displayBox();
                d.width = java.lang.Math.max(d.width, ((r.x) + (r.width)));
                d.height = java.lang.Math.max(d.height, ((r.y) + (r.height)));
            }
        } 
        return d;
    }

    public boolean isFocusTraversable() {
        return true;
    }

    public boolean isInteractive() {
        return true;
    }

    public void keyTyped(java.awt.event.KeyEvent e) {
    }

    public void keyReleased(java.awt.event.KeyEvent e) {
    }

    public void addFigureSelectionListener(Module01.FigureSelectionListener fsl) {
        fSelectionListeners.add(fsl);
    }

    public void removeFigureSelectionListener(Module01.FigureSelectionListener fsl) {
        fSelectionListeners.remove(fsl);
    }

    public int getDefaultDNDActions() {
        return java.awt.dnd.DnDConstants.ACTION_COPY_OR_MOVE;
    }

    private Module03.StandardDrawingView.ASH ash = new Module03.StandardDrawingView.ASH(10);

    public void autoscroll(java.awt.Point p) {
        ash.autoscroll(p);
    }

    public java.awt.Insets getAutoscrollInsets() {
        return ash.getAutoscrollInsets();
    }

    class ASH extends Module06.AutoscrollHelper {
        public ASH(int margin) {
            super(margin);
        }

        public java.awt.Dimension getSize() {
            return Module03.StandardDrawingView.this.getSize();
        }

        public java.awt.Rectangle getVisibleRect() {
            return Module03.StandardDrawingView.this.getVisibleRect();
        }

        public void scrollRectToVisible(java.awt.Rectangle aRect) {
            Module03.StandardDrawingView.this.scrollRectToVisible(aRect);
        }
    }

    public java.lang.String toString() {
        return "DrawingView Nr: " + (myCounter);
    }

    protected void handleMouseEventException(java.lang.Throwable t) {
        javax.swing.JOptionPane.showMessageDialog(Module03.StandardDrawingView.this, (((t.getClass().getName()) + " - ") + (t.getMessage())), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        t.printStackTrace();
    }

    public class DrawingViewMouseListener extends java.awt.event.MouseAdapter {
        public void mousePressed(java.awt.event.MouseEvent e) {
            try {
                requestFocus();
                java.awt.Point p = constrainPoint(new java.awt.Point(e.getX() , e.getY()));
                setLastClick(new java.awt.Point(e.getX() , e.getY()));
                tool().mouseDown(e, p.x, p.y);
                checkDamage();
            } catch (java.lang.Throwable t) {
                handleMouseEventException(t);
            }
        }

        public void mouseReleased(java.awt.event.MouseEvent e) {
            try {
                java.awt.Point p = constrainPoint(new java.awt.Point(e.getX() , e.getY()));
                tool().mouseUp(e, p.x, p.y);
                checkDamage();
            } catch (java.lang.Throwable t) {
                handleMouseEventException(t);
            }
        }
    }

    public class DrawingViewMouseMotionListener implements java.awt.event.MouseMotionListener {
        public void mouseDragged(java.awt.event.MouseEvent e) {
            try {
                java.awt.Point p = constrainPoint(new java.awt.Point(e.getX() , e.getY()));
                tool().mouseDrag(e, p.x, p.y);
                checkDamage();
            } catch (java.lang.Throwable t) {
                handleMouseEventException(t);
            }
        }

        public void mouseMoved(java.awt.event.MouseEvent e) {
            try {
                tool().mouseMove(e, e.getX(), e.getY());
            } catch (java.lang.Throwable t) {
                handleMouseEventException(t);
            }
        }
    }

    public class DrawingViewKeyListener implements java.awt.event.KeyListener {
        private Module01.Command deleteCmd;

        public DrawingViewKeyListener() {
            deleteCmd = createDeleteCommand();
        }

        public void keyPressed(java.awt.event.KeyEvent e) {
            int code = e.getKeyCode();
            int modifiers = e.getModifiers();
            if ((modifiers == 0) && ((code == (java.awt.event.KeyEvent.VK_BACK_SPACE)) || (code == (java.awt.event.KeyEvent.VK_DELETE)))) {
                if (deleteCmd.isExecutable()) {
                    deleteCmd.execute();
                } 
            } else if ((modifiers == 0) && ((((code == (java.awt.event.KeyEvent.VK_DOWN)) || (code == (java.awt.event.KeyEvent.VK_UP))) || (code == (java.awt.event.KeyEvent.VK_RIGHT))) || (code == (java.awt.event.KeyEvent.VK_LEFT)))) {
                handleCursorKey(code);
            } else {
                tool().keyDown(e, code);
            }
            checkDamage();
        }

        protected void handleCursorKey(int key) {
            int dx = 0;
            int dy = 0;
            int stepX = 1;
            int stepY = 1;
            if ((fConstrainer) != null) {
                stepX = fConstrainer.getStepX();
                stepY = fConstrainer.getStepY();
            } 
            switch (key) {
                case java.awt.event.KeyEvent.VK_DOWN :
                    dy = stepY;
                    break;
                case java.awt.event.KeyEvent.VK_UP :
                    dy = -stepY;
                    break;
                case java.awt.event.KeyEvent.VK_RIGHT :
                    dx = stepX;
                    break;
                case java.awt.event.KeyEvent.VK_LEFT :
                    dx = -stepX;
                    break;
            }
            moveSelection(dx, dy);
        }

        public void keyTyped(java.awt.event.KeyEvent event) {
        }

        public void keyReleased(java.awt.event.KeyEvent event) {
        }

        protected Module01.Command createDeleteCommand() {
            Module01.DrawingEditor de = editor();
            Module01.DeleteCommand dc = new Module01.DeleteCommand("Delete" , de);
            Module01.UndoableCommand uc = new Module01.UndoableCommand(dc);
            return uc;
        }
    }

    protected Module03.DNDHelper createDNDHelper() {
        Module03.DNDHelper dndHelper = new Module03.DNDHelper(true, true) {
            protected Module03.DrawingView view() {
                return Module03.StandardDrawingView.this;
            }

            protected Module01.DrawingEditor editor() {
                return Module03.StandardDrawingView.this.editor();
            }
        };
        return dndHelper;
    }

    protected Module03.DNDHelper getDNDHelper() {
        if ((dndh) == null) {
            dndh = createDNDHelper();
        } 
        return dndh;
    }

    public java.awt.dnd.DragSourceListener getDragSourceListener() {
        Module03.DNDHelper dndh = getDNDHelper();
        return dndh.getDragSourceListener();
    }

    public void DNDInitialize(java.awt.dnd.DragGestureListener dgl) {
        Module03.DNDHelper dndh = getDNDHelper();
        dndh.initialize(dgl);
    }

    public void DNDDeinitialize() {
        Module03.DNDHelper dndh = getDNDHelper();
        dndh.deinitialize();
    }

    public boolean isReadOnly() {
        return myIsReadOnly;
    }

    public void setReadOnly(boolean newIsReadOnly) {
        if (newIsReadOnly != (isReadOnly())) {
            if (newIsReadOnly) {
                removeMouseListener(mouseListener);
                removeMouseMotionListener(motionListener);
                removeKeyListener(keyListener);
            } else {
                addMouseListener(mouseListener);
                addMouseMotionListener(motionListener);
                addKeyListener(keyListener);
            }
            myIsReadOnly = newIsReadOnly;
        } 
    }

    public void setCursor(Module06.Cursor cursor) {
        if (cursor instanceof java.awt.Cursor) {
            super.setCursor(((java.awt.Cursor)(cursor)));
        } 
    }

    public java.awt.Dimension getMinimumSize() {
        java.awt.Rectangle r = new java.awt.Rectangle();
        Module03.FigureEnumeration k = drawing().figures();
        while (k.hasNextFigure()) {
            r.add(k.nextFigure().displayBox());
        }
        return new java.awt.Dimension(r.width , r.height);
    }
}


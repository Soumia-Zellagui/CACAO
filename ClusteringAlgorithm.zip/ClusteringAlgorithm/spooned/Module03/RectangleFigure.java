package Module03;


public class RectangleFigure extends Module03.AttributeFigure {
    private java.awt.Rectangle fDisplayBox;

    private static final long serialVersionUID = 184722075881789163L;

    private int rectangleFigureSerializedDataVersion = 1;

    public RectangleFigure() {
        this(new java.awt.Point(0 , 0), new java.awt.Point(0 , 0));
    }

    public RectangleFigure(java.awt.Point origin ,java.awt.Point corner) {
        basicDisplayBox(origin, corner);
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        fDisplayBox = new java.awt.Rectangle(origin);
        fDisplayBox.add(corner);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.RectangleFigure.this, handles);
        return new Module06.HandleEnumerator(handles);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(fDisplayBox.x , fDisplayBox.y , fDisplayBox.width , fDisplayBox.height);
    }

    protected void basicMoveBy(int x, int y) {
        fDisplayBox.translate(x, y);
    }

    public void drawBackground(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.fillRect(r.x, r.y, r.width, r.height);
    }

    public void drawFrame(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.drawRect(r.x, r.y, ((r.width) - 1), ((r.height) - 1));
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fDisplayBox.x);
        dw.writeInt(fDisplayBox.y);
        dw.writeInt(fDisplayBox.width);
        dw.writeInt(fDisplayBox.height);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fDisplayBox = new java.awt.Rectangle(dr.readInt() , dr.readInt() , dr.readInt() , dr.readInt());
    }
}


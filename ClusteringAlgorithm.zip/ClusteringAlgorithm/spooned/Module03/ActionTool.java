package Module03;


public abstract class ActionTool extends Module03.AbstractTool {
    public ActionTool(Module01.DrawingEditor newDrawingEditor) {
        super(newDrawingEditor);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        Module03.Figure target = drawing().findFigure(x, y);
        if (target != null) {
            view().addToSelection(target);
            action(target);
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        editor().toolDone();
    }

    public abstract void action(Module03.Figure figure);
}


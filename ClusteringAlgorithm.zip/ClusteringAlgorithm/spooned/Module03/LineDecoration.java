package Module03;


public interface LineDecoration extends Module03.Storable , java.io.Serializable , java.lang.Cloneable {
    public void draw(java.awt.Graphics g, int x1, int y1, int x2, int y2);

    public java.awt.Rectangle displayBox();
}


package Module03;


public class HTMLColorContentProducer extends Module03.ColorContentProducer implements java.io.Serializable {
    public HTMLColorContentProducer() {
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        java.awt.Color color = (getColor()) != null ? getColor() : ((java.awt.Color)(ctxAttrValue));
        return Module03.HTMLColorContentProducer.getHTMLColorCode(color);
    }

    public static java.lang.String getHTMLColorCode(java.awt.Color color) {
        java.lang.String colorCode = java.lang.Integer.toHexString(color.getRGB());
        return "#" + (colorCode.substring(((colorCode.length()) - 6)));
    }
}


package Module03;


public class FigureChangeEvent extends java.util.EventObject {
    private java.awt.Rectangle myRectangle;

    private Module03.FigureChangeEvent myNestedEvent;

    private static final java.awt.Rectangle EMPTY_RECTANGLE = new java.awt.Rectangle(0 , 0 , 0 , 0);

    public FigureChangeEvent(Module03.Figure newSource ,java.awt.Rectangle newRect) {
        super(newSource);
        myRectangle = newRect;
    }

    public FigureChangeEvent(Module03.Figure newSource) {
        super(newSource);
        myRectangle = Module03.FigureChangeEvent.EMPTY_RECTANGLE;
    }

    public FigureChangeEvent(Module03.Figure newSource ,java.awt.Rectangle newRect ,Module03.FigureChangeEvent nestedEvent) {
        this(newSource, newRect);
        myNestedEvent = nestedEvent;
    }

    public Module03.Figure getFigure() {
        return ((Module03.Figure)(getSource()));
    }

    public java.awt.Rectangle getInvalidatedRectangle() {
        return myRectangle;
    }

    public Module03.FigureChangeEvent getNestedEvent() {
        return myNestedEvent;
    }
}


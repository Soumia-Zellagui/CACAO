package Module03;


public class NullFigure extends Module03.AbstractFigure {
    private java.awt.Rectangle myDisplayBox;

    protected void basicMoveBy(int dx, int dy) {
        myDisplayBox.translate(dx, dy);
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        myDisplayBox = new java.awt.Rectangle(origin);
        myDisplayBox.add(corner);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(myDisplayBox);
    }

    public void draw(java.awt.Graphics g) {
    }

    public Module06.HandleEnumeration handles() {
        return Module06.HandleEnumerator.getEmptyEnumeration();
    }

    public boolean isEmpty() {
        return true;
    }

    public Module03.FigureEnumeration figures() {
        return Module03.FigureEnumerator.getEmptyEnumeration();
    }

    public Module03.Figure findFigureInside(int x, int y) {
        return null;
    }

    public java.lang.Object clone() {
        return super.clone();
    }

    public boolean includes(Module03.Figure figure) {
        return false;
    }

    public Module03.FigureEnumeration decompose() {
        return new Module03.SingleFigureEnumerator(Module03.NullFigure.this);
    }

    public void release() {
    }

    public void invalidate() {
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return null;
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        return null;
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
    }
}


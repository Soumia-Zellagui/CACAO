package Module03;


public class SelectAreaTracker extends Module03.AbstractTool {
    private java.awt.Rectangle fSelectGroup;

    private java.awt.Color fRubberBandColor;

    public SelectAreaTracker(Module01.DrawingEditor newDrawingEditor) {
        this(newDrawingEditor, java.awt.Color.black);
    }

    public SelectAreaTracker(Module01.DrawingEditor newDrawingEditor ,java.awt.Color rubberBandColor) {
        super(newDrawingEditor);
        fRubberBandColor = rubberBandColor;
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, e.getX(), e.getY());
        rubberBand(getAnchorX(), getAnchorY(), getAnchorX(), getAnchorY());
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDrag(e, x, y);
        eraseRubberBand();
        rubberBand(getAnchorX(), getAnchorY(), x, y);
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        eraseRubberBand();
        selectGroup(e.isShiftDown());
        super.mouseUp(e, x, y);
    }

    private void rubberBand(int x1, int y1, int x2, int y2) {
        fSelectGroup = new java.awt.Rectangle(new java.awt.Point(x1 , y1));
        fSelectGroup.add(new java.awt.Point(x2 , y2));
        drawXORRect(fSelectGroup);
    }

    private void eraseRubberBand() {
        drawXORRect(fSelectGroup);
    }

    private void drawXORRect(java.awt.Rectangle r) {
        java.awt.Graphics g = view().getGraphics();
        if (g != null) {
            try {
                if (g instanceof java.awt.Graphics2D) {
                    java.awt.Stroke dashedStroke = new java.awt.BasicStroke(1.0F , java.awt.BasicStroke.CAP_SQUARE , java.awt.BasicStroke.JOIN_MITER , 10.0F , new float[]{ 5.0F , 5.0F , 5.0F , 5.0F } , 5.0F);
                    ((java.awt.Graphics2D)(g)).setStroke(dashedStroke);
                } 
                g.setXORMode(view().getBackground());
                g.setColor(fRubberBandColor);
                g.drawRect(r.x, r.y, r.width, r.height);
            } finally {
                g.dispose();
            }
        } 
    }

    private void selectGroup(boolean toggle) {
        Module03.FigureEnumeration fe = drawing().figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            java.awt.Rectangle r2 = figure.displayBox();
            if ((fSelectGroup.contains(r2.x, r2.y)) && (fSelectGroup.contains(((r2.x) + (r2.width)), ((r2.y) + (r2.height))))) {
                if (toggle) {
                    view().toggleSelection(figure);
                } else {
                    view().addToSelection(figure);
                }
            } 
        }
    }
}


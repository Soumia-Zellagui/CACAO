package Module03;


public class MappedDrawingChangeListener implements Module03.DrawingChangeListener {
    private final Module06.MiniMapView miniMapView;

    public MappedDrawingChangeListener(Module06.MiniMapView miniMapView) {
        this.miniMapView = miniMapView;
    }

    public void drawingInvalidated(Module06.DrawingChangeEvent e) {
        Module03.MappedDrawingChangeListener.this.miniMapView.repaint();
    }

    public void drawingRequestUpdate(Module06.DrawingChangeEvent e) {
        Module03.MappedDrawingChangeListener.this.miniMapView.repaint();
    }

    public void drawingTitleChanged(Module06.DrawingChangeEvent e) {
    }
}


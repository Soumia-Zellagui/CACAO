package Module03;


public class TextAreaFigure extends Module03.AttributeFigure implements Module03.FigureChangeListener , Module03.TextHolder {
    protected boolean fTextIsDirty = true;

    protected transient boolean fSizeIsDirty = true;

    private java.awt.Rectangle fDisplayBox;

    protected java.util.List fParagraphs;

    protected java.lang.String fText;

    protected java.awt.Font fFont;

    protected boolean fFontIsDirty = true;

    protected float fFontWidth;

    protected java.util.Hashtable attributesMap = new java.util.Hashtable();

    protected boolean fIsReadOnly;

    protected Module03.Figure fObservedFigure = null;

    protected Module03.OffsetLocator fLocator = null;

    static final long serialVersionUID = 4993631445423148845L;

    static {
        Module03.AttributeFigure.initDefaultAttribute("LeftMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("RightMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("TopMargin", new java.lang.Float(5));
        Module03.AttributeFigure.initDefaultAttribute("TabSize", new java.lang.Float(8));
    }

    public TextAreaFigure() {
        fParagraphs = Module06.CollectionsFactory.current().createList();
        fDisplayBox = new java.awt.Rectangle(0 , 0 , 30 , 15);
        fFont = createFont();
        fText = new java.lang.String("");
        fSizeIsDirty = true;
        fTextIsDirty = true;
        fFontIsDirty = true;
    }

    public java.lang.String getText() {
        return fText;
    }

    public void setText(java.lang.String newText) {
        if ((newText == null) || (!(newText.equals(fText)))) {
            markTextDirty();
            fText = newText;
            changed();
        } 
    }

    public java.awt.Rectangle textDisplayBox() {
        return displayBox();
    }

    public java.awt.Font createFont() {
        return new java.awt.Font(((java.lang.String)(getAttribute("FontName"))) , ((java.lang.Integer)(getAttribute("FontStyle"))).intValue() , ((java.lang.Integer)(getAttribute("FontSize"))).intValue());
    }

    public boolean isReadOnly() {
        return fIsReadOnly;
    }

    public void setReadOnly(boolean newReadOnly) {
        fIsReadOnly = newReadOnly;
    }

    public boolean acceptsTyping() {
        return !(isReadOnly());
    }

    protected void markTextDirty() {
        setTextDirty(true);
    }

    protected void setTextDirty(boolean newTextDirty) {
        fTextIsDirty = newTextDirty;
    }

    public boolean isTextDirty() {
        return fTextIsDirty;
    }

    protected void markSizeDirty() {
        setSizeDirty(true);
    }

    public void setSizeDirty(boolean newSizeIsDirty) {
        fSizeIsDirty = newSizeIsDirty;
    }

    public boolean isSizeDirty() {
        return fSizeIsDirty;
    }

    public java.awt.Font getFont() {
        return fFont;
    }

    public void setFont(java.awt.Font newFont) {
        if (newFont == null) {
            throw new java.lang.IllegalArgumentException();
        } 
        willChange();
        fFont = newFont;
        markSizeDirty();
        markFontDirty();
        attributesMap = new java.util.Hashtable(1);
        attributesMap.put(java.awt.font.TextAttribute.FONT, newFont);
        changed();
    }

    public int overlayColumns() {
        return 0;
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
        java.awt.Dimension prevSize = fDisplayBox.getSize();
        fDisplayBox = new java.awt.Rectangle(origin);
        fDisplayBox.add(corner);
        if (!(fDisplayBox.getSize().equals(prevSize))) {
            markSizeDirty();
        } 
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        Module06.BoxHandleKit.addHandles(Module03.TextAreaFigure.this, handles);
        return new Module06.HandleEnumerator(handles);
    }

    public java.awt.Rectangle displayBox() {
        return new java.awt.Rectangle(fDisplayBox.x , fDisplayBox.y , fDisplayBox.width , fDisplayBox.height);
    }

    public void moveBy(int x, int y) {
        willChange();
        basicMoveBy(x, y);
        if ((fLocator) != null) {
            fLocator.moveBy(x, y);
        } 
        changed();
    }

    protected void basicMoveBy(int x, int y) {
        fDisplayBox.translate(x, y);
    }

    public void drawBackground(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.fillRect(r.x, r.y, r.width, r.height);
    }

    public void draw(java.awt.Graphics g) {
        super.draw(g);
        drawText(g, displayBox());
    }

    public void drawFrame(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(((java.awt.Color)(getAttribute("FrameColor"))));
        g.drawRect(r.x, r.y, r.width, r.height);
    }

    protected float drawText(java.awt.Graphics g, java.awt.Rectangle displayBox) {
        java.awt.Graphics2D g2 = null;
        java.awt.Shape savedClipArea = null;
        java.awt.Color savedFontColor = null;
        java.awt.geom.Rectangle2D clipRect = null;
        java.awt.RenderingHints savedRenderingHints = null;
        if (g != null) {
            g2 = ((java.awt.Graphics2D)(g));
            savedRenderingHints = g2.getRenderingHints();
            g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(java.awt.RenderingHints.KEY_RENDERING, java.awt.RenderingHints.VALUE_RENDER_QUALITY);
            savedFontColor = g2.getColor();
            savedClipArea = g2.getClip();
            if (savedClipArea != null) {
                clipRect = displayBox.createIntersection(((java.awt.geom.Rectangle2D)(savedClipArea)));
            } else {
                clipRect = displayBox;
            }
            g2.setClip(clipRect);
            java.awt.Color textColor = getTextColor();
            if (!(Module06.ColorMap.isTransparent(textColor))) {
                g2.setColor(textColor);
            } 
            g2.setFont(getFont());
        } 
        java.awt.font.FontRenderContext fontRenderCtx = new java.awt.font.FontRenderContext(null , false , false);
        prepareText();
        float leftMargin = (displayBox.x) + (((java.lang.Float)(getAttribute("LeftMargin"))).floatValue());
        float rightMargin = ((displayBox.x) + (displayBox.width)) - (((java.lang.Float)(getAttribute("RightMargin"))).floatValue());
        float topMargin = (displayBox.y) + (((java.lang.Float)(getAttribute("TopMargin"))).floatValue());
        float[] tabStops = new float[40];
        float tabSize = (((java.lang.Float)(getAttribute("TabSize"))).floatValue()) * (getFontWidth());
        float tabPos = tabSize;
        for (int tabCnt = 0 ; tabCnt < 40 ; tabCnt++) {
            tabStops[tabCnt] = tabPos + leftMargin;
            tabPos += tabSize;
        }
        float verticalPos = topMargin;
        java.util.Iterator paragraphs = fParagraphs.iterator();
        while (paragraphs.hasNext()) {
            java.lang.String paragraphText = ((java.lang.String)(paragraphs.next()));
            java.text.AttributedString attrText = new java.text.AttributedString(paragraphText);
            java.text.AttributedCharacterIterator paragraphIter = attrText.getIterator();
            int[] tabLocations = new int[paragraphText.length()];
            int tabCount = 0;
            for (char c = paragraphIter.first() ; c != (java.text.CharacterIterator.DONE) ; c = paragraphIter.next()) {
                if (c == '\t') {
                    tabLocations[(tabCount++)] = paragraphIter.getIndex();
                } 
            }
            tabLocations[tabCount] = (paragraphIter.getEndIndex()) - 1;
            paragraphText = paragraphText.replace('\t', ' ');
            attrText = new java.text.AttributedString(paragraphText , attributesMap);
            paragraphIter = attrText.getIterator();
            java.awt.font.LineBreakMeasurer measurer = new java.awt.font.LineBreakMeasurer(paragraphIter , fontRenderCtx);
            int currentTab = 0;
            while ((measurer.getPosition()) < (paragraphIter.getEndIndex())) {
                boolean lineContainsText = false;
                boolean lineComplete = false;
                float maxAscent = 0;
                float maxDescent = 0;
                float horizontalPos = leftMargin;
                java.util.List layouts = Module06.CollectionsFactory.current().createList(1);
                java.util.List penPositions = Module06.CollectionsFactory.current().createList(1);
                while (!lineComplete) {
                    float wrappingWidth = rightMargin - horizontalPos;
                    wrappingWidth = java.lang.Math.max(1, wrappingWidth);
                    java.awt.font.TextLayout layout = measurer.nextLayout(wrappingWidth, ((tabLocations[currentTab]) + 1), lineContainsText);
                    if (layout != null) {
                        layouts.add(layout);
                        penPositions.add(new java.lang.Float(horizontalPos));
                        horizontalPos += layout.getAdvance();
                        maxAscent = java.lang.Math.max(maxAscent, layout.getAscent());
                        maxDescent = java.lang.Math.max(maxDescent, ((layout.getDescent()) + (layout.getLeading())));
                    } else {
                        lineComplete = true;
                    }
                    lineContainsText = true;
                    if ((measurer.getPosition()) == ((tabLocations[currentTab]) + 1)) {
                        currentTab++;
                    } 
                    if ((measurer.getPosition()) == (paragraphIter.getEndIndex())) {
                        lineComplete = true;
                    } else if (horizontalPos >= (tabStops[((tabStops.length) - 1)])) {
                        lineComplete = true;
                    } 
                    if (!lineComplete) {
                        int j;
                        for (j = 0 ; horizontalPos >= (tabStops[j]) ; j++) {
                        }
                        horizontalPos = tabStops[j];
                    } 
                }
                verticalPos += maxAscent;
                java.util.Iterator layoutEnum = layouts.iterator();
                java.util.Iterator positionEnum = penPositions.iterator();
                while (layoutEnum.hasNext()) {
                    java.awt.font.TextLayout nextLayout = ((java.awt.font.TextLayout)(layoutEnum.next()));
                    java.lang.Float nextPosition = ((java.lang.Float)(positionEnum.next()));
                    if (g2 != null) {
                        nextLayout.draw(g2, nextPosition.floatValue(), verticalPos);
                    } 
                }
                verticalPos += maxDescent;
            }
        }
        if (((g2 != null) && (verticalPos > (clipRect.getMaxY()))) && ((clipRect.getMaxY()) == (displayBox.getMaxY()))) {
            java.awt.Stroke savedStroke = g2.getStroke();
            float[] dash = new float[2];
            dash[0] = 2.0F;
            dash[1] = 4.0F;
            g2.setStroke(new java.awt.BasicStroke(1.0F , java.awt.BasicStroke.CAP_SQUARE , java.awt.BasicStroke.JOIN_MITER , 1.0F , dash , 0.0F));
            g2.setColor(java.awt.Color.red);
            g2.drawLine((((int)(clipRect.getMinX())) + 1), (((int)(clipRect.getMaxY())) - 1), (((int)(clipRect.getMaxX())) - 1), (((int)(clipRect.getMaxY())) - 1));
            g2.setStroke(savedStroke);
        } 
        if (g2 != null) {
            if (savedClipArea != null) {
                g2.setClip(savedClipArea);
            } 
            g2.setColor(savedFontColor);
            g2.setRenderingHints(savedRenderingHints);
        } 
        return verticalPos;
    }

    protected void prepareText() {
        if (!(isTextDirty())) {
            return ;
        } 
        fParagraphs = Module06.CollectionsFactory.current().createList();
        java.lang.String paragraphText;
        java.awt.Point pos = new java.awt.Point((-1) , (-1));
        while ((paragraphText = getNextParagraph(fText, pos)) != null) {
            if ((paragraphText.length()) == 0) {
                paragraphText = " ";
            } 
            fParagraphs.add(paragraphText);
        }
        setTextDirty(false);
    }

    protected java.lang.String getNextParagraph(java.lang.String text, java.awt.Point pos) {
        int start = (pos.y) + 1;
        if (start >= (text.length())) {
            return null;
        } 
        pos.x = start;
        int end = text.indexOf('\n', start);
        if (end == (-1)) {
            end = text.length();
        } 
        pos.y = end;
        if ((text.charAt((end - 1))) == '\r') {
            return text.substring(start, (end - 1));
        } else {
            return text.substring(start, end);
        }
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return super.getAttribute(name);
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        java.awt.Font font = getFont();
        if (name.equals("FontSize")) {
            java.lang.Integer s = ((java.lang.Integer)(value));
            setFont(new java.awt.Font(font.getName() , font.getStyle() , s.intValue()));
            super.setAttribute(name, value);
        } else if (name.equals("FontStyle")) {
            java.lang.Integer s = ((java.lang.Integer)(value));
            int style = font.getStyle();
            if ((s.intValue()) == (java.awt.Font.PLAIN)) {
                style = java.awt.Font.PLAIN;
            } else {
                style = style ^ (s.intValue());
            }
            setFont(new java.awt.Font(font.getName() , style , font.getSize()));
            super.setAttribute(name, new java.lang.Integer(style));
        } else if (name.equals("FontName")) {
            java.lang.String n = ((java.lang.String)(value));
            setFont(new java.awt.Font(n , font.getStyle() , font.getSize()));
            super.setAttribute(name, value);
        } else {
            super.setAttribute(name, value);
        }
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fDisplayBox.x);
        dw.writeInt(fDisplayBox.y);
        dw.writeInt(fDisplayBox.width);
        dw.writeInt(fDisplayBox.height);
        dw.writeString(fText);
        dw.writeBoolean(fIsReadOnly);
        dw.writeStorable(fObservedFigure);
        dw.writeStorable(fLocator);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        markSizeDirty();
        markTextDirty();
        markFontDirty();
        fDisplayBox.x = dr.readInt();
        fDisplayBox.y = dr.readInt();
        fDisplayBox.width = dr.readInt();
        fDisplayBox.height = dr.readInt();
        fText = dr.readString();
        fIsReadOnly = dr.readBoolean();
        fObservedFigure = ((Module03.Figure)(dr.readStorable()));
        if ((fObservedFigure) != null) {
            fObservedFigure.addFigureChangeListener(Module03.TextAreaFigure.this);
        } 
        fLocator = ((Module03.OffsetLocator)(dr.readStorable()));
        setFont(createFont());
    }

    protected void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((fObservedFigure) != null) {
            fObservedFigure.addFigureChangeListener(Module03.TextAreaFigure.this);
        } 
        markSizeDirty();
        markTextDirty();
        markFontDirty();
    }

    public void connect(Module03.Figure figure) {
        if ((fObservedFigure) != null) {
            fObservedFigure.removeFigureChangeListener(Module03.TextAreaFigure.this);
        } 
        fObservedFigure = figure;
        fLocator = new Module03.OffsetLocator(figure.connectedTextLocator(Module03.TextAreaFigure.this));
        fObservedFigure.addFigureChangeListener(Module03.TextAreaFigure.this);
        updateLocation();
    }

    public void disconnect(Module03.Figure disconnectFigure) {
        if (disconnectFigure != null) {
            disconnectFigure.removeFigureChangeListener(Module03.TextAreaFigure.this);
        } 
        fLocator = null;
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        updateLocation();
    }

    protected void updateLocation() {
        if ((fLocator) != null) {
            java.awt.Point p = fLocator.locate(fObservedFigure);
            p.x -= ((size().width) / 2) + (fDisplayBox.x);
            p.y -= ((size().height) / 2) + (fDisplayBox.y);
            if (((p.x) != 0) || ((p.y) != 0)) {
                willChange();
                basicMoveBy(p.x, p.y);
                changed();
            } 
        } 
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            listener().figureRemoved(new Module03.FigureChangeEvent(Module03.TextAreaFigure.this));
        } 
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            listener().figureRequestRemove(new Module03.FigureChangeEvent(Module03.TextAreaFigure.this));
        } 
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
    }

    protected float getFontWidth() {
        updateFontInfo();
        return fFontWidth;
    }

    protected void updateFontInfo() {
        if (!(isFontDirty())) {
            return ;
        } 
        fFontWidth = ((int)(getFont().getMaxCharBounds(new java.awt.font.FontRenderContext(null , false , false)).getWidth()));
        setFontDirty(false);
    }

    public java.awt.Color getTextColor() {
        return ((java.awt.Color)(getAttribute("TextColor")));
    }

    public boolean isEmpty() {
        return (fText.length()) == 0;
    }

    protected void markFontDirty() {
        setFontDirty(true);
    }

    public boolean isFontDirty() {
        return fFontIsDirty;
    }

    public void setFontDirty(boolean newFontIsDirty) {
        fFontIsDirty = newFontIsDirty;
    }

    public Module03.Figure getRepresentingFigure() {
        return Module03.TextAreaFigure.this;
    }
}


package Module03;


public class BouncingDrawing extends Module03.StandardDrawing implements Module03.Animatable {
    private static final long serialVersionUID = -8566272817418441758L;

    private int bouncingDrawingSerializedDataVersion = 1;

    public synchronized Module03.Figure add(Module03.Figure figure) {
        if ((!(figure instanceof Module03.AnimationDecorator)) && (!(figure instanceof Module03.ConnectionFigure))) {
            figure = new Module03.AnimationDecorator(figure);
        } 
        return super.add(figure);
    }

    public synchronized Module03.Figure remove(Module03.Figure figure) {
        Module03.Figure f = super.remove(figure);
        if (f instanceof Module03.AnimationDecorator) {
            return ((Module03.AnimationDecorator)(f)).peelDecoration();
        } 
        return f;
    }

    public synchronized Module03.Figure replace(Module03.Figure figure, Module03.Figure replacement) {
        if ((!(replacement instanceof Module03.AnimationDecorator)) && (!(replacement instanceof Module03.ConnectionFigure))) {
            replacement = new Module03.AnimationDecorator(replacement);
        } 
        return super.replace(figure, replacement);
    }

    public void animationStep() {
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure f = fe.nextFigure();
            if (!(f instanceof Module03.ConnectionFigure)) {
                ((Module03.AnimationDecorator)(f)).animationStep();
            } 
        }
    }
}


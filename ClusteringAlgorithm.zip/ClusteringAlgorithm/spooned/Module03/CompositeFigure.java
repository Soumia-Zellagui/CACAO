package Module03;


public abstract class CompositeFigure extends Module03.AbstractFigure implements Module03.FigureChangeListener {
    protected java.util.List fFigures;

    private static final long serialVersionUID = 7408153435700021866L;

    private int compositeFigureSerializedDataVersion = 1;

    private transient Module03.QuadTree _theQuadTree;

    protected int _nLowestZ;

    protected int _nHighestZ;

    protected CompositeFigure() {
        fFigures = Module06.CollectionsFactory.current().createList();
        _nLowestZ = 0;
        _nHighestZ = 0;
    }

    public Module03.Figure add(Module03.Figure figure) {
        if (!(containsFigure(figure))) {
            figure.setZValue((++(_nHighestZ)));
            fFigures.add(figure);
            figure.addToContainer(Module03.CompositeFigure.this);
            _addToQuadTree(figure);
        } 
        return figure;
    }

    public void addAll(java.util.List newFigures) {
        addAll(new Module03.FigureEnumerator(newFigures));
    }

    public void addAll(Module03.FigureEnumeration fe) {
        while (fe.hasNextFigure()) {
            add(fe.nextFigure());
        }
    }

    public Module03.Figure remove(Module03.Figure figure) {
        Module03.Figure orphanedFigure = orphan(figure);
        if (orphanedFigure != null) {
            orphanedFigure.release();
        } 
        return orphanedFigure;
    }

    public void removeAll(java.util.List figures) {
        removeAll(new Module03.FigureEnumerator(figures));
    }

    public void removeAll(Module03.FigureEnumeration fe) {
        while (fe.hasNextFigure()) {
            remove(fe.nextFigure());
        }
    }

    public void removeAll() {
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            figure.removeFromContainer(Module03.CompositeFigure.this);
        }
        fFigures.clear();
        _clearQuadTree();
        _nLowestZ = 0;
        _nHighestZ = 0;
    }

    public synchronized Module03.Figure orphan(Module03.Figure figure) {
        figure.removeFromContainer(Module03.CompositeFigure.this);
        fFigures.remove(figure);
        _removeFromQuadTree(figure);
        return figure;
    }

    public void orphanAll(java.util.List newFigures) {
        orphanAll(new Module03.FigureEnumerator(newFigures));
    }

    public void orphanAll(Module03.FigureEnumeration fe) {
        while (fe.hasNextFigure()) {
            orphan(fe.nextFigure());
        }
    }

    public synchronized Module03.Figure replace(Module03.Figure figure, Module03.Figure replacement) {
        int index = fFigures.indexOf(figure);
        if (index != (-1)) {
            replacement.setZValue(figure.getZValue());
            replacement.addToContainer(Module03.CompositeFigure.this);
            figure.removeFromContainer(Module03.CompositeFigure.this);
            fFigures.set(index, replacement);
            figure.changed();
            replacement.changed();
        } 
        return replacement;
    }

    public synchronized void sendToBack(Module03.Figure figure) {
        if (containsFigure(figure)) {
            fFigures.remove(figure);
            fFigures.add(0, figure);
            (_nLowestZ)--;
            figure.setZValue(_nLowestZ);
            figure.changed();
        } 
    }

    public synchronized void bringToFront(Module03.Figure figure) {
        if (containsFigure(figure)) {
            fFigures.remove(figure);
            fFigures.add(figure);
            (_nHighestZ)++;
            figure.setZValue(_nHighestZ);
            figure.changed();
        } 
    }

    public void sendToLayer(Module03.Figure figure, int layerNr) {
        if (containsFigure(figure)) {
            if (layerNr >= (fFigures.size())) {
                layerNr = (fFigures.size()) - 1;
            } 
            Module03.Figure layerFigure = getFigureFromLayer(layerNr);
            int layerFigureZValue = layerFigure.getZValue();
            int figureLayer = getLayer(figure);
            if (figureLayer < layerNr) {
                assignFiguresToPredecessorZValue((figureLayer + 1), layerNr);
            } else if (figureLayer > layerNr) {
                assignFiguresToSuccessorZValue(layerNr, (figureLayer - 1));
            } 
            fFigures.remove(figure);
            fFigures.add(layerNr, figure);
            figure.setZValue(layerFigureZValue);
            figure.changed();
        } 
    }

    private void assignFiguresToPredecessorZValue(int lowerBound, int upperBound) {
        if (upperBound >= (fFigures.size())) {
            upperBound = (fFigures.size()) - 1;
        } 
        for (int i = upperBound ; i >= lowerBound ; i--) {
            Module03.Figure currentFigure = ((Module03.Figure)(fFigures.get(i)));
            Module03.Figure predecessorFigure = ((Module03.Figure)(fFigures.get((i - 1))));
            currentFigure.setZValue(predecessorFigure.getZValue());
        }
    }

    private void assignFiguresToSuccessorZValue(int lowerBound, int upperBound) {
        if (upperBound >= (fFigures.size())) {
            upperBound = (fFigures.size()) - 1;
        } 
        for (int i = upperBound ; i >= lowerBound ; i--) {
            Module03.Figure currentFigure = ((Module03.Figure)(fFigures.get(i)));
            Module03.Figure successorFigure = ((Module03.Figure)(fFigures.get((i + 1))));
            currentFigure.setZValue(successorFigure.getZValue());
        }
    }

    public int getLayer(Module03.Figure figure) {
        if (!(containsFigure(figure))) {
            return -1;
        } else {
            return fFigures.indexOf(figure);
        }
    }

    public Module03.Figure getFigureFromLayer(int layerNr) {
        if ((layerNr >= 0) && (layerNr < (fFigures.size()))) {
            return ((Module03.Figure)(fFigures.get(layerNr)));
        } else {
            return null;
        }
    }

    public void draw(java.awt.Graphics g) {
        draw(g, figures());
    }

    public void draw(java.awt.Graphics g, Module03.FigureEnumeration fe) {
        while (fe.hasNextFigure()) {
            fe.nextFigure().draw(g);
        }
    }

    public Module03.Figure figureAt(int i) {
        return ((Module03.Figure)(fFigures.get(i)));
    }

    public Module03.FigureEnumeration figures() {
        Module03.FigureEnumerator figureEnumerator = new Module03.FigureEnumerator(Module06.CollectionsFactory.current().createList(fFigures));
        return figureEnumerator;
    }

    public Module03.FigureEnumeration figures(java.awt.Rectangle viewRectangle) {
        if ((_theQuadTree) != null) {
            Module06.Bounds bounds = new Module06.Bounds(viewRectangle);
            java.awt.geom.Rectangle2D rectangle2D = bounds.asRectangle2D();
            Module03.FigureEnumeration fe = _theQuadTree.getAllWithin(rectangle2D);
            java.util.List l2 = Module06.CollectionsFactory.current().createList();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                l2.add(new Module06.OrderedFigureElement(f , f.getZValue()));
            }
            java.util.Collections.sort(l2);
            java.util.List l3 = Module06.CollectionsFactory.current().createList();
            for (java.util.Iterator iter = l2.iterator() ; iter.hasNext() ; ) {
                Module06.OrderedFigureElement ofe = ((Module06.OrderedFigureElement)(iter.next()));
                l3.add(ofe.getFigure());
            }
            Module03.FigureEnumerator figureEnumerator = new Module03.FigureEnumerator(l3);
            return figureEnumerator;
        } 
        return figures();
    }

    public int figureCount() {
        return fFigures.size();
    }

    public boolean containsFigure(Module03.Figure checkFigure) {
        return fFigures.contains(checkFigure);
    }

    public final Module03.FigureEnumeration figuresReverse() {
        Module03.ReverseFigureEnumerator reverseFigureEnumerator = new Module03.ReverseFigureEnumerator(Module06.CollectionsFactory.current().createList(fFigures));
        return reverseFigureEnumerator;
    }

    public Module03.Figure findFigure(int x, int y) {
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (figure.containsPoint(x, y)) {
                return figure;
            } 
        }
        return null;
    }

    public Module03.Figure findFigure(java.awt.Rectangle r) {
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            java.awt.Rectangle fr = figure.displayBox();
            if (r.intersects(fr)) {
                return figure;
            } 
        }
        return null;
    }

    public Module03.Figure findFigureWithout(int x, int y, Module03.Figure without) {
        if (without == null) {
            return findFigure(x, y);
        } 
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if ((figure.containsPoint(x, y)) && (!(figure.includes(without)))) {
                return figure;
            } 
        }
        return null;
    }

    public Module03.Figure findFigure(java.awt.Rectangle r, Module03.Figure without) {
        if (without == null) {
            return findFigure(r);
        } 
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            java.awt.Rectangle fr = figure.displayBox();
            if ((r.intersects(fr)) && (!(figure.includes(without)))) {
                return figure;
            } 
        }
        return null;
    }

    public Module03.Figure findFigureInside(int x, int y) {
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure f = fe.nextFigure();
            Module03.Figure figure = f.findFigureInside(x, y);
            if (figure != null) {
                return figure;
            } 
        }
        if (containsPoint(x, y)) {
            return Module03.CompositeFigure.this;
        } else {
            return null;
        }
    }

    public Module03.Figure findFigureInsideWithout(int x, int y, Module03.Figure without) {
        if (without == null) {
            return findFigureInside(x, y);
        } 
        Module03.FigureEnumeration fe = figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (figure != without) {
                Module03.Figure found = figure.findFigureInside(x, y);
                if ((found != null) && (!(figure.includes(without)))) {
                    return found;
                } 
            } 
        }
        if (containsPoint(x, y)) {
            return Module03.CompositeFigure.this;
        } else {
            return null;
        }
    }

    public boolean includes(Module03.Figure figure) {
        if (super.includes(figure)) {
            return true;
        } 
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure f = fe.nextFigure();
            if (f.includes(figure)) {
                return true;
            } 
        }
        return false;
    }

    protected void basicMoveBy(int x, int y) {
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure f = fe.nextFigure();
            f.moveBy(x, y);
        }
    }

    public void release() {
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            figure.release();
        }
        super.release();
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            Module03.FigureChangeListener listener = listener();
            listener.figureInvalidated(e);
        } 
    }

    public void figureRequestRemove(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            Module03.FigureChangeEvent figureChangeEvent = new Module03.FigureChangeEvent(Module03.CompositeFigure.this);
            Module03.FigureChangeListener listener = listener();
            listener.figureRequestRemove(figureChangeEvent);
        } 
    }

    public void figureRequestUpdate(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            Module03.FigureChangeListener listener = listener();
            listener.figureRequestUpdate(e);
        } 
    }

    public void figureChanged(Module03.FigureChangeEvent e) {
        Module03.Figure fig = e.getFigure();
        _removeFromQuadTree(fig);
        _addToQuadTree(fig);
    }

    public void figureRemoved(Module03.FigureChangeEvent e) {
        if ((listener()) != null) {
            Module03.FigureChangeListener listener = listener();
            listener.figureRemoved(e);
        } 
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(figureCount());
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            dw.writeStorable(fe.nextFigure());
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        int size = dr.readInt();
        fFigures = Module06.CollectionsFactory.current().createList(size);
        for (int i = 0 ; i < size ; i++) {
            Module03.Figure Figure = ((Module03.Figure)(dr.readStorable()));
            add(Figure);
        }
        init(displayBox());
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            figure.addToContainer(Module03.CompositeFigure.this);
        }
        init(new java.awt.Rectangle(0 , 0));
    }

    public void init(java.awt.Rectangle viewRectangle) {
        _theQuadTree = new Module03.QuadTree(new Module06.Bounds(viewRectangle).asRectangle2D());
        Module03.FigureEnumeration fe = figures();
        while (fe.hasNextFigure()) {
            _addToQuadTree(fe.nextFigure());
        }
    }

    private void _addToQuadTree(Module03.Figure f) {
        if ((_theQuadTree) != null) {
            java.awt.Rectangle r = f.displayBox();
            if ((r.height) == 0) {
                r.grow(0, 1);
            } 
            if ((r.width) == 0) {
                r.grow(1, 0);
            } 
            _theQuadTree.add(f, new Module06.Bounds(r).asRectangle2D());
        } 
    }

    private void _removeFromQuadTree(Module03.Figure f) {
        if ((_theQuadTree) != null) {
            _theQuadTree.remove(f);
        } 
    }

    private void _clearQuadTree() {
        if ((_theQuadTree) != null) {
            _theQuadTree.clear();
        } 
    }
}


package Module03;


public abstract class AbstractConnector implements Module03.Connector {
    private Module03.Figure fOwner;

    private static final long serialVersionUID = -5170007865562687545L;

    private int abstractConnectorSerializedDataVersion = 1;

    public AbstractConnector() {
        fOwner = null;
    }

    public AbstractConnector(Module03.Figure owner) {
        fOwner = owner;
    }

    public Module03.Figure owner() {
        return fOwner;
    }

    public java.awt.Point findStart(Module03.ConnectionFigure connection) {
        return findPoint(connection);
    }

    public java.awt.Point findEnd(Module03.ConnectionFigure connection) {
        return findPoint(connection);
    }

    protected java.awt.Point findPoint(Module03.ConnectionFigure connection) {
        return Module06.Geom.center(displayBox());
    }

    public java.awt.Rectangle displayBox() {
        return owner().displayBox();
    }

    public boolean containsPoint(int x, int y) {
        return owner().containsPoint(x, y);
    }

    public void draw(java.awt.Graphics g) {
    }

    public void write(Module06.StorableOutput dw) {
        dw.writeStorable(owner());
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        fOwner = ((Module03.Figure)(dr.readStorable()));
    }

    public void connectorVisibility(boolean isVisible, Module03.ConnectionFigure courtingConnection) {
    }
}


package Module03;


public abstract class AbstractContentProducer implements Module03.ContentProducer , java.io.Serializable {
    static final long serialVersionUID = -2715253447095419531L;

    public AbstractContentProducer() {
    }

    public void write(Module06.StorableOutput dw) {
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
    }
}


package Module03;


public class PolyLineFigure extends Module03.AbstractFigure {
    public static final int ARROW_TIP_NONE = 0;

    public static final int ARROW_TIP_START = 1;

    public static final int ARROW_TIP_END = 2;

    public static final int ARROW_TIP_BOTH = 3;

    protected java.util.List fPoints;

    protected Module03.LineDecoration fStartDecoration = null;

    protected Module03.LineDecoration fEndDecoration = null;

    protected java.awt.Color fFrameColor = java.awt.Color.black;

    private static final long serialVersionUID = -7951352179906577773L;

    private int polyLineFigureSerializedDataVersion = 1;

    public PolyLineFigure() {
        this(4);
    }

    public PolyLineFigure(int size) {
        fPoints = Module06.CollectionsFactory.current().createList(size);
    }

    public PolyLineFigure(int x ,int y) {
        fPoints = Module06.CollectionsFactory.current().createList();
        fPoints.add(new java.awt.Point(x , y));
    }

    public java.awt.Rectangle displayBox() {
        java.util.Iterator iter = points();
        if (iter.hasNext()) {
            java.awt.Rectangle r = new java.awt.Rectangle(((java.awt.Point)(iter.next())));
            while (iter.hasNext()) {
                r.add(((java.awt.Point)(iter.next())));
            }
            return r;
        } else {
            return new java.awt.Rectangle();
        }
    }

    public boolean isEmpty() {
        return ((size().width) < 3) && ((size().height) < 3);
    }

    public Module06.HandleEnumeration handles() {
        java.util.List handles = Module06.CollectionsFactory.current().createList(fPoints.size());
        for (int i = 0 ; i < (fPoints.size()) ; i++) {
            handles.add(new Module05.PolyLineHandle(Module03.PolyLineFigure.this , Module03.PolyLineFigure.locator(i) , i));
        }
        return new Module06.HandleEnumerator(handles);
    }

    public void basicDisplayBox(java.awt.Point origin, java.awt.Point corner) {
    }

    public void addPoint(int x, int y) {
        fPoints.add(new java.awt.Point(x , y));
        changed();
    }

    public java.util.Iterator points() {
        return fPoints.iterator();
    }

    public int pointCount() {
        return fPoints.size();
    }

    protected void basicMoveBy(int dx, int dy) {
        java.util.Iterator iter = points();
        while (iter.hasNext()) {
            ((java.awt.Point)(iter.next())).translate(dx, dy);
        }
    }

    public void setPointAt(java.awt.Point p, int i) {
        willChange();
        fPoints.set(i, p);
        changed();
    }

    public void insertPointAt(java.awt.Point p, int i) {
        fPoints.add(i, p);
        changed();
    }

    public void removePointAt(int i) {
        willChange();
        fPoints.remove(i);
        changed();
    }

    public int splitSegment(int x, int y) {
        int i = findSegment(x, y);
        if (i != (-1)) {
            insertPointAt(new java.awt.Point(x , y), (i + 1));
        } 
        return i + 1;
    }

    public java.awt.Point pointAt(int i) {
        return ((java.awt.Point)(fPoints.get(i)));
    }

    public boolean joinSegments(int x, int y) {
        for (int i = 1 ; i < ((fPoints.size()) - 1) ; i++) {
            java.awt.Point p = pointAt(i);
            if ((Module06.Geom.length(x, y, p.x, p.y)) < 3) {
                removePointAt(i);
                return true;
            } 
        }
        return false;
    }

    public Module03.Connector connectorAt(int x, int y) {
        return new Module03.PolyLineConnector(Module03.PolyLineFigure.this);
    }

    public void setStartDecoration(Module03.LineDecoration l) {
        fStartDecoration = l;
    }

    public Module03.LineDecoration getStartDecoration() {
        return fStartDecoration;
    }

    public void setEndDecoration(Module03.LineDecoration l) {
        fEndDecoration = l;
    }

    public Module03.LineDecoration getEndDecoration() {
        return fEndDecoration;
    }

    public void draw(java.awt.Graphics g) {
        g.setColor(getFrameColor());
        java.awt.Point p1;
        java.awt.Point p2;
        for (int i = 0 ; i < ((fPoints.size()) - 1) ; i++) {
            p1 = pointAt(i);
            p2 = pointAt((i + 1));
            drawLine(g, p1.x, p1.y, p2.x, p2.y);
        }
        decorate(g);
    }

    protected void drawLine(java.awt.Graphics g, int x1, int y1, int x2, int y2) {
        g.drawLine(x1, y1, x2, y2);
    }

    public boolean containsPoint(int x, int y) {
        java.awt.Rectangle bounds = displayBox();
        bounds.grow(4, 4);
        if (!(bounds.contains(x, y))) {
            return false;
        } 
        for (int i = 0 ; i < ((fPoints.size()) - 1) ; i++) {
            java.awt.Point p1 = pointAt(i);
            java.awt.Point p2 = pointAt((i + 1));
            if (Module06.Geom.lineContainsPoint(p1.x, p1.y, p2.x, p2.y, x, y)) {
                return true;
            } 
        }
        return false;
    }

    public int findSegment(int x, int y) {
        for (int i = 0 ; i < ((fPoints.size()) - 1) ; i++) {
            java.awt.Point p1 = pointAt(i);
            java.awt.Point p2 = pointAt((i + 1));
            if (Module06.Geom.lineContainsPoint(p1.x, p1.y, p2.x, p2.y, x, y)) {
                return i;
            } 
        }
        return -1;
    }

    private void decorate(java.awt.Graphics g) {
        if ((getStartDecoration()) != null) {
            java.awt.Point p1 = pointAt(0);
            java.awt.Point p2 = pointAt(1);
            getStartDecoration().draw(g, p1.x, p1.y, p2.x, p2.y);
        } 
        if ((getEndDecoration()) != null) {
            java.awt.Point p3 = pointAt(((fPoints.size()) - 2));
            java.awt.Point p4 = pointAt(((fPoints.size()) - 1));
            getEndDecoration().draw(g, p4.x, p4.y, p3.x, p3.y);
        } 
    }

    public java.lang.Object getAttribute(java.lang.String name) {
        return getAttribute(Module06.FigureAttributeConstant.getConstant(name));
    }

    public java.lang.Object getAttribute(Module06.FigureAttributeConstant attributeConstant) {
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FRAME_COLOR)) {
            return getFrameColor();
        } else if (attributeConstant.equals(Module06.FigureAttributeConstant.ARROW_MODE)) {
            int value = 0;
            if ((getStartDecoration()) != null) {
                value |= Module03.PolyLineFigure.ARROW_TIP_START;
            } 
            if ((getEndDecoration()) != null) {
                value |= Module03.PolyLineFigure.ARROW_TIP_END;
            } 
            return new java.lang.Integer(value);
        } 
        return super.getAttribute(attributeConstant);
    }

    public void setAttribute(java.lang.String name, java.lang.Object value) {
        setAttribute(Module06.FigureAttributeConstant.getConstant(name), value);
    }

    public void setAttribute(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        if (attributeConstant.equals(Module06.FigureAttributeConstant.FRAME_COLOR)) {
            setFrameColor(((java.awt.Color)(value)));
            changed();
        } else if (attributeConstant.equals(Module06.FigureAttributeConstant.ARROW_MODE)) {
            java.lang.Integer intObj = ((java.lang.Integer)(value));
            if (intObj != null) {
                int decoration = intObj.intValue();
                if ((decoration & (Module03.PolyLineFigure.ARROW_TIP_START)) != 0) {
                    setStartDecoration(new Module03.ArrowTip());
                } else {
                    setStartDecoration(null);
                }
                if ((decoration & (Module03.PolyLineFigure.ARROW_TIP_END)) != 0) {
                    setEndDecoration(new Module03.ArrowTip());
                } else {
                    setEndDecoration(null);
                }
            } 
            changed();
        } else {
            super.setAttribute(attributeConstant, value);
        }
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeInt(fPoints.size());
        java.util.Iterator iter = points();
        while (iter.hasNext()) {
            java.awt.Point p = ((java.awt.Point)(iter.next()));
            dw.writeInt(p.x);
            dw.writeInt(p.y);
        }
        dw.writeStorable(fStartDecoration);
        dw.writeStorable(fEndDecoration);
        dw.writeColor(fFrameColor);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        int size = dr.readInt();
        fPoints = Module06.CollectionsFactory.current().createList(size);
        for (int i = 0 ; i < size ; i++) {
            int x = dr.readInt();
            int y = dr.readInt();
            fPoints.add(new java.awt.Point(x , y));
        }
        setStartDecoration(((Module03.LineDecoration)(dr.readStorable())));
        setEndDecoration(((Module03.LineDecoration)(dr.readStorable())));
        fFrameColor = dr.readColor();
    }

    public static Module03.Locator locator(int pointIndex) {
        return new Module03.PolyLineLocator(pointIndex);
    }

    protected java.awt.Color getFrameColor() {
        return fFrameColor;
    }

    protected void setFrameColor(java.awt.Color c) {
        fFrameColor = c;
    }

    protected java.awt.Rectangle invalidateRectangle(java.awt.Rectangle r) {
        r.grow(Module05.Handle.HANDLESIZE, Module05.Handle.HANDLESIZE);
        if ((getStartDecoration()) != null) {
            Module03.LineDecoration ld = getStartDecoration();
            java.awt.Rectangle rec = ld.displayBox();
            r.add(rec);
        } 
        if ((getEndDecoration()) != null) {
            Module03.LineDecoration ld = getStartDecoration();
            java.awt.Rectangle rec = ld.displayBox();
            r.add(rec);
        } 
        return r;
    }
}


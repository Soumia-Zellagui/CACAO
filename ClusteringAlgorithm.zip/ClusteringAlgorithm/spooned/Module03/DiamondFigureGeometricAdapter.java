package Module03;


public class DiamondFigureGeometricAdapter extends Module03.DiamondFigure implements Module03.GeometricFigure {
    public DiamondFigureGeometricAdapter() {
        super();
    }

    public DiamondFigureGeometricAdapter(java.awt.Point origin ,java.awt.Point corner) {
        super(origin, corner);
    }

    public java.awt.Shape getShape() {
        return getPolygon();
    }
}


package Module03;


public class RoundRectangleGeometricAdapter extends Module03.RoundRectangleFigure implements Module03.GeometricFigure {
    public RoundRectangleGeometricAdapter() {
        super();
    }

    public RoundRectangleGeometricAdapter(java.awt.Point origin ,java.awt.Point corner) {
        super(origin, corner);
    }

    public java.awt.Shape getShape() {
        java.awt.Point arc = getArc();
        java.awt.Rectangle dspBox = displayBox();
        java.awt.geom.RoundRectangle2D.Float roundRectangle = new java.awt.geom.RoundRectangle2D.Float(dspBox.x , dspBox.y , dspBox.width , dspBox.height , arc.x , arc.y);
        return roundRectangle;
    }
}


package Module03;


class ElbowTextLocator extends Module03.AbstractLocator {
    public java.awt.Point locate(Module03.Figure owner) {
        java.awt.Point p = owner.center();
        return new java.awt.Point(p.x , ((p.y) - 10));
    }
}


package Module03;


public class CreationTool extends Module03.AbstractTool {
    private java.util.List fAddedFigures;

    private Module03.Figure fCreatedFigure;

    private Module03.Figure myAddedFigure;

    private Module03.Figure myPrototypeFigure;

    public CreationTool(Module01.DrawingEditor newDrawingEditor ,Module03.Figure prototype) {
        super(newDrawingEditor);
        setPrototypeFigure(prototype);
    }

    protected CreationTool(Module01.DrawingEditor newDrawingEditor) {
        this(newDrawingEditor, null);
    }

    public void activate() {
        super.activate();
        if (isUsable()) {
            getActiveView().setCursor(new Module06.AWTCursor(java.awt.Cursor.CROSSHAIR_CURSOR));
        } 
        setAddedFigures(Module06.CollectionsFactory.current().createList());
    }

    public void deactivate() {
        setCreatedFigure(null);
        setAddedFigure(null);
        setAddedFigures(null);
        super.deactivate();
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        setCreatedFigure(createFigure());
        setAddedFigure(getActiveView().add(getCreatedFigure()));
        getAddedFigure().displayBox(new java.awt.Point(getAnchorX() , getAnchorY()), new java.awt.Point(getAnchorX() , getAnchorY()));
    }

    protected Module03.Figure createFigure() {
        if ((getPrototypeFigure()) == null) {
            throw new Module06.JHotDrawRuntimeException("No protoype defined");
        } 
        return ((Module03.Figure)(getPrototypeFigure().clone()));
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((getAddedFigure()) != null) {
            getAddedFigure().displayBox(new java.awt.Point(getAnchorX() , getAnchorY()), new java.awt.Point(x , y));
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if (((getAddedFigure()) != null) && (!(getCreatedFigure().isEmpty()))) {
            getAddedFigures().add(getAddedFigure());
        } else {
            getActiveView().remove(getAddedFigure());
        }
        if (getAddedFigures().isEmpty()) {
            setUndoActivity(null);
        } else {
            setUndoActivity(createUndoActivity());
            getUndoActivity().setAffectedFigures(new Module03.FigureEnumerator(getAddedFigures()));
        }
        editor().toolDone();
    }

    protected void setPrototypeFigure(Module03.Figure newPrototypeFigure) {
        myPrototypeFigure = newPrototypeFigure;
    }

    protected Module03.Figure getPrototypeFigure() {
        return myPrototypeFigure;
    }

    protected java.util.List getAddedFigures() {
        return fAddedFigures;
    }

    protected void setAddedFigures(java.util.List newAddedFigures) {
        fAddedFigures = newAddedFigures;
    }

    protected Module03.Figure getCreatedFigure() {
        return fCreatedFigure;
    }

    protected void setCreatedFigure(Module03.Figure newCreatedFigure) {
        fCreatedFigure = newCreatedFigure;
    }

    protected Module03.Figure getAddedFigure() {
        return myAddedFigure;
    }

    protected void setAddedFigure(Module03.Figure newAddedFigure) {
        myAddedFigure = newAddedFigure;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.PasteCommand.UndoActivity(getActiveView());
    }
}


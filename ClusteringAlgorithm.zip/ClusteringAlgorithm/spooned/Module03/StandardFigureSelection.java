package Module03;


public class StandardFigureSelection implements Module03.FigureSelection , java.io.Serializable {
    private byte[] fData;

    public static final java.lang.String TYPE = "org.jhotdraw.Figures";

    public StandardFigureSelection(Module03.FigureEnumeration fe ,int figureCount) {
        java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream(200);
        Module06.StorableOutput writer = new Module06.StorableOutput(output);
        writer.writeInt(figureCount);
        while (fe.hasNextFigure()) {
            writer.writeStorable(fe.nextFigure());
        }
        writer.close();
        fData = output.toByteArray();
    }

    public java.lang.String getType() {
        return Module03.StandardFigureSelection.TYPE;
    }

    public java.lang.Object getData(java.lang.String type) {
        if (type.equals(Module03.StandardFigureSelection.TYPE)) {
            java.io.InputStream input = new java.io.ByteArrayInputStream(fData);
            java.util.List result = Module06.CollectionsFactory.current().createList(10);
            Module06.StorableInput reader = new Module06.StorableInput(input);
            int numRead = 0;
            try {
                int count = reader.readInt();
                while (numRead < count) {
                    Module03.Figure newFigure = ((Module03.Figure)(reader.readStorable()));
                    result.add(newFigure);
                    numRead++;
                }
            } catch (java.io.IOException e) {
                java.lang.System.err.println(e.toString());
            }
            Module03.FigureEnumerator fe = new Module03.FigureEnumerator(result);
            return fe;
        } 
        return null;
    }

    public static Module03.FigureEnumeration duplicateFigures(Module03.FigureEnumeration toBeCloned, int figureCount) {
        Module03.StandardFigureSelection duplicater = new Module03.StandardFigureSelection(toBeCloned , figureCount);
        return ((Module03.FigureEnumeration)(duplicater.getData(duplicater.getType())));
    }
}


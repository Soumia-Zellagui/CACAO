package Module03;


public class DragNDropTool extends Module03.AbstractTool {
    private Module03.Tool fChild;

    private java.awt.dnd.DragGestureListener dragGestureListener;

    private boolean dragOn;

    public DragNDropTool(Module01.DrawingEditor editor) {
        super(editor);
        setDragGestureListener(createDragGestureListener());
        dragOn = false;
    }

    protected void viewCreated(Module03.DrawingView view) {
        super.viewCreated(view);
        if (Module03.DNDInterface.class.isInstance(view)) {
            Module03.DNDInterface dndi = ((Module03.DNDInterface)(view));
            dndi.DNDInitialize(getDragGestureListener());
        } 
    }

    protected void viewDestroying(Module03.DrawingView view) {
        if (Module03.DNDInterface.class.isInstance(view)) {
            Module03.DNDInterface dndi = ((Module03.DNDInterface)(view));
            dndi.DNDDeinitialize();
        } 
        super.viewDestroying(view);
    }

    public void activate() {
        super.activate();
        setDragOn(true);
    }

    public void deactivate() {
        setDragOn(false);
        super.deactivate();
    }

    public static void setCursor(int x, int y, Module03.DrawingView view) {
        if (view == null) {
            return ;
        } 
        Module05.Handle handle = view.findHandle(x, y);
        Module03.Figure figure = view.drawing().findFigure(x, y);
        if (handle != null) {
            view.setCursor(handle.getCursor());
        } else if (figure != null) {
            Module06.AWTCursor awtCursor = new Module06.AWTCursor(java.awt.Cursor.MOVE_CURSOR);
            view.setCursor(awtCursor);
        } else {
            Module06.AWTCursor awtCursor = new Module06.AWTCursor(java.awt.Cursor.DEFAULT_CURSOR);
            view.setCursor(awtCursor);
        }
    }

    public void mouseMove(java.awt.event.MouseEvent evt, int x, int y) {
        if ((evt.getSource()) == (getActiveView())) {
            Module03.DragNDropTool.setCursor(x, y, getActiveView());
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        if ((fChild) != null) {
            fChild.mouseUp(e, x, y);
            fChild = null;
        } 
        setDragOn(true);
        view().unfreezeView();
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        Module03.DrawingView view = view();
        Module03.Drawing drawing = drawing();
        if ((fChild) != null) {
            return ;
        } 
        view.freezeView();
        Module05.Handle handle = view.findHandle(getAnchorX(), getAnchorY());
        if (handle != null) {
            setDragOn(false);
            fChild = createHandleTracker(handle);
        } else {
            Module03.Figure figure = drawing.findFigure(getAnchorX(), getAnchorY());
            if (figure != null) {
                fChild = null;
                if (e.isShiftDown()) {
                    view.toggleSelection(figure);
                } else if (!(view.isFigureSelected(figure))) {
                    view.clearSelection();
                    view.addToSelection(figure);
                } 
            } else {
                setDragOn(false);
                if (!(e.isShiftDown())) {
                    view.clearSelection();
                } 
                fChild = createAreaTracker();
            }
        }
        if ((fChild) != null) {
            fChild.mouseDown(e, x, y);
        } 
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        if ((fChild) != null) {
            fChild.mouseDrag(e, x, y);
        } 
    }

    protected Module03.Tool createAreaTracker() {
        Module03.SelectAreaTracker selectAreaTracker = new Module03.SelectAreaTracker(editor());
        return selectAreaTracker;
    }

    protected Module03.Tool createDragTracker(Module01.DrawingEditor editor, Module03.Figure f) {
        Module03.DragTracker dragTracker = new Module03.DragTracker(editor , f);
        return dragTracker;
    }

    protected Module03.Tool createHandleTracker(Module05.Handle handle) {
        Module03.HandleTracker handleTracker = new Module03.HandleTracker(editor() , handle);
        return handleTracker;
    }

    private java.awt.dnd.DragGestureListener getDragGestureListener() {
        return dragGestureListener;
    }

    private void setDragGestureListener(java.awt.dnd.DragGestureListener dragGestureListener) {
        Module03.DragNDropTool.this.dragGestureListener = dragGestureListener;
    }

    protected boolean isDragOn() {
        return dragOn;
    }

    protected void setDragOn(boolean isNewDragOn) {
        Module03.DragNDropTool.this.dragOn = isNewDragOn;
    }

    private java.awt.dnd.DragGestureListener createDragGestureListener() {
        java.awt.dnd.DragGestureListener dragGestureListener = new java.awt.dnd.DragGestureListener() {
            public void dragGestureRecognized(final java.awt.dnd.DragGestureEvent dge) {
                java.awt.Component c = dge.getComponent();
                if ((isDragOn()) == false) {
                    return ;
                } 
                if (c instanceof Module03.DrawingView) {
                    boolean found = false;
                    Module03.DrawingView dv = ((Module03.DrawingView)(c));
                    Module03.FigureEnumeration selectedElements = dv.selection();
                    if ((selectedElements.hasNextFigure()) == false) {
                        return ;
                    } 
                    java.awt.Point p = dge.getDragOrigin();
                    while (selectedElements.hasNextFigure()) {
                        Module03.Figure f = selectedElements.nextFigure();
                        if (f.containsPoint(p.x, p.y)) {
                            found = true;
                            break;
                        } 
                    }
                    if (found == true) {
                        Module03.DNDFigures dndff = new Module03.DNDFigures(dv.selection() , p);
                        Module03.DNDFiguresTransferable trans = new Module03.DNDFiguresTransferable(dndff);
                        if (c instanceof javax.swing.JComponent) {
                            ((javax.swing.JComponent)(c)).setAutoscrolls(false);
                        } 
                        dge.getDragSource().startDrag(dge, null, trans, ((Module03.DNDInterface)(dv)).getDragSourceListener());
                    } 
                } 
            }
        };
        return dragGestureListener;
    }
}


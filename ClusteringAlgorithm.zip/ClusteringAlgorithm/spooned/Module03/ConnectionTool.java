package Module03;


public class ConnectionTool extends Module03.AbstractTool {
    private Module03.Connector myStartConnector;

    private Module03.Connector myEndConnector;

    private Module03.Connector myTargetConnector;

    private Module03.Figure myTarget;

    private Module03.ConnectionFigure myConnection;

    private int fSplitPoint;

    private Module03.ConnectionFigure fEditedConnection;

    private Module03.Figure myAddedFigure;

    private Module03.ConnectionFigure fPrototype;

    public ConnectionTool(Module01.DrawingEditor newDrawingEditor ,Module03.ConnectionFigure newPrototype) {
        super(newDrawingEditor);
        fPrototype = newPrototype;
    }

    public void mouseMove(java.awt.event.MouseEvent e, int x, int y) {
        trackConnectors(e, x, y);
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        super.mouseDown(e, x, y);
        int ex = e.getX();
        int ey = e.getY();
        Module03.ConnectionFigure connection = findConnection(ex, ey, drawing());
        if (connection != null) {
            if (!(connection.joinSegments(ex, ey))) {
                fSplitPoint = connection.splitSegment(ex, ey);
                fEditedConnection = connection;
            } else {
                fEditedConnection = null;
            }
        } else {
            setTargetFigure(findConnectionStart(ex, ey, drawing()));
            if ((getTargetFigure()) != null) {
                setStartConnector(findConnector(ex, ey, getTargetFigure()));
                if ((getStartConnector()) != null) {
                    setConnection(createConnection());
                    getConnection().startPoint(ex, ey);
                    getConnection().endPoint(ex, ey);
                    setAddedFigure(view().add(getConnection()));
                } 
            } 
        }
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
        java.awt.Point p = new java.awt.Point(e.getX() , e.getY());
        if ((getConnection()) != null) {
            trackConnectors(e, x, y);
            if ((getTargetConnector()) != null) {
                p = Module06.Geom.center(getTargetConnector().displayBox());
            } 
            getConnection().endPoint(p.x, p.y);
        } else if ((fEditedConnection) != null) {
            java.awt.Point pp = new java.awt.Point(x , y);
            fEditedConnection.setPointAt(pp, fSplitPoint);
        } 
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Figure c = null;
        if ((getStartConnector()) != null) {
            c = findTarget(e.getX(), e.getY(), drawing());
        } 
        if (c != null) {
            setEndConnector(findConnector(e.getX(), e.getY(), c));
            if ((getEndConnector()) != null) {
                getConnection().connectStart(getStartConnector());
                getConnection().connectEnd(getEndConnector());
                getConnection().updateConnection();
                setUndoActivity(createUndoActivity());
                getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(getAddedFigure()));
            } 
        } else if ((getConnection()) != null) {
            view().remove(getConnection());
        } 
        setConnection(null);
        setStartConnector(null);
        setEndConnector(null);
        setAddedFigure(null);
        editor().toolDone();
    }

    public void deactivate() {
        super.deactivate();
        if ((getTargetFigure()) != null) {
            getTargetFigure().connectorVisibility(false, null);
        } 
    }

    protected Module03.ConnectionFigure createConnection() {
        return ((Module03.ConnectionFigure)(fPrototype.clone()));
    }

    protected Module03.Figure findSource(int x, int y, Module03.Drawing drawing) {
        return findConnectableFigure(x, y, drawing);
    }

    protected Module03.Figure findTarget(int x, int y, Module03.Drawing drawing) {
        Module03.Figure target = findConnectableFigure(x, y, drawing);
        Module03.Figure start = getStartConnector().owner();
        if (((((target != null) && ((getConnection()) != null)) && (target.canConnect())) && (!(target.includes(start)))) && (getConnection().canConnect(start, target))) {
            return target;
        } 
        return null;
    }

    protected Module03.ConnectionFigure findConnection(int x, int y, Module03.Drawing drawing) {
        Module03.FigureEnumeration fe = drawing.figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            figure = figure.findFigureInside(x, y);
            if ((figure != null) && (figure instanceof Module03.ConnectionFigure)) {
                return ((Module03.ConnectionFigure)(figure));
            } 
        }
        return null;
    }

    protected void setConnection(Module03.ConnectionFigure newConnection) {
        myConnection = newConnection;
    }

    protected Module03.ConnectionFigure getConnection() {
        return myConnection;
    }

    protected void trackConnectors(java.awt.event.MouseEvent e, int x, int y) {
        Module03.Figure c = null;
        if ((getStartConnector()) == null) {
            c = findSource(x, y, getActiveDrawing());
        } else {
            c = findTarget(x, y, getActiveDrawing());
        }
        if (c != (getTargetFigure())) {
            if ((getTargetFigure()) != null) {
                getTargetFigure().connectorVisibility(false, null);
            } 
            setTargetFigure(c);
            if ((getTargetFigure()) != null) {
                getTargetFigure().connectorVisibility(true, getConnection());
            } 
        } 
        Module03.Connector cc = null;
        if (c != null) {
            cc = findConnector(e.getX(), e.getY(), c);
        } 
        if (cc != (getTargetConnector())) {
            setTargetConnector(cc);
        } 
        getActiveView().checkDamage();
    }

    protected Module03.Connector findConnector(int x, int y, Module03.Figure f) {
        return f.connectorAt(x, y);
    }

    protected Module03.Figure findConnectionStart(int x, int y, Module03.Drawing drawing) {
        Module03.Figure target = findConnectableFigure(x, y, drawing);
        if ((target != null) && (target.canConnect())) {
            return target;
        } 
        return null;
    }

    protected Module03.Figure findConnectableFigure(int x, int y, Module03.Drawing drawing) {
        Module03.FigureEnumeration fe = drawing.figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (((!(figure.includes(getConnection()))) && (figure.canConnect())) && (figure.containsPoint(x, y))) {
                return figure;
            } 
        }
        return null;
    }

    protected void setStartConnector(Module03.Connector newStartConnector) {
        myStartConnector = newStartConnector;
    }

    protected Module03.Connector getStartConnector() {
        return myStartConnector;
    }

    protected void setEndConnector(Module03.Connector newEndConnector) {
        myEndConnector = newEndConnector;
    }

    protected Module03.Connector getEndConnector() {
        return myEndConnector;
    }

    protected void setTargetConnector(Module03.Connector newTargetConnector) {
        myTargetConnector = newTargetConnector;
    }

    protected Module03.Connector getTargetConnector() {
        return myTargetConnector;
    }

    protected void setTargetFigure(Module03.Figure newTarget) {
        myTarget = newTarget;
    }

    protected Module03.Figure getTargetFigure() {
        return myTarget;
    }

    protected Module03.Figure getAddedFigure() {
        return myAddedFigure;
    }

    protected void setAddedFigure(Module03.Figure newAddedFigure) {
        myAddedFigure = newAddedFigure;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module03.ConnectionTool.UndoActivity(view() , getConnection());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private Module03.ConnectionFigure myConnection;

        private Module03.Connector myStartConnector;

        private Module03.Connector myEndConnector;

        public UndoActivity(Module03.DrawingView newDrawingView ,Module03.ConnectionFigure newConnection) {
            super(newDrawingView);
            setConnection(newConnection);
            myStartConnector = getConnection().getStartConnector();
            myEndConnector = getConnection().getEndConnector();
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getConnection().disconnectStart();
            getConnection().disconnectEnd();
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                getDrawingView().drawing().orphan(fe.nextFigure());
            }
            getDrawingView().clearSelection();
            return true;
        }

        public boolean redo() {
            if (!(super.redo())) {
                return false;
            } 
            getConnection().connectStart(myStartConnector);
            getConnection().connectEnd(myEndConnector);
            getConnection().updateConnection();
            getDrawingView().insertFigures(getAffectedFigures(), 0, 0, false);
            return true;
        }

        protected void setConnection(Module03.ConnectionFigure newConnection) {
            myConnection = newConnection;
        }

        protected Module03.ConnectionFigure getConnection() {
            return myConnection;
        }
    }
}


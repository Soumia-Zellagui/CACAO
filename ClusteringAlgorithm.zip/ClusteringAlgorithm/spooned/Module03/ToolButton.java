package Module03;


public class ToolButton extends Module06.PaletteButton implements Module03.ToolListener {
    private Module03.Tool myTool;

    private Module03.PaletteIcon myIcon;

    public ToolButton(Module01.PaletteListener listener ,java.lang.String iconName ,java.lang.String name ,Module03.Tool tool) {
        super(listener);
        tool.addToolListener(Module03.ToolButton.this);
        setEnabled(tool.isUsable());
        Module01.Iconkit kit = Module01.Iconkit.instance();
        if (kit == null) {
            throw new Module06.JHotDrawRuntimeException("Iconkit instance isn't set");
        } 
        java.awt.Image[] im = new java.awt.Image[3];
        im[0] = kit.loadImageResource((iconName + "1.gif"));
        im[1] = kit.loadImageResource((iconName + "2.gif"));
        im[2] = kit.loadImageResource((iconName + "3.gif"));
        java.awt.MediaTracker tracker = new java.awt.MediaTracker(Module03.ToolButton.this);
        for (int i = 0 ; i < 3 ; i++) {
            tracker.addImage(im[i], i);
        }
        try {
            tracker.waitForAll();
        } catch (java.lang.Exception e) {
        }
        Module03.PaletteIcon paletteIcon = new Module03.PaletteIcon(new java.awt.Dimension(24 , 24) , im[0] , im[1] , im[2]);
        setPaletteIcon(paletteIcon);
        setTool(tool);
        setName(name);
        if ((im[0]) != null) {
            setIcon(new javax.swing.ImageIcon(im[0]));
        } 
        if ((im[1]) != null) {
            setPressedIcon(new javax.swing.ImageIcon(im[1]));
        } 
        if ((im[2]) != null) {
            setSelectedIcon(new javax.swing.ImageIcon(im[2]));
        } 
        setToolTipText(name);
    }

    public Module03.Tool tool() {
        return myTool;
    }

    public java.lang.String name() {
        return getName();
    }

    public java.lang.Object attributeValue() {
        return tool();
    }

    public java.awt.Dimension getMinimumSize() {
        return new java.awt.Dimension(getPaletteIcon().getWidth() , getPaletteIcon().getHeight());
    }

    public java.awt.Dimension getPreferredSize() {
        return new java.awt.Dimension(getPaletteIcon().getWidth() , getPaletteIcon().getHeight());
    }

    public java.awt.Dimension getMaximumSize() {
        return new java.awt.Dimension(getPaletteIcon().getWidth() , getPaletteIcon().getHeight());
    }

    public void paintSelected(java.awt.Graphics g) {
        if ((getPaletteIcon().selected()) != null) {
            g.drawImage(getPaletteIcon().selected(), 0, 0, Module03.ToolButton.this);
        } 
    }

    public void paint(java.awt.Graphics g) {
        if (isSelected()) {
            paintSelected(g);
        } else {
            super.paint(g);
        }
    }

    public void toolUsable(java.util.EventObject toolEvent) {
        setEnabled(true);
    }

    public void toolUnusable(java.util.EventObject toolEvent) {
        setEnabled(false);
        setSelected(false);
    }

    public void toolActivated(java.util.EventObject toolEvent) {
    }

    public void toolDeactivated(java.util.EventObject toolEvent) {
    }

    public void toolEnabled(java.util.EventObject toolEvent) {
        setEnabled(true);
    }

    public void toolDisabled(java.util.EventObject toolEvent) {
        setEnabled(false);
    }

    protected Module03.PaletteIcon getPaletteIcon() {
        return myIcon;
    }

    private void setPaletteIcon(Module03.PaletteIcon newIcon) {
        myIcon = newIcon;
    }

    private void setTool(Module03.Tool newTool) {
        myTool = newTool;
    }
}


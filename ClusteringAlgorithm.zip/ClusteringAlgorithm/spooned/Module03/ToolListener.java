package Module03;


public interface ToolListener {
    public void toolEnabled(java.util.EventObject toolEvent);

    public void toolDisabled(java.util.EventObject toolEvent);

    public void toolUsable(java.util.EventObject toolEvent);

    public void toolUnusable(java.util.EventObject toolEvent);

    public void toolActivated(java.util.EventObject toolEvent);

    public void toolDeactivated(java.util.EventObject toolEvent);
}


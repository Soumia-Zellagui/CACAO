package Module03;


public class HTMLContentProducer extends Module03.AttributeFigureContentProducer implements java.io.Serializable {
    protected static final int[][] htmlFontSizeEquivalences = new int[][]{ new int[]{ 1 , 0 , 9 } , new int[]{ 2 , 10 , 11 } , new int[]{ 3 , 12 , 13 } , new int[]{ 4 , 14 , 17 } , new int[]{ 5 , 18 , 23 } , new int[]{ 6 , 24 , 35 } , new int[]{ 7 , 36 , java.lang.Integer.MAX_VALUE } };

    public HTMLContentProducer() {
    }

    public java.lang.Object getContent(Module03.ContentProducerContext context, java.lang.String ctxAttrName, java.lang.Object ctxAttrValue) {
        Module03.HTMLContentProducerContext htmlContext = ((Module03.HTMLContentProducerContext)(context));
        if ((ctxAttrName.compareTo(Module03.ContentProducer.ENTITY_FONT_SIZE)) == 0) {
            return java.lang.Integer.toString(getHTMLFontSizeEquivalent(htmlContext.getFont().getSize()));
        } 
        return super.getContent(context, ctxAttrName, ctxAttrValue);
    }

    public int getHTMLFontSizeEquivalent(int pointSize) {
        for (int i = 0 ; i < (Module03.HTMLContentProducer.htmlFontSizeEquivalences.length) ; i++) {
            if ((pointSize >= (Module03.HTMLContentProducer.htmlFontSizeEquivalences[i][1])) && (pointSize <= (Module03.HTMLContentProducer.htmlFontSizeEquivalences[i][2]))) {
                return Module03.HTMLContentProducer.htmlFontSizeEquivalences[i][0];
            } 
        }
        return 3;
    }
}


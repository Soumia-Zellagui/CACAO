package Module03;


public abstract class AbstractTool implements Module03.Tool {
    private Module01.DrawingEditor myDrawingEditor;

    private int myAnchorX;

    private int myAnchorY;

    private Module03.DrawingView myDrawingView;

    private Module06.Undoable myUndoActivity;

    private Module03.AbstractTool.EventDispatcher myEventDispatcher;

    private boolean myIsUsable;

    private boolean myIsEnabled;

    public AbstractTool(Module01.DrawingEditor newDrawingEditor) {
        setEditor(newDrawingEditor);
        Module03.AbstractTool.EventDispatcher eventDispatcher = createEventDispatcher();
        setEventDispatcher(eventDispatcher);
        setEnabled(true);
        checkUsable();
        Module01.DrawingEditor editor = editor();
        Module06.ViewChangeListener vcl = createViewChangeListener();
        editor.addViewChangeListener(vcl);
    }

    public void activate() {
        if ((getActiveView()) != null) {
            getActiveView().clearSelection();
            getActiveView().checkDamage();
            getEventDispatcher().fireToolActivatedEvent();
        } 
    }

    public void deactivate() {
        if (isActive()) {
            if ((getActiveView()) != null) {
                getActiveView().setCursor(new Module06.AWTCursor(java.awt.Cursor.DEFAULT_CURSOR));
            } 
            getEventDispatcher().fireToolDeactivatedEvent();
        } 
    }

    protected void viewSelectionChanged(Module03.DrawingView oldView, Module03.DrawingView newView) {
        if (isActive()) {
            deactivate();
            activate();
        } 
        checkUsable();
    }

    protected void viewCreated(Module03.DrawingView view) {
    }

    protected void viewDestroying(Module03.DrawingView view) {
    }

    public void mouseDown(java.awt.event.MouseEvent e, int x, int y) {
        setAnchorX(x);
        setAnchorY(y);
        setView(((Module03.DrawingView)(e.getSource())));
    }

    public void mouseDrag(java.awt.event.MouseEvent e, int x, int y) {
    }

    public void mouseUp(java.awt.event.MouseEvent e, int x, int y) {
    }

    public void mouseMove(java.awt.event.MouseEvent evt, int x, int y) {
    }

    public void keyDown(java.awt.event.KeyEvent evt, int key) {
    }

    public Module03.Drawing drawing() {
        return view().drawing();
    }

    public Module03.Drawing getActiveDrawing() {
        return getActiveView().drawing();
    }

    public Module01.DrawingEditor editor() {
        return myDrawingEditor;
    }

    protected void setEditor(Module01.DrawingEditor newDrawingEditor) {
        myDrawingEditor = newDrawingEditor;
    }

    public Module03.DrawingView view() {
        return myDrawingView;
    }

    protected void setView(Module03.DrawingView newDrawingView) {
        myDrawingView = newDrawingView;
    }

    public Module03.DrawingView getActiveView() {
        return editor().view();
    }

    public boolean isUsable() {
        return (isEnabled()) && (myIsUsable);
    }

    public void setUsable(boolean newIsUsable) {
        if ((isUsable()) != newIsUsable) {
            myIsUsable = newIsUsable;
            if (isUsable()) {
                getEventDispatcher().fireToolUsableEvent();
            } else {
                getEventDispatcher().fireToolUnusableEvent();
            }
        } 
    }

    public void setEnabled(boolean newIsEnabled) {
        if ((isEnabled()) != newIsEnabled) {
            myIsEnabled = newIsEnabled;
            if (isEnabled()) {
                getEventDispatcher().fireToolEnabledEvent();
            } else {
                getEventDispatcher().fireToolDisabledEvent();
                setUsable(false);
                deactivate();
            }
        } 
    }

    public boolean isEnabled() {
        return myIsEnabled;
    }

    protected void setAnchorX(int newAnchorX) {
        myAnchorX = newAnchorX;
    }

    protected int getAnchorX() {
        return myAnchorX;
    }

    protected void setAnchorY(int newAnchorY) {
        myAnchorY = newAnchorY;
    }

    protected int getAnchorY() {
        return myAnchorY;
    }

    public Module06.Undoable getUndoActivity() {
        return myUndoActivity;
    }

    public void setUndoActivity(Module06.Undoable newUndoActivity) {
        myUndoActivity = newUndoActivity;
    }

    public boolean isActive() {
        return ((editor().tool()) == (Module03.AbstractTool.this)) && (isUsable());
    }

    public void addToolListener(Module03.ToolListener newToolListener) {
        getEventDispatcher().addToolListener(newToolListener);
    }

    public void removeToolListener(Module03.ToolListener oldToolListener) {
        getEventDispatcher().removeToolListener(oldToolListener);
    }

    private void setEventDispatcher(Module03.AbstractTool.EventDispatcher newEventDispatcher) {
        myEventDispatcher = newEventDispatcher;
    }

    protected Module03.AbstractTool.EventDispatcher getEventDispatcher() {
        return myEventDispatcher;
    }

    protected Module03.AbstractTool.EventDispatcher createEventDispatcher() {
        return new Module03.AbstractTool.EventDispatcher(Module03.AbstractTool.this);
    }

    protected Module06.ViewChangeListener createViewChangeListener() {
        return new Module06.ViewChangeListener() {
            public void viewSelectionChanged(Module03.DrawingView oldView, Module03.DrawingView newView) {
                Module03.AbstractTool.this.viewSelectionChanged(oldView, newView);
            }

            public void viewCreated(Module03.DrawingView view) {
                Module03.AbstractTool.this.viewCreated(view);
            }

            public void viewDestroying(Module03.DrawingView view) {
                Module03.AbstractTool.this.viewDestroying(view);
            }
        };
    }

    protected void checkUsable() {
        if (isEnabled()) {
            setUsable((((getActiveView()) != null) && (getActiveView().isInteractive())));
        } 
    }

    public static class EventDispatcher {
        private java.util.List myRegisteredListeners;

        private Module03.Tool myObservedTool;

        public EventDispatcher(Module03.Tool newObservedTool) {
            myRegisteredListeners = Module06.CollectionsFactory.current().createList();
            myObservedTool = newObservedTool;
        }

        public void fireToolUsableEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolUsable(new java.util.EventObject(myObservedTool));
            }
        }

        public void fireToolUnusableEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolUnusable(new java.util.EventObject(myObservedTool));
            }
        }

        public void fireToolActivatedEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolActivated(new java.util.EventObject(myObservedTool));
            }
        }

        public void fireToolDeactivatedEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolDeactivated(new java.util.EventObject(myObservedTool));
            }
        }

        public void fireToolEnabledEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolEnabled(new java.util.EventObject(myObservedTool));
            }
        }

        public void fireToolDisabledEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module03.ToolListener)(iter.next())).toolDisabled(new java.util.EventObject(myObservedTool));
            }
        }

        public void addToolListener(Module03.ToolListener newToolListener) {
            if (!(myRegisteredListeners.contains(newToolListener))) {
                myRegisteredListeners.add(newToolListener);
            } 
        }

        public void removeToolListener(Module03.ToolListener oldToolListener) {
            if (myRegisteredListeners.contains(oldToolListener)) {
                myRegisteredListeners.remove(oldToolListener);
            } 
        }
    }
}


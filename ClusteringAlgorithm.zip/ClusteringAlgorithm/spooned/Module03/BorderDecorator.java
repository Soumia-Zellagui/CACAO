package Module03;


public class BorderDecorator extends Module03.DecoratorFigure {
    private static final long serialVersionUID = 1205601808259084917L;

    private int borderDecoratorSerializedDataVersion = 1;

    private java.awt.Point myBorderOffset;

    private java.awt.Color myBorderColor;

    private java.awt.Color myShadowColor;

    public BorderDecorator() {
    }

    public BorderDecorator(Module03.Figure figure) {
        super(figure);
    }

    protected void initialize() {
        setBorderOffset(new java.awt.Point(3 , 3));
    }

    public void setBorderOffset(java.awt.Point newBorderOffset) {
        myBorderOffset = newBorderOffset;
    }

    public java.awt.Point getBorderOffset() {
        if ((myBorderOffset) == null) {
            return new java.awt.Point(0 , 0);
        } else {
            return myBorderOffset;
        }
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        super.draw(g);
        g.setColor(java.awt.Color.white);
        g.drawLine(r.x, r.y, r.x, ((r.y) + (r.height)));
        g.drawLine(r.x, r.y, ((r.x) + (r.width)), r.y);
        g.setColor(java.awt.Color.gray);
        g.drawLine(((r.x) + (r.width)), r.y, ((r.x) + (r.width)), ((r.y) + (r.height)));
        g.drawLine(r.x, ((r.y) + (r.height)), ((r.x) + (r.width)), ((r.y) + (r.height)));
    }

    public java.awt.Rectangle displayBox() {
        java.awt.Rectangle r = getDecoratedFigure().displayBox();
        r.grow(getBorderOffset().x, getBorderOffset().y);
        return r;
    }

    public void figureInvalidated(Module03.FigureChangeEvent e) {
        java.awt.Rectangle rect = e.getInvalidatedRectangle();
        rect.grow(getBorderOffset().x, getBorderOffset().y);
        super.figureInvalidated(new Module03.FigureChangeEvent(Module03.BorderDecorator.this , rect , e));
    }

    public java.awt.Insets connectionInsets() {
        java.awt.Insets i = super.connectionInsets();
        i.top -= getBorderOffset().y;
        i.bottom -= getBorderOffset().y;
        i.left -= getBorderOffset().x;
        i.right -= getBorderOffset().x;
        return i;
    }
}


package Module03;


public class RelativeLocator extends Module03.AbstractLocator {
    private static final long serialVersionUID = 2619148876087898602L;

    private int relativeLocatorSerializedDataVersion = 1;

    double fRelativeX;

    double fRelativeY;

    public RelativeLocator() {
        fRelativeX = 0.0;
        fRelativeY = 0.0;
    }

    public boolean equals(java.lang.Object o) {
        if (Module03.RelativeLocator.class.isInstance(o)) {
            Module03.RelativeLocator rl = ((Module03.RelativeLocator)(o));
            if (((rl.fRelativeX) == (fRelativeX)) && ((rl.fRelativeY) == (fRelativeY))) {
                return true;
            } 
        } 
        return false;
    }

    public RelativeLocator(double relativeX ,double relativeY) {
        fRelativeX = relativeX;
        fRelativeY = relativeY;
    }

    public java.awt.Point locate(Module03.Figure owner) {
        java.awt.Rectangle r = owner.displayBox();
        return new java.awt.Point(((r.x) + ((int)(((r.width) * (fRelativeX))))) , ((r.y) + ((int)(((r.height) * (fRelativeY))))));
    }

    public void write(Module06.StorableOutput dw) {
        super.write(dw);
        dw.writeDouble(fRelativeX);
        dw.writeDouble(fRelativeY);
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        super.read(dr);
        fRelativeX = dr.readDouble();
        fRelativeY = dr.readDouble();
    }

    public static Module03.Locator east() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(1.0 , 0.5);
        return rl;
    }

    public static Module03.Locator north() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(0.5 , 0.0);
        return rl;
    }

    public static Module03.Locator west() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(0.0 , 0.5);
        return rl;
    }

    public static Module03.Locator northEast() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(1.0 , 0.0);
        return rl;
    }

    public static Module03.Locator northWest() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(0.0 , 0.0);
        return rl;
    }

    public static Module03.Locator south() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(0.5 , 1.0);
        return rl;
    }

    public static Module03.Locator southEast() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(1.0 , 1.0);
        return rl;
    }

    public static Module03.Locator southWest() {
        Module03.RelativeLocator rl = new Module03.RelativeLocator(0.0 , 1.0);
        return rl;
    }

    public static Module03.Locator center() {
        return new Module03.RelativeLocator(0.5 , 0.5);
    }
}


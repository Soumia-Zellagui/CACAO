package Cluster4;


public class G {
    public void mG() {
        Cluster2.J f = new Cluster2.J();
    }
}


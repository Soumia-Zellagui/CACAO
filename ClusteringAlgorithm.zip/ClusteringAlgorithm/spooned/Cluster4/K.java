package Cluster4;


public class K {
    public void mK() {
        Cluster1.I i = new Cluster1.I();
        i.mI();
    }
}


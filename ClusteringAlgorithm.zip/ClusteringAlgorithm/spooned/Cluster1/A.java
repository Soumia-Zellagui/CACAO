package Cluster1;


public class A {
    Cluster2.B b;

    public void mA(Cluster1.C c) {
        b = new Cluster2.B();
        Cluster2.B b2 = new Cluster2.B();
        Cluster1.C cc = new Cluster1.C();
    }
}


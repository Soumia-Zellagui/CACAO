package Cluster1;


public class C {
    public Cluster4.K mC() {
        Cluster4.K k = new Cluster4.K();
        return k;
    }
}


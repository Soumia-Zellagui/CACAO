package java.awt;


public class Scrollbar extends java.awt.Component implements java.awt.Adjustable , javax.accessibility.Accessible {
    public static final int HORIZONTAL = 0;

    public static final int VERTICAL = 1;

    int value;

    int maximum;

    int minimum;

    int visibleAmount;

    int orientation;

    int lineIncrement = 1;

    int pageIncrement = 10;

    transient boolean isAdjusting;

    transient java.awt.event.AdjustmentListener adjustmentListener;

    private static final java.lang.String base = "scrollbar";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 8451667562882310543L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Scrollbar.initIDs();
        } 
    }

    public Scrollbar() throws java.awt.HeadlessException {
        this(java.awt.Scrollbar.VERTICAL, 0, 10, 0, 100);
    }

    public Scrollbar(int orientation) throws java.awt.HeadlessException {
        this(orientation, 0, 10, 0, 100);
    }

    public Scrollbar(int orientation ,int value ,int visible ,int minimum ,int maximum) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        switch (orientation) {
            case java.awt.Scrollbar.HORIZONTAL :
            case java.awt.Scrollbar.VERTICAL :
                java.awt.Scrollbar.this.orientation = orientation;
                break;
            default :
                throw new java.lang.IllegalArgumentException("illegal scrollbar orientation");
        }
        setValues(value, visible, minimum, maximum);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Scrollbar.class) {
            return (java.awt.Scrollbar.base) + ((java.awt.Scrollbar.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createScrollbar(java.awt.Scrollbar.this);
            
            super.addNotify();
        }
    }

    public int getOrientation() {
        return orientation;
    }

    public void setOrientation(int orientation) {
        synchronized(getTreeLock()) {
            if (orientation == (java.awt.Scrollbar.this.orientation)) {
                return ;
            } 
            switch (orientation) {
                case java.awt.Scrollbar.HORIZONTAL :
                case java.awt.Scrollbar.VERTICAL :
                    java.awt.Scrollbar.this.orientation = orientation;
                    break;
                default :
                    throw new java.lang.IllegalArgumentException("illegal scrollbar orientation");
            }
            if ((peer) != null) {
                removeNotify();
                addNotify();
                invalidate();
            } 
        }
        if ((accessibleContext) != null) {
            accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, (orientation == (java.awt.Scrollbar.VERTICAL) ? javax.accessibility.AccessibleState.HORIZONTAL : javax.accessibility.AccessibleState.VERTICAL), (orientation == (java.awt.Scrollbar.VERTICAL) ? javax.accessibility.AccessibleState.VERTICAL : javax.accessibility.AccessibleState.HORIZONTAL));
        } 
    }

    public int getValue() {
        return value;
    }

    public void setValue(int newValue) {
        setValues(newValue, visibleAmount, minimum, maximum);
    }

    public int getMinimum() {
        return minimum;
    }

    public void setMinimum(int newMinimum) {
        setValues(value, visibleAmount, newMinimum, maximum);
    }

    public int getMaximum() {
        return maximum;
    }

    public void setMaximum(int newMaximum) {
        if (newMaximum == (java.lang.Integer.MIN_VALUE)) {
            newMaximum = (java.lang.Integer.MIN_VALUE) + 1;
        } 
        if ((minimum) >= newMaximum) {
            minimum = newMaximum - 1;
        } 
        setValues(value, visibleAmount, minimum, newMaximum);
    }

    public int getVisibleAmount() {
        return getVisible();
    }

    @java.lang.Deprecated
    public int getVisible() {
        return visibleAmount;
    }

    public void setVisibleAmount(int newAmount) {
        setValues(value, newAmount, minimum, maximum);
    }

    public void setUnitIncrement(int v) {
        setLineIncrement(v);
    }

    @java.lang.Deprecated
    public synchronized void setLineIncrement(int v) {
        int tmp = v < 1 ? 1 : v;
        if ((lineIncrement) == tmp) {
            return ;
        } 
        lineIncrement = tmp;
        java.awt.peer.ScrollbarPeer peer = ((java.awt.peer.ScrollbarPeer)(java.awt.Scrollbar.this.peer));
        if (peer != null) {
            peer.setLineIncrement(lineIncrement);
        } 
    }

    public int getUnitIncrement() {
        return getLineIncrement();
    }

    @java.lang.Deprecated
    public int getLineIncrement() {
        return lineIncrement;
    }

    public void setBlockIncrement(int v) {
        setPageIncrement(v);
    }

    @java.lang.Deprecated
    public synchronized void setPageIncrement(int v) {
        int tmp = v < 1 ? 1 : v;
        if ((pageIncrement) == tmp) {
            return ;
        } 
        pageIncrement = tmp;
        java.awt.peer.ScrollbarPeer peer = ((java.awt.peer.ScrollbarPeer)(java.awt.Scrollbar.this.peer));
        if (peer != null) {
            peer.setPageIncrement(pageIncrement);
        } 
    }

    public int getBlockIncrement() {
        return getPageIncrement();
    }

    @java.lang.Deprecated
    public int getPageIncrement() {
        return pageIncrement;
    }

    public void setValues(int value, int visible, int minimum, int maximum) {
        int oldValue;
        synchronized(java.awt.Scrollbar.this) {
            if (minimum == (java.lang.Integer.MAX_VALUE)) {
                minimum = (java.lang.Integer.MAX_VALUE) - 1;
            } 
            if (maximum <= minimum) {
                maximum = minimum + 1;
            } 
            long maxMinusMin = ((long)(maximum)) - ((long)(minimum));
            if (maxMinusMin > (java.lang.Integer.MAX_VALUE)) {
                maxMinusMin = java.lang.Integer.MAX_VALUE;
                maximum = minimum + ((int)(maxMinusMin));
            } 
            if (visible > ((int)(maxMinusMin))) {
                visible = ((int)(maxMinusMin));
            } 
            if (visible < 1) {
                visible = 1;
            } 
            if (value < minimum) {
                value = minimum;
            } 
            if (value > (maximum - visible)) {
                value = maximum - visible;
            } 
            oldValue = java.awt.Scrollbar.this.value;
            java.awt.Scrollbar.this.value = value;
            java.awt.Scrollbar.this.visibleAmount = visible;
            java.awt.Scrollbar.this.minimum = minimum;
            java.awt.Scrollbar.this.maximum = maximum;
            java.awt.peer.ScrollbarPeer peer = ((java.awt.peer.ScrollbarPeer)(java.awt.Scrollbar.this.peer));
            if (peer != null) {
                peer.setValues(value, visibleAmount, minimum, maximum);
            } 
        }
        if ((oldValue != value) && ((accessibleContext) != null)) {
            accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_VALUE_PROPERTY, java.lang.Integer.valueOf(oldValue), java.lang.Integer.valueOf(value));
        } 
    }

    public boolean getValueIsAdjusting() {
        return isAdjusting;
    }

    public void setValueIsAdjusting(boolean b) {
        boolean oldValue;
        synchronized(java.awt.Scrollbar.this) {
            oldValue = isAdjusting;
            isAdjusting = b;
        }
        if ((oldValue != b) && ((accessibleContext) != null)) {
            accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, (oldValue ? javax.accessibility.AccessibleState.BUSY : null), (b ? javax.accessibility.AccessibleState.BUSY : null));
        } 
    }

    public synchronized void addAdjustmentListener(java.awt.event.AdjustmentListener l) {
        if (l == null) {
            return ;
        } 
        adjustmentListener = java.awt.AWTEventMulticaster.add(adjustmentListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeAdjustmentListener(java.awt.event.AdjustmentListener l) {
        if (l == null) {
            return ;
        } 
        adjustmentListener = java.awt.AWTEventMulticaster.remove(adjustmentListener, l);
    }

    public synchronized java.awt.event.AdjustmentListener[] getAdjustmentListeners() {
        return getListeners(java.awt.event.AdjustmentListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.AdjustmentListener.class)) {
            l = adjustmentListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ADJUSTMENT_EVENT_MASK)) != 0) || ((adjustmentListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.AdjustmentEvent) {
            processAdjustmentEvent(((java.awt.event.AdjustmentEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processAdjustmentEvent(java.awt.event.AdjustmentEvent e) {
        java.awt.event.AdjustmentListener listener = adjustmentListener;
        if (listener != null) {
            listener.adjustmentValueChanged(e);
        } 
    }

    protected java.lang.String paramString() {
        return (((((((((((super.paramString()) + ",val=") + (value)) + ",vis=") + (visibleAmount)) + ",min=") + (minimum)) + ",max=") + (maximum)) + ((orientation) == (java.awt.Scrollbar.VERTICAL) ? ",vert" : ",horz")) + ",isAdjusting=") + (isAdjusting);
    }

    private int scrollbarSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.adjustmentListenerK, adjustmentListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.adjustmentListenerK) == key)
                addAdjustmentListener(((java.awt.event.AdjustmentListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Scrollbar.AccessibleAWTScrollBar();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTScrollBar extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleValue {
        private static final long serialVersionUID = -344337268523697807L;

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if (getValueIsAdjusting()) {
                states.add(javax.accessibility.AccessibleState.BUSY);
            } 
            if ((getOrientation()) == (java.awt.Scrollbar.VERTICAL)) {
                states.add(javax.accessibility.AccessibleState.VERTICAL);
            } else {
                states.add(javax.accessibility.AccessibleState.HORIZONTAL);
            }
            return states;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.SCROLL_BAR;
        }

        public javax.accessibility.AccessibleValue getAccessibleValue() {
            return java.awt.Scrollbar.AccessibleAWTScrollBar.this;
        }

        public java.lang.Number getCurrentAccessibleValue() {
            return java.lang.Integer.valueOf(getValue());
        }

        public boolean setCurrentAccessibleValue(java.lang.Number n) {
            if (n instanceof java.lang.Integer) {
                setValue(n.intValue());
                return true;
            } else {
                return false;
            }
        }

        public java.lang.Number getMinimumAccessibleValue() {
            return java.lang.Integer.valueOf(getMinimum());
        }

        public java.lang.Number getMaximumAccessibleValue() {
            return java.lang.Integer.valueOf(getMaximum());
        }
    }
}


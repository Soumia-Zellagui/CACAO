package java.awt;


public class GridBagConstraints implements java.io.Serializable , java.lang.Cloneable {
    public static final int RELATIVE = -1;

    public static final int REMAINDER = 0;

    public static final int NONE = 0;

    public static final int BOTH = 1;

    public static final int HORIZONTAL = 2;

    public static final int VERTICAL = 3;

    public static final int CENTER = 10;

    public static final int NORTH = 11;

    public static final int NORTHEAST = 12;

    public static final int EAST = 13;

    public static final int SOUTHEAST = 14;

    public static final int SOUTH = 15;

    public static final int SOUTHWEST = 16;

    public static final int WEST = 17;

    public static final int NORTHWEST = 18;

    public static final int PAGE_START = 19;

    public static final int PAGE_END = 20;

    public static final int LINE_START = 21;

    public static final int LINE_END = 22;

    public static final int FIRST_LINE_START = 23;

    public static final int FIRST_LINE_END = 24;

    public static final int LAST_LINE_START = 25;

    public static final int LAST_LINE_END = 26;

    public static final int BASELINE = 256;

    public static final int BASELINE_LEADING = 512;

    public static final int BASELINE_TRAILING = 768;

    public static final int ABOVE_BASELINE = 1024;

    public static final int ABOVE_BASELINE_LEADING = 1280;

    public static final int ABOVE_BASELINE_TRAILING = 1536;

    public static final int BELOW_BASELINE = 1792;

    public static final int BELOW_BASELINE_LEADING = 2048;

    public static final int BELOW_BASELINE_TRAILING = 2304;

    public int gridx;

    public int gridy;

    public int gridwidth;

    public int gridheight;

    public double weightx;

    public double weighty;

    public int anchor;

    public int fill;

    public java.awt.Insets insets;

    public int ipadx;

    public int ipady;

    int tempX;

    int tempY;

    int tempWidth;

    int tempHeight;

    int minWidth;

    int minHeight;

    transient int ascent;

    transient int descent;

    transient java.awt.Component.BaselineResizeBehavior baselineResizeBehavior;

    transient int centerPadding;

    transient int centerOffset;

    private static final long serialVersionUID = -1000070633030801713L;

    public GridBagConstraints() {
        gridx = java.awt.GridBagConstraints.RELATIVE;
        gridy = java.awt.GridBagConstraints.RELATIVE;
        gridwidth = 1;
        gridheight = 1;
        weightx = 0;
        weighty = 0;
        anchor = java.awt.GridBagConstraints.CENTER;
        fill = java.awt.GridBagConstraints.NONE;
        insets = new java.awt.Insets(0 , 0 , 0 , 0);
        ipadx = 0;
        ipady = 0;
    }

    public GridBagConstraints(int gridx ,int gridy ,int gridwidth ,int gridheight ,double weightx ,double weighty ,int anchor ,int fill ,java.awt.Insets insets ,int ipadx ,int ipady) {
        java.awt.GridBagConstraints.this.gridx = gridx;
        java.awt.GridBagConstraints.this.gridy = gridy;
        java.awt.GridBagConstraints.this.gridwidth = gridwidth;
        java.awt.GridBagConstraints.this.gridheight = gridheight;
        java.awt.GridBagConstraints.this.fill = fill;
        java.awt.GridBagConstraints.this.ipadx = ipadx;
        java.awt.GridBagConstraints.this.ipady = ipady;
        java.awt.GridBagConstraints.this.insets = insets;
        java.awt.GridBagConstraints.this.anchor = anchor;
        java.awt.GridBagConstraints.this.weightx = weightx;
        java.awt.GridBagConstraints.this.weighty = weighty;
    }

    public java.lang.Object clone() {
        try {
            java.awt.GridBagConstraints c = ((java.awt.GridBagConstraints)(super.clone()));
            c.insets = ((java.awt.Insets)(insets.clone()));
            return c;
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }

    boolean isVerticallyResizable() {
        return ((fill) == (java.awt.GridBagConstraints.BOTH)) || ((fill) == (java.awt.GridBagConstraints.VERTICAL));
    }
}


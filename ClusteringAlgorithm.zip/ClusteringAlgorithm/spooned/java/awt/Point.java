package java.awt;


public class Point extends java.awt.geom.Point2D implements java.io.Serializable {
    public int x;

    public int y;

    private static final long serialVersionUID = -5276940640259749850L;

    public Point() {
        this(0, 0);
    }

    public Point(java.awt.Point p) {
        this(p.x, p.y);
    }

    public Point(int x ,int y) {
        java.awt.Point.this.x = x;
        java.awt.Point.this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @java.beans.Transient
    public java.awt.Point getLocation() {
        return new java.awt.Point(x , y);
    }

    public void setLocation(java.awt.Point p) {
        setLocation(p.x, p.y);
    }

    public void setLocation(int x, int y) {
        move(x, y);
    }

    public void setLocation(double x, double y) {
        java.awt.Point.this.x = ((int)(java.lang.Math.floor((x + 0.5))));
        java.awt.Point.this.y = ((int)(java.lang.Math.floor((y + 0.5))));
    }

    public void move(int x, int y) {
        java.awt.Point.this.x = x;
        java.awt.Point.this.y = y;
    }

    public void translate(int dx, int dy) {
        java.awt.Point.this.x += dx;
        java.awt.Point.this.y += dy;
    }

    public boolean equals(java.lang.Object obj) {
        if (obj instanceof java.awt.Point) {
            java.awt.Point pt = ((java.awt.Point)(obj));
            return ((x) == (pt.x)) && ((y) == (pt.y));
        } 
        return super.equals(obj);
    }

    public java.lang.String toString() {
        return (((((getClass().getName()) + "[x=") + (x)) + ",y=") + (y)) + "]";
    }
}


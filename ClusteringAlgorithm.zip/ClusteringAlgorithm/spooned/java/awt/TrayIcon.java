package java.awt;


public class TrayIcon {
    private java.awt.Image image;

    private java.lang.String tooltip;

    private java.awt.PopupMenu popup;

    private boolean autosize;

    private int id;

    private java.lang.String actionCommand;

    private transient java.awt.peer.TrayIconPeer peer;

    transient java.awt.event.MouseListener mouseListener;

    transient java.awt.event.MouseMotionListener mouseMotionListener;

    transient java.awt.event.ActionListener actionListener;

    private final java.security.AccessControlContext acc = java.security.AccessController.getContext();

    final java.security.AccessControlContext getAccessControlContext() {
        if ((acc) == null) {
            throw new java.lang.SecurityException("TrayIcon is missing AccessControlContext");
        } 
        return acc;
    }

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.TrayIcon.initIDs();
        } 
        sun.awt.AWTAccessor.setTrayIconAccessor(new sun.awt.AWTAccessor.TrayIconAccessor() {
            public void addNotify(java.awt.TrayIcon trayIcon) throws java.awt.AWTException {
                trayIcon.addNotify();
            }

            public void removeNotify(java.awt.TrayIcon trayIcon) {
                trayIcon.removeNotify();
            }
        });
    }

    private TrayIcon() throws java.awt.HeadlessException , java.lang.SecurityException , java.lang.UnsupportedOperationException {
        java.awt.SystemTray.checkSystemTrayAllowed();
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        if (!(java.awt.SystemTray.isSupported())) {
            throw new java.lang.UnsupportedOperationException();
        } 
        sun.awt.SunToolkit.insertTargetMapping(java.awt.TrayIcon.this, sun.awt.AppContext.getAppContext());
    }

    public TrayIcon(java.awt.Image image) {
        this();
        if (image == null) {
            throw new java.lang.IllegalArgumentException("creating TrayIcon with null Image");
        } 
        setImage(image);
    }

    public TrayIcon(java.awt.Image image ,java.lang.String tooltip) {
        this(image);
        setToolTip(tooltip);
    }

    public TrayIcon(java.awt.Image image ,java.lang.String tooltip ,java.awt.PopupMenu popup) {
        this(image, tooltip);
        setPopupMenu(popup);
    }

    public void setImage(java.awt.Image image) {
        if (image == null) {
            throw new java.lang.NullPointerException("setting null Image");
        } 
        java.awt.TrayIcon.this.image = image;
        java.awt.peer.TrayIconPeer peer = java.awt.TrayIcon.this.peer;
        if (peer != null) {
            peer.updateImage();
        } 
    }

    public java.awt.Image getImage() {
        return image;
    }

    public void setPopupMenu(java.awt.PopupMenu popup) {
        if (popup == (java.awt.TrayIcon.this.popup)) {
            return ;
        } 
        synchronized(java.awt.TrayIcon.class) {
            if (popup != null) {
                if (popup.isTrayIconPopup) {
                    throw new java.lang.IllegalArgumentException("the PopupMenu is already set for another TrayIcon");
                } 
                popup.isTrayIconPopup = true;
            } 
            if ((java.awt.TrayIcon.this.popup) != null) {
                java.awt.TrayIcon.this.popup.isTrayIconPopup = false;
            } 
            java.awt.TrayIcon.this.popup = popup;
        }
    }

    public java.awt.PopupMenu getPopupMenu() {
        return popup;
    }

    public void setToolTip(java.lang.String tooltip) {
        java.awt.TrayIcon.this.tooltip = tooltip;
        java.awt.peer.TrayIconPeer peer = java.awt.TrayIcon.this.peer;
        if (peer != null) {
            peer.setToolTip(tooltip);
        } 
    }

    public java.lang.String getToolTip() {
        return tooltip;
    }

    public void setImageAutoSize(boolean autosize) {
        java.awt.TrayIcon.this.autosize = autosize;
        java.awt.peer.TrayIconPeer peer = java.awt.TrayIcon.this.peer;
        if (peer != null) {
            peer.updateImage();
        } 
    }

    public boolean isImageAutoSize() {
        return autosize;
    }

    public synchronized void addMouseListener(java.awt.event.MouseListener listener) {
        if (listener == null) {
            return ;
        } 
        mouseListener = java.awt.AWTEventMulticaster.add(mouseListener, listener);
    }

    public synchronized void removeMouseListener(java.awt.event.MouseListener listener) {
        if (listener == null) {
            return ;
        } 
        mouseListener = java.awt.AWTEventMulticaster.remove(mouseListener, listener);
    }

    public synchronized java.awt.event.MouseListener[] getMouseListeners() {
        return java.awt.AWTEventMulticaster.getListeners(mouseListener, java.awt.event.MouseListener.class);
    }

    public synchronized void addMouseMotionListener(java.awt.event.MouseMotionListener listener) {
        if (listener == null) {
            return ;
        } 
        mouseMotionListener = java.awt.AWTEventMulticaster.add(mouseMotionListener, listener);
    }

    public synchronized void removeMouseMotionListener(java.awt.event.MouseMotionListener listener) {
        if (listener == null) {
            return ;
        } 
        mouseMotionListener = java.awt.AWTEventMulticaster.remove(mouseMotionListener, listener);
    }

    public synchronized java.awt.event.MouseMotionListener[] getMouseMotionListeners() {
        return java.awt.AWTEventMulticaster.getListeners(mouseMotionListener, java.awt.event.MouseMotionListener.class);
    }

    public java.lang.String getActionCommand() {
        return actionCommand;
    }

    public void setActionCommand(java.lang.String command) {
        actionCommand = command;
    }

    public synchronized void addActionListener(java.awt.event.ActionListener listener) {
        if (listener == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.add(actionListener, listener);
    }

    public synchronized void removeActionListener(java.awt.event.ActionListener listener) {
        if (listener == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.remove(actionListener, listener);
    }

    public synchronized java.awt.event.ActionListener[] getActionListeners() {
        return java.awt.AWTEventMulticaster.getListeners(actionListener, java.awt.event.ActionListener.class);
    }

    public enum MessageType {
ERROR, WARNING, INFO, NONE;    }

    public void displayMessage(java.lang.String caption, java.lang.String text, java.awt.TrayIcon.MessageType messageType) {
        if ((caption == null) && (text == null)) {
            throw new java.lang.NullPointerException("displaying the message with both caption and text being null");
        } 
        java.awt.peer.TrayIconPeer peer = java.awt.TrayIcon.this.peer;
        if (peer != null) {
            peer.displayMessage(caption, text, messageType.name());
        } 
    }

    public java.awt.Dimension getSize() {
        return java.awt.SystemTray.getSystemTray().getTrayIconSize();
    }

    void addNotify() throws java.awt.AWTException {
        synchronized(java.awt.TrayIcon.this) {
            if ((peer) == null) {
                java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
                if (toolkit instanceof sun.awt.SunToolkit) {
                    peer = ((sun.awt.SunToolkit)(java.awt.Toolkit.getDefaultToolkit())).createTrayIcon(java.awt.TrayIcon.this);
                } else if (toolkit instanceof sun.awt.HeadlessToolkit) {
                    peer = ((sun.awt.HeadlessToolkit)(java.awt.Toolkit.getDefaultToolkit())).createTrayIcon(java.awt.TrayIcon.this);
                } 
            } 
        }
        peer.setToolTip(tooltip);
    }

    void removeNotify() {
        java.awt.peer.TrayIconPeer p = null;
        synchronized(java.awt.TrayIcon.this) {
            p = peer;
            peer = null;
        }
        if (p != null) {
            p.dispose();
        } 
    }

    void setID(int id) {
        java.awt.TrayIcon.this.id = id;
    }

    int getID() {
        return id;
    }

    void dispatchEvent(java.awt.AWTEvent e) {
        java.awt.EventQueue.setCurrentEventAndMostRecentTime(e);
        java.awt.Toolkit.getDefaultToolkit().notifyAWTEventListeners(e);
        processEvent(e);
    }

    void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.MouseEvent) {
            switch (e.getID()) {
                case java.awt.event.MouseEvent.MOUSE_PRESSED :
                case java.awt.event.MouseEvent.MOUSE_RELEASED :
                case java.awt.event.MouseEvent.MOUSE_CLICKED :
                    processMouseEvent(((java.awt.event.MouseEvent)(e)));
                    break;
                case java.awt.event.MouseEvent.MOUSE_MOVED :
                    processMouseMotionEvent(((java.awt.event.MouseEvent)(e)));
                    break;
                default :
                    return ;
            }
        } else if (e instanceof java.awt.event.ActionEvent) {
            processActionEvent(((java.awt.event.ActionEvent)(e)));
        } 
    }

    void processMouseEvent(java.awt.event.MouseEvent e) {
        java.awt.event.MouseListener listener = mouseListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.MouseEvent.MOUSE_PRESSED :
                    listener.mousePressed(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_RELEASED :
                    listener.mouseReleased(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_CLICKED :
                    listener.mouseClicked(e);
                    break;
                default :
                    return ;
            }
        } 
    }

    void processMouseMotionEvent(java.awt.event.MouseEvent e) {
        java.awt.event.MouseMotionListener listener = mouseMotionListener;
        if ((listener != null) && ((e.getID()) == (java.awt.event.MouseEvent.MOUSE_MOVED))) {
            listener.mouseMoved(e);
        } 
    }

    void processActionEvent(java.awt.event.ActionEvent e) {
        java.awt.event.ActionListener listener = actionListener;
        if (listener != null) {
            listener.actionPerformed(e);
        } 
    }

    private static native void initIDs();
}


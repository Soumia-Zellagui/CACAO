package java.awt;


public class Menu extends java.awt.MenuItem implements java.awt.MenuContainer , javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Menu.initIDs();
        } 
        sun.awt.AWTAccessor.setMenuAccessor(new sun.awt.AWTAccessor.MenuAccessor() {
            public java.util.Vector<java.awt.MenuComponent> getItems(java.awt.Menu menu) {
                return menu.items;
            }
        });
    }

    java.util.Vector<java.awt.MenuComponent> items = new java.util.Vector<>();

    boolean tearOff;

    boolean isHelpMenu;

    private static final java.lang.String base = "menu";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -8809584163345499784L;

    public Menu() throws java.awt.HeadlessException {
        this("", false);
    }

    public Menu(java.lang.String label) throws java.awt.HeadlessException {
        this(label, false);
    }

    public Menu(java.lang.String label ,boolean tearOff) throws java.awt.HeadlessException {
        super(label);
        java.awt.Menu.this.tearOff = tearOff;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Menu.class) {
            return (java.awt.Menu.base) + ((java.awt.Menu.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = java.awt.Toolkit.getDefaultToolkit().createMenu(java.awt.Menu.this);
            
            int nitems = getItemCount();
            for (int i = 0 ; i < nitems ; i++) {
                java.awt.MenuItem mi = getItem(i);
                mi.parent = java.awt.Menu.this;
                mi.addNotify();
            }
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            int nitems = getItemCount();
            for (int i = 0 ; i < nitems ; i++) {
                getItem(i).removeNotify();
            }
            super.removeNotify();
        }
    }

    public boolean isTearOff() {
        return tearOff;
    }

    public int getItemCount() {
        return countItems();
    }

    @java.lang.Deprecated
    public int countItems() {
        return countItemsImpl();
    }

    final int countItemsImpl() {
        return items.size();
    }

    public java.awt.MenuItem getItem(int index) {
        return getItemImpl(index);
    }

    final java.awt.MenuItem getItemImpl(int index) {
        return ((java.awt.MenuItem)(items.elementAt(index)));
    }

    public java.awt.MenuItem add(java.awt.MenuItem mi) {
        synchronized(getTreeLock()) {
            if ((mi.parent) != null) {
                mi.parent.remove(mi);
            } 
            items.addElement(mi);
            mi.parent = java.awt.Menu.this;
            java.awt.peer.MenuPeer peer = ((java.awt.peer.MenuPeer)(java.awt.Menu.this.peer));
            if (peer != null) {
                mi.addNotify();
                peer.addItem(mi);
            } 
            return mi;
        }
    }

    public void add(java.lang.String label) {
        add(new java.awt.MenuItem(label));
    }

    public void insert(java.awt.MenuItem menuitem, int index) {
        synchronized(getTreeLock()) {
            if (index < 0) {
                throw new java.lang.IllegalArgumentException("index less than zero.");
            } 
            int nitems = getItemCount();
            java.util.Vector<java.awt.MenuItem> tempItems = new java.util.Vector<>();
            for (int i = index ; i < nitems ; i++) {
                tempItems.addElement(getItem(index));
                remove(index);
            }
            add(menuitem);
            for (int i = 0 ; i < (tempItems.size()) ; i++) {
                add(tempItems.elementAt(i));
            }
        }
    }

    public void insert(java.lang.String label, int index) {
        insert(new java.awt.MenuItem(label), index);
    }

    public void addSeparator() {
        add("-");
    }

    public void insertSeparator(int index) {
        synchronized(getTreeLock()) {
            if (index < 0) {
                throw new java.lang.IllegalArgumentException("index less than zero.");
            } 
            int nitems = getItemCount();
            java.util.Vector<java.awt.MenuItem> tempItems = new java.util.Vector<>();
            for (int i = index ; i < nitems ; i++) {
                tempItems.addElement(getItem(index));
                remove(index);
            }
            addSeparator();
            for (int i = 0 ; i < (tempItems.size()) ; i++) {
                add(tempItems.elementAt(i));
            }
        }
    }

    public void remove(int index) {
        synchronized(getTreeLock()) {
            java.awt.MenuItem mi = getItem(index);
            items.removeElementAt(index);
            java.awt.peer.MenuPeer peer = ((java.awt.peer.MenuPeer)(java.awt.Menu.this.peer));
            if (peer != null) {
                mi.removeNotify();
                mi.parent = null;
                peer.delItem(index);
            } 
        }
    }

    public void remove(java.awt.MenuComponent item) {
        synchronized(getTreeLock()) {
            int index = items.indexOf(item);
            if (index >= 0) {
                remove(index);
            } 
        }
    }

    public void removeAll() {
        synchronized(getTreeLock()) {
            int nitems = getItemCount();
            for (int i = nitems - 1 ; i >= 0 ; i--) {
                remove(i);
            }
        }
    }

    boolean handleShortcut(java.awt.event.KeyEvent e) {
        int nitems = getItemCount();
        for (int i = 0 ; i < nitems ; i++) {
            java.awt.MenuItem mi = getItem(i);
            if (mi.handleShortcut(e)) {
                return true;
            } 
        }
        return false;
    }

    java.awt.MenuItem getShortcutMenuItem(java.awt.MenuShortcut s) {
        int nitems = getItemCount();
        for (int i = 0 ; i < nitems ; i++) {
            java.awt.MenuItem mi = getItem(i).getShortcutMenuItem(s);
            if (mi != null) {
                return mi;
            } 
        }
        return null;
    }

    synchronized java.util.Enumeration<java.awt.MenuShortcut> shortcuts() {
        java.util.Vector<java.awt.MenuShortcut> shortcuts = new java.util.Vector<>();
        int nitems = getItemCount();
        for (int i = 0 ; i < nitems ; i++) {
            java.awt.MenuItem mi = getItem(i);
            if (mi instanceof java.awt.Menu) {
                java.util.Enumeration<java.awt.MenuShortcut> e = ((java.awt.Menu)(mi)).shortcuts();
                while (e.hasMoreElements()) {
                    shortcuts.addElement(e.nextElement());
                }
            } else {
                java.awt.MenuShortcut ms = mi.getShortcut();
                if (ms != null) {
                    shortcuts.addElement(ms);
                } 
            }
        }
        return shortcuts.elements();
    }

    void deleteShortcut(java.awt.MenuShortcut s) {
        int nitems = getItemCount();
        for (int i = 0 ; i < nitems ; i++) {
            getItem(i).deleteShortcut(s);
        }
    }

    private int menuSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        for (int i = 0 ; i < (items.size()) ; i++) {
            java.awt.MenuItem item = ((java.awt.MenuItem)(items.elementAt(i)));
            item.parent = java.awt.Menu.this;
        }
    }

    public java.lang.String paramString() {
        java.lang.String str = ((",tearOff=" + (tearOff)) + ",isHelpMenu=") + (isHelpMenu);
        return (super.paramString()) + str;
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Menu.AccessibleAWTMenu();
        } 
        return accessibleContext;
    }

    int getAccessibleChildIndex(java.awt.MenuComponent child) {
        return items.indexOf(child);
    }

    protected class AccessibleAWTMenu extends java.awt.MenuItem.AccessibleAWTMenuItem {
        private static final long serialVersionUID = 5228160894980069094L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.MENU;
        }
    }
}


package java.awt;


public class BasicStroke implements java.awt.Stroke {
    @java.lang.annotation.Native
    public static final int JOIN_MITER = 0;

    @java.lang.annotation.Native
    public static final int JOIN_ROUND = 1;

    @java.lang.annotation.Native
    public static final int JOIN_BEVEL = 2;

    @java.lang.annotation.Native
    public static final int CAP_BUTT = 0;

    @java.lang.annotation.Native
    public static final int CAP_ROUND = 1;

    @java.lang.annotation.Native
    public static final int CAP_SQUARE = 2;

    float width;

    int join;

    int cap;

    float miterlimit;

    float[] dash;

    float dash_phase;

    @java.beans.ConstructorProperties(value = { "lineWidth" , "endCap" , "lineJoin" , "miterLimit" , "dashArray" , "dashPhase" })
    public BasicStroke(float width ,int cap ,int join ,float miterlimit ,float[] dash ,float dash_phase) {
        if (width < 0.0F) {
            throw new java.lang.IllegalArgumentException("negative width");
        } 
        if (((cap != (java.awt.BasicStroke.CAP_BUTT)) && (cap != (java.awt.BasicStroke.CAP_ROUND))) && (cap != (java.awt.BasicStroke.CAP_SQUARE))) {
            throw new java.lang.IllegalArgumentException("illegal end cap value");
        } 
        if (join == (java.awt.BasicStroke.JOIN_MITER)) {
            if (miterlimit < 1.0F) {
                throw new java.lang.IllegalArgumentException("miter limit < 1");
            } 
        } else if ((join != (java.awt.BasicStroke.JOIN_ROUND)) && (join != (java.awt.BasicStroke.JOIN_BEVEL))) {
            throw new java.lang.IllegalArgumentException("illegal line join value");
        } 
        if (dash != null) {
            if (dash_phase < 0.0F) {
                throw new java.lang.IllegalArgumentException("negative dash phase");
            } 
            boolean allzero = true;
            for (int i = 0 ; i < (dash.length) ; i++) {
                float d = dash[i];
                if (d > 0.0) {
                    allzero = false;
                } else if (d < 0.0) {
                    throw new java.lang.IllegalArgumentException("negative dash length");
                } 
            }
            if (allzero) {
                throw new java.lang.IllegalArgumentException("dash lengths all zero");
            } 
        } 
        java.awt.BasicStroke.this.width = width;
        java.awt.BasicStroke.this.cap = cap;
        java.awt.BasicStroke.this.join = join;
        java.awt.BasicStroke.this.miterlimit = miterlimit;
        if (dash != null) {
            java.awt.BasicStroke.this.dash = ((float[])(dash.clone()));
        } 
        java.awt.BasicStroke.this.dash_phase = dash_phase;
    }

    public BasicStroke(float width ,int cap ,int join ,float miterlimit) {
        this(width, cap, join, miterlimit, null, 0.0F);
    }

    public BasicStroke(float width ,int cap ,int join) {
        this(width, cap, join, 10.0F, null, 0.0F);
    }

    public BasicStroke(float width) {
        this(width, java.awt.BasicStroke.CAP_SQUARE, java.awt.BasicStroke.JOIN_MITER, 10.0F, null, 0.0F);
    }

    public BasicStroke() {
        this(1.0F, java.awt.BasicStroke.CAP_SQUARE, java.awt.BasicStroke.JOIN_MITER, 10.0F, null, 0.0F);
    }

    public java.awt.Shape createStrokedShape(java.awt.Shape s) {
        sun.java2d.pipe.RenderingEngine re = sun.java2d.pipe.RenderingEngine.getInstance();
        return re.createStrokedShape(s, width, cap, join, miterlimit, dash, dash_phase);
    }

    public float getLineWidth() {
        return width;
    }

    public int getEndCap() {
        return cap;
    }

    public int getLineJoin() {
        return join;
    }

    public float getMiterLimit() {
        return miterlimit;
    }

    public float[] getDashArray() {
        if ((dash) == null) {
            return null;
        } 
        return ((float[])(dash.clone()));
    }

    public float getDashPhase() {
        return dash_phase;
    }

    public int hashCode() {
        int hash = java.lang.Float.floatToIntBits(width);
        hash = (hash * 31) + (join);
        hash = (hash * 31) + (cap);
        hash = (hash * 31) + (java.lang.Float.floatToIntBits(miterlimit));
        if ((dash) != null) {
            hash = (hash * 31) + (java.lang.Float.floatToIntBits(dash_phase));
            for (int i = 0 ; i < (dash.length) ; i++) {
                hash = (hash * 31) + (java.lang.Float.floatToIntBits(dash[i]));
            }
        } 
        return hash;
    }

    public boolean equals(java.lang.Object obj) {
        if (!(obj instanceof java.awt.BasicStroke)) {
            return false;
        } 
        java.awt.BasicStroke bs = ((java.awt.BasicStroke)(obj));
        if ((width) != (bs.width)) {
            return false;
        } 
        if ((join) != (bs.join)) {
            return false;
        } 
        if ((cap) != (bs.cap)) {
            return false;
        } 
        if ((miterlimit) != (bs.miterlimit)) {
            return false;
        } 
        if ((dash) != null) {
            if ((dash_phase) != (bs.dash_phase)) {
                return false;
            } 
            if (!(java.util.Arrays.equals(dash, bs.dash))) {
                return false;
            } 
        } else if ((bs.dash) != null) {
            return false;
        } 
        return true;
    }
}


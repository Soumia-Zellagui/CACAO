package java.awt;


public class TextArea extends java.awt.TextComponent {
    int rows;

    int columns;

    private static final java.lang.String base = "text";

    private static int nameCounter = 0;

    public static final int SCROLLBARS_BOTH = 0;

    public static final int SCROLLBARS_VERTICAL_ONLY = 1;

    public static final int SCROLLBARS_HORIZONTAL_ONLY = 2;

    public static final int SCROLLBARS_NONE = 3;

    private int scrollbarVisibility;

    private static java.util.Set<java.awt.AWTKeyStroke> forwardTraversalKeys;

    private static java.util.Set<java.awt.AWTKeyStroke> backwardTraversalKeys;

    private static final long serialVersionUID = 3692302836626095722L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.TextArea.initIDs();
        } 
        forwardTraversalKeys = java.awt.KeyboardFocusManager.initFocusTraversalKeysSet("ctrl TAB", new java.util.HashSet<java.awt.AWTKeyStroke>());
        backwardTraversalKeys = java.awt.KeyboardFocusManager.initFocusTraversalKeysSet("ctrl shift TAB", new java.util.HashSet<java.awt.AWTKeyStroke>());
    }

    public TextArea() throws java.awt.HeadlessException {
        this("", 0, 0, java.awt.TextArea.SCROLLBARS_BOTH);
    }

    public TextArea(java.lang.String text) throws java.awt.HeadlessException {
        this(text, 0, 0, java.awt.TextArea.SCROLLBARS_BOTH);
    }

    public TextArea(int rows ,int columns) throws java.awt.HeadlessException {
        this("", rows, columns, java.awt.TextArea.SCROLLBARS_BOTH);
    }

    public TextArea(java.lang.String text ,int rows ,int columns) throws java.awt.HeadlessException {
        this(text, rows, columns, java.awt.TextArea.SCROLLBARS_BOTH);
    }

    public TextArea(java.lang.String text ,int rows ,int columns ,int scrollbars) throws java.awt.HeadlessException {
        super(text);
        java.awt.TextArea.this.rows = rows >= 0 ? rows : 0;
        java.awt.TextArea.this.columns = columns >= 0 ? columns : 0;
        if ((scrollbars >= (java.awt.TextArea.SCROLLBARS_BOTH)) && (scrollbars <= (java.awt.TextArea.SCROLLBARS_NONE))) {
            java.awt.TextArea.this.scrollbarVisibility = scrollbars;
        } else {
            java.awt.TextArea.this.scrollbarVisibility = java.awt.TextArea.SCROLLBARS_BOTH;
        }
        setFocusTraversalKeys(java.awt.KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, java.awt.TextArea.forwardTraversalKeys);
        setFocusTraversalKeys(java.awt.KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, java.awt.TextArea.backwardTraversalKeys);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.TextArea.class) {
            return (java.awt.TextArea.base) + ((java.awt.TextArea.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createTextArea(java.awt.TextArea.this);
            
            super.addNotify();
        }
    }

    public void insert(java.lang.String str, int pos) {
        insertText(str, pos);
    }

    @java.lang.Deprecated
    public synchronized void insertText(java.lang.String str, int pos) {
        java.awt.peer.TextAreaPeer peer = ((java.awt.peer.TextAreaPeer)(java.awt.TextArea.this.peer));
        if (peer != null) {
            peer.insert(str, pos);
        } else {
            text = ((text.substring(0, pos)) + str) + (text.substring(pos));
        }
    }

    public void append(java.lang.String str) {
        appendText(str);
    }

    @java.lang.Deprecated
    public synchronized void appendText(java.lang.String str) {
        if ((peer) != null) {
            insertText(str, getText().length());
        } else {
            text = (text) + str;
        }
    }

    public void replaceRange(java.lang.String str, int start, int end) {
        replaceText(str, start, end);
    }

    @java.lang.Deprecated
    public synchronized void replaceText(java.lang.String str, int start, int end) {
        java.awt.peer.TextAreaPeer peer = ((java.awt.peer.TextAreaPeer)(java.awt.TextArea.this.peer));
        if (peer != null) {
            peer.replaceRange(str, start, end);
        } else {
            text = ((text.substring(0, start)) + str) + (text.substring(end));
        }
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        int oldVal = java.awt.TextArea.this.rows;
        if (rows < 0) {
            throw new java.lang.IllegalArgumentException("rows less than zero.");
        } 
        if (rows != oldVal) {
            java.awt.TextArea.this.rows = rows;
            invalidate();
        } 
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        int oldVal = java.awt.TextArea.this.columns;
        if (columns < 0) {
            throw new java.lang.IllegalArgumentException("columns less than zero.");
        } 
        if (columns != oldVal) {
            java.awt.TextArea.this.columns = columns;
            invalidate();
        } 
    }

    public int getScrollbarVisibility() {
        return scrollbarVisibility;
    }

    public java.awt.Dimension getPreferredSize(int rows, int columns) {
        return preferredSize(rows, columns);
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize(int rows, int columns) {
        synchronized(getTreeLock()) {
            java.awt.peer.TextAreaPeer peer = ((java.awt.peer.TextAreaPeer)(java.awt.TextArea.this.peer));
            return peer != null ? peer.getPreferredSize(rows, columns) : super.preferredSize();
        }
    }

    public java.awt.Dimension getPreferredSize() {
        return preferredSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize() {
        synchronized(getTreeLock()) {
            return ((rows) > 0) && ((columns) > 0) ? preferredSize(rows, columns) : super.preferredSize();
        }
    }

    public java.awt.Dimension getMinimumSize(int rows, int columns) {
        return minimumSize(rows, columns);
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize(int rows, int columns) {
        synchronized(getTreeLock()) {
            java.awt.peer.TextAreaPeer peer = ((java.awt.peer.TextAreaPeer)(java.awt.TextArea.this.peer));
            return peer != null ? peer.getMinimumSize(rows, columns) : super.minimumSize();
        }
    }

    public java.awt.Dimension getMinimumSize() {
        return minimumSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize() {
        synchronized(getTreeLock()) {
            return ((rows) > 0) && ((columns) > 0) ? minimumSize(rows, columns) : super.minimumSize();
        }
    }

    protected java.lang.String paramString() {
        java.lang.String sbVisStr;
        switch (scrollbarVisibility) {
            case java.awt.TextArea.SCROLLBARS_BOTH :
                sbVisStr = "both";
                break;
            case java.awt.TextArea.SCROLLBARS_VERTICAL_ONLY :
                sbVisStr = "vertical-only";
                break;
            case java.awt.TextArea.SCROLLBARS_HORIZONTAL_ONLY :
                sbVisStr = "horizontal-only";
                break;
            case java.awt.TextArea.SCROLLBARS_NONE :
                sbVisStr = "none";
                break;
            default :
                sbVisStr = "invalid display policy";
        }
        return ((((((super.paramString()) + ",rows=") + (rows)) + ",columns=") + (columns)) + ",scrollbarVisibility=") + sbVisStr;
    }

    private int textAreaSerializedDataVersion = 2;

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((columns) < 0) {
            columns = 0;
        } 
        if ((rows) < 0) {
            rows = 0;
        } 
        if (((scrollbarVisibility) < (java.awt.TextArea.SCROLLBARS_BOTH)) || ((scrollbarVisibility) > (java.awt.TextArea.SCROLLBARS_NONE))) {
            java.awt.TextArea.this.scrollbarVisibility = java.awt.TextArea.SCROLLBARS_BOTH;
        } 
        if ((textAreaSerializedDataVersion) < 2) {
            setFocusTraversalKeys(java.awt.KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, java.awt.TextArea.forwardTraversalKeys);
            setFocusTraversalKeys(java.awt.KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, java.awt.TextArea.backwardTraversalKeys);
        } 
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.TextArea.AccessibleAWTTextArea();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTTextArea extends java.awt.TextComponent.AccessibleAWTTextComponent {
        private static final long serialVersionUID = 3472827823632144419L;

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            states.add(javax.accessibility.AccessibleState.MULTI_LINE);
            return states;
        }
    }
}


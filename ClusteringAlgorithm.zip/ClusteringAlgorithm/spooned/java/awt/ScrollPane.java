package java.awt;


public class ScrollPane extends java.awt.Container implements javax.accessibility.Accessible {
    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.ScrollPane.initIDs();
        } 
    }

    public static final int SCROLLBARS_AS_NEEDED = 0;

    public static final int SCROLLBARS_ALWAYS = 1;

    public static final int SCROLLBARS_NEVER = 2;

    private int scrollbarDisplayPolicy;

    private java.awt.ScrollPaneAdjustable vAdjustable;

    private java.awt.ScrollPaneAdjustable hAdjustable;

    private static final java.lang.String base = "scrollpane";

    private static int nameCounter = 0;

    private static final boolean defaultWheelScroll = true;

    private boolean wheelScrollingEnabled = java.awt.ScrollPane.defaultWheelScroll;

    private static final long serialVersionUID = 7956609840827222915L;

    public ScrollPane() throws java.awt.HeadlessException {
        this(java.awt.ScrollPane.SCROLLBARS_AS_NEEDED);
    }

    @java.beans.ConstructorProperties(value = { "scrollbarDisplayPolicy" })
    public ScrollPane(int scrollbarDisplayPolicy) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.ScrollPane.this.layoutMgr = null;
        java.awt.ScrollPane.this.width = 100;
        java.awt.ScrollPane.this.height = 100;
        switch (scrollbarDisplayPolicy) {
            case java.awt.ScrollPane.SCROLLBARS_NEVER :
            case java.awt.ScrollPane.SCROLLBARS_AS_NEEDED :
            case java.awt.ScrollPane.SCROLLBARS_ALWAYS :
                java.awt.ScrollPane.this.scrollbarDisplayPolicy = scrollbarDisplayPolicy;
                break;
            default :
                throw new java.lang.IllegalArgumentException("illegal scrollbar display policy");
        }
        vAdjustable = new java.awt.ScrollPaneAdjustable(java.awt.ScrollPane.this , new java.awt.ScrollPane.PeerFixer(java.awt.ScrollPane.this) , java.awt.Adjustable.VERTICAL);
        hAdjustable = new java.awt.ScrollPaneAdjustable(java.awt.ScrollPane.this , new java.awt.ScrollPane.PeerFixer(java.awt.ScrollPane.this) , java.awt.Adjustable.HORIZONTAL);
        setWheelScrollingEnabled(java.awt.ScrollPane.defaultWheelScroll);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.ScrollPane.class) {
            return (java.awt.ScrollPane.base) + ((java.awt.ScrollPane.nameCounter)++);
        }
    }

    private void addToPanel(java.awt.Component comp, java.lang.Object constraints, int index) {
        java.awt.Panel child = new java.awt.Panel();
        child.setLayout(new java.awt.BorderLayout());
        child.add(comp);
        super.addImpl(child, constraints, index);
        validate();
    }

    protected final void addImpl(java.awt.Component comp, java.lang.Object constraints, int index) {
        synchronized(getTreeLock()) {
            if ((getComponentCount()) > 0) {
                remove(0);
            } 
            if (index > 0) {
                throw new java.lang.IllegalArgumentException("position greater than 0");
            } 
            if (!(sun.awt.SunToolkit.isLightweightOrUnknown(comp))) {
                super.addImpl(comp, constraints, index);
            } else {
                addToPanel(comp, constraints, index);
            }
        }
    }

    public int getScrollbarDisplayPolicy() {
        return scrollbarDisplayPolicy;
    }

    public java.awt.Dimension getViewportSize() {
        java.awt.Insets i = getInsets();
        return new java.awt.Dimension((((width) - (i.right)) - (i.left)) , (((height) - (i.top)) - (i.bottom)));
    }

    public int getHScrollbarHeight() {
        int h = 0;
        if ((scrollbarDisplayPolicy) != (java.awt.ScrollPane.SCROLLBARS_NEVER)) {
            java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(java.awt.ScrollPane.this.peer));
            if (peer != null) {
                h = peer.getHScrollbarHeight();
            } 
        } 
        return h;
    }

    public int getVScrollbarWidth() {
        int w = 0;
        if ((scrollbarDisplayPolicy) != (java.awt.ScrollPane.SCROLLBARS_NEVER)) {
            java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(java.awt.ScrollPane.this.peer));
            if (peer != null) {
                w = peer.getVScrollbarWidth();
            } 
        } 
        return w;
    }

    public java.awt.Adjustable getVAdjustable() {
        return vAdjustable;
    }

    public java.awt.Adjustable getHAdjustable() {
        return hAdjustable;
    }

    public void setScrollPosition(int x, int y) {
        synchronized(getTreeLock()) {
            if ((getComponentCount()) == 0) {
                throw new java.lang.NullPointerException("child is null");
            } 
            hAdjustable.setValue(x);
            vAdjustable.setValue(y);
        }
    }

    public void setScrollPosition(java.awt.Point p) {
        setScrollPosition(p.x, p.y);
    }

    @java.beans.Transient
    public java.awt.Point getScrollPosition() {
        synchronized(getTreeLock()) {
            if ((getComponentCount()) == 0) {
                throw new java.lang.NullPointerException("child is null");
            } 
            return new java.awt.Point(hAdjustable.getValue() , vAdjustable.getValue());
        }
    }

    public final void setLayout(java.awt.LayoutManager mgr) {
        throw new java.awt.AWTError("ScrollPane controls layout");
    }

    public void doLayout() {
        layout();
    }

    java.awt.Dimension calculateChildSize() {
        java.awt.Dimension size = getSize();
        java.awt.Insets insets = getInsets();
        int viewWidth = (size.width) - ((insets.left) * 2);
        int viewHeight = (size.height) - ((insets.top) * 2);
        boolean vbarOn;
        boolean hbarOn;
        java.awt.Component child = getComponent(0);
        java.awt.Dimension childSize = new java.awt.Dimension(child.getPreferredSize());
        if ((scrollbarDisplayPolicy) == (java.awt.ScrollPane.SCROLLBARS_AS_NEEDED)) {
            vbarOn = (childSize.height) > viewHeight;
            hbarOn = (childSize.width) > viewWidth;
        } else if ((scrollbarDisplayPolicy) == (java.awt.ScrollPane.SCROLLBARS_ALWAYS)) {
            vbarOn = hbarOn = true;
        } else {
            vbarOn = hbarOn = false;
        }
        int vbarWidth = getVScrollbarWidth();
        int hbarHeight = getHScrollbarHeight();
        if (vbarOn) {
            viewWidth -= vbarWidth;
        } 
        if (hbarOn) {
            viewHeight -= hbarHeight;
        } 
        if ((childSize.width) < viewWidth) {
            childSize.width = viewWidth;
        } 
        if ((childSize.height) < viewHeight) {
            childSize.height = viewHeight;
        } 
        return childSize;
    }

    @java.lang.Deprecated
    public void layout() {
        if ((getComponentCount()) == 0) {
            return ;
        } 
        java.awt.Component c = getComponent(0);
        java.awt.Point p = getScrollPosition();
        java.awt.Dimension cs = calculateChildSize();
        java.awt.Dimension vs = getViewportSize();
        c.reshape((-(p.x)), (-(p.y)), cs.width, cs.height);
        java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(java.awt.ScrollPane.this.peer));
        if (peer != null) {
            peer.childResized(cs.width, cs.height);
        } 
        vs = getViewportSize();
        hAdjustable.setSpan(0, cs.width, vs.width);
        vAdjustable.setSpan(0, cs.height, vs.height);
    }

    public void printComponents(java.awt.Graphics g) {
        if ((getComponentCount()) == 0) {
            return ;
        } 
        java.awt.Component c = getComponent(0);
        java.awt.Point p = c.getLocation();
        java.awt.Dimension vs = getViewportSize();
        java.awt.Insets i = getInsets();
        java.awt.Graphics cg = g.create();
        try {
            cg.clipRect(i.left, i.top, vs.width, vs.height);
            cg.translate(p.x, p.y);
            c.printAll(cg);
        } finally {
            cg.dispose();
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            int vAdjustableValue = 0;
            int hAdjustableValue = 0;
            if ((getComponentCount()) > 0) {
                vAdjustableValue = vAdjustable.getValue();
                hAdjustableValue = hAdjustable.getValue();
                vAdjustable.setValue(0);
                hAdjustable.setValue(0);
            } 
            if ((peer) == null)
                peer = getToolkit().createScrollPane(java.awt.ScrollPane.this);
            
            super.addNotify();
            if ((getComponentCount()) > 0) {
                vAdjustable.setValue(vAdjustableValue);
                hAdjustable.setValue(hAdjustableValue);
            } 
        }
    }

    public java.lang.String paramString() {
        java.lang.String sdpStr;
        switch (scrollbarDisplayPolicy) {
            case java.awt.ScrollPane.SCROLLBARS_AS_NEEDED :
                sdpStr = "as-needed";
                break;
            case java.awt.ScrollPane.SCROLLBARS_ALWAYS :
                sdpStr = "always";
                break;
            case java.awt.ScrollPane.SCROLLBARS_NEVER :
                sdpStr = "never";
                break;
            default :
                sdpStr = "invalid display policy";
        }
        java.awt.Point p = (getComponentCount()) > 0 ? getScrollPosition() : new java.awt.Point(0 , 0);
        java.awt.Insets i = getInsets();
        return ((((((((((((((((((super.paramString()) + ",ScrollPosition=(") + (p.x)) + ",") + (p.y)) + ")") + ",Insets=(") + (i.top)) + ",") + (i.left)) + ",") + (i.bottom)) + ",") + (i.right)) + ")") + ",ScrollbarDisplayPolicy=") + sdpStr) + ",wheelScrollingEnabled=") + (isWheelScrollingEnabled());
    }

    void autoProcessMouseWheel(java.awt.event.MouseWheelEvent e) {
        processMouseWheelEvent(e);
    }

    protected void processMouseWheelEvent(java.awt.event.MouseWheelEvent e) {
        if (isWheelScrollingEnabled()) {
            sun.awt.ScrollPaneWheelScroller.handleWheelScrolling(java.awt.ScrollPane.this, e);
            e.consume();
        } 
        super.processMouseWheelEvent(e);
    }

    protected boolean eventTypeEnabled(int type) {
        if ((type == (java.awt.event.MouseEvent.MOUSE_WHEEL)) && (isWheelScrollingEnabled())) {
            return true;
        } else {
            return super.eventTypeEnabled(type);
        }
    }

    public void setWheelScrollingEnabled(boolean handleWheel) {
        wheelScrollingEnabled = handleWheel;
    }

    public boolean isWheelScrollingEnabled() {
        return wheelScrollingEnabled;
    }

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.io.ObjectInputStream.GetField f = s.readFields();
        scrollbarDisplayPolicy = f.get("scrollbarDisplayPolicy", java.awt.ScrollPane.SCROLLBARS_AS_NEEDED);
        hAdjustable = ((java.awt.ScrollPaneAdjustable)(f.get("hAdjustable", null)));
        vAdjustable = ((java.awt.ScrollPaneAdjustable)(f.get("vAdjustable", null)));
        wheelScrollingEnabled = f.get("wheelScrollingEnabled", java.awt.ScrollPane.defaultWheelScroll);
    }

    class PeerFixer implements java.awt.event.AdjustmentListener , java.io.Serializable {
        private static final long serialVersionUID = 1043664721353696630L;

        PeerFixer(java.awt.ScrollPane scroller) {
            java.awt.ScrollPane.PeerFixer.this.scroller = scroller;
        }

        public void adjustmentValueChanged(java.awt.event.AdjustmentEvent e) {
            java.awt.Adjustable adj = e.getAdjustable();
            int value = e.getValue();
            java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(scroller.peer));
            if (peer != null) {
                peer.setValue(adj, value);
            } 
            java.awt.Component c = scroller.getComponent(0);
            switch (adj.getOrientation()) {
                case java.awt.Adjustable.VERTICAL :
                    c.move(c.getLocation().x, (-value));
                    break;
                case java.awt.Adjustable.HORIZONTAL :
                    c.move((-value), c.getLocation().y);
                    break;
                default :
                    throw new java.lang.IllegalArgumentException("Illegal adjustable orientation");
            }
        }

        private java.awt.ScrollPane scroller;
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.ScrollPane.AccessibleAWTScrollPane();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTScrollPane extends java.awt.Container.AccessibleAWTContainer {
        private static final long serialVersionUID = 6100703663886637L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.SCROLL_PANE;
        }
    }
}


package java.awt;


public class RenderingHints implements java.lang.Cloneable , java.util.Map<java.lang.Object, java.lang.Object> {
    public abstract static class Key {
        private static java.util.HashMap<java.lang.Object, java.lang.Object> identitymap = new java.util.HashMap<>(17);

        private java.lang.String getIdentity() {
            return ((((getClass().getName()) + "@") + (java.lang.Integer.toHexString(java.lang.System.identityHashCode(getClass())))) + ":") + (java.lang.Integer.toHexString(privatekey));
        }

        private static synchronized void recordIdentity(java.awt.RenderingHints.Key k) {
            java.lang.Object identity = k.getIdentity();
            java.lang.Object otherref = java.awt.RenderingHints.Key.identitymap.get(identity);
            if (otherref != null) {
                java.awt.RenderingHints.Key otherkey = ((java.awt.RenderingHints.Key)(((java.lang.ref.WeakReference)(otherref)).get()));
                if ((otherkey != null) && ((otherkey.getClass()) == (k.getClass()))) {
                    throw new java.lang.IllegalArgumentException((identity + " already registered"));
                } 
            } 
            java.awt.RenderingHints.Key.identitymap.put(identity, new java.lang.ref.WeakReference<java.awt.RenderingHints.Key>(k));
        }

        private int privatekey;

        protected Key(int privatekey) {
            java.awt.RenderingHints.Key.this.privatekey = privatekey;
            java.awt.RenderingHints.Key.recordIdentity(java.awt.RenderingHints.Key.this);
        }

        public abstract boolean isCompatibleValue(java.lang.Object val);

        protected final int intKey() {
            return privatekey;
        }

        public final int hashCode() {
            return super.hashCode();
        }

        public final boolean equals(java.lang.Object o) {
            return (java.awt.RenderingHints.Key.this) == o;
        }
    }

    java.util.HashMap<java.lang.Object, java.lang.Object> hintmap = new java.util.HashMap<>(7);

    public static final java.awt.RenderingHints.Key KEY_ANTIALIASING = sun.awt.SunHints.KEY_ANTIALIASING;

    public static final java.lang.Object VALUE_ANTIALIAS_ON = sun.awt.SunHints.VALUE_ANTIALIAS_ON;

    public static final java.lang.Object VALUE_ANTIALIAS_OFF = sun.awt.SunHints.VALUE_ANTIALIAS_OFF;

    public static final java.lang.Object VALUE_ANTIALIAS_DEFAULT = sun.awt.SunHints.VALUE_ANTIALIAS_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_RENDERING = sun.awt.SunHints.KEY_RENDERING;

    public static final java.lang.Object VALUE_RENDER_SPEED = sun.awt.SunHints.VALUE_RENDER_SPEED;

    public static final java.lang.Object VALUE_RENDER_QUALITY = sun.awt.SunHints.VALUE_RENDER_QUALITY;

    public static final java.lang.Object VALUE_RENDER_DEFAULT = sun.awt.SunHints.VALUE_RENDER_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_DITHERING = sun.awt.SunHints.KEY_DITHERING;

    public static final java.lang.Object VALUE_DITHER_DISABLE = sun.awt.SunHints.VALUE_DITHER_DISABLE;

    public static final java.lang.Object VALUE_DITHER_ENABLE = sun.awt.SunHints.VALUE_DITHER_ENABLE;

    public static final java.lang.Object VALUE_DITHER_DEFAULT = sun.awt.SunHints.VALUE_DITHER_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_TEXT_ANTIALIASING = sun.awt.SunHints.KEY_TEXT_ANTIALIASING;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_ON = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_ON;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_OFF = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_OFF;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_DEFAULT = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_DEFAULT;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_GASP = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_GASP;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_LCD_HRGB = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_LCD_HBGR = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_LCD_HBGR;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_LCD_VRGB = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_LCD_VRGB;

    public static final java.lang.Object VALUE_TEXT_ANTIALIAS_LCD_VBGR = sun.awt.SunHints.VALUE_TEXT_ANTIALIAS_LCD_VBGR;

    public static final java.awt.RenderingHints.Key KEY_TEXT_LCD_CONTRAST = sun.awt.SunHints.KEY_TEXT_ANTIALIAS_LCD_CONTRAST;

    public static final java.awt.RenderingHints.Key KEY_FRACTIONALMETRICS = sun.awt.SunHints.KEY_FRACTIONALMETRICS;

    public static final java.lang.Object VALUE_FRACTIONALMETRICS_OFF = sun.awt.SunHints.VALUE_FRACTIONALMETRICS_OFF;

    public static final java.lang.Object VALUE_FRACTIONALMETRICS_ON = sun.awt.SunHints.VALUE_FRACTIONALMETRICS_ON;

    public static final java.lang.Object VALUE_FRACTIONALMETRICS_DEFAULT = sun.awt.SunHints.VALUE_FRACTIONALMETRICS_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_INTERPOLATION = sun.awt.SunHints.KEY_INTERPOLATION;

    public static final java.lang.Object VALUE_INTERPOLATION_NEAREST_NEIGHBOR = sun.awt.SunHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR;

    public static final java.lang.Object VALUE_INTERPOLATION_BILINEAR = sun.awt.SunHints.VALUE_INTERPOLATION_BILINEAR;

    public static final java.lang.Object VALUE_INTERPOLATION_BICUBIC = sun.awt.SunHints.VALUE_INTERPOLATION_BICUBIC;

    public static final java.awt.RenderingHints.Key KEY_ALPHA_INTERPOLATION = sun.awt.SunHints.KEY_ALPHA_INTERPOLATION;

    public static final java.lang.Object VALUE_ALPHA_INTERPOLATION_SPEED = sun.awt.SunHints.VALUE_ALPHA_INTERPOLATION_SPEED;

    public static final java.lang.Object VALUE_ALPHA_INTERPOLATION_QUALITY = sun.awt.SunHints.VALUE_ALPHA_INTERPOLATION_QUALITY;

    public static final java.lang.Object VALUE_ALPHA_INTERPOLATION_DEFAULT = sun.awt.SunHints.VALUE_ALPHA_INTERPOLATION_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_COLOR_RENDERING = sun.awt.SunHints.KEY_COLOR_RENDERING;

    public static final java.lang.Object VALUE_COLOR_RENDER_SPEED = sun.awt.SunHints.VALUE_COLOR_RENDER_SPEED;

    public static final java.lang.Object VALUE_COLOR_RENDER_QUALITY = sun.awt.SunHints.VALUE_COLOR_RENDER_QUALITY;

    public static final java.lang.Object VALUE_COLOR_RENDER_DEFAULT = sun.awt.SunHints.VALUE_COLOR_RENDER_DEFAULT;

    public static final java.awt.RenderingHints.Key KEY_STROKE_CONTROL = sun.awt.SunHints.KEY_STROKE_CONTROL;

    public static final java.lang.Object VALUE_STROKE_DEFAULT = sun.awt.SunHints.VALUE_STROKE_DEFAULT;

    public static final java.lang.Object VALUE_STROKE_NORMALIZE = sun.awt.SunHints.VALUE_STROKE_NORMALIZE;

    public static final java.lang.Object VALUE_STROKE_PURE = sun.awt.SunHints.VALUE_STROKE_PURE;

    public RenderingHints(java.util.Map<java.awt.RenderingHints.Key, ?> init) {
        if (init != null) {
            hintmap.putAll(init);
        } 
    }

    public RenderingHints(java.awt.RenderingHints.Key key ,java.lang.Object value) {
        hintmap.put(key, value);
    }

    public int size() {
        return hintmap.size();
    }

    public boolean isEmpty() {
        return hintmap.isEmpty();
    }

    public boolean containsKey(java.lang.Object key) {
        return hintmap.containsKey(((java.awt.RenderingHints.Key)(key)));
    }

    public boolean containsValue(java.lang.Object value) {
        return hintmap.containsValue(value);
    }

    public java.lang.Object get(java.lang.Object key) {
        return hintmap.get(((java.awt.RenderingHints.Key)(key)));
    }

    public java.lang.Object put(java.lang.Object key, java.lang.Object value) {
        if (!(((java.awt.RenderingHints.Key)(key)).isCompatibleValue(value))) {
            throw new java.lang.IllegalArgumentException(((value + " incompatible with ") + key));
        } 
        return hintmap.put(((java.awt.RenderingHints.Key)(key)), value);
    }

    public void add(java.awt.RenderingHints hints) {
        hintmap.putAll(hints.hintmap);
    }

    public void clear() {
        hintmap.clear();
    }

    public java.lang.Object remove(java.lang.Object key) {
        return hintmap.remove(((java.awt.RenderingHints.Key)(key)));
    }

    public void putAll(java.util.Map<?, ?> m) {
        if (java.awt.RenderingHints.class.isInstance(m)) {
            for (java.util.Map.Entry<?, ?> entry : m.entrySet())
                hintmap.put(entry.getKey(), entry.getValue());
        } else {
            for (java.util.Map.Entry<?, ?> entry : m.entrySet())
                put(entry.getKey(), entry.getValue());
        }
    }

    public java.util.Set<java.lang.Object> keySet() {
        return hintmap.keySet();
    }

    public java.util.Collection<java.lang.Object> values() {
        return hintmap.values();
    }

    public java.util.Set<java.util.Map.Entry<java.lang.Object, java.lang.Object>> entrySet() {
        return java.util.Collections.unmodifiableMap(hintmap).entrySet();
    }

    public boolean equals(java.lang.Object o) {
        if (o instanceof java.awt.RenderingHints) {
            return hintmap.equals(((java.awt.RenderingHints)(o)).hintmap);
        } else if (o instanceof java.util.Map) {
            return hintmap.equals(o);
        } 
        return false;
    }

    public int hashCode() {
        return hintmap.hashCode();
    }

    @java.lang.SuppressWarnings(value = "unchecked")
    public java.lang.Object clone() {
        java.awt.RenderingHints rh;
        try {
            rh = ((java.awt.RenderingHints)(super.clone()));
            if ((hintmap) != null) {
                rh.hintmap = ((java.util.HashMap<java.lang.Object, java.lang.Object>)(hintmap.clone()));
            } 
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
        return rh;
    }

    public java.lang.String toString() {
        if ((hintmap) == null) {
            return (((getClass().getName()) + "@") + (java.lang.Integer.toHexString(hashCode()))) + " (0 hints)";
        } 
        return hintmap.toString();
    }
}


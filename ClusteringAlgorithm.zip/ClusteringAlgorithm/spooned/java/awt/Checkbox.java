package java.awt;


public class Checkbox extends java.awt.Component implements java.awt.ItemSelectable , javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Checkbox.initIDs();
        } 
    }

    java.lang.String label;

    boolean state;

    java.awt.CheckboxGroup group;

    transient java.awt.event.ItemListener itemListener;

    private static final java.lang.String base = "checkbox";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 7270714317450821763L;

    void setStateInternal(boolean state) {
        java.awt.Checkbox.this.state = state;
        java.awt.peer.CheckboxPeer peer = ((java.awt.peer.CheckboxPeer)(java.awt.Checkbox.this.peer));
        if (peer != null) {
            peer.setState(state);
        } 
    }

    public Checkbox() throws java.awt.HeadlessException {
        this("", false, null);
    }

    public Checkbox(java.lang.String label) throws java.awt.HeadlessException {
        this(label, false, null);
    }

    public Checkbox(java.lang.String label ,boolean state) throws java.awt.HeadlessException {
        this(label, state, null);
    }

    public Checkbox(java.lang.String label ,boolean state ,java.awt.CheckboxGroup group) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.Checkbox.this.label = label;
        java.awt.Checkbox.this.state = state;
        java.awt.Checkbox.this.group = group;
        if (state && (group != null)) {
            group.setSelectedCheckbox(java.awt.Checkbox.this);
        } 
    }

    public Checkbox(java.lang.String label ,java.awt.CheckboxGroup group ,boolean state) throws java.awt.HeadlessException {
        this(label, state, group);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Checkbox.class) {
            return (java.awt.Checkbox.base) + ((java.awt.Checkbox.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createCheckbox(java.awt.Checkbox.this);
            
            super.addNotify();
        }
    }

    public java.lang.String getLabel() {
        return label;
    }

    public void setLabel(java.lang.String label) {
        boolean testvalid = false;
        synchronized(java.awt.Checkbox.this) {
            if ((label != (java.awt.Checkbox.this.label)) && (((java.awt.Checkbox.this.label) == null) || (!(java.awt.Checkbox.this.label.equals(label))))) {
                java.awt.Checkbox.this.label = label;
                java.awt.peer.CheckboxPeer peer = ((java.awt.peer.CheckboxPeer)(java.awt.Checkbox.this.peer));
                if (peer != null) {
                    peer.setLabel(label);
                } 
                testvalid = true;
            } 
        }
        if (testvalid) {
            invalidateIfValid();
        } 
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        java.awt.CheckboxGroup group = java.awt.Checkbox.this.group;
        if (group != null) {
            if (state) {
                group.setSelectedCheckbox(java.awt.Checkbox.this);
            } else if ((group.getSelectedCheckbox()) == (java.awt.Checkbox.this)) {
                state = true;
            } 
        } 
        setStateInternal(state);
    }

    public java.lang.Object[] getSelectedObjects() {
        if (state) {
            java.lang.Object[] items = new java.lang.Object[1];
            items[0] = label;
            return items;
        } 
        return null;
    }

    public java.awt.CheckboxGroup getCheckboxGroup() {
        return group;
    }

    public void setCheckboxGroup(java.awt.CheckboxGroup g) {
        java.awt.CheckboxGroup oldGroup;
        boolean oldState;
        if ((java.awt.Checkbox.this.group) == g) {
            return ;
        } 
        synchronized(java.awt.Checkbox.this) {
            oldGroup = java.awt.Checkbox.this.group;
            oldState = getState();
            java.awt.Checkbox.this.group = g;
            java.awt.peer.CheckboxPeer peer = ((java.awt.peer.CheckboxPeer)(java.awt.Checkbox.this.peer));
            if (peer != null) {
                peer.setCheckboxGroup(g);
            } 
            if (((java.awt.Checkbox.this.group) != null) && (getState())) {
                if ((java.awt.Checkbox.this.group.getSelectedCheckbox()) != null) {
                    setState(false);
                } else {
                    java.awt.Checkbox.this.group.setSelectedCheckbox(java.awt.Checkbox.this);
                }
            } 
        }
        if ((oldGroup != null) && oldState) {
            oldGroup.setSelectedCheckbox(null);
        } 
    }

    public synchronized void addItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.add(itemListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.remove(itemListener, l);
    }

    public synchronized java.awt.event.ItemListener[] getItemListeners() {
        return getListeners(java.awt.event.ItemListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ItemListener.class)) {
            l = itemListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ItemEvent.ITEM_STATE_CHANGED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) || ((itemListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ItemEvent) {
            processItemEvent(((java.awt.event.ItemEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processItemEvent(java.awt.event.ItemEvent e) {
        java.awt.event.ItemListener listener = itemListener;
        if (listener != null) {
            listener.itemStateChanged(e);
        } 
    }

    protected java.lang.String paramString() {
        java.lang.String str = super.paramString();
        java.lang.String label = java.awt.Checkbox.this.label;
        if (label != null) {
            str += ",label=" + label;
        } 
        return (str + ",state=") + (state);
    }

    private int checkboxSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.itemListenerK, itemListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.itemListenerK) == key)
                addItemListener(((java.awt.event.ItemListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Checkbox.AccessibleAWTCheckbox();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTCheckbox extends java.awt.Component.AccessibleAWTComponent implements java.awt.event.ItemListener , javax.accessibility.AccessibleAction , javax.accessibility.AccessibleValue {
        private static final long serialVersionUID = 7881579233144754107L;

        public AccessibleAWTCheckbox() {
            super();
            java.awt.Checkbox.this.addItemListener(java.awt.Checkbox.AccessibleAWTCheckbox.this);
        }

        public void itemStateChanged(java.awt.event.ItemEvent e) {
            java.awt.Checkbox cb = ((java.awt.Checkbox)(e.getSource()));
            if ((java.awt.Checkbox.this.accessibleContext) != null) {
                if (cb.getState()) {
                    java.awt.Checkbox.this.accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.CHECKED);
                } else {
                    java.awt.Checkbox.this.accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, javax.accessibility.AccessibleState.CHECKED, null);
                }
            } 
        }

        public javax.accessibility.AccessibleAction getAccessibleAction() {
            return java.awt.Checkbox.AccessibleAWTCheckbox.this;
        }

        public javax.accessibility.AccessibleValue getAccessibleValue() {
            return java.awt.Checkbox.AccessibleAWTCheckbox.this;
        }

        public int getAccessibleActionCount() {
            return 0;
        }

        public java.lang.String getAccessibleActionDescription(int i) {
            return null;
        }

        public boolean doAccessibleAction(int i) {
            return false;
        }

        public java.lang.Number getCurrentAccessibleValue() {
            return null;
        }

        public boolean setCurrentAccessibleValue(java.lang.Number n) {
            return false;
        }

        public java.lang.Number getMinimumAccessibleValue() {
            return null;
        }

        public java.lang.Number getMaximumAccessibleValue() {
            return null;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.CHECK_BOX;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if (getState()) {
                states.add(javax.accessibility.AccessibleState.CHECKED);
            } 
            return states;
        }
    }
}


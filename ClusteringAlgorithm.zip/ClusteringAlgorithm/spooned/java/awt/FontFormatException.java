package java.awt;


public class FontFormatException extends java.lang.Exception {
    private static final long serialVersionUID = -4481290147811361272L;

    public FontFormatException(java.lang.String reason) {
        super(reason);
    }
}


package java.awt;


class GradientPaintContext implements java.awt.PaintContext {
    static java.awt.image.ColorModel xrgbmodel = new java.awt.image.DirectColorModel(24 , 16711680 , 65280 , 255);

    static java.awt.image.ColorModel xbgrmodel = new java.awt.image.DirectColorModel(24 , 255 , 65280 , 16711680);

    static java.awt.image.ColorModel cachedModel;

    static java.lang.ref.WeakReference<java.awt.image.Raster> cached;

    static synchronized java.awt.image.Raster getCachedRaster(java.awt.image.ColorModel cm, int w, int h) {
        if (cm == (java.awt.GradientPaintContext.cachedModel)) {
            if ((java.awt.GradientPaintContext.cached) != null) {
                java.awt.image.Raster ras = ((java.awt.image.Raster)(java.awt.GradientPaintContext.cached.get()));
                if (((ras != null) && ((ras.getWidth()) >= w)) && ((ras.getHeight()) >= h)) {
                    java.awt.GradientPaintContext.cached = null;
                    return ras;
                } 
            } 
        } 
        return cm.createCompatibleWritableRaster(w, h);
    }

    static synchronized void putCachedRaster(java.awt.image.ColorModel cm, java.awt.image.Raster ras) {
        if ((java.awt.GradientPaintContext.cached) != null) {
            java.awt.image.Raster cras = ((java.awt.image.Raster)(java.awt.GradientPaintContext.cached.get()));
            if (cras != null) {
                int cw = cras.getWidth();
                int ch = cras.getHeight();
                int iw = ras.getWidth();
                int ih = ras.getHeight();
                if ((cw >= iw) && (ch >= ih)) {
                    return ;
                } 
                if ((cw * ch) >= (iw * ih)) {
                    return ;
                } 
            } 
        } 
        java.awt.GradientPaintContext.cachedModel = cm;
        java.awt.GradientPaintContext.cached = new java.lang.ref.WeakReference<>(ras);
    }

    double x1;

    double y1;

    double dx;

    double dy;

    boolean cyclic;

    int[] interp;

    java.awt.image.Raster saved;

    java.awt.image.ColorModel model;

    public GradientPaintContext(java.awt.image.ColorModel cm ,java.awt.geom.Point2D p1 ,java.awt.geom.Point2D p2 ,java.awt.geom.AffineTransform xform ,java.awt.Color c1 ,java.awt.Color c2 ,boolean cyclic) {
        java.awt.geom.Point2D xvec = new java.awt.geom.Point2D.Double(1 , 0);
        java.awt.geom.Point2D yvec = new java.awt.geom.Point2D.Double(0 , 1);
        try {
            java.awt.geom.AffineTransform inverse = xform.createInverse();
            inverse.deltaTransform(xvec, xvec);
            inverse.deltaTransform(yvec, yvec);
        } catch (java.awt.geom.NoninvertibleTransformException e) {
            xvec.setLocation(0, 0);
            yvec.setLocation(0, 0);
        }
        double udx = (p2.getX()) - (p1.getX());
        double udy = (p2.getY()) - (p1.getY());
        double ulenSq = (udx * udx) + (udy * udy);
        if (ulenSq <= (java.lang.Double.MIN_VALUE)) {
            dx = 0;
            dy = 0;
        } else {
            dx = (((xvec.getX()) * udx) + ((xvec.getY()) * udy)) / ulenSq;
            dy = (((yvec.getX()) * udx) + ((yvec.getY()) * udy)) / ulenSq;
            if (cyclic) {
                dx = (dx) % 1.0;
                dy = (dy) % 1.0;
            } else {
                if ((dx) < 0) {
                    java.awt.geom.Point2D p = p1;
                    p1 = p2;
                    p2 = p;
                    java.awt.Color c = c1;
                    c1 = c2;
                    c2 = c;
                    dx = -(dx);
                    dy = -(dy);
                } 
            }
        }
        java.awt.geom.Point2D dp1 = xform.transform(p1, null);
        java.awt.GradientPaintContext.this.x1 = dp1.getX();
        java.awt.GradientPaintContext.this.y1 = dp1.getY();
        java.awt.GradientPaintContext.this.cyclic = cyclic;
        int rgb1 = c1.getRGB();
        int rgb2 = c2.getRGB();
        int a1 = (rgb1 >> 24) & 255;
        int r1 = (rgb1 >> 16) & 255;
        int g1 = (rgb1 >> 8) & 255;
        int b1 = rgb1 & 255;
        int da = ((rgb2 >> 24) & 255) - a1;
        int dr = ((rgb2 >> 16) & 255) - r1;
        int dg = ((rgb2 >> 8) & 255) - g1;
        int db = (rgb2 & 255) - b1;
        if ((a1 == 255) && (da == 0)) {
            model = java.awt.GradientPaintContext.xrgbmodel;
            if (cm instanceof java.awt.image.DirectColorModel) {
                java.awt.image.DirectColorModel dcm = ((java.awt.image.DirectColorModel)(cm));
                int tmp = dcm.getAlphaMask();
                if (((((tmp == 0) || (tmp == 255)) && ((dcm.getRedMask()) == 255)) && ((dcm.getGreenMask()) == 65280)) && ((dcm.getBlueMask()) == 16711680)) {
                    model = java.awt.GradientPaintContext.xbgrmodel;
                    tmp = r1;
                    r1 = b1;
                    b1 = tmp;
                    tmp = dr;
                    dr = db;
                    db = tmp;
                } 
            } 
        } else {
            model = java.awt.image.ColorModel.getRGBdefault();
        }
        interp = new int[cyclic ? 513 : 257];
        for (int i = 0 ; i <= 256 ; i++) {
            float rel = i / 256.0F;
            int rgb = (((((int)((a1 + (da * rel)))) << 24) | (((int)((r1 + (dr * rel)))) << 16)) | (((int)((g1 + (dg * rel)))) << 8)) | ((int)((b1 + (db * rel))));
            interp[i] = rgb;
            if (cyclic) {
                interp[(512 - i)] = rgb;
            } 
        }
    }

    public void dispose() {
        if ((saved) != null) {
            java.awt.GradientPaintContext.putCachedRaster(model, saved);
            saved = null;
        } 
    }

    public java.awt.image.ColorModel getColorModel() {
        return model;
    }

    public java.awt.image.Raster getRaster(int x, int y, int w, int h) {
        double rowrel = ((x - (x1)) * (dx)) + ((y - (y1)) * (dy));
        java.awt.image.Raster rast = saved;
        if (((rast == null) || ((rast.getWidth()) < w)) || ((rast.getHeight()) < h)) {
            rast = java.awt.GradientPaintContext.getCachedRaster(model, w, h);
            saved = rast;
        } 
        sun.awt.image.IntegerComponentRaster irast = ((sun.awt.image.IntegerComponentRaster)(rast));
        int off = irast.getDataOffset(0);
        int adjust = (irast.getScanlineStride()) - w;
        int[] pixels = irast.getDataStorage();
        if (cyclic) {
            cycleFillRaster(pixels, off, adjust, w, h, rowrel, dx, dy);
        } else {
            clipFillRaster(pixels, off, adjust, w, h, rowrel, dx, dy);
        }
        irast.markDirty();
        return rast;
    }

    void cycleFillRaster(int[] pixels, int off, int adjust, int w, int h, double rowrel, double dx, double dy) {
        rowrel = rowrel % 2.0;
        int irowrel = ((int)((rowrel * (1 << 30)))) << 1;
        int idx = ((int)((-dx) * (1 << 31)));
        int idy = ((int)((-dy) * (1 << 31)));
        while ((--h) >= 0) {
            int icolrel = irowrel;
            for (int j = w ; j > 0 ; j--) {
                pixels[(off++)] = interp[(icolrel >>> 23)];
                icolrel += idx;
            }
            off += adjust;
            irowrel += idy;
        }
    }

    void clipFillRaster(int[] pixels, int off, int adjust, int w, int h, double rowrel, double dx, double dy) {
        while ((--h) >= 0) {
            double colrel = rowrel;
            int j = w;
            if (colrel <= 0.0) {
                int rgb = interp[0];
                do {
                    pixels[(off++)] = rgb;
                    colrel += dx;
                } while (((--j) > 0) && (colrel <= 0.0) );
            } 
            while ((colrel < 1.0) && ((--j) >= 0)) {
                pixels[(off++)] = interp[((int)(colrel * 256))];
                colrel += dx;
            }
            if (j > 0) {
                int rgb = interp[256];
                do {
                    pixels[(off++)] = rgb;
                } while ((--j) > 0 );
            } 
            off += adjust;
            rowrel += dy;
        }
    }
}


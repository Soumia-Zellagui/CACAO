package java.awt;


public class TextField extends java.awt.TextComponent {
    int columns;

    char echoChar;

    transient java.awt.event.ActionListener actionListener;

    private static final java.lang.String base = "textfield";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -2966288784432217853L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.TextField.initIDs();
        } 
    }

    public TextField() throws java.awt.HeadlessException {
        this("", 0);
    }

    public TextField(java.lang.String text) throws java.awt.HeadlessException {
        this(text, (text != null ? text.length() : 0));
    }

    public TextField(int columns) throws java.awt.HeadlessException {
        this("", columns);
    }

    public TextField(java.lang.String text ,int columns) throws java.awt.HeadlessException {
        super(text);
        java.awt.TextField.this.columns = columns >= 0 ? columns : 0;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.TextField.class) {
            return (java.awt.TextField.base) + ((java.awt.TextField.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createTextField(java.awt.TextField.this);
            
            super.addNotify();
        }
    }

    public char getEchoChar() {
        return echoChar;
    }

    public void setEchoChar(char c) {
        setEchoCharacter(c);
    }

    @java.lang.Deprecated
    public synchronized void setEchoCharacter(char c) {
        if ((echoChar) != c) {
            echoChar = c;
            java.awt.peer.TextFieldPeer peer = ((java.awt.peer.TextFieldPeer)(java.awt.TextField.this.peer));
            if (peer != null) {
                peer.setEchoChar(c);
            } 
        } 
    }

    public void setText(java.lang.String t) {
        super.setText(t);
        invalidateIfValid();
    }

    public boolean echoCharIsSet() {
        return (echoChar) != 0;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        int oldVal;
        synchronized(java.awt.TextField.this) {
            oldVal = java.awt.TextField.this.columns;
            if (columns < 0) {
                throw new java.lang.IllegalArgumentException("columns less than zero.");
            } 
            if (columns != oldVal) {
                java.awt.TextField.this.columns = columns;
            } 
        }
        if (columns != oldVal) {
            invalidate();
        } 
    }

    public java.awt.Dimension getPreferredSize(int columns) {
        return preferredSize(columns);
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize(int columns) {
        synchronized(getTreeLock()) {
            java.awt.peer.TextFieldPeer peer = ((java.awt.peer.TextFieldPeer)(java.awt.TextField.this.peer));
            return peer != null ? peer.getPreferredSize(columns) : super.preferredSize();
        }
    }

    public java.awt.Dimension getPreferredSize() {
        return preferredSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize() {
        synchronized(getTreeLock()) {
            return (columns) > 0 ? preferredSize(columns) : super.preferredSize();
        }
    }

    public java.awt.Dimension getMinimumSize(int columns) {
        return minimumSize(columns);
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize(int columns) {
        synchronized(getTreeLock()) {
            java.awt.peer.TextFieldPeer peer = ((java.awt.peer.TextFieldPeer)(java.awt.TextField.this.peer));
            return peer != null ? peer.getMinimumSize(columns) : super.minimumSize();
        }
    }

    public java.awt.Dimension getMinimumSize() {
        return minimumSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize() {
        synchronized(getTreeLock()) {
            return (columns) > 0 ? minimumSize(columns) : super.minimumSize();
        }
    }

    public synchronized void addActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.add(actionListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.remove(actionListener, l);
    }

    public synchronized java.awt.event.ActionListener[] getActionListeners() {
        return getListeners(java.awt.event.ActionListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ActionListener.class)) {
            l = actionListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ActionEvent.ACTION_PERFORMED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) || ((actionListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ActionEvent) {
            processActionEvent(((java.awt.event.ActionEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processActionEvent(java.awt.event.ActionEvent e) {
        java.awt.event.ActionListener listener = actionListener;
        if (listener != null) {
            listener.actionPerformed(e);
        } 
    }

    protected java.lang.String paramString() {
        java.lang.String str = super.paramString();
        if ((echoChar) != 0) {
            str += ",echo=" + (echoChar);
        } 
        return str;
    }

    private int textFieldSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.actionListenerK, actionListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((columns) < 0) {
            columns = 0;
        } 
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.actionListenerK) == key) {
                addActionListener(((java.awt.event.ActionListener)(s.readObject())));
            } else {
                s.readObject();
            }
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.TextField.AccessibleAWTTextField();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTTextField extends java.awt.TextComponent.AccessibleAWTTextComponent {
        private static final long serialVersionUID = 6219164359235943158L;

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            states.add(javax.accessibility.AccessibleState.SINGLE_LINE);
            return states;
        }
    }
}


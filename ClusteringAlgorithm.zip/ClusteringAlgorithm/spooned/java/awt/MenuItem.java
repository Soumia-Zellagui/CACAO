package java.awt;


public class MenuItem extends java.awt.MenuComponent implements javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.MenuItem.initIDs();
        } 
        sun.awt.AWTAccessor.setMenuItemAccessor(new sun.awt.AWTAccessor.MenuItemAccessor() {
            public boolean isEnabled(java.awt.MenuItem item) {
                return item.enabled;
            }

            public java.lang.String getLabel(java.awt.MenuItem item) {
                return item.label;
            }

            public java.awt.MenuShortcut getShortcut(java.awt.MenuItem item) {
                return item.shortcut;
            }

            public java.lang.String getActionCommandImpl(java.awt.MenuItem item) {
                return item.getActionCommandImpl();
            }

            public boolean isItemEnabled(java.awt.MenuItem item) {
                return item.isItemEnabled();
            }
        });
    }

    boolean enabled = true;

    java.lang.String label;

    java.lang.String actionCommand;

    long eventMask;

    transient java.awt.event.ActionListener actionListener;

    private java.awt.MenuShortcut shortcut = null;

    private static final java.lang.String base = "menuitem";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -21757335363267194L;

    public MenuItem() throws java.awt.HeadlessException {
        this("", null);
    }

    public MenuItem(java.lang.String label) throws java.awt.HeadlessException {
        this(label, null);
    }

    public MenuItem(java.lang.String label ,java.awt.MenuShortcut s) throws java.awt.HeadlessException {
        java.awt.MenuItem.this.label = label;
        java.awt.MenuItem.this.shortcut = s;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.MenuItem.class) {
            return (java.awt.MenuItem.base) + ((java.awt.MenuItem.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = java.awt.Toolkit.getDefaultToolkit().createMenuItem(java.awt.MenuItem.this);
            
        }
    }

    public java.lang.String getLabel() {
        return label;
    }

    public synchronized void setLabel(java.lang.String label) {
        java.awt.MenuItem.this.label = label;
        java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
        if (peer != null) {
            peer.setLabel(label);
        } 
    }

    public boolean isEnabled() {
        return enabled;
    }

    public synchronized void setEnabled(boolean b) {
        enable(b);
    }

    @java.lang.Deprecated
    public synchronized void enable() {
        enabled = true;
        java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
        if (peer != null) {
            peer.setEnabled(true);
        } 
    }

    @java.lang.Deprecated
    public void enable(boolean b) {
        if (b) {
            enable();
        } else {
            disable();
        }
    }

    @java.lang.Deprecated
    public synchronized void disable() {
        enabled = false;
        java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
        if (peer != null) {
            peer.setEnabled(false);
        } 
    }

    public java.awt.MenuShortcut getShortcut() {
        return shortcut;
    }

    public void setShortcut(java.awt.MenuShortcut s) {
        shortcut = s;
        java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
        if (peer != null) {
            peer.setLabel(label);
        } 
    }

    public void deleteShortcut() {
        shortcut = null;
        java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
        if (peer != null) {
            peer.setLabel(label);
        } 
    }

    void deleteShortcut(java.awt.MenuShortcut s) {
        if (s.equals(shortcut)) {
            shortcut = null;
            java.awt.peer.MenuItemPeer peer = ((java.awt.peer.MenuItemPeer)(java.awt.MenuItem.this.peer));
            if (peer != null) {
                peer.setLabel(label);
            } 
        } 
    }

    void doMenuEvent(long when, int modifiers) {
        java.awt.Toolkit.getEventQueue().postEvent(new java.awt.event.ActionEvent(java.awt.MenuItem.this , java.awt.event.ActionEvent.ACTION_PERFORMED , getActionCommand() , when , modifiers));
    }

    private final boolean isItemEnabled() {
        if (!(isEnabled())) {
            return false;
        } 
        java.awt.MenuContainer container = getParent_NoClientCode();
        do {
            if (!(container instanceof java.awt.Menu)) {
                return true;
            } 
            java.awt.Menu menu = ((java.awt.Menu)(container));
            if (!(menu.isEnabled())) {
                return false;
            } 
            container = menu.getParent_NoClientCode();
        } while (container != null );
        return true;
    }

    boolean handleShortcut(java.awt.event.KeyEvent e) {
        java.awt.MenuShortcut s = new java.awt.MenuShortcut(e.getKeyCode() , (((e.getModifiers()) & (java.awt.event.InputEvent.SHIFT_MASK)) > 0));
        java.awt.MenuShortcut sE = new java.awt.MenuShortcut(e.getExtendedKeyCode() , (((e.getModifiers()) & (java.awt.event.InputEvent.SHIFT_MASK)) > 0));
        if (((s.equals(shortcut)) || (sE.equals(shortcut))) && (isItemEnabled())) {
            if ((e.getID()) == (java.awt.event.KeyEvent.KEY_PRESSED)) {
                doMenuEvent(e.getWhen(), e.getModifiers());
            } else {
            }
            return true;
        } 
        return false;
    }

    java.awt.MenuItem getShortcutMenuItem(java.awt.MenuShortcut s) {
        return s.equals(shortcut) ? java.awt.MenuItem.this : null;
    }

    protected final void enableEvents(long eventsToEnable) {
        eventMask |= eventsToEnable;
        newEventsOnly = true;
    }

    protected final void disableEvents(long eventsToDisable) {
        eventMask &= ~eventsToDisable;
    }

    public void setActionCommand(java.lang.String command) {
        actionCommand = command;
    }

    public java.lang.String getActionCommand() {
        return getActionCommandImpl();
    }

    final java.lang.String getActionCommandImpl() {
        return (actionCommand) == null ? label : actionCommand;
    }

    public synchronized void addActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.add(actionListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.remove(actionListener, l);
    }

    public synchronized java.awt.event.ActionListener[] getActionListeners() {
        return getListeners(java.awt.event.ActionListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ActionListener.class)) {
            l = actionListener;
        } 
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ActionEvent) {
            processActionEvent(((java.awt.event.ActionEvent)(e)));
        } 
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ActionEvent.ACTION_PERFORMED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) || ((actionListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processActionEvent(java.awt.event.ActionEvent e) {
        java.awt.event.ActionListener listener = actionListener;
        if (listener != null) {
            listener.actionPerformed(e);
        } 
    }

    public java.lang.String paramString() {
        java.lang.String str = ",label=" + (label);
        if ((shortcut) != null) {
            str += ",shortcut=" + (shortcut);
        } 
        return (super.paramString()) + str;
    }

    private int menuItemSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.MenuComponent.actionListenerK, actionListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.MenuComponent.actionListenerK) == key)
                addActionListener(((java.awt.event.ActionListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.MenuItem.AccessibleAWTMenuItem();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTMenuItem extends java.awt.MenuComponent.AccessibleAWTMenuComponent implements javax.accessibility.AccessibleAction , javax.accessibility.AccessibleValue {
        private static final long serialVersionUID = -217847831945965825L;

        public java.lang.String getAccessibleName() {
            if ((accessibleName) != null) {
                return accessibleName;
            } else {
                if ((getLabel()) == null) {
                    return super.getAccessibleName();
                } else {
                    return getLabel();
                }
            }
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.MENU_ITEM;
        }

        public javax.accessibility.AccessibleAction getAccessibleAction() {
            return java.awt.MenuItem.AccessibleAWTMenuItem.this;
        }

        public javax.accessibility.AccessibleValue getAccessibleValue() {
            return java.awt.MenuItem.AccessibleAWTMenuItem.this;
        }

        public int getAccessibleActionCount() {
            return 1;
        }

        public java.lang.String getAccessibleActionDescription(int i) {
            if (i == 0) {
                return "click";
            } else {
                return null;
            }
        }

        public boolean doAccessibleAction(int i) {
            if (i == 0) {
                java.awt.Toolkit.getEventQueue().postEvent(new java.awt.event.ActionEvent(java.awt.MenuItem.this , java.awt.event.ActionEvent.ACTION_PERFORMED , java.awt.MenuItem.this.getActionCommand() , java.awt.EventQueue.getMostRecentEventTime() , 0));
                return true;
            } else {
                return false;
            }
        }

        public java.lang.Number getCurrentAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }

        public boolean setCurrentAccessibleValue(java.lang.Number n) {
            return false;
        }

        public java.lang.Number getMinimumAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }

        public java.lang.Number getMaximumAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }
    }
}


package java.awt;


public class Color implements java.awt.Paint , java.io.Serializable {
    public static final java.awt.Color white = new java.awt.Color(255 , 255 , 255);

    public static final java.awt.Color WHITE = java.awt.Color.white;

    public static final java.awt.Color lightGray = new java.awt.Color(192 , 192 , 192);

    public static final java.awt.Color LIGHT_GRAY = java.awt.Color.lightGray;

    public static final java.awt.Color gray = new java.awt.Color(128 , 128 , 128);

    public static final java.awt.Color GRAY = java.awt.Color.gray;

    public static final java.awt.Color darkGray = new java.awt.Color(64 , 64 , 64);

    public static final java.awt.Color DARK_GRAY = java.awt.Color.darkGray;

    public static final java.awt.Color black = new java.awt.Color(0 , 0 , 0);

    public static final java.awt.Color BLACK = java.awt.Color.black;

    public static final java.awt.Color red = new java.awt.Color(255 , 0 , 0);

    public static final java.awt.Color RED = java.awt.Color.red;

    public static final java.awt.Color pink = new java.awt.Color(255 , 175 , 175);

    public static final java.awt.Color PINK = java.awt.Color.pink;

    public static final java.awt.Color orange = new java.awt.Color(255 , 200 , 0);

    public static final java.awt.Color ORANGE = java.awt.Color.orange;

    public static final java.awt.Color yellow = new java.awt.Color(255 , 255 , 0);

    public static final java.awt.Color YELLOW = java.awt.Color.yellow;

    public static final java.awt.Color green = new java.awt.Color(0 , 255 , 0);

    public static final java.awt.Color GREEN = java.awt.Color.green;

    public static final java.awt.Color magenta = new java.awt.Color(255 , 0 , 255);

    public static final java.awt.Color MAGENTA = java.awt.Color.magenta;

    public static final java.awt.Color cyan = new java.awt.Color(0 , 255 , 255);

    public static final java.awt.Color CYAN = java.awt.Color.cyan;

    public static final java.awt.Color blue = new java.awt.Color(0 , 0 , 255);

    public static final java.awt.Color BLUE = java.awt.Color.blue;

    int value;

    private float[] frgbvalue = null;

    private float[] fvalue = null;

    private float falpha = 0.0F;

    private java.awt.color.ColorSpace cs = null;

    private static final long serialVersionUID = 118526816881161077L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Color.initIDs();
        } 
    }

    private static void testColorValueRange(int r, int g, int b, int a) {
        boolean rangeError = false;
        java.lang.String badComponentString = "";
        if ((a < 0) || (a > 255)) {
            rangeError = true;
            badComponentString = badComponentString + " Alpha";
        } 
        if ((r < 0) || (r > 255)) {
            rangeError = true;
            badComponentString = badComponentString + " Red";
        } 
        if ((g < 0) || (g > 255)) {
            rangeError = true;
            badComponentString = badComponentString + " Green";
        } 
        if ((b < 0) || (b > 255)) {
            rangeError = true;
            badComponentString = badComponentString + " Blue";
        } 
        if (rangeError == true) {
            throw new java.lang.IllegalArgumentException(("Color parameter outside of expected range:" + badComponentString));
        } 
    }

    private static void testColorValueRange(float r, float g, float b, float a) {
        boolean rangeError = false;
        java.lang.String badComponentString = "";
        if ((a < 0.0) || (a > 1.0)) {
            rangeError = true;
            badComponentString = badComponentString + " Alpha";
        } 
        if ((r < 0.0) || (r > 1.0)) {
            rangeError = true;
            badComponentString = badComponentString + " Red";
        } 
        if ((g < 0.0) || (g > 1.0)) {
            rangeError = true;
            badComponentString = badComponentString + " Green";
        } 
        if ((b < 0.0) || (b > 1.0)) {
            rangeError = true;
            badComponentString = badComponentString + " Blue";
        } 
        if (rangeError == true) {
            throw new java.lang.IllegalArgumentException(("Color parameter outside of expected range:" + badComponentString));
        } 
    }

    public Color(int r ,int g ,int b) {
        this(r, g, b, 255);
    }

    @java.beans.ConstructorProperties(value = { "red" , "green" , "blue" , "alpha" })
    public Color(int r ,int g ,int b ,int a) {
        value = ((((a & 255) << 24) | ((r & 255) << 16)) | ((g & 255) << 8)) | ((b & 255) << 0);
        java.awt.Color.testColorValueRange(r, g, b, a);
    }

    public Color(int rgb) {
        value = -16777216 | rgb;
    }

    public Color(int rgba ,boolean hasalpha) {
        if (hasalpha) {
            value = rgba;
        } else {
            value = -16777216 | rgba;
        }
    }

    public Color(float r ,float g ,float b) {
        this(((int)((r * 255) + 0.5)), ((int)((g * 255) + 0.5)), ((int)((b * 255) + 0.5)));
        java.awt.Color.testColorValueRange(r, g, b, 1.0F);
        frgbvalue = new float[3];
        frgbvalue[0] = r;
        frgbvalue[1] = g;
        frgbvalue[2] = b;
        falpha = 1.0F;
        fvalue = frgbvalue;
    }

    public Color(float r ,float g ,float b ,float a) {
        this(((int)((r * 255) + 0.5)), ((int)((g * 255) + 0.5)), ((int)((b * 255) + 0.5)), ((int)((a * 255) + 0.5)));
        frgbvalue = new float[3];
        frgbvalue[0] = r;
        frgbvalue[1] = g;
        frgbvalue[2] = b;
        falpha = a;
        fvalue = frgbvalue;
    }

    public Color(java.awt.color.ColorSpace cspace ,float[] components ,float alpha) {
        boolean rangeError = false;
        java.lang.String badComponentString = "";
        int n = cspace.getNumComponents();
        fvalue = new float[n];
        for (int i = 0 ; i < n ; i++) {
            if (((components[i]) < 0.0) || ((components[i]) > 1.0)) {
                rangeError = true;
                badComponentString = ((badComponentString + "Component ") + i) + " ";
            } else {
                fvalue[i] = components[i];
            }
        }
        if ((alpha < 0.0) || (alpha > 1.0)) {
            rangeError = true;
            badComponentString = badComponentString + "Alpha";
        } else {
            falpha = alpha;
        }
        if (rangeError) {
            throw new java.lang.IllegalArgumentException(("Color parameter outside of expected range: " + badComponentString));
        } 
        frgbvalue = cspace.toRGB(fvalue);
        cs = cspace;
        value = ((((((int)(((falpha) * 255))) & 255) << 24) | ((((int)(((frgbvalue[0]) * 255))) & 255) << 16)) | ((((int)(((frgbvalue[1]) * 255))) & 255) << 8)) | ((((int)(((frgbvalue[2]) * 255))) & 255) << 0);
    }

    public int getRed() {
        return ((getRGB()) >> 16) & 255;
    }

    public int getGreen() {
        return ((getRGB()) >> 8) & 255;
    }

    public int getBlue() {
        return ((getRGB()) >> 0) & 255;
    }

    public int getAlpha() {
        return ((getRGB()) >> 24) & 255;
    }

    public int getRGB() {
        return value;
    }

    private static final double FACTOR = 0.7;

    public java.awt.Color brighter() {
        int r = getRed();
        int g = getGreen();
        int b = getBlue();
        int alpha = getAlpha();
        int i = ((int)(1.0 / (1.0 - (java.awt.Color.FACTOR))));
        if (((r == 0) && (g == 0)) && (b == 0)) {
            return new java.awt.Color(i , i , i , alpha);
        } 
        if ((r > 0) && (r < i))
            r = i;
        
        if ((g > 0) && (g < i))
            g = i;
        
        if ((b > 0) && (b < i))
            b = i;
        
        return new java.awt.Color(java.lang.Math.min(((int)(r / (java.awt.Color.FACTOR))), 255) , java.lang.Math.min(((int)(g / (java.awt.Color.FACTOR))), 255) , java.lang.Math.min(((int)(b / (java.awt.Color.FACTOR))), 255) , alpha);
    }

    public java.awt.Color darker() {
        return new java.awt.Color(java.lang.Math.max(((int)((getRed()) * (java.awt.Color.FACTOR))), 0) , java.lang.Math.max(((int)((getGreen()) * (java.awt.Color.FACTOR))), 0) , java.lang.Math.max(((int)((getBlue()) * (java.awt.Color.FACTOR))), 0) , getAlpha());
    }

    public int hashCode() {
        return value;
    }

    public boolean equals(java.lang.Object obj) {
        return (obj instanceof java.awt.Color) && ((((java.awt.Color)(obj)).getRGB()) == (java.awt.Color.this.getRGB()));
    }

    public java.lang.String toString() {
        return (((((((getClass().getName()) + "[r=") + (getRed())) + ",g=") + (getGreen())) + ",b=") + (getBlue())) + "]";
    }

    public static java.awt.Color decode(java.lang.String nm) throws java.lang.NumberFormatException {
        java.lang.Integer intval = java.lang.Integer.decode(nm);
        int i = intval.intValue();
        return new java.awt.Color(((i >> 16) & 255) , ((i >> 8) & 255) , (i & 255));
    }

    public static java.awt.Color getColor(java.lang.String nm) {
        return java.awt.Color.getColor(nm, null);
    }

    public static java.awt.Color getColor(java.lang.String nm, java.awt.Color v) {
        java.lang.Integer intval = java.lang.Integer.getInteger(nm);
        if (intval == null) {
            return v;
        } 
        int i = intval.intValue();
        return new java.awt.Color(((i >> 16) & 255) , ((i >> 8) & 255) , (i & 255));
    }

    public static java.awt.Color getColor(java.lang.String nm, int v) {
        java.lang.Integer intval = java.lang.Integer.getInteger(nm);
        int i = intval != null ? intval.intValue() : v;
        return new java.awt.Color(((i >> 16) & 255) , ((i >> 8) & 255) , ((i >> 0) & 255));
    }

    public static int HSBtoRGB(float hue, float saturation, float brightness) {
        int r = 0;
        int g = 0;
        int b = 0;
        if (saturation == 0) {
            r = g = b = ((int)((brightness * 255.0F) + 0.5F));
        } else {
            float h = (hue - ((float)(java.lang.Math.floor(hue)))) * 6.0F;
            float f = h - ((float)(java.lang.Math.floor(h)));
            float p = brightness * (1.0F - saturation);
            float q = brightness * (1.0F - (saturation * f));
            float t = brightness * (1.0F - (saturation * (1.0F - f)));
            switch (((int)(h))) {
                case 0 :
                    r = ((int)((brightness * 255.0F) + 0.5F));
                    g = ((int)((t * 255.0F) + 0.5F));
                    b = ((int)((p * 255.0F) + 0.5F));
                    break;
                case 1 :
                    r = ((int)((q * 255.0F) + 0.5F));
                    g = ((int)((brightness * 255.0F) + 0.5F));
                    b = ((int)((p * 255.0F) + 0.5F));
                    break;
                case 2 :
                    r = ((int)((p * 255.0F) + 0.5F));
                    g = ((int)((brightness * 255.0F) + 0.5F));
                    b = ((int)((t * 255.0F) + 0.5F));
                    break;
                case 3 :
                    r = ((int)((p * 255.0F) + 0.5F));
                    g = ((int)((q * 255.0F) + 0.5F));
                    b = ((int)((brightness * 255.0F) + 0.5F));
                    break;
                case 4 :
                    r = ((int)((t * 255.0F) + 0.5F));
                    g = ((int)((p * 255.0F) + 0.5F));
                    b = ((int)((brightness * 255.0F) + 0.5F));
                    break;
                case 5 :
                    r = ((int)((brightness * 255.0F) + 0.5F));
                    g = ((int)((p * 255.0F) + 0.5F));
                    b = ((int)((q * 255.0F) + 0.5F));
                    break;
            }
        }
        return ((-16777216 | (r << 16)) | (g << 8)) | (b << 0);
    }

    public static float[] RGBtoHSB(int r, int g, int b, float[] hsbvals) {
        float hue;
        float saturation;
        float brightness;
        if (hsbvals == null) {
            hsbvals = new float[3];
        } 
        int cmax = r > g ? r : g;
        if (b > cmax)
            cmax = b;
        
        int cmin = r < g ? r : g;
        if (b < cmin)
            cmin = b;
        
        brightness = ((float)(cmax)) / 255.0F;
        if (cmax != 0)
            saturation = ((float)((cmax - cmin))) / ((float)(cmax));
        else
            saturation = 0;
        
        if (saturation == 0)
            hue = 0;
        else {
            float redc = ((float)((cmax - r))) / ((float)((cmax - cmin)));
            float greenc = ((float)((cmax - g))) / ((float)((cmax - cmin)));
            float bluec = ((float)((cmax - b))) / ((float)((cmax - cmin)));
            if (r == cmax)
                hue = bluec - greenc;
            else if (g == cmax)
                hue = (2.0F + redc) - bluec;
            else
                hue = (4.0F + greenc) - redc;
            
            hue = hue / 6.0F;
            if (hue < 0)
                hue = hue + 1.0F;
            
        }
        hsbvals[0] = hue;
        hsbvals[1] = saturation;
        hsbvals[2] = brightness;
        return hsbvals;
    }

    public static java.awt.Color getHSBColor(float h, float s, float b) {
        return new java.awt.Color(java.awt.Color.HSBtoRGB(h, s, b));
    }

    public float[] getRGBComponents(float[] compArray) {
        float[] f;
        if (compArray == null) {
            f = new float[4];
        } else {
            f = compArray;
        }
        if ((frgbvalue) == null) {
            f[0] = ((float)(getRed())) / 255.0F;
            f[1] = ((float)(getGreen())) / 255.0F;
            f[2] = ((float)(getBlue())) / 255.0F;
            f[3] = ((float)(getAlpha())) / 255.0F;
        } else {
            f[0] = frgbvalue[0];
            f[1] = frgbvalue[1];
            f[2] = frgbvalue[2];
            f[3] = falpha;
        }
        return f;
    }

    public float[] getRGBColorComponents(float[] compArray) {
        float[] f;
        if (compArray == null) {
            f = new float[3];
        } else {
            f = compArray;
        }
        if ((frgbvalue) == null) {
            f[0] = ((float)(getRed())) / 255.0F;
            f[1] = ((float)(getGreen())) / 255.0F;
            f[2] = ((float)(getBlue())) / 255.0F;
        } else {
            f[0] = frgbvalue[0];
            f[1] = frgbvalue[1];
            f[2] = frgbvalue[2];
        }
        return f;
    }

    public float[] getComponents(float[] compArray) {
        if ((fvalue) == null)
            return getRGBComponents(compArray);
        
        float[] f;
        int n = fvalue.length;
        if (compArray == null) {
            f = new float[n + 1];
        } else {
            f = compArray;
        }
        for (int i = 0 ; i < n ; i++) {
            f[i] = fvalue[i];
        }
        f[n] = falpha;
        return f;
    }

    public float[] getColorComponents(float[] compArray) {
        if ((fvalue) == null)
            return getRGBColorComponents(compArray);
        
        float[] f;
        int n = fvalue.length;
        if (compArray == null) {
            f = new float[n];
        } else {
            f = compArray;
        }
        for (int i = 0 ; i < n ; i++) {
            f[i] = fvalue[i];
        }
        return f;
    }

    public float[] getComponents(java.awt.color.ColorSpace cspace, float[] compArray) {
        if ((cs) == null) {
            cs = java.awt.color.ColorSpace.getInstance(java.awt.color.ColorSpace.CS_sRGB);
        } 
        float[] f;
        if ((fvalue) == null) {
            f = new float[3];
            f[0] = ((float)(getRed())) / 255.0F;
            f[1] = ((float)(getGreen())) / 255.0F;
            f[2] = ((float)(getBlue())) / 255.0F;
        } else {
            f = fvalue;
        }
        float[] tmp = cs.toCIEXYZ(f);
        float[] tmpout = cspace.fromCIEXYZ(tmp);
        if (compArray == null) {
            compArray = new float[(tmpout.length) + 1];
        } 
        for (int i = 0 ; i < (tmpout.length) ; i++) {
            compArray[i] = tmpout[i];
        }
        if ((fvalue) == null) {
            compArray[tmpout.length] = ((float)(getAlpha())) / 255.0F;
        } else {
            compArray[tmpout.length] = falpha;
        }
        return compArray;
    }

    public float[] getColorComponents(java.awt.color.ColorSpace cspace, float[] compArray) {
        if ((cs) == null) {
            cs = java.awt.color.ColorSpace.getInstance(java.awt.color.ColorSpace.CS_sRGB);
        } 
        float[] f;
        if ((fvalue) == null) {
            f = new float[3];
            f[0] = ((float)(getRed())) / 255.0F;
            f[1] = ((float)(getGreen())) / 255.0F;
            f[2] = ((float)(getBlue())) / 255.0F;
        } else {
            f = fvalue;
        }
        float[] tmp = cs.toCIEXYZ(f);
        float[] tmpout = cspace.fromCIEXYZ(tmp);
        if (compArray == null) {
            return tmpout;
        } 
        for (int i = 0 ; i < (tmpout.length) ; i++) {
            compArray[i] = tmpout[i];
        }
        return compArray;
    }

    public java.awt.color.ColorSpace getColorSpace() {
        if ((cs) == null) {
            cs = java.awt.color.ColorSpace.getInstance(java.awt.color.ColorSpace.CS_sRGB);
        } 
        return cs;
    }

    public synchronized java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle r, java.awt.geom.Rectangle2D r2d, java.awt.geom.AffineTransform xform, java.awt.RenderingHints hints) {
        return new java.awt.ColorPaintContext(getRGB() , cm);
    }

    public int getTransparency() {
        int alpha = getAlpha();
        if (alpha == 255) {
            return java.awt.Transparency.OPAQUE;
        } else if (alpha == 0) {
            return java.awt.Transparency.BITMASK;
        } else {
            return java.awt.Transparency.TRANSLUCENT;
        }
    }
}


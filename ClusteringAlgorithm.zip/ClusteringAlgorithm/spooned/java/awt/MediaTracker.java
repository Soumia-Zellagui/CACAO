package java.awt;


public class MediaTracker implements java.io.Serializable {
    java.awt.Component target;

    java.awt.MediaEntry head;

    private static final long serialVersionUID = -483174189758638095L;

    public MediaTracker(java.awt.Component comp) {
        target = comp;
    }

    public void addImage(java.awt.Image image, int id) {
        addImage(image, id, (-1), (-1));
    }

    public synchronized void addImage(java.awt.Image image, int id, int w, int h) {
        addImageImpl(image, id, w, h);
        java.awt.Image rvImage = java.awt.MediaTracker.getResolutionVariant(image);
        if (rvImage != null) {
            addImageImpl(rvImage, id, (w == (-1) ? -1 : 2 * w), (h == (-1) ? -1 : 2 * h));
        } 
    }

    private void addImageImpl(java.awt.Image image, int id, int w, int h) {
        head = java.awt.MediaEntry.insert(head, new java.awt.ImageMediaEntry(java.awt.MediaTracker.this , image , id , w , h));
    }

    public static final int LOADING = 1;

    public static final int ABORTED = 2;

    public static final int ERRORED = 4;

    public static final int COMPLETE = 8;

    static final int DONE = ((java.awt.MediaTracker.ABORTED) | (java.awt.MediaTracker.ERRORED)) | (java.awt.MediaTracker.COMPLETE);

    public boolean checkAll() {
        return checkAll(false, true);
    }

    public boolean checkAll(boolean load) {
        return checkAll(load, true);
    }

    private synchronized boolean checkAll(boolean load, boolean verify) {
        java.awt.MediaEntry cur = head;
        boolean done = true;
        while (cur != null) {
            if (((cur.getStatus(load, verify)) & (java.awt.MediaTracker.DONE)) == 0) {
                done = false;
            } 
            cur = cur.next;
        }
        return done;
    }

    public synchronized boolean isErrorAny() {
        java.awt.MediaEntry cur = head;
        while (cur != null) {
            if (((cur.getStatus(false, true)) & (java.awt.MediaTracker.ERRORED)) != 0) {
                return true;
            } 
            cur = cur.next;
        }
        return false;
    }

    public synchronized java.lang.Object[] getErrorsAny() {
        java.awt.MediaEntry cur = head;
        int numerrors = 0;
        while (cur != null) {
            if (((cur.getStatus(false, true)) & (java.awt.MediaTracker.ERRORED)) != 0) {
                numerrors++;
            } 
            cur = cur.next;
        }
        if (numerrors == 0) {
            return null;
        } 
        java.lang.Object[] errors = new java.lang.Object[numerrors];
        cur = head;
        numerrors = 0;
        while (cur != null) {
            if (((cur.getStatus(false, false)) & (java.awt.MediaTracker.ERRORED)) != 0) {
                errors[(numerrors++)] = cur.getMedia();
            } 
            cur = cur.next;
        }
        return errors;
    }

    public void waitForAll() throws java.lang.InterruptedException {
        waitForAll(0);
    }

    public synchronized boolean waitForAll(long ms) throws java.lang.InterruptedException {
        long end = (java.lang.System.currentTimeMillis()) + ms;
        boolean first = true;
        while (true) {
            int status = statusAll(first, first);
            if ((status & (java.awt.MediaTracker.LOADING)) == 0) {
                return status == (java.awt.MediaTracker.COMPLETE);
            } 
            first = false;
            long timeout;
            if (ms == 0) {
                timeout = 0;
            } else {
                timeout = end - (java.lang.System.currentTimeMillis());
                if (timeout <= 0) {
                    return false;
                } 
            }
            wait(timeout);
        }
    }

    public int statusAll(boolean load) {
        return statusAll(load, true);
    }

    private synchronized int statusAll(boolean load, boolean verify) {
        java.awt.MediaEntry cur = head;
        int status = 0;
        while (cur != null) {
            status = status | (cur.getStatus(load, verify));
            cur = cur.next;
        }
        return status;
    }

    public boolean checkID(int id) {
        return checkID(id, false, true);
    }

    public boolean checkID(int id, boolean load) {
        return checkID(id, load, true);
    }

    private synchronized boolean checkID(int id, boolean load, boolean verify) {
        java.awt.MediaEntry cur = head;
        boolean done = true;
        while (cur != null) {
            if (((cur.getID()) == id) && (((cur.getStatus(load, verify)) & (java.awt.MediaTracker.DONE)) == 0)) {
                done = false;
            } 
            cur = cur.next;
        }
        return done;
    }

    public synchronized boolean isErrorID(int id) {
        java.awt.MediaEntry cur = head;
        while (cur != null) {
            if (((cur.getID()) == id) && (((cur.getStatus(false, true)) & (java.awt.MediaTracker.ERRORED)) != 0)) {
                return true;
            } 
            cur = cur.next;
        }
        return false;
    }

    public synchronized java.lang.Object[] getErrorsID(int id) {
        java.awt.MediaEntry cur = head;
        int numerrors = 0;
        while (cur != null) {
            if (((cur.getID()) == id) && (((cur.getStatus(false, true)) & (java.awt.MediaTracker.ERRORED)) != 0)) {
                numerrors++;
            } 
            cur = cur.next;
        }
        if (numerrors == 0) {
            return null;
        } 
        java.lang.Object[] errors = new java.lang.Object[numerrors];
        cur = head;
        numerrors = 0;
        while (cur != null) {
            if (((cur.getID()) == id) && (((cur.getStatus(false, false)) & (java.awt.MediaTracker.ERRORED)) != 0)) {
                errors[(numerrors++)] = cur.getMedia();
            } 
            cur = cur.next;
        }
        return errors;
    }

    public void waitForID(int id) throws java.lang.InterruptedException {
        waitForID(id, 0);
    }

    public synchronized boolean waitForID(int id, long ms) throws java.lang.InterruptedException {
        long end = (java.lang.System.currentTimeMillis()) + ms;
        boolean first = true;
        while (true) {
            int status = statusID(id, first, first);
            if ((status & (java.awt.MediaTracker.LOADING)) == 0) {
                return status == (java.awt.MediaTracker.COMPLETE);
            } 
            first = false;
            long timeout;
            if (ms == 0) {
                timeout = 0;
            } else {
                timeout = end - (java.lang.System.currentTimeMillis());
                if (timeout <= 0) {
                    return false;
                } 
            }
            wait(timeout);
        }
    }

    public int statusID(int id, boolean load) {
        return statusID(id, load, true);
    }

    private synchronized int statusID(int id, boolean load, boolean verify) {
        java.awt.MediaEntry cur = head;
        int status = 0;
        while (cur != null) {
            if ((cur.getID()) == id) {
                status = status | (cur.getStatus(load, verify));
            } 
            cur = cur.next;
        }
        return status;
    }

    public synchronized void removeImage(java.awt.Image image) {
        removeImageImpl(image);
        java.awt.Image rvImage = java.awt.MediaTracker.getResolutionVariant(image);
        if (rvImage != null) {
            removeImageImpl(rvImage);
        } 
        notifyAll();
    }

    private void removeImageImpl(java.awt.Image image) {
        java.awt.MediaEntry cur = head;
        java.awt.MediaEntry prev = null;
        while (cur != null) {
            java.awt.MediaEntry next = cur.next;
            if ((cur.getMedia()) == image) {
                if (prev == null) {
                    head = next;
                } else {
                    prev.next = next;
                }
                cur.cancel();
            } else {
                prev = cur;
            }
            cur = next;
        }
    }

    public synchronized void removeImage(java.awt.Image image, int id) {
        removeImageImpl(image, id);
        java.awt.Image rvImage = java.awt.MediaTracker.getResolutionVariant(image);
        if (rvImage != null) {
            removeImageImpl(rvImage, id);
        } 
        notifyAll();
    }

    private void removeImageImpl(java.awt.Image image, int id) {
        java.awt.MediaEntry cur = head;
        java.awt.MediaEntry prev = null;
        while (cur != null) {
            java.awt.MediaEntry next = cur.next;
            if (((cur.getID()) == id) && ((cur.getMedia()) == image)) {
                if (prev == null) {
                    head = next;
                } else {
                    prev.next = next;
                }
                cur.cancel();
            } else {
                prev = cur;
            }
            cur = next;
        }
    }

    public synchronized void removeImage(java.awt.Image image, int id, int width, int height) {
        removeImageImpl(image, id, width, height);
        java.awt.Image rvImage = java.awt.MediaTracker.getResolutionVariant(image);
        if (rvImage != null) {
            removeImageImpl(rvImage, id, (width == (-1) ? -1 : 2 * width), (height == (-1) ? -1 : 2 * height));
        } 
        notifyAll();
    }

    private void removeImageImpl(java.awt.Image image, int id, int width, int height) {
        java.awt.MediaEntry cur = head;
        java.awt.MediaEntry prev = null;
        while (cur != null) {
            java.awt.MediaEntry next = cur.next;
            if ((((cur.getID()) == id) && (cur instanceof java.awt.ImageMediaEntry)) && (((java.awt.ImageMediaEntry)(cur)).matches(image, width, height))) {
                if (prev == null) {
                    head = next;
                } else {
                    prev.next = next;
                }
                cur.cancel();
            } else {
                prev = cur;
            }
            cur = next;
        }
    }

    synchronized void setDone() {
        notifyAll();
    }

    private static java.awt.Image getResolutionVariant(java.awt.Image image) {
        if (image instanceof sun.awt.image.MultiResolutionToolkitImage) {
            return ((sun.awt.image.MultiResolutionToolkitImage)(image)).getResolutionVariant();
        } 
        return null;
    }
}


package java.awt;


public abstract class FontMetrics implements java.io.Serializable {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.FontMetrics.initIDs();
        } 
    }

    private static final java.awt.font.FontRenderContext DEFAULT_FRC = new java.awt.font.FontRenderContext(null , false , false);

    protected java.awt.Font font;

    private static final long serialVersionUID = 1681126225205050147L;

    protected FontMetrics(java.awt.Font font) {
        java.awt.FontMetrics.this.font = font;
    }

    public java.awt.Font getFont() {
        return font;
    }

    public java.awt.font.FontRenderContext getFontRenderContext() {
        return java.awt.FontMetrics.DEFAULT_FRC;
    }

    public int getLeading() {
        return 0;
    }

    public int getAscent() {
        return font.getSize();
    }

    public int getDescent() {
        return 0;
    }

    public int getHeight() {
        return ((getLeading()) + (getAscent())) + (getDescent());
    }

    public int getMaxAscent() {
        return getAscent();
    }

    public int getMaxDescent() {
        return getDescent();
    }

    @java.lang.Deprecated
    public int getMaxDecent() {
        return getMaxDescent();
    }

    public int getMaxAdvance() {
        return -1;
    }

    public int charWidth(int codePoint) {
        if (!(java.lang.Character.isValidCodePoint(codePoint))) {
            codePoint = 65535;
        } 
        if (codePoint < 256) {
            return getWidths()[codePoint];
        } else {
            char[] buffer = new char[2];
            int len = java.lang.Character.toChars(codePoint, buffer, 0);
            return charsWidth(buffer, 0, len);
        }
    }

    public int charWidth(char ch) {
        if (ch < 256) {
            return getWidths()[ch];
        } 
        char[] data = new char[]{ ch };
        return charsWidth(data, 0, 1);
    }

    public int stringWidth(java.lang.String str) {
        int len = str.length();
        char[] data = new char[len];
        str.getChars(0, len, data, 0);
        return charsWidth(data, 0, len);
    }

    public int charsWidth(char[] data, int off, int len) {
        return stringWidth(new java.lang.String(data , off , len));
    }

    public int bytesWidth(byte[] data, int off, int len) {
        return stringWidth(new java.lang.String(data , 0 , off , len));
    }

    public int[] getWidths() {
        int[] widths = new int[256];
        for (char ch = 0 ; ch < 256 ; ch++) {
            widths[ch] = charWidth(ch);
        }
        return widths;
    }

    public boolean hasUniformLineMetrics() {
        return font.hasUniformLineMetrics();
    }

    public java.awt.font.LineMetrics getLineMetrics(java.lang.String str, java.awt.Graphics context) {
        return font.getLineMetrics(str, myFRC(context));
    }

    public java.awt.font.LineMetrics getLineMetrics(java.lang.String str, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getLineMetrics(str, beginIndex, limit, myFRC(context));
    }

    public java.awt.font.LineMetrics getLineMetrics(char[] chars, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getLineMetrics(chars, beginIndex, limit, myFRC(context));
    }

    public java.awt.font.LineMetrics getLineMetrics(java.text.CharacterIterator ci, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getLineMetrics(ci, beginIndex, limit, myFRC(context));
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.lang.String str, java.awt.Graphics context) {
        return font.getStringBounds(str, myFRC(context));
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.lang.String str, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getStringBounds(str, beginIndex, limit, myFRC(context));
    }

    public java.awt.geom.Rectangle2D getStringBounds(char[] chars, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getStringBounds(chars, beginIndex, limit, myFRC(context));
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.text.CharacterIterator ci, int beginIndex, int limit, java.awt.Graphics context) {
        return font.getStringBounds(ci, beginIndex, limit, myFRC(context));
    }

    public java.awt.geom.Rectangle2D getMaxCharBounds(java.awt.Graphics context) {
        return font.getMaxCharBounds(myFRC(context));
    }

    private java.awt.font.FontRenderContext myFRC(java.awt.Graphics context) {
        if (context instanceof java.awt.Graphics2D) {
            return ((java.awt.Graphics2D)(context)).getFontRenderContext();
        } 
        return java.awt.FontMetrics.DEFAULT_FRC;
    }

    public java.lang.String toString() {
        return (((((((((getClass().getName()) + "[font=") + (getFont())) + "ascent=") + (getAscent())) + ", descent=") + (getDescent())) + ", height=") + (getHeight())) + "]";
    }

    private static native void initIDs();
}


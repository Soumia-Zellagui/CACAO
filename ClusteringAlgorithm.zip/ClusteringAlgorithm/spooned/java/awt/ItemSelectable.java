package java.awt;


public interface ItemSelectable {
    public java.lang.Object[] getSelectedObjects();

    public void addItemListener(java.awt.event.ItemListener l);

    public void removeItemListener(java.awt.event.ItemListener l);
}


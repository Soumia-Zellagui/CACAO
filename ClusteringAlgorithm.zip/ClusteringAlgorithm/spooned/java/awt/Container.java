package java.awt;


public class Container extends java.awt.Component {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.Container");

    private static final sun.util.logging.PlatformLogger eventLog = sun.util.logging.PlatformLogger.getLogger("java.awt.event.Container");

    private static final java.awt.Component[] EMPTY_ARRAY = new java.awt.Component[0];

    private java.util.List<java.awt.Component> component = new java.util.ArrayList<>();

    java.awt.LayoutManager layoutMgr;

    private java.awt.LightweightDispatcher dispatcher;

    private transient java.awt.FocusTraversalPolicy focusTraversalPolicy;

    private boolean focusCycleRoot = false;

    private boolean focusTraversalPolicyProvider;

    private transient java.util.Set<java.lang.Thread> printingThreads;

    private transient boolean printing = false;

    transient java.awt.event.ContainerListener containerListener;

    transient int listeningChildren;

    transient int listeningBoundsChildren;

    transient int descendantsCount;

    transient java.awt.Color preserveBackgroundColor = null;

    private static final long serialVersionUID = 4613797578919906343L;

    static final boolean INCLUDE_SELF = true;

    static final boolean SEARCH_HEAVYWEIGHTS = true;

    private transient int numOfHWComponents = 0;

    private transient int numOfLWComponents = 0;

    private static final sun.util.logging.PlatformLogger mixingLog = sun.util.logging.PlatformLogger.getLogger("java.awt.mixing.Container");

    private static final java.io.ObjectStreamField[] serialPersistentFields = new java.io.ObjectStreamField[]{ new java.io.ObjectStreamField("ncomponents" , java.lang.Integer.TYPE) , new java.io.ObjectStreamField("component" , java.awt.Component[].class) , new java.io.ObjectStreamField("layoutMgr" , java.awt.LayoutManager.class) , new java.io.ObjectStreamField("dispatcher" , java.awt.LightweightDispatcher.class) , new java.io.ObjectStreamField("maxSize" , java.awt.Dimension.class) , new java.io.ObjectStreamField("focusCycleRoot" , java.lang.Boolean.TYPE) , new java.io.ObjectStreamField("containerSerializedDataVersion" , java.lang.Integer.TYPE) , new java.io.ObjectStreamField("focusTraversalPolicyProvider" , java.lang.Boolean.TYPE) };

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Container.initIDs();
        } 
        sun.awt.AWTAccessor.setContainerAccessor(new sun.awt.AWTAccessor.ContainerAccessor() {
            @java.lang.Override
            public void validateUnconditionally(java.awt.Container cont) {
                cont.validateUnconditionally();
            }

            @java.lang.Override
            public java.awt.Component findComponentAt(java.awt.Container cont, int x, int y, boolean ignoreEnabled) {
                return cont.findComponentAt(x, y, ignoreEnabled);
            }
        });
    }

    private static native void initIDs();

    public Container() {
    }

    @java.lang.SuppressWarnings(value = { "unchecked" , "rawtypes" })
    void initializeFocusTraversalKeys() {
        focusTraversalKeys = new java.util.Set[4];
    }

    public int getComponentCount() {
        return countComponents();
    }

    @java.lang.Deprecated
    public int countComponents() {
        return component.size();
    }

    public java.awt.Component getComponent(int n) {
        try {
            return component.get(n);
        } catch (java.lang.IndexOutOfBoundsException z) {
            throw new java.lang.ArrayIndexOutOfBoundsException(("No such child: " + n));
        }
    }

    public java.awt.Component[] getComponents() {
        return getComponents_NoClientCode();
    }

    final java.awt.Component[] getComponents_NoClientCode() {
        return component.toArray(java.awt.Container.EMPTY_ARRAY);
    }

    java.awt.Component[] getComponentsSync() {
        synchronized(getTreeLock()) {
            return getComponents();
        }
    }

    public java.awt.Insets getInsets() {
        return insets();
    }

    @java.lang.Deprecated
    public java.awt.Insets insets() {
        java.awt.peer.ComponentPeer peer = java.awt.Container.this.peer;
        if (peer instanceof java.awt.peer.ContainerPeer) {
            java.awt.peer.ContainerPeer cpeer = ((java.awt.peer.ContainerPeer)(peer));
            return ((java.awt.Insets)(cpeer.getInsets().clone()));
        } 
        return new java.awt.Insets(0 , 0 , 0 , 0);
    }

    public java.awt.Component add(java.awt.Component comp) {
        addImpl(comp, null, (-1));
        return comp;
    }

    public java.awt.Component add(java.lang.String name, java.awt.Component comp) {
        addImpl(comp, name, (-1));
        return comp;
    }

    public java.awt.Component add(java.awt.Component comp, int index) {
        addImpl(comp, null, index);
        return comp;
    }

    private void checkAddToSelf(java.awt.Component comp) {
        if (comp instanceof java.awt.Container) {
            for (java.awt.Container cn = java.awt.Container.this ; cn != null ; cn = cn.parent) {
                if (cn == comp) {
                    throw new java.lang.IllegalArgumentException("adding container's parent to itself");
                } 
            }
        } 
    }

    private void checkNotAWindow(java.awt.Component comp) {
        if (comp instanceof java.awt.Window) {
            throw new java.lang.IllegalArgumentException("adding a window to a container");
        } 
    }

    private void checkAdding(java.awt.Component comp, int index) {
        checkTreeLock();
        java.awt.GraphicsConfiguration thisGC = getGraphicsConfiguration();
        if ((index > (component.size())) || (index < 0)) {
            throw new java.lang.IllegalArgumentException("illegal component position");
        } 
        if ((comp.parent) == (java.awt.Container.this)) {
            if (index == (component.size())) {
                throw new java.lang.IllegalArgumentException(((("illegal component position " + index) + " should be less then ") + (component.size())));
            } 
        } 
        checkAddToSelf(comp);
        checkNotAWindow(comp);
        java.awt.Window thisTopLevel = getContainingWindow();
        java.awt.Window compTopLevel = comp.getContainingWindow();
        if (thisTopLevel != compTopLevel) {
            throw new java.lang.IllegalArgumentException("component and container should be in the same top-level window");
        } 
        if (thisGC != null) {
            comp.checkGD(thisGC.getDevice().getIDstring());
        } 
    }

    private boolean removeDelicately(java.awt.Component comp, java.awt.Container newParent, int newIndex) {
        checkTreeLock();
        int index = getComponentZOrder(comp);
        boolean needRemoveNotify = java.awt.Container.isRemoveNotifyNeeded(comp, java.awt.Container.this, newParent);
        if (needRemoveNotify) {
            comp.removeNotify();
        } 
        if (newParent != (java.awt.Container.this)) {
            if ((layoutMgr) != null) {
                layoutMgr.removeLayoutComponent(comp);
            } 
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, (-(comp.numListening(java.awt.AWTEvent.HIERARCHY_EVENT_MASK))));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, (-(comp.numListening(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK))));
            adjustDescendants((-(comp.countHierarchyMembers())));
            comp.parent = null;
            if (needRemoveNotify) {
                comp.setGraphicsConfiguration(null);
            } 
            component.remove(index);
            invalidateIfValid();
        } else {
            component.remove(index);
            component.add(newIndex, comp);
        }
        if ((comp.parent) == null) {
            if ((((containerListener) != null) || (((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.CONTAINER_EVENT_MASK))) {
                java.awt.event.ContainerEvent e = new java.awt.event.ContainerEvent(java.awt.Container.this , java.awt.event.ContainerEvent.COMPONENT_REMOVED , comp);
                dispatchEvent(e);
            } 
            comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.PARENT_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            if ((((peer) != null) && ((layoutMgr) == null)) && (isVisible())) {
                updateCursorImmediately();
            } 
        } 
        return needRemoveNotify;
    }

    boolean canContainFocusOwner(java.awt.Component focusOwnerCandidate) {
        if (!((((isEnabled()) && (isDisplayable())) && (isVisible())) && (isFocusable()))) {
            return false;
        } 
        if (isFocusCycleRoot()) {
            java.awt.FocusTraversalPolicy policy = getFocusTraversalPolicy();
            if (policy instanceof java.awt.DefaultFocusTraversalPolicy) {
                if (!(((java.awt.DefaultFocusTraversalPolicy)(policy)).accept(focusOwnerCandidate))) {
                    return false;
                } 
            } 
        } 
        synchronized(getTreeLock()) {
            if ((parent) != null) {
                return parent.canContainFocusOwner(focusOwnerCandidate);
            } 
        }
        return true;
    }

    final boolean hasHeavyweightDescendants() {
        checkTreeLock();
        return (numOfHWComponents) > 0;
    }

    final boolean hasLightweightDescendants() {
        checkTreeLock();
        return (numOfLWComponents) > 0;
    }

    java.awt.Container getHeavyweightContainer() {
        checkTreeLock();
        if (((peer) != null) && (!((peer) instanceof java.awt.peer.LightweightPeer))) {
            return java.awt.Container.this;
        } else {
            return getNativeContainer();
        }
    }

    private static boolean isRemoveNotifyNeeded(java.awt.Component comp, java.awt.Container oldContainer, java.awt.Container newContainer) {
        if (oldContainer == null) {
            return false;
        } 
        if ((comp.peer) == null) {
            return false;
        } 
        if ((newContainer.peer) == null) {
            return true;
        } 
        if (comp.isLightweight()) {
            boolean isContainer = comp instanceof java.awt.Container;
            if ((!isContainer) || (isContainer && (!(((java.awt.Container)(comp)).hasHeavyweightDescendants())))) {
                return false;
            } 
        } 
        java.awt.Container newNativeContainer = oldContainer.getHeavyweightContainer();
        java.awt.Container oldNativeContainer = newContainer.getHeavyweightContainer();
        if (newNativeContainer != oldNativeContainer) {
            return !(comp.peer.isReparentSupported());
        } else {
            return false;
        }
    }

    public void setComponentZOrder(java.awt.Component comp, int index) {
        synchronized(getTreeLock()) {
            java.awt.Container curParent = comp.parent;
            int oldZindex = getComponentZOrder(comp);
            if ((curParent == (java.awt.Container.this)) && (index == oldZindex)) {
                return ;
            } 
            checkAdding(comp, index);
            boolean peerRecreated = curParent != null ? curParent.removeDelicately(comp, java.awt.Container.this, index) : false;
            addDelicately(comp, curParent, index);
            if ((!peerRecreated) && (oldZindex != (-1))) {
                comp.mixOnZOrderChanging(oldZindex, index);
            } 
        }
    }

    private void reparentTraverse(java.awt.peer.ContainerPeer parentPeer, java.awt.Container child) {
        checkTreeLock();
        for (int i = 0 ; i < (child.getComponentCount()) ; i++) {
            java.awt.Component comp = child.getComponent(i);
            if (comp.isLightweight()) {
                if (comp instanceof java.awt.Container) {
                    reparentTraverse(parentPeer, ((java.awt.Container)(comp)));
                } 
            } else {
                comp.getPeer().reparent(parentPeer);
            }
        }
    }

    private void reparentChild(java.awt.Component comp) {
        checkTreeLock();
        if (comp == null) {
            return ;
        } 
        if (comp.isLightweight()) {
            if (comp instanceof java.awt.Container) {
                reparentTraverse(((java.awt.peer.ContainerPeer)(getPeer())), ((java.awt.Container)(comp)));
            } 
        } else {
            comp.getPeer().reparent(((java.awt.peer.ContainerPeer)(getPeer())));
        }
    }

    private void addDelicately(java.awt.Component comp, java.awt.Container curParent, int index) {
        checkTreeLock();
        if (curParent != (java.awt.Container.this)) {
            if (index == (-1)) {
                component.add(comp);
            } else {
                component.add(index, comp);
            }
            comp.parent = java.awt.Container.this;
            comp.setGraphicsConfiguration(getGraphicsConfiguration());
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK));
            adjustDescendants(comp.countHierarchyMembers());
        } else {
            if (index < (component.size())) {
                component.set(index, comp);
            } 
        }
        invalidateIfValid();
        if ((peer) != null) {
            if ((comp.peer) == null) {
                comp.addNotify();
            } else {
                java.awt.Container newNativeContainer = getHeavyweightContainer();
                java.awt.Container oldNativeContainer = curParent.getHeavyweightContainer();
                if (oldNativeContainer != newNativeContainer) {
                    newNativeContainer.reparentChild(comp);
                } 
                comp.updateZOrder();
                if ((!(comp.isLightweight())) && (isLightweight())) {
                    comp.relocateComponent();
                } 
            }
        } 
        if (curParent != (java.awt.Container.this)) {
            if ((layoutMgr) != null) {
                if ((layoutMgr) instanceof java.awt.LayoutManager2) {
                    ((java.awt.LayoutManager2)(layoutMgr)).addLayoutComponent(comp, null);
                } else {
                    layoutMgr.addLayoutComponent(null, comp);
                }
            } 
            if ((((containerListener) != null) || (((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.CONTAINER_EVENT_MASK))) {
                java.awt.event.ContainerEvent e = new java.awt.event.ContainerEvent(java.awt.Container.this , java.awt.event.ContainerEvent.COMPONENT_ADDED , comp);
                dispatchEvent(e);
            } 
            comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.PARENT_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            if ((comp.isFocusOwner()) && (!(comp.canBeFocusOwnerRecursively()))) {
                comp.transferFocus();
            } else if (comp instanceof java.awt.Container) {
                java.awt.Component focusOwner = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                if (((focusOwner != null) && (isParentOf(focusOwner))) && (!(focusOwner.canBeFocusOwnerRecursively()))) {
                    focusOwner.transferFocus();
                } 
            } 
        } else {
            comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
        }
        if ((((peer) != null) && ((layoutMgr) == null)) && (isVisible())) {
            updateCursorImmediately();
        } 
    }

    public int getComponentZOrder(java.awt.Component comp) {
        if (comp == null) {
            return -1;
        } 
        synchronized(getTreeLock()) {
            if ((comp.parent) != (java.awt.Container.this)) {
                return -1;
            } 
            return component.indexOf(comp);
        }
    }

    public void add(java.awt.Component comp, java.lang.Object constraints) {
        addImpl(comp, constraints, (-1));
    }

    public void add(java.awt.Component comp, java.lang.Object constraints, int index) {
        addImpl(comp, constraints, index);
    }

    protected void addImpl(java.awt.Component comp, java.lang.Object constraints, int index) {
        synchronized(getTreeLock()) {
            java.awt.GraphicsConfiguration thisGC = java.awt.Container.this.getGraphicsConfiguration();
            if ((index > (component.size())) || ((index < 0) && (index != (-1)))) {
                throw new java.lang.IllegalArgumentException("illegal component position");
            } 
            checkAddToSelf(comp);
            checkNotAWindow(comp);
            if (thisGC != null) {
                comp.checkGD(thisGC.getDevice().getIDstring());
            } 
            if ((comp.parent) != null) {
                comp.parent.remove(comp);
                if (index > (component.size())) {
                    throw new java.lang.IllegalArgumentException("illegal component position");
                } 
            } 
            if (index == (-1)) {
                component.add(comp);
            } else {
                component.add(index, comp);
            }
            comp.parent = java.awt.Container.this;
            comp.setGraphicsConfiguration(thisGC);
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK));
            adjustDescendants(comp.countHierarchyMembers());
            invalidateIfValid();
            if ((peer) != null) {
                comp.addNotify();
            } 
            if ((layoutMgr) != null) {
                if ((layoutMgr) instanceof java.awt.LayoutManager2) {
                    ((java.awt.LayoutManager2)(layoutMgr)).addLayoutComponent(comp, constraints);
                } else if (constraints instanceof java.lang.String) {
                    layoutMgr.addLayoutComponent(((java.lang.String)(constraints)), comp);
                } 
            } 
            if ((((containerListener) != null) || (((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.CONTAINER_EVENT_MASK))) {
                java.awt.event.ContainerEvent e = new java.awt.event.ContainerEvent(java.awt.Container.this , java.awt.event.ContainerEvent.COMPONENT_ADDED , comp);
                dispatchEvent(e);
            } 
            comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.PARENT_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            if ((((peer) != null) && ((layoutMgr) == null)) && (isVisible())) {
                updateCursorImmediately();
            } 
        }
    }

    @java.lang.Override
    boolean updateGraphicsData(java.awt.GraphicsConfiguration gc) {
        checkTreeLock();
        boolean ret = super.updateGraphicsData(gc);
        for (java.awt.Component comp : component) {
            if (comp != null) {
                ret |= comp.updateGraphicsData(gc);
            } 
        }
        return ret;
    }

    void checkGD(java.lang.String stringID) {
        for (java.awt.Component comp : component) {
            if (comp != null) {
                comp.checkGD(stringID);
            } 
        }
    }

    public void remove(int index) {
        synchronized(getTreeLock()) {
            if ((index < 0) || (index >= (component.size()))) {
                throw new java.lang.ArrayIndexOutOfBoundsException(index);
            } 
            java.awt.Component comp = component.get(index);
            if ((peer) != null) {
                comp.removeNotify();
            } 
            if ((layoutMgr) != null) {
                layoutMgr.removeLayoutComponent(comp);
            } 
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, (-(comp.numListening(java.awt.AWTEvent.HIERARCHY_EVENT_MASK))));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, (-(comp.numListening(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK))));
            adjustDescendants((-(comp.countHierarchyMembers())));
            comp.parent = null;
            component.remove(index);
            comp.setGraphicsConfiguration(null);
            invalidateIfValid();
            if ((((containerListener) != null) || (((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.CONTAINER_EVENT_MASK))) {
                java.awt.event.ContainerEvent e = new java.awt.event.ContainerEvent(java.awt.Container.this , java.awt.event.ContainerEvent.COMPONENT_REMOVED , comp);
                dispatchEvent(e);
            } 
            comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.PARENT_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            if ((((peer) != null) && ((layoutMgr) == null)) && (isVisible())) {
                updateCursorImmediately();
            } 
        }
    }

    public void remove(java.awt.Component comp) {
        synchronized(getTreeLock()) {
            if ((comp.parent) == (java.awt.Container.this)) {
                int index = component.indexOf(comp);
                if (index >= 0) {
                    remove(index);
                } 
            } 
        }
    }

    public void removeAll() {
        synchronized(getTreeLock()) {
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, (-(listeningChildren)));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, (-(listeningBoundsChildren)));
            adjustDescendants((-(descendantsCount)));
            while (!(component.isEmpty())) {
                java.awt.Component comp = component.remove(((component.size()) - 1));
                if ((peer) != null) {
                    comp.removeNotify();
                } 
                if ((layoutMgr) != null) {
                    layoutMgr.removeLayoutComponent(comp);
                } 
                comp.parent = null;
                comp.setGraphicsConfiguration(null);
                if ((((containerListener) != null) || (((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.CONTAINER_EVENT_MASK))) {
                    java.awt.event.ContainerEvent e = new java.awt.event.ContainerEvent(java.awt.Container.this , java.awt.event.ContainerEvent.COMPONENT_REMOVED , comp);
                    dispatchEvent(e);
                } 
                comp.createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, comp, java.awt.Container.this, java.awt.event.HierarchyEvent.PARENT_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            }
            if ((((peer) != null) && ((layoutMgr) == null)) && (isVisible())) {
                updateCursorImmediately();
            } 
            invalidateIfValid();
        }
    }

    int numListening(long mask) {
        int superListening = super.numListening(mask);
        if (mask == (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) {
            if (java.awt.Container.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                int sum = 0;
                for (java.awt.Component comp : component) {
                    sum += comp.numListening(mask);
                }
                if ((listeningChildren) != sum) {
                    java.awt.Container.eventLog.fine("Assertion (listeningChildren == sum) failed");
                } 
            } 
            return (listeningChildren) + superListening;
        } else if (mask == (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) {
            if (java.awt.Container.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                int sum = 0;
                for (java.awt.Component comp : component) {
                    sum += comp.numListening(mask);
                }
                if ((listeningBoundsChildren) != sum) {
                    java.awt.Container.eventLog.fine("Assertion (listeningBoundsChildren == sum) failed");
                } 
            } 
            return (listeningBoundsChildren) + superListening;
        } else {
            if (java.awt.Container.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.eventLog.fine("This code must never be reached");
            } 
            return superListening;
        }
    }

    void adjustListeningChildren(long mask, int num) {
        if (java.awt.Container.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            boolean toAssert = ((mask == (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) || (mask == (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK))) || (mask == ((java.awt.AWTEvent.HIERARCHY_EVENT_MASK) | (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)));
            if (!toAssert) {
                java.awt.Container.eventLog.fine("Assertion failed");
            } 
        } 
        if (num == 0)
            return ;
        
        if ((mask & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0) {
            listeningChildren += num;
        } 
        if ((mask & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0) {
            listeningBoundsChildren += num;
        } 
        adjustListeningChildrenOnParent(mask, num);
    }

    void adjustDescendants(int num) {
        if (num == 0)
            return ;
        
        descendantsCount += num;
        adjustDecendantsOnParent(num);
    }

    void adjustDecendantsOnParent(int num) {
        if ((parent) != null) {
            parent.adjustDescendants(num);
        } 
    }

    int countHierarchyMembers() {
        if (java.awt.Container.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            int sum = 0;
            for (java.awt.Component comp : component) {
                sum += comp.countHierarchyMembers();
            }
            if ((descendantsCount) != sum) {
                java.awt.Container.log.fine("Assertion (descendantsCount == sum) failed");
            } 
        } 
        return (descendantsCount) + 1;
    }

    private int getListenersCount(int id, boolean enabledOnToolkit) {
        checkTreeLock();
        if (enabledOnToolkit) {
            return descendantsCount;
        } 
        switch (id) {
            case java.awt.event.HierarchyEvent.HIERARCHY_CHANGED :
                return listeningChildren;
            case java.awt.event.HierarchyEvent.ANCESTOR_MOVED :
            case java.awt.event.HierarchyEvent.ANCESTOR_RESIZED :
                return listeningBoundsChildren;
            default :
                return 0;
        }
    }

    final int createHierarchyEvents(int id, java.awt.Component changed, java.awt.Container changedParent, long changeFlags, boolean enabledOnToolkit) {
        checkTreeLock();
        int listeners = getListenersCount(id, enabledOnToolkit);
        for (int count = listeners, i = 0 ; count > 0 ; i++) {
            count -= component.get(i).createHierarchyEvents(id, changed, changedParent, changeFlags, enabledOnToolkit);
        }
        return listeners + (super.createHierarchyEvents(id, changed, changedParent, changeFlags, enabledOnToolkit));
    }

    final void createChildHierarchyEvents(int id, long changeFlags, boolean enabledOnToolkit) {
        checkTreeLock();
        if (component.isEmpty()) {
            return ;
        } 
        int listeners = getListenersCount(id, enabledOnToolkit);
        for (int count = listeners, i = 0 ; count > 0 ; i++) {
            count -= component.get(i).createHierarchyEvents(id, java.awt.Container.this, parent, changeFlags, enabledOnToolkit);
        }
    }

    public java.awt.LayoutManager getLayout() {
        return layoutMgr;
    }

    public void setLayout(java.awt.LayoutManager mgr) {
        layoutMgr = mgr;
        invalidateIfValid();
    }

    public void doLayout() {
        layout();
    }

    @java.lang.Deprecated
    public void layout() {
        java.awt.LayoutManager layoutMgr = java.awt.Container.this.layoutMgr;
        if (layoutMgr != null) {
            layoutMgr.layoutContainer(java.awt.Container.this);
        } 
    }

    public boolean isValidateRoot() {
        return false;
    }

    private static final boolean isJavaAwtSmartInvalidate;

    static {
        isJavaAwtSmartInvalidate = java.security.AccessController.doPrivileged(new sun.security.action.GetBooleanAction("java.awt.smartInvalidate"));
    }

    @java.lang.Override
    void invalidateParent() {
        if ((!(java.awt.Container.isJavaAwtSmartInvalidate)) || (!(isValidateRoot()))) {
            super.invalidateParent();
        } 
    }

    @java.lang.Override
    public void invalidate() {
        java.awt.LayoutManager layoutMgr = java.awt.Container.this.layoutMgr;
        if (layoutMgr instanceof java.awt.LayoutManager2) {
            java.awt.LayoutManager2 lm = ((java.awt.LayoutManager2)(layoutMgr));
            lm.invalidateLayout(java.awt.Container.this);
        } 
        super.invalidate();
    }

    public void validate() {
        boolean updateCur = false;
        synchronized(getTreeLock()) {
            if (((!(isValid())) || (java.awt.Container.descendUnconditionallyWhenValidating)) && ((peer) != null)) {
                java.awt.peer.ContainerPeer p = null;
                if ((peer) instanceof java.awt.peer.ContainerPeer) {
                    p = ((java.awt.peer.ContainerPeer)(peer));
                } 
                if (p != null) {
                    p.beginValidate();
                } 
                validateTree();
                if (p != null) {
                    p.endValidate();
                    if (!(java.awt.Container.descendUnconditionallyWhenValidating)) {
                        updateCur = isVisible();
                    } 
                } 
            } 
        }
        if (updateCur) {
            updateCursorImmediately();
        } 
    }

    private static boolean descendUnconditionallyWhenValidating = false;

    final void validateUnconditionally() {
        boolean updateCur = false;
        synchronized(getTreeLock()) {
            java.awt.Container.descendUnconditionallyWhenValidating = true;
            validate();
            if ((peer) instanceof java.awt.peer.ContainerPeer) {
                updateCur = isVisible();
            } 
            java.awt.Container.descendUnconditionallyWhenValidating = false;
        }
        if (updateCur) {
            updateCursorImmediately();
        } 
    }

    protected void validateTree() {
        checkTreeLock();
        if ((!(isValid())) || (java.awt.Container.descendUnconditionallyWhenValidating)) {
            if ((peer) instanceof java.awt.peer.ContainerPeer) {
                ((java.awt.peer.ContainerPeer)(peer)).beginLayout();
            } 
            if (!(isValid())) {
                doLayout();
            } 
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                if (((comp instanceof java.awt.Container) && (!(comp instanceof java.awt.Window))) && ((!(comp.isValid())) || (java.awt.Container.descendUnconditionallyWhenValidating))) {
                    ((java.awt.Container)(comp)).validateTree();
                } else {
                    comp.validate();
                }
            }
            if ((peer) instanceof java.awt.peer.ContainerPeer) {
                ((java.awt.peer.ContainerPeer)(peer)).endLayout();
            } 
        } 
        super.validate();
    }

    void invalidateTree() {
        synchronized(getTreeLock()) {
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                if (comp instanceof java.awt.Container) {
                    ((java.awt.Container)(comp)).invalidateTree();
                } else {
                    comp.invalidateIfValid();
                }
            }
            invalidateIfValid();
        }
    }

    public void setFont(java.awt.Font f) {
        boolean shouldinvalidate = false;
        java.awt.Font oldfont = getFont();
        super.setFont(f);
        java.awt.Font newfont = getFont();
        if ((newfont != oldfont) && ((oldfont == null) || (!(oldfont.equals(newfont))))) {
            invalidateTree();
        } 
    }

    public java.awt.Dimension getPreferredSize() {
        return preferredSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize() {
        java.awt.Dimension dim = prefSize;
        if ((dim == null) || (!((isPreferredSizeSet()) || (isValid())))) {
            synchronized(getTreeLock()) {
                prefSize = (layoutMgr) != null ? layoutMgr.preferredLayoutSize(java.awt.Container.this) : super.preferredSize();
                dim = prefSize;
            }
        } 
        if (dim != null) {
            return new java.awt.Dimension(dim);
        } else {
            return dim;
        }
    }

    public java.awt.Dimension getMinimumSize() {
        return minimumSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize() {
        java.awt.Dimension dim = minSize;
        if ((dim == null) || (!((isMinimumSizeSet()) || (isValid())))) {
            synchronized(getTreeLock()) {
                minSize = (layoutMgr) != null ? layoutMgr.minimumLayoutSize(java.awt.Container.this) : super.minimumSize();
                dim = minSize;
            }
        } 
        if (dim != null) {
            return new java.awt.Dimension(dim);
        } else {
            return dim;
        }
    }

    public java.awt.Dimension getMaximumSize() {
        java.awt.Dimension dim = maxSize;
        if ((dim == null) || (!((isMaximumSizeSet()) || (isValid())))) {
            synchronized(getTreeLock()) {
                if ((layoutMgr) instanceof java.awt.LayoutManager2) {
                    java.awt.LayoutManager2 lm = ((java.awt.LayoutManager2)(layoutMgr));
                    maxSize = lm.maximumLayoutSize(java.awt.Container.this);
                } else {
                    maxSize = super.getMaximumSize();
                }
                dim = maxSize;
            }
        } 
        if (dim != null) {
            return new java.awt.Dimension(dim);
        } else {
            return dim;
        }
    }

    public float getAlignmentX() {
        float xAlign;
        if ((layoutMgr) instanceof java.awt.LayoutManager2) {
            synchronized(getTreeLock()) {
                java.awt.LayoutManager2 lm = ((java.awt.LayoutManager2)(layoutMgr));
                xAlign = lm.getLayoutAlignmentX(java.awt.Container.this);
            }
        } else {
            xAlign = super.getAlignmentX();
        }
        return xAlign;
    }

    public float getAlignmentY() {
        float yAlign;
        if ((layoutMgr) instanceof java.awt.LayoutManager2) {
            synchronized(getTreeLock()) {
                java.awt.LayoutManager2 lm = ((java.awt.LayoutManager2)(layoutMgr));
                yAlign = lm.getLayoutAlignmentY(java.awt.Container.this);
            }
        } else {
            yAlign = super.getAlignmentY();
        }
        return yAlign;
    }

    public void paint(java.awt.Graphics g) {
        if (isShowing()) {
            synchronized(getObjectLock()) {
                if (printing) {
                    if (printingThreads.contains(java.lang.Thread.currentThread())) {
                        return ;
                    } 
                } 
            }
            java.awt.GraphicsCallback.PaintCallback.getInstance().runComponents(getComponentsSync(), g, java.awt.GraphicsCallback.LIGHTWEIGHTS);
        } 
    }

    public void update(java.awt.Graphics g) {
        if (isShowing()) {
            if (!((peer) instanceof java.awt.peer.LightweightPeer)) {
                g.clearRect(0, 0, width, height);
            } 
            paint(g);
        } 
    }

    public void print(java.awt.Graphics g) {
        if (isShowing()) {
            java.lang.Thread t = java.lang.Thread.currentThread();
            try {
                synchronized(getObjectLock()) {
                    if ((printingThreads) == null) {
                        printingThreads = new java.util.HashSet<>();
                    } 
                    printingThreads.add(t);
                    printing = true;
                }
                super.print(g);
            } finally {
                synchronized(getObjectLock()) {
                    printingThreads.remove(t);
                    printing = !(printingThreads.isEmpty());
                }
            }
            java.awt.GraphicsCallback.PrintCallback.getInstance().runComponents(getComponentsSync(), g, java.awt.GraphicsCallback.LIGHTWEIGHTS);
        } 
    }

    public void paintComponents(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PaintAllCallback.getInstance().runComponents(getComponentsSync(), g, java.awt.GraphicsCallback.TWO_PASSES);
        } 
    }

    void lightweightPaint(java.awt.Graphics g) {
        super.lightweightPaint(g);
        paintHeavyweightComponents(g);
    }

    void paintHeavyweightComponents(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PaintHeavyweightComponentsCallback.getInstance().runComponents(getComponentsSync(), g, ((java.awt.GraphicsCallback.LIGHTWEIGHTS) | (java.awt.GraphicsCallback.HEAVYWEIGHTS)));
        } 
    }

    public void printComponents(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PrintAllCallback.getInstance().runComponents(getComponentsSync(), g, java.awt.GraphicsCallback.TWO_PASSES);
        } 
    }

    void lightweightPrint(java.awt.Graphics g) {
        super.lightweightPrint(g);
        printHeavyweightComponents(g);
    }

    void printHeavyweightComponents(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PrintHeavyweightComponentsCallback.getInstance().runComponents(getComponentsSync(), g, ((java.awt.GraphicsCallback.LIGHTWEIGHTS) | (java.awt.GraphicsCallback.HEAVYWEIGHTS)));
        } 
    }

    public synchronized void addContainerListener(java.awt.event.ContainerListener l) {
        if (l == null) {
            return ;
        } 
        containerListener = java.awt.AWTEventMulticaster.add(containerListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeContainerListener(java.awt.event.ContainerListener l) {
        if (l == null) {
            return ;
        } 
        containerListener = java.awt.AWTEventMulticaster.remove(containerListener, l);
    }

    public synchronized java.awt.event.ContainerListener[] getContainerListeners() {
        return getListeners(java.awt.event.ContainerListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ContainerListener.class)) {
            l = containerListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        int id = e.getID();
        if ((id == (java.awt.event.ContainerEvent.COMPONENT_ADDED)) || (id == (java.awt.event.ContainerEvent.COMPONENT_REMOVED))) {
            if ((((eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0) || ((containerListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ContainerEvent) {
            processContainerEvent(((java.awt.event.ContainerEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processContainerEvent(java.awt.event.ContainerEvent e) {
        java.awt.event.ContainerListener listener = containerListener;
        if (listener != null) {
            switch (e.getID()) {
                case java.awt.event.ContainerEvent.COMPONENT_ADDED :
                    listener.componentAdded(e);
                    break;
                case java.awt.event.ContainerEvent.COMPONENT_REMOVED :
                    listener.componentRemoved(e);
                    break;
            }
        } 
    }

    void dispatchEventImpl(java.awt.AWTEvent e) {
        if (((dispatcher) != null) && (dispatcher.dispatchEvent(e))) {
            e.consume();
            if ((peer) != null) {
                peer.handleEvent(e);
            } 
            return ;
        } 
        super.dispatchEventImpl(e);
        synchronized(getTreeLock()) {
            switch (e.getID()) {
                case java.awt.event.ComponentEvent.COMPONENT_RESIZED :
                    createChildHierarchyEvents(java.awt.event.HierarchyEvent.ANCESTOR_RESIZED, 0, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK));
                    break;
                case java.awt.event.ComponentEvent.COMPONENT_MOVED :
                    createChildHierarchyEvents(java.awt.event.HierarchyEvent.ANCESTOR_MOVED, 0, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK));
                    break;
                default :
                    break;
            }
        }
    }

    void dispatchEventToSelf(java.awt.AWTEvent e) {
        super.dispatchEventImpl(e);
    }

    java.awt.Component getMouseEventTarget(int x, int y, boolean includeSelf) {
        return getMouseEventTarget(x, y, includeSelf, java.awt.Container.MouseEventTargetFilter.FILTER, (!(java.awt.Container.SEARCH_HEAVYWEIGHTS)));
    }

    java.awt.Component getDropTargetEventTarget(int x, int y, boolean includeSelf) {
        return getMouseEventTarget(x, y, includeSelf, java.awt.Container.DropTargetEventTargetFilter.FILTER, java.awt.Container.SEARCH_HEAVYWEIGHTS);
    }

    private java.awt.Component getMouseEventTarget(int x, int y, boolean includeSelf, java.awt.Container.EventTargetFilter filter, boolean searchHeavyweights) {
        java.awt.Component comp = null;
        if (searchHeavyweights) {
            comp = getMouseEventTargetImpl(x, y, includeSelf, filter, java.awt.Container.SEARCH_HEAVYWEIGHTS, searchHeavyweights);
        } 
        if ((comp == null) || (comp == (java.awt.Container.this))) {
            comp = getMouseEventTargetImpl(x, y, includeSelf, filter, (!(java.awt.Container.SEARCH_HEAVYWEIGHTS)), searchHeavyweights);
        } 
        return comp;
    }

    private java.awt.Component getMouseEventTargetImpl(int x, int y, boolean includeSelf, java.awt.Container.EventTargetFilter filter, boolean searchHeavyweightChildren, boolean searchHeavyweightDescendants) {
        synchronized(getTreeLock()) {
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                if ((((comp != null) && (comp.visible)) && (((!searchHeavyweightChildren) && ((comp.peer) instanceof java.awt.peer.LightweightPeer)) || (searchHeavyweightChildren && (!((comp.peer) instanceof java.awt.peer.LightweightPeer))))) && (comp.contains((x - (comp.x)), (y - (comp.y))))) {
                    if (comp instanceof java.awt.Container) {
                        java.awt.Container child = ((java.awt.Container)(comp));
                        java.awt.Component deeper = child.getMouseEventTarget((x - (child.x)), (y - (child.y)), includeSelf, filter, searchHeavyweightDescendants);
                        if (deeper != null) {
                            return deeper;
                        } 
                    } else {
                        if (filter.accept(comp)) {
                            return comp;
                        } 
                    }
                } 
            }
            boolean isPeerOK;
            boolean isMouseOverMe;
            isPeerOK = ((peer) instanceof java.awt.peer.LightweightPeer) || includeSelf;
            isMouseOverMe = contains(x, y);
            if ((isMouseOverMe && isPeerOK) && (filter.accept(java.awt.Container.this))) {
                return java.awt.Container.this;
            } 
            return null;
        }
    }

    static interface EventTargetFilter {
        boolean accept(final java.awt.Component comp);
    }

    static class MouseEventTargetFilter implements java.awt.Container.EventTargetFilter {
        static final java.awt.Container.EventTargetFilter FILTER = new java.awt.Container.MouseEventTargetFilter();

        private MouseEventTargetFilter() {
        }

        public boolean accept(final java.awt.Component comp) {
            return (((((((comp.eventMask) & (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) != 0) || (((comp.eventMask) & (java.awt.AWTEvent.MOUSE_EVENT_MASK)) != 0)) || (((comp.eventMask) & (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK)) != 0)) || ((comp.mouseListener) != null)) || ((comp.mouseMotionListener) != null)) || ((comp.mouseWheelListener) != null);
        }
    }

    static class DropTargetEventTargetFilter implements java.awt.Container.EventTargetFilter {
        static final java.awt.Container.EventTargetFilter FILTER = new java.awt.Container.DropTargetEventTargetFilter();

        private DropTargetEventTargetFilter() {
        }

        public boolean accept(final java.awt.Component comp) {
            java.awt.dnd.DropTarget dt = comp.getDropTarget();
            return (dt != null) && (dt.isActive());
        }
    }

    void proxyEnableEvents(long events) {
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            if ((parent) != null) {
                parent.proxyEnableEvents(events);
            } 
        } else {
            if ((dispatcher) != null) {
                dispatcher.enableEvents(events);
            } 
        }
    }

    @java.lang.Deprecated
    public void deliverEvent(java.awt.Event e) {
        java.awt.Component comp = getComponentAt(e.x, e.y);
        if ((comp != null) && (comp != (java.awt.Container.this))) {
            e.translate((-(comp.x)), (-(comp.y)));
            comp.deliverEvent(e);
        } else {
            postEvent(e);
        }
    }

    public java.awt.Component getComponentAt(int x, int y) {
        return locate(x, y);
    }

    @java.lang.Deprecated
    public java.awt.Component locate(int x, int y) {
        if (!(contains(x, y))) {
            return null;
        } 
        java.awt.Component lightweight = null;
        synchronized(getTreeLock()) {
            for (final java.awt.Component comp : component) {
                if (comp.contains((x - (comp.x)), (y - (comp.y)))) {
                    if (!(comp.isLightweight())) {
                        return comp;
                    } 
                    if (lightweight == null) {
                        lightweight = comp;
                    } 
                } 
            }
        }
        return lightweight != null ? lightweight : java.awt.Container.this;
    }

    public java.awt.Component getComponentAt(java.awt.Point p) {
        return getComponentAt(p.x, p.y);
    }

    public java.awt.Point getMousePosition(boolean allowChildren) throws java.awt.HeadlessException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        java.awt.PointerInfo pi = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.awt.PointerInfo>() {
            public java.awt.PointerInfo run() {
                return java.awt.MouseInfo.getPointerInfo();
            }
        });
        synchronized(getTreeLock()) {
            java.awt.Component inTheSameWindow = findUnderMouseInWindow(pi);
            if (isSameOrAncestorOf(inTheSameWindow, allowChildren)) {
                return pointRelativeToComponent(pi.getLocation());
            } 
            return null;
        }
    }

    boolean isSameOrAncestorOf(java.awt.Component comp, boolean allowChildren) {
        return ((java.awt.Container.this) == comp) || (allowChildren && (isParentOf(comp)));
    }

    public java.awt.Component findComponentAt(int x, int y) {
        return findComponentAt(x, y, true);
    }

    final java.awt.Component findComponentAt(int x, int y, boolean ignoreEnabled) {
        synchronized(getTreeLock()) {
            if (isRecursivelyVisible()) {
                return findComponentAtImpl(x, y, ignoreEnabled);
            } 
        }
        return null;
    }

    final java.awt.Component findComponentAtImpl(int x, int y, boolean ignoreEnabled) {
        if (!(((contains(x, y)) && (visible)) && (ignoreEnabled || (enabled)))) {
            return null;
        } 
        java.awt.Component lightweight = null;
        for (final java.awt.Component comp : component) {
            final int x1 = x - (comp.x);
            final int y1 = y - (comp.y);
            if (!(comp.contains(x1, y1))) {
                continue;
            } 
            if (!(comp.isLightweight())) {
                final java.awt.Component child = java.awt.Container.getChildAt(comp, x1, y1, ignoreEnabled);
                if (child != null) {
                    return child;
                } 
            } else {
                if (lightweight == null) {
                    lightweight = java.awt.Container.getChildAt(comp, x1, y1, ignoreEnabled);
                } 
            }
        }
        return lightweight != null ? lightweight : java.awt.Container.this;
    }

    private static java.awt.Component getChildAt(java.awt.Component comp, int x, int y, boolean ignoreEnabled) {
        if (comp instanceof java.awt.Container) {
            comp = ((java.awt.Container)(comp)).findComponentAtImpl(x, y, ignoreEnabled);
        } else {
            comp = comp.getComponentAt(x, y);
        }
        if (((comp != null) && (comp.visible)) && (ignoreEnabled || (comp.enabled))) {
            return comp;
        } 
        return null;
    }

    public java.awt.Component findComponentAt(java.awt.Point p) {
        return findComponentAt(p.x, p.y);
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            super.addNotify();
            if (!((peer) instanceof java.awt.peer.LightweightPeer)) {
                dispatcher = new java.awt.LightweightDispatcher(java.awt.Container.this);
            } 
            for (int i = 0 ; i < (component.size()) ; i++) {
                component.get(i).addNotify();
            }
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            for (int i = (component.size()) - 1 ; i >= 0 ; i--) {
                java.awt.Component comp = component.get(i);
                if (comp != null) {
                    comp.setAutoFocusTransferOnDisposal(false);
                    comp.removeNotify();
                    comp.setAutoFocusTransferOnDisposal(true);
                } 
            }
            if ((containsFocus()) && (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabledFor(java.awt.Container.this))) {
                if (!(transferFocus(false))) {
                    transferFocusBackward(true);
                } 
            } 
            if ((dispatcher) != null) {
                dispatcher.dispose();
                dispatcher = null;
            } 
            super.removeNotify();
        }
    }

    public boolean isAncestorOf(java.awt.Component c) {
        java.awt.Container p;
        if ((c == null) || ((p = c.getParent()) == null)) {
            return false;
        } 
        while (p != null) {
            if (p == (java.awt.Container.this)) {
                return true;
            } 
            p = p.getParent();
        }
        return false;
    }

    transient java.awt.Component modalComp;

    transient sun.awt.AppContext modalAppContext;

    private void startLWModal() {
        modalAppContext = sun.awt.AppContext.getAppContext();
        long time = java.awt.Toolkit.getEventQueue().getMostRecentKeyEventTime();
        java.awt.Component predictedFocusOwner = java.awt.Component.isInstanceOf(java.awt.Container.this, "javax.swing.JInternalFrame") ? ((javax.swing.JInternalFrame)(java.awt.Container.this)).getMostRecentFocusOwner() : null;
        if (predictedFocusOwner != null) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().enqueueKeyEvents(time, predictedFocusOwner);
        } 
        final java.awt.Container nativeContainer;
        synchronized(getTreeLock()) {
            nativeContainer = getHeavyweightContainer();
            if ((nativeContainer.modalComp) != null) {
                java.awt.Container.this.modalComp = nativeContainer.modalComp;
                nativeContainer.modalComp = java.awt.Container.this;
                return ;
            } else {
                nativeContainer.modalComp = java.awt.Container.this;
            }
        }
        java.lang.Runnable pumpEventsForHierarchy = new java.lang.Runnable() {
            public void run() {
                java.awt.EventDispatchThread dispatchThread = ((java.awt.EventDispatchThread)(java.lang.Thread.currentThread()));
                dispatchThread.pumpEventsForHierarchy(new java.awt.Conditional() {
                    public boolean evaluate() {
                        return ((windowClosingException) == null) && ((nativeContainer.modalComp) != null);
                    }
                }, java.awt.Container.this);
            }
        };
        if (java.awt.EventQueue.isDispatchThread()) {
            java.awt.SequencedEvent currentSequencedEvent = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getCurrentSequencedEvent();
            if (currentSequencedEvent != null) {
                currentSequencedEvent.dispose();
            } 
            pumpEventsForHierarchy.run();
        } else {
            synchronized(getTreeLock()) {
                java.awt.Toolkit.getEventQueue().postEvent(new sun.awt.PeerEvent(java.awt.Container.this , pumpEventsForHierarchy , sun.awt.PeerEvent.PRIORITY_EVENT));
                while (((windowClosingException) == null) && ((nativeContainer.modalComp) != null)) {
                    try {
                        getTreeLock().wait();
                    } catch (java.lang.InterruptedException e) {
                        break;
                    }
                }
            }
        }
        if ((windowClosingException) != null) {
            windowClosingException.fillInStackTrace();
            throw windowClosingException;
        } 
        if (predictedFocusOwner != null) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().dequeueKeyEvents(time, predictedFocusOwner);
        } 
    }

    private void stopLWModal() {
        synchronized(getTreeLock()) {
            if ((modalAppContext) != null) {
                java.awt.Container nativeContainer = getHeavyweightContainer();
                if (nativeContainer != null) {
                    if ((java.awt.Container.this.modalComp) != null) {
                        nativeContainer.modalComp = java.awt.Container.this.modalComp;
                        java.awt.Container.this.modalComp = null;
                        return ;
                    } else {
                        nativeContainer.modalComp = null;
                    }
                } 
                sun.awt.SunToolkit.postEvent(modalAppContext, new sun.awt.PeerEvent(java.awt.Container.this , new java.awt.Container.WakingRunnable() , sun.awt.PeerEvent.PRIORITY_EVENT));
            } 
            java.awt.EventQueue.invokeLater(new java.awt.Container.WakingRunnable());
            getTreeLock().notifyAll();
        }
    }

    static final class WakingRunnable implements java.lang.Runnable {
        public void run() {
        }
    }

    protected java.lang.String paramString() {
        java.lang.String str = super.paramString();
        java.awt.LayoutManager layoutMgr = java.awt.Container.this.layoutMgr;
        if (layoutMgr != null) {
            str += ",layout=" + (layoutMgr.getClass().getName());
        } 
        return str;
    }

    public void list(java.io.PrintStream out, int indent) {
        super.list(out, indent);
        synchronized(getTreeLock()) {
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                if (comp != null) {
                    comp.list(out, (indent + 1));
                } 
            }
        }
    }

    public void list(java.io.PrintWriter out, int indent) {
        super.list(out, indent);
        synchronized(getTreeLock()) {
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                if (comp != null) {
                    comp.list(out, (indent + 1));
                } 
            }
        }
    }

    public void setFocusTraversalKeys(int id, java.util.Set<? extends java.awt.AWTKeyStroke> keystrokes) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        setFocusTraversalKeys_NoIDCheck(id, keystrokes);
    }

    public java.util.Set<java.awt.AWTKeyStroke> getFocusTraversalKeys(int id) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        return getFocusTraversalKeys_NoIDCheck(id);
    }

    public boolean areFocusTraversalKeysSet(int id) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        return ((focusTraversalKeys) != null) && ((focusTraversalKeys[id]) != null);
    }

    public boolean isFocusCycleRoot(java.awt.Container container) {
        if ((isFocusCycleRoot()) && (container == (java.awt.Container.this))) {
            return true;
        } else {
            return super.isFocusCycleRoot(container);
        }
    }

    private java.awt.Container findTraversalRoot() {
        java.awt.Container currentFocusCycleRoot = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getCurrentFocusCycleRoot();
        java.awt.Container root;
        if (currentFocusCycleRoot == (java.awt.Container.this)) {
            root = java.awt.Container.this;
        } else {
            root = getFocusCycleRootAncestor();
            if (root == null) {
                root = java.awt.Container.this;
            } 
        }
        if (root != currentFocusCycleRoot) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setGlobalCurrentFocusCycleRootPriv(root);
        } 
        return root;
    }

    final boolean containsFocus() {
        final java.awt.Component focusOwner = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
        return isParentOf(focusOwner);
    }

    private boolean isParentOf(java.awt.Component comp) {
        synchronized(getTreeLock()) {
            while (((comp != null) && (comp != (java.awt.Container.this))) && (!(comp instanceof java.awt.Window))) {
                comp = comp.getParent();
            }
            return comp == (java.awt.Container.this);
        }
    }

    void clearMostRecentFocusOwnerOnHide() {
        boolean reset = false;
        java.awt.Window window = null;
        synchronized(getTreeLock()) {
            window = getContainingWindow();
            if (window != null) {
                java.awt.Component comp = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(window);
                reset = (comp == (java.awt.Container.this)) || (isParentOf(comp));
                synchronized(java.awt.KeyboardFocusManager.class) {
                    java.awt.Component storedComp = window.getTemporaryLostComponent();
                    if ((isParentOf(storedComp)) || (storedComp == (java.awt.Container.this))) {
                        window.setTemporaryLostComponent(null);
                    } 
                }
            } 
        }
        if (reset) {
            java.awt.KeyboardFocusManager.setMostRecentFocusOwner(window, null);
        } 
    }

    void clearCurrentFocusCycleRootOnHide() {
        java.awt.KeyboardFocusManager kfm = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        java.awt.Container cont = kfm.getCurrentFocusCycleRoot();
        if ((cont == (java.awt.Container.this)) || (isParentOf(cont))) {
            kfm.setGlobalCurrentFocusCycleRootPriv(null);
        } 
    }

    final java.awt.Container getTraversalRoot() {
        if (isFocusCycleRoot()) {
            return findTraversalRoot();
        } 
        return super.getTraversalRoot();
    }

    public void setFocusTraversalPolicy(java.awt.FocusTraversalPolicy policy) {
        java.awt.FocusTraversalPolicy oldPolicy;
        synchronized(java.awt.Container.this) {
            oldPolicy = java.awt.Container.this.focusTraversalPolicy;
            java.awt.Container.this.focusTraversalPolicy = policy;
        }
        firePropertyChange("focusTraversalPolicy", oldPolicy, policy);
    }

    public java.awt.FocusTraversalPolicy getFocusTraversalPolicy() {
        if ((!(isFocusTraversalPolicyProvider())) && (!(isFocusCycleRoot()))) {
            return null;
        } 
        java.awt.FocusTraversalPolicy policy = java.awt.Container.this.focusTraversalPolicy;
        if (policy != null) {
            return policy;
        } 
        java.awt.Container rootAncestor = getFocusCycleRootAncestor();
        if (rootAncestor != null) {
            return rootAncestor.getFocusTraversalPolicy();
        } else {
            return java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getDefaultFocusTraversalPolicy();
        }
    }

    public boolean isFocusTraversalPolicySet() {
        return (focusTraversalPolicy) != null;
    }

    public void setFocusCycleRoot(boolean focusCycleRoot) {
        boolean oldFocusCycleRoot;
        synchronized(java.awt.Container.this) {
            oldFocusCycleRoot = java.awt.Container.this.focusCycleRoot;
            java.awt.Container.this.focusCycleRoot = focusCycleRoot;
        }
        firePropertyChange("focusCycleRoot", oldFocusCycleRoot, focusCycleRoot);
    }

    public boolean isFocusCycleRoot() {
        return focusCycleRoot;
    }

    public final void setFocusTraversalPolicyProvider(boolean provider) {
        boolean oldProvider;
        synchronized(java.awt.Container.this) {
            oldProvider = focusTraversalPolicyProvider;
            focusTraversalPolicyProvider = provider;
        }
        firePropertyChange("focusTraversalPolicyProvider", oldProvider, provider);
    }

    public final boolean isFocusTraversalPolicyProvider() {
        return focusTraversalPolicyProvider;
    }

    public void transferFocusDownCycle() {
        if (isFocusCycleRoot()) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setGlobalCurrentFocusCycleRootPriv(java.awt.Container.this);
            java.awt.Component toFocus = getFocusTraversalPolicy().getDefaultComponent(java.awt.Container.this);
            if (toFocus != null) {
                toFocus.requestFocus(sun.awt.CausedFocusEvent.Cause.TRAVERSAL_DOWN);
            } 
        } 
    }

    void preProcessKeyEvent(java.awt.event.KeyEvent e) {
        java.awt.Container parent = java.awt.Container.this.parent;
        if (parent != null) {
            parent.preProcessKeyEvent(e);
        } 
    }

    void postProcessKeyEvent(java.awt.event.KeyEvent e) {
        java.awt.Container parent = java.awt.Container.this.parent;
        if (parent != null) {
            parent.postProcessKeyEvent(e);
        } 
    }

    boolean postsOldMouseEvents() {
        return true;
    }

    public void applyComponentOrientation(java.awt.ComponentOrientation o) {
        super.applyComponentOrientation(o);
        synchronized(getTreeLock()) {
            for (int i = 0 ; i < (component.size()) ; i++) {
                java.awt.Component comp = component.get(i);
                comp.applyComponentOrientation(o);
            }
        }
    }

    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        super.addPropertyChangeListener(listener);
    }

    public void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        super.addPropertyChangeListener(propertyName, listener);
    }

    private int containerSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        java.io.ObjectOutputStream.PutField f = s.putFields();
        f.put("ncomponents", component.size());
        f.put("component", component.toArray(java.awt.Container.EMPTY_ARRAY));
        f.put("layoutMgr", layoutMgr);
        f.put("dispatcher", dispatcher);
        f.put("maxSize", maxSize);
        f.put("focusCycleRoot", focusCycleRoot);
        f.put("containerSerializedDataVersion", containerSerializedDataVersion);
        f.put("focusTraversalPolicyProvider", focusTraversalPolicyProvider);
        s.writeFields();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.containerListenerK, containerListener);
        s.writeObject(null);
        if ((focusTraversalPolicy) instanceof java.io.Serializable) {
            s.writeObject(focusTraversalPolicy);
        } else {
            s.writeObject(null);
        }
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        java.io.ObjectInputStream.GetField f = s.readFields();
        java.awt.Component[] tmpComponent = ((java.awt.Component[])(f.get("component", java.awt.Container.EMPTY_ARRAY)));
        int ncomponents = ((java.lang.Integer)(f.get("ncomponents", 0)));
        component = new java.util.ArrayList<java.awt.Component>(ncomponents);
        for (int i = 0 ; i < ncomponents ; ++i) {
            component.add(tmpComponent[i]);
        }
        layoutMgr = ((java.awt.LayoutManager)(f.get("layoutMgr", null)));
        dispatcher = ((java.awt.LightweightDispatcher)(f.get("dispatcher", null)));
        if ((maxSize) == null) {
            maxSize = ((java.awt.Dimension)(f.get("maxSize", null)));
        } 
        focusCycleRoot = f.get("focusCycleRoot", false);
        containerSerializedDataVersion = f.get("containerSerializedDataVersion", 1);
        focusTraversalPolicyProvider = f.get("focusTraversalPolicyProvider", false);
        java.util.List<java.awt.Component> component = java.awt.Container.this.component;
        for (java.awt.Component comp : component) {
            comp.parent = java.awt.Container.this;
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
            adjustListeningChildren(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, comp.numListening(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK));
            adjustDescendants(comp.countHierarchyMembers());
        }
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.containerListenerK) == key) {
                addContainerListener(((java.awt.event.ContainerListener)(s.readObject())));
            } else {
                s.readObject();
            }
        }
        try {
            java.lang.Object policy = s.readObject();
            if (policy instanceof java.awt.FocusTraversalPolicy) {
                focusTraversalPolicy = ((java.awt.FocusTraversalPolicy)(policy));
            } 
        } catch (java.io.OptionalDataException e) {
            if (!(e.eof)) {
                throw e;
            } 
        }
    }

    protected class AccessibleAWTContainer extends java.awt.Component.AccessibleAWTComponent {
        private static final long serialVersionUID = 5081320404842566097L;

        public int getAccessibleChildrenCount() {
            return java.awt.Container.this.getAccessibleChildrenCount();
        }

        public javax.accessibility.Accessible getAccessibleChild(int i) {
            return java.awt.Container.this.getAccessibleChild(i);
        }

        public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
            return java.awt.Container.this.getAccessibleAt(p);
        }

        private transient volatile int propertyListenersCount = 0;

        protected java.awt.event.ContainerListener accessibleContainerHandler = null;

        protected class AccessibleContainerHandler implements java.awt.event.ContainerListener {
            public void componentAdded(java.awt.event.ContainerEvent e) {
                java.awt.Component c = e.getChild();
                if ((c != null) && (c instanceof javax.accessibility.Accessible)) {
                    java.awt.Container.AccessibleAWTContainer.this.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_CHILD_PROPERTY, null, ((javax.accessibility.Accessible)(c)).getAccessibleContext());
                } 
            }

            public void componentRemoved(java.awt.event.ContainerEvent e) {
                java.awt.Component c = e.getChild();
                if ((c != null) && (c instanceof javax.accessibility.Accessible)) {
                    java.awt.Container.AccessibleAWTContainer.this.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_CHILD_PROPERTY, ((javax.accessibility.Accessible)(c)).getAccessibleContext(), null);
                } 
            }
        }

        public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
            if ((accessibleContainerHandler) == null) {
                accessibleContainerHandler = new java.awt.Container.AccessibleAWTContainer.AccessibleContainerHandler();
            } 
            if (((propertyListenersCount)++) == 0) {
                java.awt.Container.this.addContainerListener(accessibleContainerHandler);
            } 
            super.addPropertyChangeListener(listener);
        }

        public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
            if ((--(propertyListenersCount)) == 0) {
                java.awt.Container.this.removeContainerListener(accessibleContainerHandler);
            } 
            super.removePropertyChangeListener(listener);
        }
    }

    javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
        synchronized(getTreeLock()) {
            if ((java.awt.Container.this) instanceof javax.accessibility.Accessible) {
                javax.accessibility.Accessible a = ((javax.accessibility.Accessible)(java.awt.Container.this));
                javax.accessibility.AccessibleContext ac = a.getAccessibleContext();
                if (ac != null) {
                    javax.accessibility.AccessibleComponent acmp;
                    java.awt.Point location;
                    int nchildren = ac.getAccessibleChildrenCount();
                    for (int i = 0 ; i < nchildren ; i++) {
                        a = ac.getAccessibleChild(i);
                        if (a != null) {
                            ac = a.getAccessibleContext();
                            if (ac != null) {
                                acmp = ac.getAccessibleComponent();
                                if ((acmp != null) && (acmp.isShowing())) {
                                    location = acmp.getLocation();
                                    java.awt.Point np = new java.awt.Point(((p.x) - (location.x)) , ((p.y) - (location.y)));
                                    if (acmp.contains(np)) {
                                        return a;
                                    } 
                                } 
                            } 
                        } 
                    }
                } 
                return ((javax.accessibility.Accessible)(java.awt.Container.this));
            } else {
                java.awt.Component ret = java.awt.Container.this;
                if (!(java.awt.Container.this.contains(p.x, p.y))) {
                    ret = null;
                } else {
                    int ncomponents = java.awt.Container.this.getComponentCount();
                    for (int i = 0 ; i < ncomponents ; i++) {
                        java.awt.Component comp = java.awt.Container.this.getComponent(i);
                        if ((comp != null) && (comp.isShowing())) {
                            java.awt.Point location = comp.getLocation();
                            if (comp.contains(((p.x) - (location.x)), ((p.y) - (location.y)))) {
                                ret = comp;
                            } 
                        } 
                    }
                }
                if (ret instanceof javax.accessibility.Accessible) {
                    return ((javax.accessibility.Accessible)(ret));
                } 
            }
            return null;
        }
    }

    int getAccessibleChildrenCount() {
        synchronized(getTreeLock()) {
            int count = 0;
            java.awt.Component[] children = java.awt.Container.this.getComponents();
            for (int i = 0 ; i < (children.length) ; i++) {
                if ((children[i]) instanceof javax.accessibility.Accessible) {
                    count++;
                } 
            }
            return count;
        }
    }

    javax.accessibility.Accessible getAccessibleChild(int i) {
        synchronized(getTreeLock()) {
            java.awt.Component[] children = java.awt.Container.this.getComponents();
            int count = 0;
            for (int j = 0 ; j < (children.length) ; j++) {
                if ((children[j]) instanceof javax.accessibility.Accessible) {
                    if (count == i) {
                        return ((javax.accessibility.Accessible)(children[j]));
                    } else {
                        count++;
                    }
                } 
            }
            return null;
        }
    }

    final void increaseComponentCount(java.awt.Component c) {
        synchronized(getTreeLock()) {
            if (!(c.isDisplayable())) {
                throw new java.lang.IllegalStateException("Peer does not exist while invoking the increaseComponentCount() method");
            } 
            int addHW = 0;
            int addLW = 0;
            if (c instanceof java.awt.Container) {
                addLW = ((java.awt.Container)(c)).numOfLWComponents;
                addHW = ((java.awt.Container)(c)).numOfHWComponents;
            } 
            if (c.isLightweight()) {
                addLW++;
            } else {
                addHW++;
            }
            for (java.awt.Container cont = java.awt.Container.this ; cont != null ; cont = cont.getContainer()) {
                cont.numOfLWComponents += addLW;
                cont.numOfHWComponents += addHW;
            }
        }
    }

    final void decreaseComponentCount(java.awt.Component c) {
        synchronized(getTreeLock()) {
            if (!(c.isDisplayable())) {
                throw new java.lang.IllegalStateException("Peer does not exist while invoking the decreaseComponentCount() method");
            } 
            int subHW = 0;
            int subLW = 0;
            if (c instanceof java.awt.Container) {
                subLW = ((java.awt.Container)(c)).numOfLWComponents;
                subHW = ((java.awt.Container)(c)).numOfHWComponents;
            } 
            if (c.isLightweight()) {
                subLW++;
            } else {
                subHW++;
            }
            for (java.awt.Container cont = java.awt.Container.this ; cont != null ; cont = cont.getContainer()) {
                cont.numOfLWComponents -= subLW;
                cont.numOfHWComponents -= subHW;
            }
        }
    }

    private int getTopmostComponentIndex() {
        checkTreeLock();
        if ((getComponentCount()) > 0) {
            return 0;
        } 
        return -1;
    }

    private int getBottommostComponentIndex() {
        checkTreeLock();
        if ((getComponentCount()) > 0) {
            return (getComponentCount()) - 1;
        } 
        return -1;
    }

    @java.lang.Override
    final sun.java2d.pipe.Region getOpaqueShape() {
        checkTreeLock();
        if (((isLightweight()) && (isNonOpaqueForMixing())) && (hasLightweightDescendants())) {
            sun.java2d.pipe.Region s = null;
            for (int index = 0 ; index < (getComponentCount()) ; index++) {
                java.awt.Component c = getComponent(index);
                if ((c.isLightweight()) && (c.isShowing())) {
                } 
            }
            return s.getIntersection(getNormalShape());
        } 
        return super.getOpaqueShape();
    }

    final void recursiveSubtractAndApplyShape(sun.java2d.pipe.Region shape) {
        recursiveSubtractAndApplyShape(shape, getTopmostComponentIndex(), getBottommostComponentIndex());
    }

    final void recursiveSubtractAndApplyShape(sun.java2d.pipe.Region shape, int fromZorder) {
        recursiveSubtractAndApplyShape(shape, fromZorder, getBottommostComponentIndex());
    }

    final void recursiveSubtractAndApplyShape(sun.java2d.pipe.Region shape, int fromZorder, int toZorder) {
        checkTreeLock();
        if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Container.mixingLog.fine(((((((("this = " + (java.awt.Container.this)) + "; shape=") + shape) + "; fromZ=") + fromZorder) + "; toZ=") + toZorder));
        } 
        if (fromZorder == (-1)) {
            return ;
        } 
        if (shape.isEmpty()) {
            return ;
        } 
        if (((getLayout()) != null) && (!(isValid()))) {
            return ;
        } 
        for (int index = fromZorder ; index <= toZorder ; index++) {
            java.awt.Component comp = getComponent(index);
            if (!(comp.isLightweight())) {
                comp.subtractAndApplyShape(shape);
            } else if (((comp instanceof java.awt.Container) && (((java.awt.Container)(comp)).hasHeavyweightDescendants())) && (comp.isShowing())) {
                ((java.awt.Container)(comp)).recursiveSubtractAndApplyShape(shape);
            } 
        }
    }

    final void recursiveApplyCurrentShape() {
        recursiveApplyCurrentShape(getTopmostComponentIndex(), getBottommostComponentIndex());
    }

    final void recursiveApplyCurrentShape(int fromZorder) {
        recursiveApplyCurrentShape(fromZorder, getBottommostComponentIndex());
    }

    final void recursiveApplyCurrentShape(int fromZorder, int toZorder) {
        checkTreeLock();
        if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Container.mixingLog.fine(((((("this = " + (java.awt.Container.this)) + "; fromZ=") + fromZorder) + "; toZ=") + toZorder));
        } 
        if (fromZorder == (-1)) {
            return ;
        } 
        if (((getLayout()) != null) && (!(isValid()))) {
            return ;
        } 
        for (int index = fromZorder ; index <= toZorder ; index++) {
            java.awt.Component comp = getComponent(index);
            if (!(comp.isLightweight())) {
                comp.applyCurrentShape();
            } 
            if ((comp instanceof java.awt.Container) && (((java.awt.Container)(comp)).hasHeavyweightDescendants())) {
                ((java.awt.Container)(comp)).recursiveApplyCurrentShape();
            } 
        }
    }

    private void recursiveShowHeavyweightChildren() {
        if ((!(hasHeavyweightDescendants())) || (!(isVisible()))) {
            return ;
        } 
        for (int index = 0 ; index < (getComponentCount()) ; index++) {
            java.awt.Component comp = getComponent(index);
            if (comp.isLightweight()) {
                if (comp instanceof java.awt.Container) {
                    ((java.awt.Container)(comp)).recursiveShowHeavyweightChildren();
                } 
            } else {
                if (comp.isVisible()) {
                    java.awt.peer.ComponentPeer peer = comp.getPeer();
                    if (peer != null) {
                        peer.setVisible(true);
                    } 
                } 
            }
        }
    }

    private void recursiveHideHeavyweightChildren() {
        if (!(hasHeavyweightDescendants())) {
            return ;
        } 
        for (int index = 0 ; index < (getComponentCount()) ; index++) {
            java.awt.Component comp = getComponent(index);
            if (comp.isLightweight()) {
                if (comp instanceof java.awt.Container) {
                    ((java.awt.Container)(comp)).recursiveHideHeavyweightChildren();
                } 
            } else {
                if (comp.isVisible()) {
                    java.awt.peer.ComponentPeer peer = comp.getPeer();
                    if (peer != null) {
                        peer.setVisible(false);
                    } 
                } 
            }
        }
    }

    private void recursiveRelocateHeavyweightChildren(java.awt.Point origin) {
        for (int index = 0 ; index < (getComponentCount()) ; index++) {
            java.awt.Component comp = getComponent(index);
            if (comp.isLightweight()) {
                if ((comp instanceof java.awt.Container) && (((java.awt.Container)(comp)).hasHeavyweightDescendants())) {
                    final java.awt.Point newOrigin = new java.awt.Point(origin);
                    newOrigin.translate(comp.getX(), comp.getY());
                    ((java.awt.Container)(comp)).recursiveRelocateHeavyweightChildren(newOrigin);
                } 
            } else {
                java.awt.peer.ComponentPeer peer = comp.getPeer();
                if (peer != null) {
                    peer.setBounds(((origin.x) + (comp.getX())), ((origin.y) + (comp.getY())), comp.getWidth(), comp.getHeight(), java.awt.peer.ComponentPeer.SET_LOCATION);
                } 
            }
        }
    }

    final boolean isRecursivelyVisibleUpToHeavyweightContainer() {
        if (!(isLightweight())) {
            return true;
        } 
        for (java.awt.Container cont = java.awt.Container.this ; (cont != null) && (cont.isLightweight()) ; cont = cont.getContainer()) {
            if (!(cont.isVisible())) {
                return false;
            } 
        }
        return true;
    }

    @java.lang.Override
    void mixOnShowing() {
        synchronized(getTreeLock()) {
            if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.mixingLog.fine(("this = " + (java.awt.Container.this)));
            } 
            boolean isLightweight = isLightweight();
            if (isLightweight && (isRecursivelyVisibleUpToHeavyweightContainer())) {
                recursiveShowHeavyweightChildren();
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if ((!isLightweight) || (isLightweight && (hasHeavyweightDescendants()))) {
                recursiveApplyCurrentShape();
            } 
            super.mixOnShowing();
        }
    }

    @java.lang.Override
    void mixOnHiding(boolean isLightweight) {
        synchronized(getTreeLock()) {
            if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.mixingLog.fine(((("this = " + (java.awt.Container.this)) + "; isLightweight=") + isLightweight));
            } 
            if (isLightweight) {
                recursiveHideHeavyweightChildren();
            } 
            super.mixOnHiding(isLightweight);
        }
    }

    @java.lang.Override
    void mixOnReshaping() {
        synchronized(getTreeLock()) {
            if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.mixingLog.fine(("this = " + (java.awt.Container.this)));
            } 
            boolean isMixingNeeded = isMixingNeeded();
            if ((isLightweight()) && (hasHeavyweightDescendants())) {
                final java.awt.Point origin = new java.awt.Point(getX() , getY());
                for (java.awt.Container cont = getContainer() ; (cont != null) && (cont.isLightweight()) ; cont = cont.getContainer()) {
                    origin.translate(cont.getX(), cont.getY());
                }
                recursiveRelocateHeavyweightChildren(origin);
                if (!isMixingNeeded) {
                    return ;
                } 
                recursiveApplyCurrentShape();
            } 
            if (!isMixingNeeded) {
                return ;
            } 
            super.mixOnReshaping();
        }
    }

    @java.lang.Override
    void mixOnZOrderChanging(int oldZorder, int newZorder) {
        synchronized(getTreeLock()) {
            if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.mixingLog.fine(((((("this = " + (java.awt.Container.this)) + "; oldZ=") + oldZorder) + "; newZ=") + newZorder));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            boolean becameHigher = newZorder < oldZorder;
            if ((becameHigher && (isLightweight())) && (hasHeavyweightDescendants())) {
                recursiveApplyCurrentShape();
            } 
            super.mixOnZOrderChanging(oldZorder, newZorder);
        }
    }

    @java.lang.Override
    void mixOnValidating() {
        synchronized(getTreeLock()) {
            if (java.awt.Container.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Container.mixingLog.fine(("this = " + (java.awt.Container.this)));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if (hasHeavyweightDescendants()) {
                recursiveApplyCurrentShape();
            } 
            if ((isLightweight()) && (isNonOpaqueForMixing())) {
                subtractAndApplyShapeBelowMe();
            } 
            super.mixOnValidating();
        }
    }
}


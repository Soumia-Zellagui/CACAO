package java.awt;


public abstract class Toolkit {
    protected abstract java.awt.peer.DesktopPeer createDesktopPeer(java.awt.Desktop target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.ButtonPeer createButton(java.awt.Button target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.TextFieldPeer createTextField(java.awt.TextField target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.LabelPeer createLabel(java.awt.Label target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.ListPeer createList(java.awt.List target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.CheckboxPeer createCheckbox(java.awt.Checkbox target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.ScrollbarPeer createScrollbar(java.awt.Scrollbar target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.ScrollPanePeer createScrollPane(java.awt.ScrollPane target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.TextAreaPeer createTextArea(java.awt.TextArea target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.ChoicePeer createChoice(java.awt.Choice target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.FramePeer createFrame(java.awt.Frame target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.CanvasPeer createCanvas(java.awt.Canvas target);

    protected abstract java.awt.peer.PanelPeer createPanel(java.awt.Panel target);

    protected abstract java.awt.peer.WindowPeer createWindow(java.awt.Window target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.DialogPeer createDialog(java.awt.Dialog target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.MenuBarPeer createMenuBar(java.awt.MenuBar target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.MenuPeer createMenu(java.awt.Menu target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.PopupMenuPeer createPopupMenu(java.awt.PopupMenu target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.MenuItemPeer createMenuItem(java.awt.MenuItem target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.FileDialogPeer createFileDialog(java.awt.FileDialog target) throws java.awt.HeadlessException;

    protected abstract java.awt.peer.CheckboxMenuItemPeer createCheckboxMenuItem(java.awt.CheckboxMenuItem target) throws java.awt.HeadlessException;

    protected java.awt.peer.MouseInfoPeer getMouseInfoPeer() {
        throw new java.lang.UnsupportedOperationException("Not implemented");
    }

    private static java.awt.peer.LightweightPeer lightweightMarker;

    protected java.awt.peer.LightweightPeer createComponent(java.awt.Component target) {
        if ((java.awt.Toolkit.lightweightMarker) == null) {
            java.awt.Toolkit.lightweightMarker = new sun.awt.NullComponentPeer();
        } 
        return java.awt.Toolkit.lightweightMarker;
    }

    @java.lang.Deprecated
    protected abstract java.awt.peer.FontPeer getFontPeer(java.lang.String name, int style);

    protected void loadSystemColors(int[] systemColors) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
    }

    public void setDynamicLayout(final boolean dynamic) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            java.awt.Toolkit.getDefaultToolkit().setDynamicLayout(dynamic);
        } 
    }

    protected boolean isDynamicLayoutSet() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().isDynamicLayoutSet();
        } else {
            return false;
        }
    }

    public boolean isDynamicLayoutActive() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().isDynamicLayoutActive();
        } else {
            return false;
        }
    }

    public abstract java.awt.Dimension getScreenSize() throws java.awt.HeadlessException;

    public abstract int getScreenResolution() throws java.awt.HeadlessException;

    public java.awt.Insets getScreenInsets(java.awt.GraphicsConfiguration gc) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().getScreenInsets(gc);
        } else {
            return new java.awt.Insets(0 , 0 , 0 , 0);
        }
    }

    public abstract java.awt.image.ColorModel getColorModel() throws java.awt.HeadlessException;

    @java.lang.Deprecated
    public abstract java.lang.String[] getFontList();

    @java.lang.Deprecated
    public abstract java.awt.FontMetrics getFontMetrics(java.awt.Font font);

    public abstract void sync();

    private static java.awt.Toolkit toolkit;

    private static java.lang.String atNames;

    private static void initAssistiveTechnologies() {
        final java.lang.String sep = java.io.File.separator;
        final java.util.Properties properties = new java.util.Properties();
        java.awt.Toolkit.atNames = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.String>() {
            public java.lang.String run() {
                try {
                    java.io.File propsFile = new java.io.File((((java.lang.System.getProperty("user.home")) + sep) + ".accessibility.properties"));
                    java.io.FileInputStream in = new java.io.FileInputStream(propsFile);
                    properties.load(in);
                    in.close();
                } catch (java.lang.Exception e) {
                }
                if ((properties.size()) == 0) {
                    try {
                        java.io.File propsFile = new java.io.File((((((java.lang.System.getProperty("java.home")) + sep) + "lib") + sep) + "accessibility.properties"));
                        java.io.FileInputStream in = new java.io.FileInputStream(propsFile);
                        properties.load(in);
                        in.close();
                    } catch (java.lang.Exception e) {
                    }
                } 
                java.lang.String magPresent = java.lang.System.getProperty("javax.accessibility.screen_magnifier_present");
                if (magPresent == null) {
                    magPresent = properties.getProperty("screen_magnifier_present", null);
                    if (magPresent != null) {
                        java.lang.System.setProperty("javax.accessibility.screen_magnifier_present", magPresent);
                    } 
                } 
                java.lang.String classNames = java.lang.System.getProperty("javax.accessibility.assistive_technologies");
                if (classNames == null) {
                    classNames = properties.getProperty("assistive_technologies", null);
                    if (classNames != null) {
                        java.lang.System.setProperty("javax.accessibility.assistive_technologies", classNames);
                    } 
                } 
                return classNames;
            }
        });
    }

    private static void loadAssistiveTechnologies() {
        if ((java.awt.Toolkit.atNames) != null) {
            java.lang.ClassLoader cl = java.lang.ClassLoader.getSystemClassLoader();
            java.util.StringTokenizer parser = new java.util.StringTokenizer(java.awt.Toolkit.atNames , " ,");
            java.lang.String atName;
            while (parser.hasMoreTokens()) {
                atName = parser.nextToken();
                try {
                    java.lang.Class<?> clazz;
                    if (cl != null) {
                        clazz = cl.loadClass(atName);
                    } else {
                        clazz = java.lang.Class.forName(atName);
                    }
                    clazz.newInstance();
                } catch (java.lang.ClassNotFoundException e) {
                    throw new java.awt.AWTError(("Assistive Technology not found: " + atName));
                } catch (java.lang.InstantiationException e) {
                    throw new java.awt.AWTError((("Could not instantiate Assistive" + " Technology: ") + atName));
                } catch (java.lang.IllegalAccessException e) {
                    throw new java.awt.AWTError((("Could not access Assistive" + " Technology: ") + atName));
                } catch (java.lang.Exception e) {
                    throw new java.awt.AWTError((((("Error trying to install Assistive" + " Technology: ") + atName) + " ") + e));
                }
            }
        } 
    }

    public static synchronized java.awt.Toolkit getDefaultToolkit() {
        if ((java.awt.Toolkit.toolkit) == null) {
            java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
                public java.lang.Void run() {
                    java.lang.Class<?> cls = null;
                    java.lang.String nm = java.lang.System.getProperty("awt.toolkit");
                    try {
                        cls = java.lang.Class.forName(nm);
                    } catch (java.lang.ClassNotFoundException e) {
                        java.lang.ClassLoader cl = java.lang.ClassLoader.getSystemClassLoader();
                        if (cl != null) {
                            try {
                                cls = cl.loadClass(nm);
                            } catch (final java.lang.ClassNotFoundException ignored) {
                                throw new java.awt.AWTError(("Toolkit not found: " + nm));
                            }
                        } 
                    }
                    try {
                        if (cls != null) {
                            java.awt.Toolkit.toolkit = ((java.awt.Toolkit)(cls.newInstance()));
                            if (java.awt.GraphicsEnvironment.isHeadless()) {
                                java.awt.Toolkit.toolkit = new sun.awt.HeadlessToolkit(java.awt.Toolkit.toolkit);
                            } 
                        } 
                    } catch (final java.lang.InstantiationException ignored) {
                        throw new java.awt.AWTError(("Could not instantiate Toolkit: " + nm));
                    } catch (final java.lang.IllegalAccessException ignored) {
                        throw new java.awt.AWTError(("Could not access Toolkit: " + nm));
                    }
                    return null;
                }
            });
            java.awt.Toolkit.loadAssistiveTechnologies();
        } 
        return java.awt.Toolkit.toolkit;
    }

    public abstract java.awt.Image getImage(java.lang.String filename);

    public abstract java.awt.Image getImage(java.net.URL url);

    public abstract java.awt.Image createImage(java.lang.String filename);

    public abstract java.awt.Image createImage(java.net.URL url);

    public abstract boolean prepareImage(java.awt.Image image, int width, int height, java.awt.image.ImageObserver observer);

    public abstract int checkImage(java.awt.Image image, int width, int height, java.awt.image.ImageObserver observer);

    public abstract java.awt.Image createImage(java.awt.image.ImageProducer producer);

    public java.awt.Image createImage(byte[] imagedata) {
        return createImage(imagedata, 0, imagedata.length);
    }

    public abstract java.awt.Image createImage(byte[] imagedata, int imageoffset, int imagelength);

    public abstract java.awt.PrintJob getPrintJob(java.awt.Frame frame, java.lang.String jobtitle, java.util.Properties props);

    public java.awt.PrintJob getPrintJob(java.awt.Frame frame, java.lang.String jobtitle, java.awt.JobAttributes jobAttributes, java.awt.PageAttributes pageAttributes) {
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().getPrintJob(frame, jobtitle, jobAttributes, pageAttributes);
        } else {
            return getPrintJob(frame, jobtitle, null);
        }
    }

    public abstract void beep();

    public abstract java.awt.datatransfer.Clipboard getSystemClipboard() throws java.awt.HeadlessException;

    public java.awt.datatransfer.Clipboard getSystemSelection() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().getSystemSelection();
        } else {
            java.awt.GraphicsEnvironment.checkHeadless();
            return null;
        }
    }

    public int getMenuShortcutKeyMask() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        return java.awt.Event.CTRL_MASK;
    }

    public boolean getLockingKeyState(int keyCode) throws java.lang.UnsupportedOperationException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if (!((((keyCode == (java.awt.event.KeyEvent.VK_CAPS_LOCK)) || (keyCode == (java.awt.event.KeyEvent.VK_NUM_LOCK))) || (keyCode == (java.awt.event.KeyEvent.VK_SCROLL_LOCK))) || (keyCode == (java.awt.event.KeyEvent.VK_KANA_LOCK)))) {
            throw new java.lang.IllegalArgumentException("invalid key for Toolkit.getLockingKeyState");
        } 
        throw new java.lang.UnsupportedOperationException("Toolkit.getLockingKeyState");
    }

    public void setLockingKeyState(int keyCode, boolean on) throws java.lang.UnsupportedOperationException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if (!((((keyCode == (java.awt.event.KeyEvent.VK_CAPS_LOCK)) || (keyCode == (java.awt.event.KeyEvent.VK_NUM_LOCK))) || (keyCode == (java.awt.event.KeyEvent.VK_SCROLL_LOCK))) || (keyCode == (java.awt.event.KeyEvent.VK_KANA_LOCK)))) {
            throw new java.lang.IllegalArgumentException("invalid key for Toolkit.setLockingKeyState");
        } 
        throw new java.lang.UnsupportedOperationException("Toolkit.setLockingKeyState");
    }

    protected static java.awt.Container getNativeContainer(java.awt.Component c) {
        return c.getNativeContainer();
    }

    public java.awt.Cursor createCustomCursor(java.awt.Image cursor, java.awt.Point hotSpot, java.lang.String name) throws java.awt.HeadlessException, java.lang.IndexOutOfBoundsException {
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().createCustomCursor(cursor, hotSpot, name);
        } else {
            return new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR);
        }
    }

    public java.awt.Dimension getBestCursorSize(int preferredWidth, int preferredHeight) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().getBestCursorSize(preferredWidth, preferredHeight);
        } else {
            return new java.awt.Dimension(0 , 0);
        }
    }

    public int getMaximumCursorColors() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().getMaximumCursorColors();
        } else {
            return 0;
        }
    }

    public boolean isFrameStateSupported(int state) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        if ((java.awt.Toolkit.this) != (java.awt.Toolkit.getDefaultToolkit())) {
            return java.awt.Toolkit.getDefaultToolkit().isFrameStateSupported(state);
        } else {
            return state == (java.awt.Frame.NORMAL);
        }
    }

    private static java.util.ResourceBundle resources;

    private static java.util.ResourceBundle platformResources;

    private static void setPlatformResources(java.util.ResourceBundle bundle) {
        java.awt.Toolkit.platformResources = bundle;
    }

    private static native void initIDs();

    private static boolean loaded = false;

    static void loadLibraries() {
        if (!(java.awt.Toolkit.loaded)) {
            java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
                public java.lang.Void run() {
                    java.lang.System.loadLibrary("awt");
                    return null;
                }
            });
            java.awt.Toolkit.loaded = true;
        } 
    }

    static {
        sun.awt.AWTAccessor.setToolkitAccessor(new sun.awt.AWTAccessor.ToolkitAccessor() {
            @java.lang.Override
            public void setPlatformResources(java.util.ResourceBundle bundle) {
                java.awt.Toolkit.setPlatformResources(bundle);
            }
        });
        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
            public java.lang.Void run() {
                try {
                    resources = java.util.ResourceBundle.getBundle("sun.awt.resources.awt", sun.util.CoreResourceBundleControl.getRBControlInstance());
                } catch (java.util.MissingResourceException e) {
                }
                return null;
            }
        });
        java.awt.Toolkit.loadLibraries();
        java.awt.Toolkit.initAssistiveTechnologies();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Toolkit.initIDs();
        } 
    }

    public static java.lang.String getProperty(java.lang.String key, java.lang.String defaultValue) {
        if ((java.awt.Toolkit.platformResources) != null) {
            try {
                return java.awt.Toolkit.platformResources.getString(key);
            } catch (java.util.MissingResourceException e) {
            }
        } 
        if ((java.awt.Toolkit.resources) != null) {
            try {
                return java.awt.Toolkit.resources.getString(key);
            } catch (java.util.MissingResourceException e) {
            }
        } 
        return defaultValue;
    }

    public final java.awt.EventQueue getSystemEventQueue() {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.CHECK_AWT_EVENTQUEUE_PERMISSION);
        } 
        return getSystemEventQueueImpl();
    }

    protected abstract java.awt.EventQueue getSystemEventQueueImpl();

    static java.awt.EventQueue getEventQueue() {
        return java.awt.Toolkit.getDefaultToolkit().getSystemEventQueueImpl();
    }

    public abstract java.awt.dnd.peer.DragSourceContextPeer createDragSourceContextPeer(java.awt.dnd.DragGestureEvent dge) throws java.awt.dnd.InvalidDnDOperationException;

    public <T extends java.awt.dnd.DragGestureRecognizer>T createDragGestureRecognizer(java.lang.Class<T> abstractRecognizerClass, java.awt.dnd.DragSource ds, java.awt.Component c, int srcActions, java.awt.dnd.DragGestureListener dgl) {
        return null;
    }

    public final synchronized java.lang.Object getDesktopProperty(java.lang.String propertyName) {
        if ((java.awt.Toolkit.this) instanceof sun.awt.HeadlessToolkit) {
            return ((sun.awt.HeadlessToolkit)(java.awt.Toolkit.this)).getUnderlyingToolkit().getDesktopProperty(propertyName);
        } 
        if (desktopProperties.isEmpty()) {
            initializeDesktopProperties();
        } 
        java.lang.Object value;
        if (propertyName.equals("awt.dynamicLayoutSupported")) {
            return java.awt.Toolkit.getDefaultToolkit().lazilyLoadDesktopProperty(propertyName);
        } 
        value = desktopProperties.get(propertyName);
        if (value == null) {
            value = lazilyLoadDesktopProperty(propertyName);
            if (value != null) {
                setDesktopProperty(propertyName, value);
            } 
        } 
        if (value instanceof java.awt.RenderingHints) {
            value = ((java.awt.RenderingHints)(value)).clone();
        } 
        return value;
    }

    protected final void setDesktopProperty(java.lang.String name, java.lang.Object newValue) {
        if ((java.awt.Toolkit.this) instanceof sun.awt.HeadlessToolkit) {
            ((sun.awt.HeadlessToolkit)(java.awt.Toolkit.this)).getUnderlyingToolkit().setDesktopProperty(name, newValue);
            return ;
        } 
        java.lang.Object oldValue;
        synchronized(java.awt.Toolkit.this) {
            oldValue = desktopProperties.get(name);
            desktopProperties.put(name, newValue);
        }
        if ((oldValue != null) || (newValue != null)) {
            desktopPropsSupport.firePropertyChange(name, oldValue, newValue);
        } 
    }

    protected java.lang.Object lazilyLoadDesktopProperty(java.lang.String name) {
        return null;
    }

    protected void initializeDesktopProperties() {
    }

    public void addPropertyChangeListener(java.lang.String name, java.beans.PropertyChangeListener pcl) {
        desktopPropsSupport.addPropertyChangeListener(name, pcl);
    }

    public void removePropertyChangeListener(java.lang.String name, java.beans.PropertyChangeListener pcl) {
        desktopPropsSupport.removePropertyChangeListener(name, pcl);
    }

    public java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
        return desktopPropsSupport.getPropertyChangeListeners();
    }

    public java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String propertyName) {
        return desktopPropsSupport.getPropertyChangeListeners(propertyName);
    }

    protected final java.util.Map<java.lang.String, java.lang.Object> desktopProperties = new java.util.HashMap<java.lang.String, java.lang.Object>();

    protected final java.beans.PropertyChangeSupport desktopPropsSupport = java.awt.Toolkit.createPropertyChangeSupport(java.awt.Toolkit.this);

    public boolean isAlwaysOnTopSupported() {
        return true;
    }

    public abstract boolean isModalityTypeSupported(java.awt.Dialog.ModalityType modalityType);

    public abstract boolean isModalExclusionTypeSupported(java.awt.Dialog.ModalExclusionType modalExclusionType);

    private static final int LONG_BITS = 64;

    private int[] calls = new int[java.awt.Toolkit.LONG_BITS];

    private static volatile long enabledOnToolkitMask;

    private java.awt.event.AWTEventListener eventListener = null;

    private java.util.WeakHashMap<java.awt.event.AWTEventListener, java.awt.Toolkit.SelectiveAWTEventListener> listener2SelectiveListener = new java.util.WeakHashMap<>();

    private static java.awt.event.AWTEventListener deProxyAWTEventListener(java.awt.event.AWTEventListener l) {
        java.awt.event.AWTEventListener localL = l;
        if (localL == null) {
            return null;
        } 
        if (l instanceof java.awt.event.AWTEventListenerProxy) {
            localL = ((java.awt.event.AWTEventListenerProxy)(l)).getListener();
        } 
        return localL;
    }

    public void addAWTEventListener(java.awt.event.AWTEventListener listener, long eventMask) {
        java.awt.event.AWTEventListener localL = java.awt.Toolkit.deProxyAWTEventListener(listener);
        if (localL == null) {
            return ;
        } 
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.ALL_AWT_EVENTS_PERMISSION);
        } 
        synchronized(java.awt.Toolkit.this) {
            java.awt.Toolkit.SelectiveAWTEventListener selectiveListener = listener2SelectiveListener.get(localL);
            if (selectiveListener == null) {
                selectiveListener = new java.awt.Toolkit.SelectiveAWTEventListener(localL , eventMask);
                listener2SelectiveListener.put(localL, selectiveListener);
                eventListener = java.awt.Toolkit.ToolkitEventMulticaster.add(eventListener, selectiveListener);
            } 
            selectiveListener.orEventMasks(eventMask);
            java.awt.Toolkit.enabledOnToolkitMask |= eventMask;
            long mask = eventMask;
            for (int i = 0 ; i < (java.awt.Toolkit.LONG_BITS) ; i++) {
                if (mask == 0) {
                    break;
                } 
                if ((mask & 1L) != 0) {
                    (calls[i])++;
                } 
                mask >>>= 1;
            }
        }
    }

    public void removeAWTEventListener(java.awt.event.AWTEventListener listener) {
        java.awt.event.AWTEventListener localL = java.awt.Toolkit.deProxyAWTEventListener(listener);
        if (listener == null) {
            return ;
        } 
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.ALL_AWT_EVENTS_PERMISSION);
        } 
        synchronized(java.awt.Toolkit.this) {
            java.awt.Toolkit.SelectiveAWTEventListener selectiveListener = listener2SelectiveListener.get(localL);
            if (selectiveListener != null) {
                listener2SelectiveListener.remove(localL);
                int[] listenerCalls = selectiveListener.getCalls();
                for (int i = 0 ; i < (java.awt.Toolkit.LONG_BITS) ; i++) {
                    calls[i] -= listenerCalls[i];
                    assert (calls[i]) >= 0 : "Negative Listeners count";
                    if ((calls[i]) == 0) {
                        java.awt.Toolkit.enabledOnToolkitMask &= ~(1L << i);
                    } 
                }
            } 
            eventListener = java.awt.Toolkit.ToolkitEventMulticaster.remove(eventListener, (selectiveListener == null ? localL : selectiveListener));
        }
    }

    static boolean enabledOnToolkit(long eventMask) {
        return ((java.awt.Toolkit.enabledOnToolkitMask) & eventMask) != 0;
    }

    synchronized int countAWTEventListeners(long eventMask) {
        int ci = 0;
        for ( ; eventMask != 0 ; eventMask >>>= 1 , ci++) {
        }
        ci--;
        return calls[ci];
    }

    public java.awt.event.AWTEventListener[] getAWTEventListeners() {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.ALL_AWT_EVENTS_PERMISSION);
        } 
        synchronized(java.awt.Toolkit.this) {
            java.util.EventListener[] la = java.awt.Toolkit.ToolkitEventMulticaster.getListeners(eventListener, java.awt.event.AWTEventListener.class);
            java.awt.event.AWTEventListener[] ret = new java.awt.event.AWTEventListener[la.length];
            for (int i = 0 ; i < (la.length) ; i++) {
                java.awt.Toolkit.SelectiveAWTEventListener sael = ((java.awt.Toolkit.SelectiveAWTEventListener)(la[i]));
                java.awt.event.AWTEventListener tempL = sael.getListener();
                ret[i] = new java.awt.event.AWTEventListenerProxy(sael.getEventMask() , tempL);
            }
            return ret;
        }
    }

    public java.awt.event.AWTEventListener[] getAWTEventListeners(long eventMask) {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.ALL_AWT_EVENTS_PERMISSION);
        } 
        synchronized(java.awt.Toolkit.this) {
            java.util.EventListener[] la = java.awt.Toolkit.ToolkitEventMulticaster.getListeners(eventListener, java.awt.event.AWTEventListener.class);
            java.util.List<java.awt.event.AWTEventListenerProxy> list = new java.util.ArrayList<>(la.length);
            for (int i = 0 ; i < (la.length) ; i++) {
                java.awt.Toolkit.SelectiveAWTEventListener sael = ((java.awt.Toolkit.SelectiveAWTEventListener)(la[i]));
                if (((sael.getEventMask()) & eventMask) == eventMask) {
                    list.add(new java.awt.event.AWTEventListenerProxy(sael.getEventMask() , sael.getListener()));
                } 
            }
            return list.toArray(new java.awt.event.AWTEventListener[0]);
        }
    }

    void notifyAWTEventListeners(java.awt.AWTEvent theEvent) {
        if ((java.awt.Toolkit.this) instanceof sun.awt.HeadlessToolkit) {
            ((sun.awt.HeadlessToolkit)(java.awt.Toolkit.this)).getUnderlyingToolkit().notifyAWTEventListeners(theEvent);
            return ;
        } 
        java.awt.event.AWTEventListener eventListener = java.awt.Toolkit.this.eventListener;
        if (eventListener != null) {
            eventListener.eventDispatched(theEvent);
        } 
    }

    private static class ToolkitEventMulticaster extends java.awt.AWTEventMulticaster implements java.awt.event.AWTEventListener {
        ToolkitEventMulticaster(java.awt.event.AWTEventListener a ,java.awt.event.AWTEventListener b) {
            super(a, b);
        }

        static java.awt.event.AWTEventListener add(java.awt.event.AWTEventListener a, java.awt.event.AWTEventListener b) {
            if (a == null)
                return b;
            
            if (b == null)
                return a;
            
            return new java.awt.Toolkit.ToolkitEventMulticaster(a , b);
        }

        static java.awt.event.AWTEventListener remove(java.awt.event.AWTEventListener l, java.awt.event.AWTEventListener oldl) {
            return ((java.awt.event.AWTEventListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
        }

        protected java.util.EventListener remove(java.util.EventListener oldl) {
            if (oldl == (a))
                return b;
            
            if (oldl == (b))
                return a;
            
            java.awt.event.AWTEventListener a2 = ((java.awt.event.AWTEventListener)(java.awt.AWTEventMulticaster.removeInternal(a, oldl)));
            java.awt.event.AWTEventListener b2 = ((java.awt.event.AWTEventListener)(java.awt.AWTEventMulticaster.removeInternal(b, oldl)));
            if ((a2 == (a)) && (b2 == (b))) {
                return java.awt.Toolkit.ToolkitEventMulticaster.this;
            } 
            return java.awt.Toolkit.ToolkitEventMulticaster.add(a2, b2);
        }

        public void eventDispatched(java.awt.AWTEvent event) {
            ((java.awt.event.AWTEventListener)(a)).eventDispatched(event);
            ((java.awt.event.AWTEventListener)(b)).eventDispatched(event);
        }
    }

    private class SelectiveAWTEventListener implements java.awt.event.AWTEventListener {
        java.awt.event.AWTEventListener listener;

        private long eventMask;

        int[] calls = new int[java.awt.Toolkit.LONG_BITS];

        public java.awt.event.AWTEventListener getListener() {
            return listener;
        }

        public long getEventMask() {
            return eventMask;
        }

        public int[] getCalls() {
            return calls;
        }

        public void orEventMasks(long mask) {
            eventMask |= mask;
            for (int i = 0 ; i < (java.awt.Toolkit.LONG_BITS) ; i++) {
                if (mask == 0) {
                    break;
                } 
                if ((mask & 1L) != 0) {
                    (calls[i])++;
                } 
                mask >>>= 1;
            }
        }

        SelectiveAWTEventListener(java.awt.event.AWTEventListener l ,long mask) {
            listener = l;
            eventMask = mask;
        }

        public void eventDispatched(java.awt.AWTEvent event) {
            long eventBit = 0;
            if (((((((((((((((((((((((eventBit = (eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.ComponentEvent.COMPONENT_FIRST))) && ((event.id) <= (java.awt.event.ComponentEvent.COMPONENT_LAST))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.CONTAINER_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.ContainerEvent.CONTAINER_FIRST))) && ((event.id) <= (java.awt.event.ContainerEvent.CONTAINER_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.FOCUS_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.FocusEvent.FOCUS_FIRST))) && ((event.id) <= (java.awt.event.FocusEvent.FOCUS_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.KEY_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.KeyEvent.KEY_FIRST))) && ((event.id) <= (java.awt.event.KeyEvent.KEY_LAST)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK)) != 0) && ((event.id) == (java.awt.event.MouseEvent.MOUSE_WHEEL)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) != 0) && (((event.id) == (java.awt.event.MouseEvent.MOUSE_MOVED)) || ((event.id) == (java.awt.event.MouseEvent.MOUSE_DRAGGED))))) || (((((((eventBit = (eventMask) & (java.awt.AWTEvent.MOUSE_EVENT_MASK)) != 0) && ((event.id) != (java.awt.event.MouseEvent.MOUSE_MOVED))) && ((event.id) != (java.awt.event.MouseEvent.MOUSE_DRAGGED))) && ((event.id) != (java.awt.event.MouseEvent.MOUSE_WHEEL))) && ((event.id) >= (java.awt.event.MouseEvent.MOUSE_FIRST))) && ((event.id) <= (java.awt.event.MouseEvent.MOUSE_LAST)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.WINDOW_EVENT_MASK)) != 0) && (((event.id) >= (java.awt.event.WindowEvent.WINDOW_FIRST)) && ((event.id) <= (java.awt.event.WindowEvent.WINDOW_LAST))))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.ActionEvent.ACTION_FIRST))) && ((event.id) <= (java.awt.event.ActionEvent.ACTION_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.ADJUSTMENT_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.AdjustmentEvent.ADJUSTMENT_FIRST))) && ((event.id) <= (java.awt.event.AdjustmentEvent.ADJUSTMENT_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.ItemEvent.ITEM_FIRST))) && ((event.id) <= (java.awt.event.ItemEvent.ITEM_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.TEXT_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.TextEvent.TEXT_FIRST))) && ((event.id) <= (java.awt.event.TextEvent.TEXT_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.INPUT_METHOD_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.InputMethodEvent.INPUT_METHOD_FIRST))) && ((event.id) <= (java.awt.event.InputMethodEvent.INPUT_METHOD_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.PAINT_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.PaintEvent.PAINT_FIRST))) && ((event.id) <= (java.awt.event.PaintEvent.PAINT_LAST)))) || ((((eventBit = (eventMask) & (java.awt.AWTEvent.INVOCATION_EVENT_MASK)) != 0) && ((event.id) >= (java.awt.event.InvocationEvent.INVOCATION_FIRST))) && ((event.id) <= (java.awt.event.InvocationEvent.INVOCATION_LAST)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0) && ((event.id) == (java.awt.event.HierarchyEvent.HIERARCHY_CHANGED)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0) && (((event.id) == (java.awt.event.HierarchyEvent.ANCESTOR_MOVED)) || ((event.id) == (java.awt.event.HierarchyEvent.ANCESTOR_RESIZED))))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.WINDOW_STATE_EVENT_MASK)) != 0) && ((event.id) == (java.awt.event.WindowEvent.WINDOW_STATE_CHANGED)))) || (((eventBit = (eventMask) & (java.awt.AWTEvent.WINDOW_FOCUS_EVENT_MASK)) != 0) && (((event.id) == (java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS)) || ((event.id) == (java.awt.event.WindowEvent.WINDOW_LOST_FOCUS))))) || (((eventBit = (eventMask) & (sun.awt.SunToolkit.GRAB_EVENT_MASK)) != 0) && (event instanceof sun.awt.UngrabEvent))) {
                int ci = 0;
                for (long eMask = eventBit ; eMask != 0 ; eMask >>>= 1 , ci++) {
                }
                ci--;
                for (int i = 0 ; i < (calls[ci]) ; i++) {
                    listener.eventDispatched(event);
                }
            } 
        }
    }

    public abstract java.util.Map<java.awt.font.TextAttribute, ?> mapInputMethodHighlight(java.awt.im.InputMethodHighlight highlight) throws java.awt.HeadlessException;

    private static java.beans.PropertyChangeSupport createPropertyChangeSupport(java.awt.Toolkit toolkit) {
        if ((toolkit instanceof sun.awt.SunToolkit) || (toolkit instanceof sun.awt.HeadlessToolkit)) {
            return new java.awt.Toolkit.DesktopPropertyChangeSupport(toolkit);
        } else {
            return new java.beans.PropertyChangeSupport(toolkit);
        }
    }

    @java.lang.SuppressWarnings(value = "serial")
    private static class DesktopPropertyChangeSupport extends java.beans.PropertyChangeSupport {
        private static final java.lang.StringBuilder PROP_CHANGE_SUPPORT_KEY = new java.lang.StringBuilder("desktop property change support key");

        private final java.lang.Object source;

        public DesktopPropertyChangeSupport(java.lang.Object sourceBean) {
            super(sourceBean);
            source = sourceBean;
        }

        @java.lang.Override
        public synchronized void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null == pcs) {
                pcs = new java.beans.PropertyChangeSupport(source);
                sun.awt.AppContext.getAppContext().put(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY, pcs);
            } 
            pcs.addPropertyChangeListener(propertyName, listener);
        }

        @java.lang.Override
        public synchronized void removePropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null != pcs) {
                pcs.removePropertyChangeListener(propertyName, listener);
            } 
        }

        @java.lang.Override
        public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null != pcs) {
                return pcs.getPropertyChangeListeners();
            } else {
                return new java.beans.PropertyChangeListener[0];
            }
        }

        @java.lang.Override
        public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String propertyName) {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null != pcs) {
                return pcs.getPropertyChangeListeners(propertyName);
            } else {
                return new java.beans.PropertyChangeListener[0];
            }
        }

        @java.lang.Override
        public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null == pcs) {
                pcs = new java.beans.PropertyChangeSupport(source);
                sun.awt.AppContext.getAppContext().put(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY, pcs);
            } 
            pcs.addPropertyChangeListener(listener);
        }

        @java.lang.Override
        public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
            java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
            if (null != pcs) {
                pcs.removePropertyChangeListener(listener);
            } 
        }

        @java.lang.Override
        public void firePropertyChange(final java.beans.PropertyChangeEvent evt) {
            java.lang.Object oldValue = evt.getOldValue();
            java.lang.Object newValue = evt.getNewValue();
            java.lang.String propertyName = evt.getPropertyName();
            if (((oldValue != null) && (newValue != null)) && (oldValue.equals(newValue))) {
                return ;
            } 
            java.lang.Runnable updater = new java.lang.Runnable() {
                public void run() {
                    java.beans.PropertyChangeSupport pcs = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.Toolkit.DesktopPropertyChangeSupport.PROP_CHANGE_SUPPORT_KEY)));
                    if (null != pcs) {
                        pcs.firePropertyChange(evt);
                    } 
                }
            };
            final sun.awt.AppContext currentAppContext = sun.awt.AppContext.getAppContext();
            for (sun.awt.AppContext appContext : sun.awt.AppContext.getAppContexts()) {
                if ((null == appContext) || (appContext.isDisposed())) {
                    continue;
                } 
                if (currentAppContext == appContext) {
                    updater.run();
                } else {
                    final sun.awt.PeerEvent e = new sun.awt.PeerEvent(source , updater , sun.awt.PeerEvent.ULTIMATE_PRIORITY_EVENT);
                    sun.awt.SunToolkit.postEvent(appContext, e);
                }
            }
        }
    }

    public boolean areExtraMouseButtonsEnabled() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        return java.awt.Toolkit.getDefaultToolkit().areExtraMouseButtonsEnabled();
    }
}


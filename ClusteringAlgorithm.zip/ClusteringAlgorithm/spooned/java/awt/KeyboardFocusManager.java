package java.awt;


public abstract class KeyboardFocusManager implements java.awt.KeyEventDispatcher , java.awt.KeyEventPostProcessor {
    private static final sun.util.logging.PlatformLogger focusLog = sun.util.logging.PlatformLogger.getLogger("java.awt.focus.KeyboardFocusManager");

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.KeyboardFocusManager.initIDs();
        } 
        sun.awt.AWTAccessor.setKeyboardFocusManagerAccessor(new sun.awt.AWTAccessor.KeyboardFocusManagerAccessor() {
            public int shouldNativelyFocusHeavyweight(java.awt.Component heavyweight, java.awt.Component descendant, boolean temporary, boolean focusedWindowChangeAllowed, long time, sun.awt.CausedFocusEvent.Cause cause) {
                return java.awt.KeyboardFocusManager.shouldNativelyFocusHeavyweight(heavyweight, descendant, temporary, focusedWindowChangeAllowed, time, cause);
            }

            public boolean processSynchronousLightweightTransfer(java.awt.Component heavyweight, java.awt.Component descendant, boolean temporary, boolean focusedWindowChangeAllowed, long time) {
                return java.awt.KeyboardFocusManager.processSynchronousLightweightTransfer(heavyweight, descendant, temporary, focusedWindowChangeAllowed, time);
            }

            public void removeLastFocusRequest(java.awt.Component heavyweight) {
                java.awt.KeyboardFocusManager.removeLastFocusRequest(heavyweight);
            }

            public void setMostRecentFocusOwner(java.awt.Window window, java.awt.Component component) {
                java.awt.KeyboardFocusManager.setMostRecentFocusOwner(window, component);
            }

            public java.awt.KeyboardFocusManager getCurrentKeyboardFocusManager(sun.awt.AppContext ctx) {
                return java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(ctx);
            }

            public java.awt.Container getCurrentFocusCycleRoot() {
                return java.awt.KeyboardFocusManager.currentFocusCycleRoot;
            }
        });
    }

    transient java.awt.peer.KeyboardFocusManagerPeer peer;

    private static native void initIDs();

    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.KeyboardFocusManager");

    public static final int FORWARD_TRAVERSAL_KEYS = 0;

    public static final int BACKWARD_TRAVERSAL_KEYS = 1;

    public static final int UP_CYCLE_TRAVERSAL_KEYS = 2;

    public static final int DOWN_CYCLE_TRAVERSAL_KEYS = 3;

    static final int TRAVERSAL_KEY_LENGTH = (java.awt.KeyboardFocusManager.DOWN_CYCLE_TRAVERSAL_KEYS) + 1;

    public static java.awt.KeyboardFocusManager getCurrentKeyboardFocusManager() {
        return java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(sun.awt.AppContext.getAppContext());
    }

    static synchronized java.awt.KeyboardFocusManager getCurrentKeyboardFocusManager(sun.awt.AppContext appcontext) {
        java.awt.KeyboardFocusManager manager = ((java.awt.KeyboardFocusManager)(appcontext.get(java.awt.KeyboardFocusManager.class)));
        if (manager == null) {
            manager = new java.awt.DefaultKeyboardFocusManager();
            appcontext.put(java.awt.KeyboardFocusManager.class, manager);
        } 
        return manager;
    }

    public static void setCurrentKeyboardFocusManager(java.awt.KeyboardFocusManager newManager) throws java.lang.SecurityException {
        java.awt.KeyboardFocusManager.checkReplaceKFMPermission();
        java.awt.KeyboardFocusManager oldManager = null;
        synchronized(java.awt.KeyboardFocusManager.class) {
            sun.awt.AppContext appcontext = sun.awt.AppContext.getAppContext();
            if (newManager != null) {
                oldManager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(appcontext);
                appcontext.put(java.awt.KeyboardFocusManager.class, newManager);
            } else {
                oldManager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(appcontext);
                appcontext.remove(java.awt.KeyboardFocusManager.class);
            }
        }
        if (oldManager != null) {
            oldManager.firePropertyChange("managingFocus", java.lang.Boolean.TRUE, java.lang.Boolean.FALSE);
        } 
        if (newManager != null) {
            newManager.firePropertyChange("managingFocus", java.lang.Boolean.FALSE, java.lang.Boolean.TRUE);
        } 
    }

    private static java.awt.Component focusOwner;

    private static java.awt.Component permanentFocusOwner;

    private static java.awt.Window focusedWindow;

    private static java.awt.Window activeWindow;

    private java.awt.FocusTraversalPolicy defaultPolicy = new java.awt.DefaultFocusTraversalPolicy();

    private static final java.lang.String[] defaultFocusTraversalKeyPropertyNames = new java.lang.String[]{ "forwardDefaultFocusTraversalKeys" , "backwardDefaultFocusTraversalKeys" , "upCycleDefaultFocusTraversalKeys" , "downCycleDefaultFocusTraversalKeys" };

    private static final java.awt.AWTKeyStroke[][] defaultFocusTraversalKeyStrokes = new java.awt.AWTKeyStroke[][]{ new java.awt.AWTKeyStroke[]{ java.awt.AWTKeyStroke.getAWTKeyStroke(java.awt.event.KeyEvent.VK_TAB, 0, false) , java.awt.AWTKeyStroke.getAWTKeyStroke(java.awt.event.KeyEvent.VK_TAB, ((java.awt.event.InputEvent.CTRL_DOWN_MASK) | (java.awt.event.InputEvent.CTRL_MASK)), false) } , new java.awt.AWTKeyStroke[]{ java.awt.AWTKeyStroke.getAWTKeyStroke(java.awt.event.KeyEvent.VK_TAB, ((java.awt.event.InputEvent.SHIFT_DOWN_MASK) | (java.awt.event.InputEvent.SHIFT_MASK)), false) , java.awt.AWTKeyStroke.getAWTKeyStroke(java.awt.event.KeyEvent.VK_TAB, ((((java.awt.event.InputEvent.SHIFT_DOWN_MASK) | (java.awt.event.InputEvent.SHIFT_MASK)) | (java.awt.event.InputEvent.CTRL_DOWN_MASK)) | (java.awt.event.InputEvent.CTRL_MASK)), false) } , new java.awt.AWTKeyStroke[]{  } , new java.awt.AWTKeyStroke[]{  } };

    private java.util.Set<java.awt.AWTKeyStroke>[] defaultFocusTraversalKeys = new java.util.Set[4];

    private static java.awt.Container currentFocusCycleRoot;

    private java.beans.VetoableChangeSupport vetoableSupport;

    private java.beans.PropertyChangeSupport changeSupport;

    private java.util.LinkedList<java.awt.KeyEventDispatcher> keyEventDispatchers;

    private java.util.LinkedList<java.awt.KeyEventPostProcessor> keyEventPostProcessors;

    private static java.util.Map<java.awt.Window, java.lang.ref.WeakReference<java.awt.Component>> mostRecentFocusOwners = new java.util.WeakHashMap<>();

    private static java.awt.AWTPermission replaceKeyboardFocusManagerPermission;

    transient java.awt.SequencedEvent currentSequencedEvent = null;

    final void setCurrentSequencedEvent(java.awt.SequencedEvent current) {
        synchronized(java.awt.SequencedEvent.class) {
            assert (current == null) || ((currentSequencedEvent) == null);
            currentSequencedEvent = current;
        }
    }

    final java.awt.SequencedEvent getCurrentSequencedEvent() {
        synchronized(java.awt.SequencedEvent.class) {
            return currentSequencedEvent;
        }
    }

    static java.util.Set<java.awt.AWTKeyStroke> initFocusTraversalKeysSet(java.lang.String value, java.util.Set<java.awt.AWTKeyStroke> targetSet) {
        java.util.StringTokenizer tokens = new java.util.StringTokenizer(value , ",");
        while (tokens.hasMoreTokens()) {
            targetSet.add(java.awt.AWTKeyStroke.getAWTKeyStroke(tokens.nextToken()));
        }
        return targetSet.isEmpty() ? java.util.Collections.EMPTY_SET : java.util.Collections.unmodifiableSet(targetSet);
    }

    public KeyboardFocusManager() {
        for (int i = 0 ; i < (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH) ; i++) {
            java.util.Set<java.awt.AWTKeyStroke> work_set = new java.util.HashSet<>();
            for (int j = 0 ; j < (java.awt.KeyboardFocusManager.defaultFocusTraversalKeyStrokes[i].length) ; j++) {
                work_set.add(java.awt.KeyboardFocusManager.defaultFocusTraversalKeyStrokes[i][j]);
            }
            defaultFocusTraversalKeys[i] = work_set.isEmpty() ? java.util.Collections.EMPTY_SET : java.util.Collections.unmodifiableSet(work_set);
        }
        initPeer();
    }

    private void initPeer() {
        java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
        sun.awt.KeyboardFocusManagerPeerProvider peerProvider = ((sun.awt.KeyboardFocusManagerPeerProvider)(tk));
        peer = peerProvider.getKeyboardFocusManagerPeer();
    }

    public java.awt.Component getFocusOwner() {
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((java.awt.KeyboardFocusManager.focusOwner) == null) {
                return null;
            } 
            return (java.awt.KeyboardFocusManager.focusOwner.appContext) == (sun.awt.AppContext.getAppContext()) ? java.awt.KeyboardFocusManager.focusOwner : null;
        }
    }

    protected java.awt.Component getGlobalFocusOwner() throws java.lang.SecurityException {
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            return java.awt.KeyboardFocusManager.focusOwner;
        }
    }

    protected void setGlobalFocusOwner(java.awt.Component focusOwner) throws java.lang.SecurityException {
        java.awt.Component oldFocusOwner = null;
        boolean shouldFire = false;
        if ((focusOwner == null) || (focusOwner.isFocusable())) {
            synchronized(java.awt.KeyboardFocusManager.class) {
                checkKFMSecurity();
                oldFocusOwner = getFocusOwner();
                try {
                    fireVetoableChange("focusOwner", oldFocusOwner, focusOwner);
                } catch (java.beans.PropertyVetoException e) {
                    return ;
                }
                java.awt.KeyboardFocusManager.focusOwner = focusOwner;
                if ((focusOwner != null) && (((getCurrentFocusCycleRoot()) == null) || (!(focusOwner.isFocusCycleRoot(getCurrentFocusCycleRoot()))))) {
                    java.awt.Container rootAncestor = focusOwner.getFocusCycleRootAncestor();
                    if ((rootAncestor == null) && (focusOwner instanceof java.awt.Window)) {
                        rootAncestor = ((java.awt.Container)(focusOwner));
                    } 
                    if (rootAncestor != null) {
                        setGlobalCurrentFocusCycleRootPriv(rootAncestor);
                    } 
                } 
                shouldFire = true;
            }
        } 
        if (shouldFire) {
            firePropertyChange("focusOwner", oldFocusOwner, focusOwner);
        } 
    }

    public void clearFocusOwner() {
        if ((getFocusOwner()) != null) {
            clearGlobalFocusOwner();
        } 
    }

    public void clearGlobalFocusOwner() throws java.lang.SecurityException {
        java.awt.KeyboardFocusManager.checkReplaceKFMPermission();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Toolkit.getDefaultToolkit();
            _clearGlobalFocusOwner();
        } 
    }

    private void _clearGlobalFocusOwner() {
        java.awt.Window activeWindow = java.awt.KeyboardFocusManager.markClearGlobalFocusOwner();
        peer.clearGlobalFocusOwner(activeWindow);
    }

    void clearGlobalFocusOwnerPriv() {
        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
            public java.lang.Void run() {
                clearGlobalFocusOwner();
                return null;
            }
        });
    }

    java.awt.Component getNativeFocusOwner() {
        return peer.getCurrentFocusOwner();
    }

    void setNativeFocusOwner(java.awt.Component comp) {
        if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.KeyboardFocusManager.focusLog.finest("Calling peer {0} setCurrentFocusOwner for {1}", java.lang.String.valueOf(peer), java.lang.String.valueOf(comp));
        } 
        peer.setCurrentFocusOwner(comp);
    }

    java.awt.Window getNativeFocusedWindow() {
        return peer.getCurrentFocusedWindow();
    }

    public java.awt.Component getPermanentFocusOwner() {
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((java.awt.KeyboardFocusManager.permanentFocusOwner) == null) {
                return null;
            } 
            return (java.awt.KeyboardFocusManager.permanentFocusOwner.appContext) == (sun.awt.AppContext.getAppContext()) ? java.awt.KeyboardFocusManager.permanentFocusOwner : null;
        }
    }

    protected java.awt.Component getGlobalPermanentFocusOwner() throws java.lang.SecurityException {
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            return java.awt.KeyboardFocusManager.permanentFocusOwner;
        }
    }

    protected void setGlobalPermanentFocusOwner(java.awt.Component permanentFocusOwner) throws java.lang.SecurityException {
        java.awt.Component oldPermanentFocusOwner = null;
        boolean shouldFire = false;
        if ((permanentFocusOwner == null) || (permanentFocusOwner.isFocusable())) {
            synchronized(java.awt.KeyboardFocusManager.class) {
                checkKFMSecurity();
                oldPermanentFocusOwner = getPermanentFocusOwner();
                try {
                    fireVetoableChange("permanentFocusOwner", oldPermanentFocusOwner, permanentFocusOwner);
                } catch (java.beans.PropertyVetoException e) {
                    return ;
                }
                java.awt.KeyboardFocusManager.permanentFocusOwner = permanentFocusOwner;
                java.awt.KeyboardFocusManager.setMostRecentFocusOwner(permanentFocusOwner);
                shouldFire = true;
            }
        } 
        if (shouldFire) {
            firePropertyChange("permanentFocusOwner", oldPermanentFocusOwner, permanentFocusOwner);
        } 
    }

    public java.awt.Window getFocusedWindow() {
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((java.awt.KeyboardFocusManager.focusedWindow) == null) {
                return null;
            } 
            return (java.awt.KeyboardFocusManager.focusedWindow.appContext) == (sun.awt.AppContext.getAppContext()) ? java.awt.KeyboardFocusManager.focusedWindow : null;
        }
    }

    protected java.awt.Window getGlobalFocusedWindow() throws java.lang.SecurityException {
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            return java.awt.KeyboardFocusManager.focusedWindow;
        }
    }

    protected void setGlobalFocusedWindow(java.awt.Window focusedWindow) throws java.lang.SecurityException {
        java.awt.Window oldFocusedWindow = null;
        boolean shouldFire = false;
        if ((focusedWindow == null) || (focusedWindow.isFocusableWindow())) {
            synchronized(java.awt.KeyboardFocusManager.class) {
                checkKFMSecurity();
                oldFocusedWindow = getFocusedWindow();
                try {
                    fireVetoableChange("focusedWindow", oldFocusedWindow, focusedWindow);
                } catch (java.beans.PropertyVetoException e) {
                    return ;
                }
                java.awt.KeyboardFocusManager.focusedWindow = focusedWindow;
                shouldFire = true;
            }
        } 
        if (shouldFire) {
            firePropertyChange("focusedWindow", oldFocusedWindow, focusedWindow);
        } 
    }

    public java.awt.Window getActiveWindow() {
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((java.awt.KeyboardFocusManager.activeWindow) == null) {
                return null;
            } 
            return (java.awt.KeyboardFocusManager.activeWindow.appContext) == (sun.awt.AppContext.getAppContext()) ? java.awt.KeyboardFocusManager.activeWindow : null;
        }
    }

    protected java.awt.Window getGlobalActiveWindow() throws java.lang.SecurityException {
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            return java.awt.KeyboardFocusManager.activeWindow;
        }
    }

    protected void setGlobalActiveWindow(java.awt.Window activeWindow) throws java.lang.SecurityException {
        java.awt.Window oldActiveWindow;
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            oldActiveWindow = getActiveWindow();
            if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                java.awt.KeyboardFocusManager.focusLog.finer(((("Setting global active window to " + activeWindow) + ", old active ") + oldActiveWindow));
            } 
            try {
                fireVetoableChange("activeWindow", oldActiveWindow, activeWindow);
            } catch (java.beans.PropertyVetoException e) {
                return ;
            }
            java.awt.KeyboardFocusManager.activeWindow = activeWindow;
        }
        firePropertyChange("activeWindow", oldActiveWindow, activeWindow);
    }

    public synchronized java.awt.FocusTraversalPolicy getDefaultFocusTraversalPolicy() {
        return defaultPolicy;
    }

    public void setDefaultFocusTraversalPolicy(java.awt.FocusTraversalPolicy defaultPolicy) {
        if (defaultPolicy == null) {
            throw new java.lang.IllegalArgumentException("default focus traversal policy cannot be null");
        } 
        java.awt.FocusTraversalPolicy oldPolicy;
        synchronized(java.awt.KeyboardFocusManager.this) {
            oldPolicy = java.awt.KeyboardFocusManager.this.defaultPolicy;
            java.awt.KeyboardFocusManager.this.defaultPolicy = defaultPolicy;
        }
        firePropertyChange("defaultFocusTraversalPolicy", oldPolicy, defaultPolicy);
    }

    public void setDefaultFocusTraversalKeys(int id, java.util.Set<? extends java.awt.AWTKeyStroke> keystrokes) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        if (keystrokes == null) {
            throw new java.lang.IllegalArgumentException("cannot set null Set of default focus traversal keys");
        } 
        java.util.Set<java.awt.AWTKeyStroke> oldKeys;
        synchronized(java.awt.KeyboardFocusManager.this) {
            for (java.awt.AWTKeyStroke keystroke : keystrokes) {
                if (keystroke == null) {
                    throw new java.lang.IllegalArgumentException("cannot set null focus traversal key");
                } 
                if ((keystroke.getKeyChar()) != (java.awt.event.KeyEvent.CHAR_UNDEFINED)) {
                    throw new java.lang.IllegalArgumentException("focus traversal keys cannot map to KEY_TYPED events");
                } 
                for (int i = 0 ; i < (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH) ; i++) {
                    if (i == id) {
                        continue;
                    } 
                    if (defaultFocusTraversalKeys[i].contains(keystroke)) {
                        throw new java.lang.IllegalArgumentException("focus traversal keys must be unique for a Component");
                    } 
                }
            }
            oldKeys = defaultFocusTraversalKeys[id];
            defaultFocusTraversalKeys[id] = java.util.Collections.unmodifiableSet(new java.util.HashSet<>(keystrokes));
        }
        firePropertyChange(java.awt.KeyboardFocusManager.defaultFocusTraversalKeyPropertyNames[id], oldKeys, keystrokes);
    }

    public java.util.Set<java.awt.AWTKeyStroke> getDefaultFocusTraversalKeys(int id) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        return defaultFocusTraversalKeys[id];
    }

    public java.awt.Container getCurrentFocusCycleRoot() {
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((java.awt.KeyboardFocusManager.currentFocusCycleRoot) == null) {
                return null;
            } 
            return (java.awt.KeyboardFocusManager.currentFocusCycleRoot.appContext) == (sun.awt.AppContext.getAppContext()) ? java.awt.KeyboardFocusManager.currentFocusCycleRoot : null;
        }
    }

    protected java.awt.Container getGlobalCurrentFocusCycleRoot() throws java.lang.SecurityException {
        synchronized(java.awt.KeyboardFocusManager.class) {
            checkKFMSecurity();
            return java.awt.KeyboardFocusManager.currentFocusCycleRoot;
        }
    }

    public void setGlobalCurrentFocusCycleRoot(java.awt.Container newFocusCycleRoot) throws java.lang.SecurityException {
        java.awt.KeyboardFocusManager.checkReplaceKFMPermission();
        java.awt.Container oldFocusCycleRoot;
        synchronized(java.awt.KeyboardFocusManager.class) {
            oldFocusCycleRoot = getCurrentFocusCycleRoot();
            java.awt.KeyboardFocusManager.currentFocusCycleRoot = newFocusCycleRoot;
        }
        firePropertyChange("currentFocusCycleRoot", oldFocusCycleRoot, newFocusCycleRoot);
    }

    void setGlobalCurrentFocusCycleRootPriv(final java.awt.Container newFocusCycleRoot) {
        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
            public java.lang.Void run() {
                setGlobalCurrentFocusCycleRoot(newFocusCycleRoot);
                return null;
            }
        });
    }

    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((changeSupport) == null) {
                    changeSupport = new java.beans.PropertyChangeSupport(java.awt.KeyboardFocusManager.this);
                } 
                changeSupport.addPropertyChangeListener(listener);
            }
        } 
    }

    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((changeSupport) != null) {
                    changeSupport.removePropertyChangeListener(listener);
                } 
            }
        } 
    }

    public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
        if ((changeSupport) == null) {
            changeSupport = new java.beans.PropertyChangeSupport(java.awt.KeyboardFocusManager.this);
        } 
        return changeSupport.getPropertyChangeListeners();
    }

    public void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((changeSupport) == null) {
                    changeSupport = new java.beans.PropertyChangeSupport(java.awt.KeyboardFocusManager.this);
                } 
                changeSupport.addPropertyChangeListener(propertyName, listener);
            }
        } 
    }

    public void removePropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((changeSupport) != null) {
                    changeSupport.removePropertyChangeListener(propertyName, listener);
                } 
            }
        } 
    }

    public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String propertyName) {
        if ((changeSupport) == null) {
            changeSupport = new java.beans.PropertyChangeSupport(java.awt.KeyboardFocusManager.this);
        } 
        return changeSupport.getPropertyChangeListeners(propertyName);
    }

    protected void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue) {
        if (oldValue == newValue) {
            return ;
        } 
        java.beans.PropertyChangeSupport changeSupport = java.awt.KeyboardFocusManager.this.changeSupport;
        if (changeSupport != null) {
            changeSupport.firePropertyChange(propertyName, oldValue, newValue);
        } 
    }

    public void addVetoableChangeListener(java.beans.VetoableChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((vetoableSupport) == null) {
                    vetoableSupport = new java.beans.VetoableChangeSupport(java.awt.KeyboardFocusManager.this);
                } 
                vetoableSupport.addVetoableChangeListener(listener);
            }
        } 
    }

    public void removeVetoableChangeListener(java.beans.VetoableChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((vetoableSupport) != null) {
                    vetoableSupport.removeVetoableChangeListener(listener);
                } 
            }
        } 
    }

    public synchronized java.beans.VetoableChangeListener[] getVetoableChangeListeners() {
        if ((vetoableSupport) == null) {
            vetoableSupport = new java.beans.VetoableChangeSupport(java.awt.KeyboardFocusManager.this);
        } 
        return vetoableSupport.getVetoableChangeListeners();
    }

    public void addVetoableChangeListener(java.lang.String propertyName, java.beans.VetoableChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((vetoableSupport) == null) {
                    vetoableSupport = new java.beans.VetoableChangeSupport(java.awt.KeyboardFocusManager.this);
                } 
                vetoableSupport.addVetoableChangeListener(propertyName, listener);
            }
        } 
    }

    public void removeVetoableChangeListener(java.lang.String propertyName, java.beans.VetoableChangeListener listener) {
        if (listener != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((vetoableSupport) != null) {
                    vetoableSupport.removeVetoableChangeListener(propertyName, listener);
                } 
            }
        } 
    }

    public synchronized java.beans.VetoableChangeListener[] getVetoableChangeListeners(java.lang.String propertyName) {
        if ((vetoableSupport) == null) {
            vetoableSupport = new java.beans.VetoableChangeSupport(java.awt.KeyboardFocusManager.this);
        } 
        return vetoableSupport.getVetoableChangeListeners(propertyName);
    }

    protected void fireVetoableChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue) throws java.beans.PropertyVetoException {
        if (oldValue == newValue) {
            return ;
        } 
        java.beans.VetoableChangeSupport vetoableSupport = java.awt.KeyboardFocusManager.this.vetoableSupport;
        if (vetoableSupport != null) {
            vetoableSupport.fireVetoableChange(propertyName, oldValue, newValue);
        } 
    }

    public void addKeyEventDispatcher(java.awt.KeyEventDispatcher dispatcher) {
        if (dispatcher != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((keyEventDispatchers) == null) {
                    keyEventDispatchers = new java.util.LinkedList<>();
                } 
                keyEventDispatchers.add(dispatcher);
            }
        } 
    }

    public void removeKeyEventDispatcher(java.awt.KeyEventDispatcher dispatcher) {
        if (dispatcher != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((keyEventDispatchers) != null) {
                    keyEventDispatchers.remove(dispatcher);
                } 
            }
        } 
    }

    protected synchronized java.util.List<java.awt.KeyEventDispatcher> getKeyEventDispatchers() {
        return (keyEventDispatchers) != null ? ((java.util.List)(keyEventDispatchers.clone())) : null;
    }

    public void addKeyEventPostProcessor(java.awt.KeyEventPostProcessor processor) {
        if (processor != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((keyEventPostProcessors) == null) {
                    keyEventPostProcessors = new java.util.LinkedList<>();
                } 
                keyEventPostProcessors.add(processor);
            }
        } 
    }

    public void removeKeyEventPostProcessor(java.awt.KeyEventPostProcessor processor) {
        if (processor != null) {
            synchronized(java.awt.KeyboardFocusManager.this) {
                if ((keyEventPostProcessors) != null) {
                    keyEventPostProcessors.remove(processor);
                } 
            }
        } 
    }

    protected java.util.List<java.awt.KeyEventPostProcessor> getKeyEventPostProcessors() {
        return (keyEventPostProcessors) != null ? ((java.util.List)(keyEventPostProcessors.clone())) : null;
    }

    static void setMostRecentFocusOwner(java.awt.Component component) {
        java.awt.Component window = component;
        while ((window != null) && (!(window instanceof java.awt.Window))) {
            window = window.parent;
        }
        if (window != null) {
            java.awt.KeyboardFocusManager.setMostRecentFocusOwner(((java.awt.Window)(window)), component);
        } 
    }

    static synchronized void setMostRecentFocusOwner(java.awt.Window window, java.awt.Component component) {
        java.lang.ref.WeakReference<java.awt.Component> weakValue = null;
        if (component != null) {
            weakValue = new java.lang.ref.WeakReference<>(component);
        } 
        java.awt.KeyboardFocusManager.mostRecentFocusOwners.put(window, weakValue);
    }

    static void clearMostRecentFocusOwner(java.awt.Component comp) {
        java.awt.Container window;
        if (comp == null) {
            return ;
        } 
        synchronized(comp.getTreeLock()) {
            window = comp.getParent();
            while ((window != null) && (!(window instanceof java.awt.Window))) {
                window = window.getParent();
            }
        }
        synchronized(java.awt.KeyboardFocusManager.class) {
            if ((window != null) && ((java.awt.KeyboardFocusManager.getMostRecentFocusOwner(((java.awt.Window)(window)))) == comp)) {
                java.awt.KeyboardFocusManager.setMostRecentFocusOwner(((java.awt.Window)(window)), null);
            } 
            if (window != null) {
                java.awt.Window realWindow = ((java.awt.Window)(window));
                if ((realWindow.getTemporaryLostComponent()) == comp) {
                    realWindow.setTemporaryLostComponent(null);
                } 
            } 
        }
    }

    static synchronized java.awt.Component getMostRecentFocusOwner(java.awt.Window window) {
        java.lang.ref.WeakReference<java.awt.Component> weakValue = ((java.lang.ref.WeakReference)(java.awt.KeyboardFocusManager.mostRecentFocusOwners.get(window)));
        return weakValue == null ? null : ((java.awt.Component)(weakValue.get()));
    }

    public abstract boolean dispatchEvent(java.awt.AWTEvent e);

    public final void redispatchEvent(java.awt.Component target, java.awt.AWTEvent e) {
        e.focusManagerIsDispatching = true;
        target.dispatchEvent(e);
        e.focusManagerIsDispatching = false;
    }

    public abstract boolean dispatchKeyEvent(java.awt.event.KeyEvent e);

    public abstract boolean postProcessKeyEvent(java.awt.event.KeyEvent e);

    public abstract void processKeyEvent(java.awt.Component focusedComponent, java.awt.event.KeyEvent e);

    protected abstract void enqueueKeyEvents(long after, java.awt.Component untilFocused);

    protected abstract void dequeueKeyEvents(long after, java.awt.Component untilFocused);

    protected abstract void discardKeyEvents(java.awt.Component comp);

    public abstract void focusNextComponent(java.awt.Component aComponent);

    public abstract void focusPreviousComponent(java.awt.Component aComponent);

    public abstract void upFocusCycle(java.awt.Component aComponent);

    public abstract void downFocusCycle(java.awt.Container aContainer);

    public final void focusNextComponent() {
        java.awt.Component focusOwner = getFocusOwner();
        if (focusOwner != null) {
            focusNextComponent(focusOwner);
        } 
    }

    public final void focusPreviousComponent() {
        java.awt.Component focusOwner = getFocusOwner();
        if (focusOwner != null) {
            focusPreviousComponent(focusOwner);
        } 
    }

    public final void upFocusCycle() {
        java.awt.Component focusOwner = getFocusOwner();
        if (focusOwner != null) {
            upFocusCycle(focusOwner);
        } 
    }

    public final void downFocusCycle() {
        java.awt.Component focusOwner = getFocusOwner();
        if (focusOwner instanceof java.awt.Container) {
            downFocusCycle(((java.awt.Container)(focusOwner)));
        } 
    }

    void dumpRequests() {
        java.lang.System.err.println((">>> Requests dump, time: " + (java.lang.System.currentTimeMillis())));
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            for (java.awt.KeyboardFocusManager.HeavyweightFocusRequest req : java.awt.KeyboardFocusManager.heavyweightRequests) {
                java.lang.System.err.println((">>> Req: " + req));
            }
        }
        java.lang.System.err.println("");
    }

    private static final class LightweightFocusRequest {
        final java.awt.Component component;

        final boolean temporary;

        final sun.awt.CausedFocusEvent.Cause cause;

        LightweightFocusRequest(java.awt.Component component ,boolean temporary ,sun.awt.CausedFocusEvent.Cause cause) {
            this.component = component;
            this.temporary = temporary;
            this.cause = cause;
        }

        public java.lang.String toString() {
            return ((((("LightweightFocusRequest[component=" + (component)) + ",temporary=") + (temporary)) + ", cause=") + (cause)) + "]";
        }
    }

    private static final class HeavyweightFocusRequest {
        final java.awt.Component heavyweight;

        final java.util.LinkedList<java.awt.KeyboardFocusManager.LightweightFocusRequest> lightweightRequests;

        static final java.awt.KeyboardFocusManager.HeavyweightFocusRequest CLEAR_GLOBAL_FOCUS_OWNER = new java.awt.KeyboardFocusManager.HeavyweightFocusRequest();

        private HeavyweightFocusRequest() {
            heavyweight = null;
            lightweightRequests = null;
        }

        HeavyweightFocusRequest(java.awt.Component heavyweight ,java.awt.Component descendant ,boolean temporary ,sun.awt.CausedFocusEvent.Cause cause) {
            if (java.awt.KeyboardFocusManager.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                if (heavyweight == null) {
                    java.awt.KeyboardFocusManager.log.fine("Assertion (heavyweight != null) failed");
                } 
            } 
            this.heavyweight = heavyweight;
            this.lightweightRequests = new java.util.LinkedList<java.awt.KeyboardFocusManager.LightweightFocusRequest>();
            addLightweightRequest(descendant, temporary, cause);
        }

        boolean addLightweightRequest(java.awt.Component descendant, boolean temporary, sun.awt.CausedFocusEvent.Cause cause) {
            if (java.awt.KeyboardFocusManager.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                if ((java.awt.KeyboardFocusManager.HeavyweightFocusRequest.this) == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                    java.awt.KeyboardFocusManager.log.fine("Assertion (this != HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER) failed");
                } 
                if (descendant == null) {
                    java.awt.KeyboardFocusManager.log.fine("Assertion (descendant != null) failed");
                } 
            } 
            java.awt.Component lastDescendant = (lightweightRequests.size()) > 0 ? lightweightRequests.getLast().component : null;
            if (descendant != lastDescendant) {
                lightweightRequests.add(new java.awt.KeyboardFocusManager.LightweightFocusRequest(descendant , temporary , cause));
                return true;
            } else {
                return false;
            }
        }

        java.awt.KeyboardFocusManager.LightweightFocusRequest getFirstLightweightRequest() {
            if ((java.awt.KeyboardFocusManager.HeavyweightFocusRequest.this) == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                return null;
            } 
            return lightweightRequests.getFirst();
        }

        public java.lang.String toString() {
            boolean first = true;
            java.lang.String str = ("HeavyweightFocusRequest[heavweight=" + (heavyweight)) + ",lightweightRequests=";
            if ((lightweightRequests) == null) {
                str += null;
            } else {
                str += "[";
                for (java.awt.KeyboardFocusManager.LightweightFocusRequest lwRequest : lightweightRequests) {
                    if (first) {
                        first = false;
                    } else {
                        str += ",";
                    }
                    str += lwRequest;
                }
                str += "]";
            }
            str += "]";
            return str;
        }
    }

    private static java.util.LinkedList<java.awt.KeyboardFocusManager.HeavyweightFocusRequest> heavyweightRequests = new java.util.LinkedList<java.awt.KeyboardFocusManager.HeavyweightFocusRequest>();

    private static java.util.LinkedList<java.awt.KeyboardFocusManager.LightweightFocusRequest> currentLightweightRequests;

    private static boolean clearingCurrentLightweightRequests;

    private static boolean allowSyncFocusRequests = true;

    private static java.awt.Component newFocusOwner = null;

    private static volatile boolean disableRestoreFocus;

    static final int SNFH_FAILURE = 0;

    static final int SNFH_SUCCESS_HANDLED = 1;

    static final int SNFH_SUCCESS_PROCEED = 2;

    static boolean processSynchronousLightweightTransfer(java.awt.Component heavyweight, java.awt.Component descendant, boolean temporary, boolean focusedWindowChangeAllowed, long time) {
        java.awt.Window parentWindow = sun.awt.SunToolkit.getContainingWindow(heavyweight);
        if ((parentWindow == null) || (!(parentWindow.syncLWRequests))) {
            return false;
        } 
        if (descendant == null) {
            descendant = heavyweight;
        } 
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(sun.awt.SunToolkit.targetToAppContext(descendant));
        java.awt.event.FocusEvent currentFocusOwnerEvent = null;
        java.awt.event.FocusEvent newFocusOwnerEvent = null;
        java.awt.Component currentFocusOwner = manager.getGlobalFocusOwner();
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getLastHWRequest();
            if (((hwFocusRequest == null) && (heavyweight == (manager.getNativeFocusOwner()))) && (java.awt.KeyboardFocusManager.allowSyncFocusRequests)) {
                if (descendant == currentFocusOwner) {
                    return true;
                } 
                manager.enqueueKeyEvents(time, descendant);
                hwFocusRequest = new java.awt.KeyboardFocusManager.HeavyweightFocusRequest(heavyweight , descendant , temporary , sun.awt.CausedFocusEvent.Cause.UNKNOWN);
                java.awt.KeyboardFocusManager.heavyweightRequests.add(hwFocusRequest);
                if (currentFocusOwner != null) {
                    currentFocusOwnerEvent = new java.awt.event.FocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , temporary , descendant);
                } 
                newFocusOwnerEvent = new java.awt.event.FocusEvent(descendant , java.awt.event.FocusEvent.FOCUS_GAINED , temporary , currentFocusOwner);
            } 
        }
        boolean result = false;
        final boolean clearing = java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests;
        java.lang.Throwable caughtEx = null;
        try {
            java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests = false;
            synchronized(java.awt.Component.LOCK) {
                if ((currentFocusOwnerEvent != null) && (currentFocusOwner != null)) {
                    ((java.awt.AWTEvent)(currentFocusOwnerEvent)).isPosted = true;
                    caughtEx = java.awt.KeyboardFocusManager.dispatchAndCatchException(caughtEx, currentFocusOwner, currentFocusOwnerEvent);
                    result = true;
                } 
                if ((newFocusOwnerEvent != null) && (descendant != null)) {
                    ((java.awt.AWTEvent)(newFocusOwnerEvent)).isPosted = true;
                    caughtEx = java.awt.KeyboardFocusManager.dispatchAndCatchException(caughtEx, descendant, newFocusOwnerEvent);
                    result = true;
                } 
            }
        } finally {
            java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests = clearing;
        }
        if (caughtEx instanceof java.lang.RuntimeException) {
            throw ((java.lang.RuntimeException)(caughtEx));
        } else if (caughtEx instanceof java.lang.Error) {
            throw ((java.lang.Error)(caughtEx));
        } 
        return result;
    }

    static int shouldNativelyFocusHeavyweight(java.awt.Component heavyweight, java.awt.Component descendant, boolean temporary, boolean focusedWindowChangeAllowed, long time, sun.awt.CausedFocusEvent.Cause cause) {
        if (java.awt.KeyboardFocusManager.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            if (heavyweight == null) {
                java.awt.KeyboardFocusManager.log.fine("Assertion (heavyweight != null) failed");
            } 
            if (time == 0) {
                java.awt.KeyboardFocusManager.log.fine("Assertion (time != 0) failed");
            } 
        } 
        if (descendant == null) {
            descendant = heavyweight;
        } 
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(sun.awt.SunToolkit.targetToAppContext(descendant));
        java.awt.KeyboardFocusManager thisManager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        java.awt.Component currentFocusOwner = thisManager.getGlobalFocusOwner();
        java.awt.Component nativeFocusOwner = thisManager.getNativeFocusOwner();
        java.awt.Window nativeFocusedWindow = thisManager.getNativeFocusedWindow();
        if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.KeyboardFocusManager.focusLog.finer("SNFH for {0} in {1}", java.lang.String.valueOf(descendant), java.lang.String.valueOf(heavyweight));
        } 
        if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.KeyboardFocusManager.focusLog.finest("0. Current focus owner {0}", java.lang.String.valueOf(currentFocusOwner));
            java.awt.KeyboardFocusManager.focusLog.finest("0. Native focus owner {0}", java.lang.String.valueOf(nativeFocusOwner));
            java.awt.KeyboardFocusManager.focusLog.finest("0. Native focused window {0}", java.lang.String.valueOf(nativeFocusedWindow));
        } 
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getLastHWRequest();
            if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.KeyboardFocusManager.focusLog.finest("Request {0}", java.lang.String.valueOf(hwFocusRequest));
            } 
            if (((hwFocusRequest == null) && (heavyweight == nativeFocusOwner)) && ((heavyweight.getContainingWindow()) == nativeFocusedWindow)) {
                if (descendant == currentFocusOwner) {
                    if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST))
                        java.awt.KeyboardFocusManager.focusLog.finest("1. SNFH_FAILURE for {0}", java.lang.String.valueOf(descendant));
                    
                    return java.awt.KeyboardFocusManager.SNFH_FAILURE;
                } 
                manager.enqueueKeyEvents(time, descendant);
                hwFocusRequest = new java.awt.KeyboardFocusManager.HeavyweightFocusRequest(heavyweight , descendant , temporary , cause);
                java.awt.KeyboardFocusManager.heavyweightRequests.add(hwFocusRequest);
                if (currentFocusOwner != null) {
                    java.awt.event.FocusEvent currentFocusOwnerEvent = new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , temporary , descendant , cause);
                    sun.awt.SunToolkit.postEvent(currentFocusOwner.appContext, currentFocusOwnerEvent);
                } 
                java.awt.event.FocusEvent newFocusOwnerEvent = new sun.awt.CausedFocusEvent(descendant , java.awt.event.FocusEvent.FOCUS_GAINED , temporary , currentFocusOwner , cause);
                sun.awt.SunToolkit.postEvent(descendant.appContext, newFocusOwnerEvent);
                if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST))
                    java.awt.KeyboardFocusManager.focusLog.finest("2. SNFH_HANDLED for {0}", java.lang.String.valueOf(descendant));
                
                return java.awt.KeyboardFocusManager.SNFH_SUCCESS_HANDLED;
            } else if ((hwFocusRequest != null) && ((hwFocusRequest.heavyweight) == heavyweight)) {
                if (hwFocusRequest.addLightweightRequest(descendant, temporary, cause)) {
                    manager.enqueueKeyEvents(time, descendant);
                } 
                if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.KeyboardFocusManager.focusLog.finest(((("3. SNFH_HANDLED for lightweight" + descendant) + " in ") + heavyweight));
                } 
                return java.awt.KeyboardFocusManager.SNFH_SUCCESS_HANDLED;
            } else {
                if (!focusedWindowChangeAllowed) {
                    if (hwFocusRequest == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                        int size = java.awt.KeyboardFocusManager.heavyweightRequests.size();
                        hwFocusRequest = ((java.awt.KeyboardFocusManager.HeavyweightFocusRequest)(size >= 2 ? java.awt.KeyboardFocusManager.heavyweightRequests.get((size - 2)) : null));
                    } 
                    if (java.awt.KeyboardFocusManager.focusedWindowChanged(heavyweight, (hwFocusRequest != null ? hwFocusRequest.heavyweight : nativeFocusedWindow))) {
                        if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                            java.awt.KeyboardFocusManager.focusLog.finest(("4. SNFH_FAILURE for " + descendant));
                        } 
                        return java.awt.KeyboardFocusManager.SNFH_FAILURE;
                    } 
                } 
                manager.enqueueKeyEvents(time, descendant);
                java.awt.KeyboardFocusManager.heavyweightRequests.add(new java.awt.KeyboardFocusManager.HeavyweightFocusRequest(heavyweight , descendant , temporary , cause));
                if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.KeyboardFocusManager.focusLog.finest(("5. SNFH_PROCEED for " + descendant));
                } 
                return java.awt.KeyboardFocusManager.SNFH_SUCCESS_PROCEED;
            }
        }
    }

    static java.awt.Window markClearGlobalFocusOwner() {
        final java.awt.Component nativeFocusedWindow = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getNativeFocusedWindow();
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getLastHWRequest();
            if (hwFocusRequest == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                return null;
            } 
            java.awt.KeyboardFocusManager.heavyweightRequests.add(java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER);
            java.awt.Component activeWindow = hwFocusRequest != null ? sun.awt.SunToolkit.getContainingWindow(hwFocusRequest.heavyweight) : nativeFocusedWindow;
            while ((activeWindow != null) && (!((activeWindow instanceof java.awt.Frame) || (activeWindow instanceof java.awt.Dialog)))) {
                activeWindow = activeWindow.getParent_NoClientCode();
            }
            return ((java.awt.Window)(activeWindow));
        }
    }

    java.awt.Component getCurrentWaitingRequest(java.awt.Component parent) {
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getFirstHWRequest();
            if (hwFocusRequest != null) {
                if ((hwFocusRequest.heavyweight) == parent) {
                    java.awt.KeyboardFocusManager.LightweightFocusRequest lwFocusRequest = hwFocusRequest.lightweightRequests.getFirst();
                    if (lwFocusRequest != null) {
                        return lwFocusRequest.component;
                    } 
                } 
            } 
        }
        return null;
    }

    static boolean isAutoFocusTransferEnabled() {
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            return (((java.awt.KeyboardFocusManager.heavyweightRequests.size()) == 0) && (!(java.awt.KeyboardFocusManager.disableRestoreFocus))) && (null == (java.awt.KeyboardFocusManager.currentLightweightRequests));
        }
    }

    static boolean isAutoFocusTransferEnabledFor(java.awt.Component comp) {
        return (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled()) && (comp.isAutoFocusTransferOnDisposal());
    }

    private static java.lang.Throwable dispatchAndCatchException(java.lang.Throwable ex, java.awt.Component comp, java.awt.event.FocusEvent event) {
        java.lang.Throwable retEx = null;
        try {
            comp.dispatchEvent(event);
        } catch (java.lang.RuntimeException re) {
            retEx = re;
        } catch (java.lang.Error er) {
            retEx = er;
        }
        if (retEx != null) {
            if (ex != null) {
                java.awt.KeyboardFocusManager.handleException(ex);
            } 
            return retEx;
        } 
        return ex;
    }

    private static void handleException(java.lang.Throwable ex) {
        ex.printStackTrace();
    }

    static void processCurrentLightweightRequests() {
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        java.util.LinkedList<java.awt.KeyboardFocusManager.LightweightFocusRequest> localLightweightRequests = null;
        java.awt.Component globalFocusOwner = manager.getGlobalFocusOwner();
        if ((globalFocusOwner != null) && ((globalFocusOwner.appContext) != (sun.awt.AppContext.getAppContext()))) {
            return ;
        } 
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            if ((java.awt.KeyboardFocusManager.currentLightweightRequests) != null) {
                java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests = true;
                java.awt.KeyboardFocusManager.disableRestoreFocus = true;
                localLightweightRequests = java.awt.KeyboardFocusManager.currentLightweightRequests;
                java.awt.KeyboardFocusManager.allowSyncFocusRequests = (localLightweightRequests.size()) < 2;
                java.awt.KeyboardFocusManager.currentLightweightRequests = null;
            } else {
                return ;
            }
        }
        java.lang.Throwable caughtEx = null;
        try {
            if (localLightweightRequests != null) {
                java.awt.Component lastFocusOwner = null;
                java.awt.Component currentFocusOwner = null;
                for (java.util.Iterator<java.awt.KeyboardFocusManager.LightweightFocusRequest> iter = localLightweightRequests.iterator() ; iter.hasNext() ; ) {
                    currentFocusOwner = manager.getGlobalFocusOwner();
                    java.awt.KeyboardFocusManager.LightweightFocusRequest lwFocusRequest = iter.next();
                    if (!(iter.hasNext())) {
                        java.awt.KeyboardFocusManager.disableRestoreFocus = false;
                    } 
                    java.awt.event.FocusEvent currentFocusOwnerEvent = null;
                    if (currentFocusOwner != null) {
                        currentFocusOwnerEvent = new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , lwFocusRequest.temporary , lwFocusRequest.component , lwFocusRequest.cause);
                    } 
                    java.awt.event.FocusEvent newFocusOwnerEvent = new sun.awt.CausedFocusEvent(lwFocusRequest.component , java.awt.event.FocusEvent.FOCUS_GAINED , lwFocusRequest.temporary , (currentFocusOwner == null ? lastFocusOwner : currentFocusOwner) , lwFocusRequest.cause);
                    if (currentFocusOwner != null) {
                        ((java.awt.AWTEvent)(currentFocusOwnerEvent)).isPosted = true;
                        caughtEx = java.awt.KeyboardFocusManager.dispatchAndCatchException(caughtEx, currentFocusOwner, currentFocusOwnerEvent);
                    } 
                    ((java.awt.AWTEvent)(newFocusOwnerEvent)).isPosted = true;
                    caughtEx = java.awt.KeyboardFocusManager.dispatchAndCatchException(caughtEx, lwFocusRequest.component, newFocusOwnerEvent);
                    if ((manager.getGlobalFocusOwner()) == (lwFocusRequest.component)) {
                        lastFocusOwner = lwFocusRequest.component;
                    } 
                }
            } 
        } finally {
            java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests = false;
            java.awt.KeyboardFocusManager.disableRestoreFocus = false;
            localLightweightRequests = null;
            java.awt.KeyboardFocusManager.allowSyncFocusRequests = true;
        }
        if (caughtEx instanceof java.lang.RuntimeException) {
            throw ((java.lang.RuntimeException)(caughtEx));
        } else if (caughtEx instanceof java.lang.Error) {
            throw ((java.lang.Error)(caughtEx));
        } 
    }

    static java.awt.event.FocusEvent retargetUnexpectedFocusEvent(java.awt.event.FocusEvent fe) {
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            if (java.awt.KeyboardFocusManager.removeFirstRequest()) {
                return ((java.awt.event.FocusEvent)(java.awt.KeyboardFocusManager.retargetFocusEvent(fe)));
            } 
            java.awt.Component source = fe.getComponent();
            java.awt.Component opposite = fe.getOppositeComponent();
            boolean temporary = false;
            if (((fe.getID()) == (java.awt.event.FocusEvent.FOCUS_LOST)) && ((opposite == null) || (java.awt.KeyboardFocusManager.isTemporary(opposite, source)))) {
                temporary = true;
            } 
            return new sun.awt.CausedFocusEvent(source , fe.getID() , temporary , opposite , sun.awt.CausedFocusEvent.Cause.NATIVE_SYSTEM);
        }
    }

    static java.awt.event.FocusEvent retargetFocusGained(java.awt.event.FocusEvent fe) {
        assert (fe.getID()) == (java.awt.event.FocusEvent.FOCUS_GAINED);
        java.awt.Component currentFocusOwner = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getGlobalFocusOwner();
        java.awt.Component source = fe.getComponent();
        java.awt.Component opposite = fe.getOppositeComponent();
        java.awt.Component nativeSource = java.awt.KeyboardFocusManager.getHeavyweight(source);
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getFirstHWRequest();
            if (hwFocusRequest == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                return java.awt.KeyboardFocusManager.retargetUnexpectedFocusEvent(fe);
            } 
            if (((source != null) && (nativeSource == null)) && (hwFocusRequest != null)) {
                if (source == (hwFocusRequest.getFirstLightweightRequest().component)) {
                    source = hwFocusRequest.heavyweight;
                    nativeSource = source;
                } 
            } 
            if ((hwFocusRequest != null) && (nativeSource == (hwFocusRequest.heavyweight))) {
                java.awt.KeyboardFocusManager.heavyweightRequests.removeFirst();
                java.awt.KeyboardFocusManager.LightweightFocusRequest lwFocusRequest = hwFocusRequest.lightweightRequests.removeFirst();
                java.awt.Component newSource = lwFocusRequest.component;
                if (currentFocusOwner != null) {
                    java.awt.KeyboardFocusManager.newFocusOwner = newSource;
                } 
                boolean temporary = (opposite == null) || (java.awt.KeyboardFocusManager.isTemporary(newSource, opposite)) ? false : lwFocusRequest.temporary;
                if ((hwFocusRequest.lightweightRequests.size()) > 0) {
                    java.awt.KeyboardFocusManager.currentLightweightRequests = hwFocusRequest.lightweightRequests;
                    java.awt.EventQueue.invokeLater(new java.lang.Runnable() {
                        public void run() {
                            java.awt.KeyboardFocusManager.processCurrentLightweightRequests();
                        }
                    });
                } 
                return new sun.awt.CausedFocusEvent(newSource , java.awt.event.FocusEvent.FOCUS_GAINED , temporary , opposite , lwFocusRequest.cause);
            } 
            if (((currentFocusOwner != null) && ((currentFocusOwner.getContainingWindow()) == source)) && ((hwFocusRequest == null) || (source != (hwFocusRequest.heavyweight)))) {
                return new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_GAINED , false , null , sun.awt.CausedFocusEvent.Cause.ACTIVATION);
            } 
            return java.awt.KeyboardFocusManager.retargetUnexpectedFocusEvent(fe);
        }
    }

    static java.awt.event.FocusEvent retargetFocusLost(java.awt.event.FocusEvent fe) {
        assert (fe.getID()) == (java.awt.event.FocusEvent.FOCUS_LOST);
        java.awt.Component currentFocusOwner = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getGlobalFocusOwner();
        java.awt.Component opposite = fe.getOppositeComponent();
        java.awt.Component nativeOpposite = java.awt.KeyboardFocusManager.getHeavyweight(opposite);
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getFirstHWRequest();
            if (hwFocusRequest == (java.awt.KeyboardFocusManager.HeavyweightFocusRequest.CLEAR_GLOBAL_FOCUS_OWNER)) {
                if (currentFocusOwner != null) {
                    java.awt.KeyboardFocusManager.heavyweightRequests.removeFirst();
                    return new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , false , null , sun.awt.CausedFocusEvent.Cause.CLEAR_GLOBAL_FOCUS_OWNER);
                } 
            } else if (opposite == null) {
                if (currentFocusOwner != null) {
                    return new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , true , null , sun.awt.CausedFocusEvent.Cause.ACTIVATION);
                } else {
                    return fe;
                }
            } else if ((hwFocusRequest != null) && ((nativeOpposite == (hwFocusRequest.heavyweight)) || ((nativeOpposite == null) && (opposite == (hwFocusRequest.getFirstLightweightRequest().component))))) {
                if (currentFocusOwner == null) {
                    return fe;
                } 
                java.awt.KeyboardFocusManager.LightweightFocusRequest lwFocusRequest = hwFocusRequest.lightweightRequests.getFirst();
                boolean temporary = java.awt.KeyboardFocusManager.isTemporary(opposite, currentFocusOwner) ? true : lwFocusRequest.temporary;
                return new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , temporary , lwFocusRequest.component , lwFocusRequest.cause);
            } else if (java.awt.KeyboardFocusManager.focusedWindowChanged(opposite, currentFocusOwner)) {
                if ((!(fe.isTemporary())) && (currentFocusOwner != null)) {
                    fe = new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , true , opposite , sun.awt.CausedFocusEvent.Cause.ACTIVATION);
                } 
                return fe;
            } 
            return java.awt.KeyboardFocusManager.retargetUnexpectedFocusEvent(fe);
        }
    }

    static java.awt.AWTEvent retargetFocusEvent(java.awt.AWTEvent event) {
        if (java.awt.KeyboardFocusManager.clearingCurrentLightweightRequests) {
            return event;
        } 
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        if (java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            if ((event instanceof java.awt.event.FocusEvent) || (event instanceof java.awt.event.WindowEvent)) {
                java.awt.KeyboardFocusManager.focusLog.finer(">>> {0}", java.lang.String.valueOf(event));
            } 
            if ((java.awt.KeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) && (event instanceof java.awt.event.KeyEvent)) {
                java.awt.KeyboardFocusManager.focusLog.finer("    focus owner is {0}", java.lang.String.valueOf(manager.getGlobalFocusOwner()));
                java.awt.KeyboardFocusManager.focusLog.finer(">>> {0}", java.lang.String.valueOf(event));
            } 
        } 
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            if (((java.awt.KeyboardFocusManager.newFocusOwner) != null) && ((event.getID()) == (java.awt.event.FocusEvent.FOCUS_LOST))) {
                java.awt.event.FocusEvent fe = ((java.awt.event.FocusEvent)(event));
                if (((manager.getGlobalFocusOwner()) == (fe.getComponent())) && ((fe.getOppositeComponent()) == (java.awt.KeyboardFocusManager.newFocusOwner))) {
                    java.awt.KeyboardFocusManager.newFocusOwner = null;
                    return event;
                } 
            } 
        }
        java.awt.KeyboardFocusManager.processCurrentLightweightRequests();
        switch (event.getID()) {
            case java.awt.event.FocusEvent.FOCUS_GAINED :
                {
                    event = java.awt.KeyboardFocusManager.retargetFocusGained(((java.awt.event.FocusEvent)(event)));
                    break;
                }
            case java.awt.event.FocusEvent.FOCUS_LOST :
                {
                    event = java.awt.KeyboardFocusManager.retargetFocusLost(((java.awt.event.FocusEvent)(event)));
                    break;
                }
            default :
        }
        return event;
    }

    void clearMarkers() {
    }

    static boolean removeFirstRequest() {
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getFirstHWRequest();
            if (hwFocusRequest != null) {
                java.awt.KeyboardFocusManager.heavyweightRequests.removeFirst();
                if ((hwFocusRequest.lightweightRequests) != null) {
                    for (java.util.Iterator<java.awt.KeyboardFocusManager.LightweightFocusRequest> lwIter = hwFocusRequest.lightweightRequests.iterator() ; lwIter.hasNext() ; ) {
                        manager.dequeueKeyEvents((-1), lwIter.next().component);
                    }
                } 
            } 
            if ((java.awt.KeyboardFocusManager.heavyweightRequests.size()) == 0) {
                manager.clearMarkers();
            } 
            return (java.awt.KeyboardFocusManager.heavyweightRequests.size()) > 0;
        }
    }

    static void removeLastFocusRequest(java.awt.Component heavyweight) {
        if (java.awt.KeyboardFocusManager.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            if (heavyweight == null) {
                java.awt.KeyboardFocusManager.log.fine("Assertion (heavyweight != null) failed");
            } 
        } 
        java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            java.awt.KeyboardFocusManager.HeavyweightFocusRequest hwFocusRequest = java.awt.KeyboardFocusManager.getLastHWRequest();
            if ((hwFocusRequest != null) && ((hwFocusRequest.heavyweight) == heavyweight)) {
                java.awt.KeyboardFocusManager.heavyweightRequests.removeLast();
            } 
            if ((java.awt.KeyboardFocusManager.heavyweightRequests.size()) == 0) {
                manager.clearMarkers();
            } 
        }
    }

    private static boolean focusedWindowChanged(java.awt.Component to, java.awt.Component from) {
        java.awt.Window wto = sun.awt.SunToolkit.getContainingWindow(to);
        java.awt.Window wfrom = sun.awt.SunToolkit.getContainingWindow(from);
        if ((wto == null) && (wfrom == null)) {
            return true;
        } 
        if (wto == null) {
            return true;
        } 
        if (wfrom == null) {
            return true;
        } 
        return wto != wfrom;
    }

    private static boolean isTemporary(java.awt.Component to, java.awt.Component from) {
        java.awt.Window wto = sun.awt.SunToolkit.getContainingWindow(to);
        java.awt.Window wfrom = sun.awt.SunToolkit.getContainingWindow(from);
        if ((wto == null) && (wfrom == null)) {
            return false;
        } 
        if (wto == null) {
            return true;
        } 
        if (wfrom == null) {
            return false;
        } 
        return wto != wfrom;
    }

    static java.awt.Component getHeavyweight(java.awt.Component comp) {
        if ((comp == null) || ((comp.getPeer()) == null)) {
            return null;
        } else if ((comp.getPeer()) instanceof java.awt.peer.LightweightPeer) {
            return comp.getNativeContainer();
        } else {
            return comp;
        }
    }

    static java.lang.reflect.Field proxyActive;

    private static boolean isProxyActiveImpl(java.awt.event.KeyEvent e) {
        if ((java.awt.KeyboardFocusManager.proxyActive) == null) {
            java.awt.KeyboardFocusManager.proxyActive = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.reflect.Field>() {
                public java.lang.reflect.Field run() {
                    java.lang.reflect.Field field = null;
                    try {
                        field = java.awt.event.KeyEvent.class.getDeclaredField("isProxyActive");
                        if (field != null) {
                            field.setAccessible(true);
                        } 
                    } catch (java.lang.NoSuchFieldException nsf) {
                        assert false;
                    }
                    return field;
                }
            });
        } 
        try {
            return java.awt.KeyboardFocusManager.proxyActive.getBoolean(e);
        } catch (java.lang.IllegalAccessException iae) {
            assert false;
        }
        return false;
    }

    static boolean isProxyActive(java.awt.event.KeyEvent e) {
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            return java.awt.KeyboardFocusManager.isProxyActiveImpl(e);
        } else {
            return false;
        }
    }

    private static java.awt.KeyboardFocusManager.HeavyweightFocusRequest getLastHWRequest() {
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            return (java.awt.KeyboardFocusManager.heavyweightRequests.size()) > 0 ? java.awt.KeyboardFocusManager.heavyweightRequests.getLast() : null;
        }
    }

    private static java.awt.KeyboardFocusManager.HeavyweightFocusRequest getFirstHWRequest() {
        synchronized(java.awt.KeyboardFocusManager.heavyweightRequests) {
            return (java.awt.KeyboardFocusManager.heavyweightRequests.size()) > 0 ? java.awt.KeyboardFocusManager.heavyweightRequests.getFirst() : null;
        }
    }

    private static void checkReplaceKFMPermission() throws java.lang.SecurityException {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            if ((java.awt.KeyboardFocusManager.replaceKeyboardFocusManagerPermission) == null) {
                java.awt.KeyboardFocusManager.replaceKeyboardFocusManagerPermission = new java.awt.AWTPermission("replaceKeyboardFocusManager");
            } 
            security.checkPermission(java.awt.KeyboardFocusManager.replaceKeyboardFocusManagerPermission);
        } 
    }

    private void checkKFMSecurity() throws java.lang.SecurityException {
        if ((java.awt.KeyboardFocusManager.this) != (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager())) {
            java.awt.KeyboardFocusManager.checkReplaceKFMPermission();
        } 
    }
}


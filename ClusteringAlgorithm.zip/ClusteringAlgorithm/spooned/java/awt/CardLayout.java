package java.awt;


public class CardLayout implements java.awt.LayoutManager2 , java.io.Serializable {
    private static final long serialVersionUID = -4328196481005934313L;

    java.util.Vector<java.awt.CardLayout.Card> vector = new java.util.Vector<>();

    class Card implements java.io.Serializable {
        static final long serialVersionUID = 6640330810709497518L;

        public java.lang.String name;

        public java.awt.Component comp;

        public Card(java.lang.String cardName ,java.awt.Component cardComponent) {
            name = cardName;
            comp = cardComponent;
        }
    }

    int currentCard = 0;

    int hgap;

    int vgap;

    private static final java.io.ObjectStreamField[] serialPersistentFields = new java.io.ObjectStreamField[]{ new java.io.ObjectStreamField("tab" , java.util.Hashtable.class) , new java.io.ObjectStreamField("hgap" , java.lang.Integer.TYPE) , new java.io.ObjectStreamField("vgap" , java.lang.Integer.TYPE) , new java.io.ObjectStreamField("vector" , java.util.Vector.class) , new java.io.ObjectStreamField("currentCard" , java.lang.Integer.TYPE) };

    public CardLayout() {
        this(0, 0);
    }

    public CardLayout(int hgap ,int vgap) {
        java.awt.CardLayout.this.hgap = hgap;
        java.awt.CardLayout.this.vgap = vgap;
    }

    public int getHgap() {
        return hgap;
    }

    public void setHgap(int hgap) {
        java.awt.CardLayout.this.hgap = hgap;
    }

    public int getVgap() {
        return vgap;
    }

    public void setVgap(int vgap) {
        java.awt.CardLayout.this.vgap = vgap;
    }

    public void addLayoutComponent(java.awt.Component comp, java.lang.Object constraints) {
        synchronized(comp.getTreeLock()) {
            if (constraints == null) {
                constraints = "";
            } 
            if (constraints instanceof java.lang.String) {
                addLayoutComponent(((java.lang.String)(constraints)), comp);
            } else {
                throw new java.lang.IllegalArgumentException("cannot add to layout: constraint must be a string");
            }
        }
    }

    @java.lang.Deprecated
    public void addLayoutComponent(java.lang.String name, java.awt.Component comp) {
        synchronized(comp.getTreeLock()) {
            if (!(vector.isEmpty())) {
                comp.setVisible(false);
            } 
            for (int i = 0 ; i < (vector.size()) ; i++) {
                if (((java.awt.CardLayout.Card)(vector.get(i))).name.equals(name)) {
                    ((java.awt.CardLayout.Card)(vector.get(i))).comp = comp;
                    return ;
                } 
            }
            vector.add(new java.awt.CardLayout.Card(name , comp));
        }
    }

    public void removeLayoutComponent(java.awt.Component comp) {
        synchronized(comp.getTreeLock()) {
            for (int i = 0 ; i < (vector.size()) ; i++) {
                if ((((java.awt.CardLayout.Card)(vector.get(i))).comp) == comp) {
                    if ((comp.isVisible()) && ((comp.getParent()) != null)) {
                        next(comp.getParent());
                    } 
                    vector.remove(i);
                    if ((currentCard) > i) {
                        (currentCard)--;
                    } 
                    break;
                } 
            }
        }
    }

    public java.awt.Dimension preferredLayoutSize(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            java.awt.Insets insets = parent.getInsets();
            int ncomponents = parent.getComponentCount();
            int w = 0;
            int h = 0;
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                java.awt.Dimension d = comp.getPreferredSize();
                if ((d.width) > w) {
                    w = d.width;
                } 
                if ((d.height) > h) {
                    h = d.height;
                } 
            }
            return new java.awt.Dimension(((((insets.left) + (insets.right)) + w) + ((hgap) * 2)) , ((((insets.top) + (insets.bottom)) + h) + ((vgap) * 2)));
        }
    }

    public java.awt.Dimension minimumLayoutSize(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            java.awt.Insets insets = parent.getInsets();
            int ncomponents = parent.getComponentCount();
            int w = 0;
            int h = 0;
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                java.awt.Dimension d = comp.getMinimumSize();
                if ((d.width) > w) {
                    w = d.width;
                } 
                if ((d.height) > h) {
                    h = d.height;
                } 
            }
            return new java.awt.Dimension(((((insets.left) + (insets.right)) + w) + ((hgap) * 2)) , ((((insets.top) + (insets.bottom)) + h) + ((vgap) * 2)));
        }
    }

    public java.awt.Dimension maximumLayoutSize(java.awt.Container target) {
        return new java.awt.Dimension(java.lang.Integer.MAX_VALUE , java.lang.Integer.MAX_VALUE);
    }

    public float getLayoutAlignmentX(java.awt.Container parent) {
        return 0.5F;
    }

    public float getLayoutAlignmentY(java.awt.Container parent) {
        return 0.5F;
    }

    public void invalidateLayout(java.awt.Container target) {
    }

    public void layoutContainer(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            java.awt.Insets insets = parent.getInsets();
            int ncomponents = parent.getComponentCount();
            java.awt.Component comp = null;
            boolean currentFound = false;
            for (int i = 0 ; i < ncomponents ; i++) {
                comp = parent.getComponent(i);
                comp.setBounds(((hgap) + (insets.left)), ((vgap) + (insets.top)), ((parent.width) - ((((hgap) * 2) + (insets.left)) + (insets.right))), ((parent.height) - ((((vgap) * 2) + (insets.top)) + (insets.bottom))));
                if (comp.isVisible()) {
                    currentFound = true;
                } 
            }
            if ((!currentFound) && (ncomponents > 0)) {
                parent.getComponent(0).setVisible(true);
            } 
        }
    }

    void checkLayout(java.awt.Container parent) {
        if ((parent.getLayout()) != (java.awt.CardLayout.this)) {
            throw new java.lang.IllegalArgumentException("wrong parent for CardLayout");
        } 
    }

    public void first(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            checkLayout(parent);
            int ncomponents = parent.getComponentCount();
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                if (comp.isVisible()) {
                    comp.setVisible(false);
                    break;
                } 
            }
            if (ncomponents > 0) {
                currentCard = 0;
                parent.getComponent(0).setVisible(true);
                parent.validate();
            } 
        }
    }

    public void next(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            checkLayout(parent);
            int ncomponents = parent.getComponentCount();
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                if (comp.isVisible()) {
                    comp.setVisible(false);
                    currentCard = (i + 1) % ncomponents;
                    comp = parent.getComponent(currentCard);
                    comp.setVisible(true);
                    parent.validate();
                    return ;
                } 
            }
            showDefaultComponent(parent);
        }
    }

    public void previous(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            checkLayout(parent);
            int ncomponents = parent.getComponentCount();
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                if (comp.isVisible()) {
                    comp.setVisible(false);
                    currentCard = i > 0 ? i - 1 : ncomponents - 1;
                    comp = parent.getComponent(currentCard);
                    comp.setVisible(true);
                    parent.validate();
                    return ;
                } 
            }
            showDefaultComponent(parent);
        }
    }

    void showDefaultComponent(java.awt.Container parent) {
        if ((parent.getComponentCount()) > 0) {
            currentCard = 0;
            parent.getComponent(0).setVisible(true);
            parent.validate();
        } 
    }

    public void last(java.awt.Container parent) {
        synchronized(parent.getTreeLock()) {
            checkLayout(parent);
            int ncomponents = parent.getComponentCount();
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.Component comp = parent.getComponent(i);
                if (comp.isVisible()) {
                    comp.setVisible(false);
                    break;
                } 
            }
            if (ncomponents > 0) {
                currentCard = ncomponents - 1;
                parent.getComponent(currentCard).setVisible(true);
                parent.validate();
            } 
        }
    }

    public void show(java.awt.Container parent, java.lang.String name) {
        synchronized(parent.getTreeLock()) {
            checkLayout(parent);
            java.awt.Component next = null;
            int ncomponents = vector.size();
            for (int i = 0 ; i < ncomponents ; i++) {
                java.awt.CardLayout.Card card = ((java.awt.CardLayout.Card)(vector.get(i)));
                if (card.name.equals(name)) {
                    next = card.comp;
                    currentCard = i;
                    break;
                } 
            }
            if ((next != null) && (!(next.isVisible()))) {
                ncomponents = parent.getComponentCount();
                for (int i = 0 ; i < ncomponents ; i++) {
                    java.awt.Component comp = parent.getComponent(i);
                    if (comp.isVisible()) {
                        comp.setVisible(false);
                        break;
                    } 
                }
                next.setVisible(true);
                parent.validate();
            } 
        }
    }

    public java.lang.String toString() {
        return (((((getClass().getName()) + "[hgap=") + (hgap)) + ",vgap=") + (vgap)) + "]";
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        java.io.ObjectInputStream.GetField f = s.readFields();
        hgap = f.get("hgap", 0);
        vgap = f.get("vgap", 0);
        if (f.defaulted("vector")) {
            java.util.Hashtable<java.lang.String, java.awt.Component> tab = ((java.util.Hashtable)(f.get("tab", null)));
            vector = new java.util.Vector<>();
            if ((tab != null) && (!(tab.isEmpty()))) {
                for (java.util.Enumeration<java.lang.String> e = tab.keys() ; e.hasMoreElements() ; ) {
                    java.lang.String key = ((java.lang.String)(e.nextElement()));
                    java.awt.Component comp = ((java.awt.Component)(tab.get(key)));
                    vector.add(new java.awt.CardLayout.Card(key , comp));
                    if (comp.isVisible()) {
                        currentCard = (vector.size()) - 1;
                    } 
                }
            } 
        } else {
            vector = ((java.util.Vector)(f.get("vector", null)));
            currentCard = f.get("currentCard", 0);
        }
    }

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        java.util.Hashtable<java.lang.String, java.awt.Component> tab = new java.util.Hashtable<>();
        int ncomponents = vector.size();
        for (int i = 0 ; i < ncomponents ; i++) {
            java.awt.CardLayout.Card card = ((java.awt.CardLayout.Card)(vector.get(i)));
            tab.put(card.name, card.comp);
        }
        java.io.ObjectOutputStream.PutField f = s.putFields();
        f.put("hgap", hgap);
        f.put("vgap", vgap);
        f.put("vector", vector);
        f.put("currentCard", currentCard);
        f.put("tab", tab);
        s.writeFields();
    }
}


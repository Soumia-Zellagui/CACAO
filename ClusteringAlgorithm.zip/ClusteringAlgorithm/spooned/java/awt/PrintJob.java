package java.awt;


public abstract class PrintJob {
    public abstract java.awt.Graphics getGraphics();

    public abstract java.awt.Dimension getPageDimension();

    public abstract int getPageResolution();

    public abstract boolean lastPageFirst();

    public abstract void end();

    public void finalize() {
        end();
    }
}


package java.awt;


abstract class MultipleGradientPaintContext implements java.awt.PaintContext {
    protected java.awt.image.ColorModel model;

    private static java.awt.image.ColorModel xrgbmodel = new java.awt.image.DirectColorModel(24 , 16711680 , 65280 , 255);

    protected static java.awt.image.ColorModel cachedModel;

    protected static java.lang.ref.WeakReference<java.awt.image.Raster> cached;

    protected java.awt.image.Raster saved;

    protected java.awt.MultipleGradientPaint.CycleMethod cycleMethod;

    protected java.awt.MultipleGradientPaint.ColorSpaceType colorSpace;

    protected float a00;

    protected float a01;

    protected float a10;

    protected float a11;

    protected float a02;

    protected float a12;

    protected boolean isSimpleLookup;

    protected int fastGradientArraySize;

    protected int[] gradient;

    private int[][] gradients;

    private float[] normalizedIntervals;

    private float[] fractions;

    private int transparencyTest;

    private static final int[] SRGBtoLinearRGB = new int[256];

    private static final int[] LinearRGBtoSRGB = new int[256];

    static {
        for (int k = 0 ; k < 256 ; k++) {
            java.awt.MultipleGradientPaintContext.SRGBtoLinearRGB[k] = java.awt.MultipleGradientPaintContext.convertSRGBtoLinearRGB(k);
            java.awt.MultipleGradientPaintContext.LinearRGBtoSRGB[k] = java.awt.MultipleGradientPaintContext.convertLinearRGBtoSRGB(k);
        }
    }

    protected static final int GRADIENT_SIZE = 256;

    protected static final int GRADIENT_SIZE_INDEX = (java.awt.MultipleGradientPaintContext.GRADIENT_SIZE) - 1;

    private static final int MAX_GRADIENT_ARRAY_SIZE = 5000;

    protected MultipleGradientPaintContext(java.awt.MultipleGradientPaint mgp ,java.awt.image.ColorModel cm ,java.awt.Rectangle deviceBounds ,java.awt.geom.Rectangle2D userBounds ,java.awt.geom.AffineTransform t ,java.awt.RenderingHints hints ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod ,java.awt.MultipleGradientPaint.ColorSpaceType colorSpace) {
        if (deviceBounds == null) {
            throw new java.lang.NullPointerException("Device bounds cannot be null");
        } 
        if (userBounds == null) {
            throw new java.lang.NullPointerException("User bounds cannot be null");
        } 
        if (t == null) {
            throw new java.lang.NullPointerException("Transform cannot be null");
        } 
        if (hints == null) {
            throw new java.lang.NullPointerException("RenderingHints cannot be null");
        } 
        java.awt.geom.AffineTransform tInv;
        try {
            t.invert();
            tInv = t;
        } catch (java.awt.geom.NoninvertibleTransformException e) {
            tInv = new java.awt.geom.AffineTransform();
        }
        double[] m = new double[6];
        tInv.getMatrix(m);
        a00 = ((float)(m[0]));
        a10 = ((float)(m[1]));
        a01 = ((float)(m[2]));
        a11 = ((float)(m[3]));
        a02 = ((float)(m[4]));
        a12 = ((float)(m[5]));
        java.awt.MultipleGradientPaintContext.this.cycleMethod = cycleMethod;
        java.awt.MultipleGradientPaintContext.this.colorSpace = colorSpace;
        java.awt.MultipleGradientPaintContext.this.fractions = fractions;
        int[] gradient = (mgp.gradient) != null ? mgp.gradient.get() : null;
        int[][] gradients = (mgp.gradients) != null ? mgp.gradients.get() : null;
        if ((gradient == null) && (gradients == null)) {
            calculateLookupData(colors);
            mgp.model = java.awt.MultipleGradientPaintContext.this.model;
            mgp.normalizedIntervals = java.awt.MultipleGradientPaintContext.this.normalizedIntervals;
            mgp.isSimpleLookup = java.awt.MultipleGradientPaintContext.this.isSimpleLookup;
            if (isSimpleLookup) {
                mgp.fastGradientArraySize = java.awt.MultipleGradientPaintContext.this.fastGradientArraySize;
                mgp.gradient = new java.lang.ref.SoftReference<int[]>(java.awt.MultipleGradientPaintContext.this.gradient);
            } else {
                mgp.gradients = new java.lang.ref.SoftReference<int[][]>(java.awt.MultipleGradientPaintContext.this.gradients);
            }
        } else {
            java.awt.MultipleGradientPaintContext.this.model = mgp.model;
            java.awt.MultipleGradientPaintContext.this.normalizedIntervals = mgp.normalizedIntervals;
            java.awt.MultipleGradientPaintContext.this.isSimpleLookup = mgp.isSimpleLookup;
            java.awt.MultipleGradientPaintContext.this.gradient = gradient;
            java.awt.MultipleGradientPaintContext.this.fastGradientArraySize = mgp.fastGradientArraySize;
            java.awt.MultipleGradientPaintContext.this.gradients = gradients;
        }
    }

    private void calculateLookupData(java.awt.Color[] colors) {
        java.awt.Color[] normalizedColors;
        if ((colorSpace) == (java.awt.MultipleGradientPaint.ColorSpaceType.LINEAR_RGB)) {
            normalizedColors = new java.awt.Color[colors.length];
            for (int i = 0 ; i < (colors.length) ; i++) {
                int argb = colors[i].getRGB();
                int a = argb >>> 24;
                int r = java.awt.MultipleGradientPaintContext.SRGBtoLinearRGB[((argb >> 16) & 255)];
                int g = java.awt.MultipleGradientPaintContext.SRGBtoLinearRGB[((argb >> 8) & 255)];
                int b = java.awt.MultipleGradientPaintContext.SRGBtoLinearRGB[(argb & 255)];
                normalizedColors[i] = new java.awt.Color(r , g , b , a);
            }
        } else {
            normalizedColors = colors;
        }
        normalizedIntervals = new float[(fractions.length) - 1];
        for (int i = 0 ; i < (normalizedIntervals.length) ; i++) {
            normalizedIntervals[i] = (java.awt.MultipleGradientPaintContext.this.fractions[(i + 1)]) - (java.awt.MultipleGradientPaintContext.this.fractions[i]);
        }
        transparencyTest = -16777216;
        gradients = new int[normalizedIntervals.length][];
        float Imin = 1;
        for (int i = 0 ; i < (normalizedIntervals.length) ; i++) {
            Imin = Imin > (normalizedIntervals[i]) ? normalizedIntervals[i] : Imin;
        }
        int estimatedSize = 0;
        for (int i = 0 ; i < (normalizedIntervals.length) ; i++) {
            estimatedSize += ((normalizedIntervals[i]) / Imin) * (java.awt.MultipleGradientPaintContext.GRADIENT_SIZE);
        }
        if (estimatedSize > (java.awt.MultipleGradientPaintContext.MAX_GRADIENT_ARRAY_SIZE)) {
            calculateMultipleArrayGradient(normalizedColors);
        } else {
            calculateSingleArrayGradient(normalizedColors, Imin);
        }
        if (((transparencyTest) >>> 24) == 255) {
            model = java.awt.MultipleGradientPaintContext.xrgbmodel;
        } else {
            model = java.awt.image.ColorModel.getRGBdefault();
        }
    }

    private void calculateSingleArrayGradient(java.awt.Color[] colors, float Imin) {
        isSimpleLookup = true;
        int rgb1;
        int rgb2;
        int gradientsTot = 1;
        for (int i = 0 ; i < (gradients.length) ; i++) {
            int nGradients = ((int)(((normalizedIntervals[i]) / Imin) * 255.0F));
            gradientsTot += nGradients;
            gradients[i] = new int[nGradients];
            rgb1 = colors[i].getRGB();
            rgb2 = colors[(i + 1)].getRGB();
            interpolate(rgb1, rgb2, gradients[i]);
            transparencyTest &= rgb1;
            transparencyTest &= rgb2;
        }
        gradient = new int[gradientsTot];
        int curOffset = 0;
        for (int i = 0 ; i < (gradients.length) ; i++) {
            java.lang.System.arraycopy(gradients[i], 0, gradient, curOffset, gradients[i].length);
            curOffset += gradients[i].length;
        }
        gradient[((gradient.length) - 1)] = colors[((colors.length) - 1)].getRGB();
        if ((colorSpace) == (java.awt.MultipleGradientPaint.ColorSpaceType.LINEAR_RGB)) {
            for (int i = 0 ; i < (gradient.length) ; i++) {
                gradient[i] = convertEntireColorLinearRGBtoSRGB(gradient[i]);
            }
        } 
        fastGradientArraySize = (gradient.length) - 1;
    }

    private void calculateMultipleArrayGradient(java.awt.Color[] colors) {
        isSimpleLookup = false;
        int rgb1;
        int rgb2;
        for (int i = 0 ; i < (gradients.length) ; i++) {
            gradients[i] = new int[java.awt.MultipleGradientPaintContext.GRADIENT_SIZE];
            rgb1 = colors[i].getRGB();
            rgb2 = colors[(i + 1)].getRGB();
            interpolate(rgb1, rgb2, gradients[i]);
            transparencyTest &= rgb1;
            transparencyTest &= rgb2;
        }
        if ((colorSpace) == (java.awt.MultipleGradientPaint.ColorSpaceType.LINEAR_RGB)) {
            for (int j = 0 ; j < (gradients.length) ; j++) {
                for (int i = 0 ; i < (gradients[j].length) ; i++) {
                    gradients[j][i] = convertEntireColorLinearRGBtoSRGB(gradients[j][i]);
                }
            }
        } 
    }

    private void interpolate(int rgb1, int rgb2, int[] output) {
        int a1;
        int r1;
        int g1;
        int b1;
        int da;
        int dr;
        int dg;
        int db;
        float stepSize = 1.0F / (output.length);
        a1 = (rgb1 >> 24) & 255;
        r1 = (rgb1 >> 16) & 255;
        g1 = (rgb1 >> 8) & 255;
        b1 = rgb1 & 255;
        da = ((rgb2 >> 24) & 255) - a1;
        dr = ((rgb2 >> 16) & 255) - r1;
        dg = ((rgb2 >> 8) & 255) - g1;
        db = (rgb2 & 255) - b1;
        for (int i = 0 ; i < (output.length) ; i++) {
            output[i] = (((((int)(((a1 + ((i * da) * stepSize)) + 0.5))) << 24) | (((int)(((r1 + ((i * dr) * stepSize)) + 0.5))) << 16)) | (((int)(((g1 + ((i * dg) * stepSize)) + 0.5))) << 8)) | ((int)(((b1 + ((i * db) * stepSize)) + 0.5)));
        }
    }

    private int convertEntireColorLinearRGBtoSRGB(int rgb) {
        int a1;
        int r1;
        int g1;
        int b1;
        a1 = (rgb >> 24) & 255;
        r1 = (rgb >> 16) & 255;
        g1 = (rgb >> 8) & 255;
        b1 = rgb & 255;
        r1 = java.awt.MultipleGradientPaintContext.LinearRGBtoSRGB[r1];
        g1 = java.awt.MultipleGradientPaintContext.LinearRGBtoSRGB[g1];
        b1 = java.awt.MultipleGradientPaintContext.LinearRGBtoSRGB[b1];
        return (((a1 << 24) | (r1 << 16)) | (g1 << 8)) | b1;
    }

    protected final int indexIntoGradientsArrays(float position) {
        if ((cycleMethod) == (java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE)) {
            if (position > 1) {
                position = 1;
            } else if (position < 0) {
                position = 0;
            } 
        } else if ((cycleMethod) == (java.awt.MultipleGradientPaint.CycleMethod.REPEAT)) {
            position = position - ((int)(position));
            if (position < 0) {
                position = position + 1;
            } 
        } else {
            if (position < 0) {
                position = -position;
            } 
            int part = ((int)(position));
            position = position - part;
            if ((part & 1) == 1) {
                position = 1 - position;
            } 
        }
        if (isSimpleLookup) {
            return gradient[((int)(position * (fastGradientArraySize)))];
        } else {
            for (int i = 0 ; i < (gradients.length) ; i++) {
                if (position < (fractions[(i + 1)])) {
                    float delta = position - (fractions[i]);
                    int index = ((int)((delta / (normalizedIntervals[i])) * (java.awt.MultipleGradientPaintContext.GRADIENT_SIZE_INDEX)));
                    return gradients[i][index];
                } 
            }
        }
        return gradients[((gradients.length) - 1)][java.awt.MultipleGradientPaintContext.GRADIENT_SIZE_INDEX];
    }

    private static int convertSRGBtoLinearRGB(int color) {
        float input;
        float output;
        input = color / 255.0F;
        if (input <= 0.04045F) {
            output = input / 12.92F;
        } else {
            output = ((float)(java.lang.Math.pow(((input + 0.055) / 1.055), 2.4)));
        }
        return java.lang.Math.round((output * 255.0F));
    }

    private static int convertLinearRGBtoSRGB(int color) {
        float input;
        float output;
        input = color / 255.0F;
        if (input <= 0.0031308) {
            output = input * 12.92F;
        } else {
            output = (1.055F * ((float)(java.lang.Math.pow(input, (1.0 / 2.4))))) - 0.055F;
        }
        return java.lang.Math.round((output * 255.0F));
    }

    public final java.awt.image.Raster getRaster(int x, int y, int w, int h) {
        java.awt.image.Raster raster = saved;
        if (((raster == null) || ((raster.getWidth()) < w)) || ((raster.getHeight()) < h)) {
            raster = java.awt.MultipleGradientPaintContext.getCachedRaster(model, w, h);
            saved = raster;
        } 
        java.awt.image.DataBufferInt rasterDB = ((java.awt.image.DataBufferInt)(raster.getDataBuffer()));
        int[] pixels = rasterDB.getData(0);
        int off = rasterDB.getOffset();
        int scanlineStride = ((java.awt.image.SinglePixelPackedSampleModel)(raster.getSampleModel())).getScanlineStride();
        int adjust = scanlineStride - w;
        fillRaster(pixels, off, adjust, x, y, w, h);
        return raster;
    }

    protected abstract void fillRaster(int[] pixels, int off, int adjust, int x, int y, int w, int h);

    private static synchronized java.awt.image.Raster getCachedRaster(java.awt.image.ColorModel cm, int w, int h) {
        if (cm == (java.awt.MultipleGradientPaintContext.cachedModel)) {
            if ((java.awt.MultipleGradientPaintContext.cached) != null) {
                java.awt.image.Raster ras = ((java.awt.image.Raster)(java.awt.MultipleGradientPaintContext.cached.get()));
                if (((ras != null) && ((ras.getWidth()) >= w)) && ((ras.getHeight()) >= h)) {
                    java.awt.MultipleGradientPaintContext.cached = null;
                    return ras;
                } 
            } 
        } 
        return cm.createCompatibleWritableRaster(w, h);
    }

    private static synchronized void putCachedRaster(java.awt.image.ColorModel cm, java.awt.image.Raster ras) {
        if ((java.awt.MultipleGradientPaintContext.cached) != null) {
            java.awt.image.Raster cras = ((java.awt.image.Raster)(java.awt.MultipleGradientPaintContext.cached.get()));
            if (cras != null) {
                int cw = cras.getWidth();
                int ch = cras.getHeight();
                int iw = ras.getWidth();
                int ih = ras.getHeight();
                if ((cw >= iw) && (ch >= ih)) {
                    return ;
                } 
                if ((cw * ch) >= (iw * ih)) {
                    return ;
                } 
            } 
        } 
        java.awt.MultipleGradientPaintContext.cachedModel = cm;
        java.awt.MultipleGradientPaintContext.cached = new java.lang.ref.WeakReference<java.awt.image.Raster>(ras);
    }

    public final void dispose() {
        if ((saved) != null) {
            java.awt.MultipleGradientPaintContext.putCachedRaster(model, saved);
            saved = null;
        } 
    }

    public final java.awt.image.ColorModel getColorModel() {
        return model;
    }
}


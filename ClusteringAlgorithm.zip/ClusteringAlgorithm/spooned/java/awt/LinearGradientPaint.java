package java.awt;


public final class LinearGradientPaint extends java.awt.MultipleGradientPaint {
    private final java.awt.geom.Point2D start;

    private final java.awt.geom.Point2D end;

    public LinearGradientPaint(float startX ,float startY ,float endX ,float endY ,float[] fractions ,java.awt.Color[] colors) {
        this(new java.awt.geom.Point2D.Float(startX , startY), new java.awt.geom.Point2D.Float(endX , endY), fractions, colors, java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }

    public LinearGradientPaint(float startX ,float startY ,float endX ,float endY ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(new java.awt.geom.Point2D.Float(startX , startY), new java.awt.geom.Point2D.Float(endX , endY), fractions, colors, cycleMethod);
    }

    public LinearGradientPaint(java.awt.geom.Point2D start ,java.awt.geom.Point2D end ,float[] fractions ,java.awt.Color[] colors) {
        this(start, end, fractions, colors, java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }

    public LinearGradientPaint(java.awt.geom.Point2D start ,java.awt.geom.Point2D end ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(start, end, fractions, colors, cycleMethod, java.awt.MultipleGradientPaint.ColorSpaceType.SRGB, new java.awt.geom.AffineTransform());
    }

    @java.beans.ConstructorProperties(value = { "startPoint" , "endPoint" , "fractions" , "colors" , "cycleMethod" , "colorSpace" , "transform" })
    public LinearGradientPaint(java.awt.geom.Point2D start ,java.awt.geom.Point2D end ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod ,java.awt.MultipleGradientPaint.ColorSpaceType colorSpace ,java.awt.geom.AffineTransform gradientTransform) {
        super(fractions, colors, cycleMethod, colorSpace, gradientTransform);
        if ((start == null) || (end == null)) {
            throw new java.lang.NullPointerException(("Start and end points must be" + "non-null"));
        } 
        if (start.equals(end)) {
            throw new java.lang.IllegalArgumentException(("Start point cannot equal" + "endpoint"));
        } 
        this.start = new java.awt.geom.Point2D.Double(start.getX() , start.getY());
        this.end = new java.awt.geom.Point2D.Double(end.getX() , end.getY());
    }

    public java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds, java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform transform, java.awt.RenderingHints hints) {
        transform = new java.awt.geom.AffineTransform(transform);
        transform.concatenate(gradientTransform);
        if ((((fractions.length) == 2) && ((cycleMethod) != (java.awt.MultipleGradientPaint.CycleMethod.REPEAT))) && ((colorSpace) == (java.awt.MultipleGradientPaint.ColorSpaceType.SRGB))) {
            boolean cyclic = (cycleMethod) != (java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
            return new java.awt.GradientPaintContext(cm , start , end , transform , colors[0] , colors[1] , cyclic);
        } else {
            return new java.awt.LinearGradientPaintContext(java.awt.LinearGradientPaint.this , cm , deviceBounds , userBounds , transform , hints , start , end , fractions , colors , cycleMethod , colorSpace);
        }
    }

    public java.awt.geom.Point2D getStartPoint() {
        return new java.awt.geom.Point2D.Double(start.getX() , start.getY());
    }

    public java.awt.geom.Point2D getEndPoint() {
        return new java.awt.geom.Point2D.Double(end.getX() , end.getY());
    }
}


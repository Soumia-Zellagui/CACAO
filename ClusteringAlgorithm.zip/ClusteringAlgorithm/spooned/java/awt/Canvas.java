package java.awt;


public class Canvas extends java.awt.Component implements javax.accessibility.Accessible {
    private static final java.lang.String base = "canvas";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -2284879212465893870L;

    public Canvas() {
    }

    public Canvas(java.awt.GraphicsConfiguration config) {
        this();
        setGraphicsConfiguration(config);
    }

    @java.lang.Override
    void setGraphicsConfiguration(java.awt.GraphicsConfiguration gc) {
        synchronized(getTreeLock()) {
            java.awt.peer.CanvasPeer peer = ((java.awt.peer.CanvasPeer)(getPeer()));
            if (peer != null) {
                gc = peer.getAppropriateGraphicsConfiguration(gc);
            } 
            super.setGraphicsConfiguration(gc);
        }
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Canvas.class) {
            return (java.awt.Canvas.base) + ((java.awt.Canvas.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createCanvas(java.awt.Canvas.this);
            
            super.addNotify();
        }
    }

    public void paint(java.awt.Graphics g) {
        g.clearRect(0, 0, width, height);
    }

    public void update(java.awt.Graphics g) {
        g.clearRect(0, 0, width, height);
        paint(g);
    }

    boolean postsOldMouseEvents() {
        return true;
    }

    public void createBufferStrategy(int numBuffers) {
        super.createBufferStrategy(numBuffers);
    }

    public void createBufferStrategy(int numBuffers, java.awt.BufferCapabilities caps) throws java.awt.AWTException {
        super.createBufferStrategy(numBuffers, caps);
    }

    public java.awt.image.BufferStrategy getBufferStrategy() {
        return super.getBufferStrategy();
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Canvas.AccessibleAWTCanvas();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTCanvas extends java.awt.Component.AccessibleAWTComponent {
        private static final long serialVersionUID = -6325592262103146699L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.CANVAS;
        }
    }
}


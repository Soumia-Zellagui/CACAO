package java.awt;


public abstract class Graphics2D extends java.awt.Graphics {
    protected Graphics2D() {
    }

    public void draw3DRect(int x, int y, int width, int height, boolean raised) {
        java.awt.Paint p = getPaint();
        java.awt.Color c = getColor();
        java.awt.Color brighter = c.brighter();
        java.awt.Color darker = c.darker();
        setColor((raised ? brighter : darker));
        fillRect(x, y, 1, (height + 1));
        fillRect((x + 1), y, (width - 1), 1);
        setColor((raised ? darker : brighter));
        fillRect((x + 1), (y + height), width, 1);
        fillRect((x + width), y, 1, height);
        setPaint(p);
    }

    public void fill3DRect(int x, int y, int width, int height, boolean raised) {
        java.awt.Paint p = getPaint();
        java.awt.Color c = getColor();
        java.awt.Color brighter = c.brighter();
        java.awt.Color darker = c.darker();
        if (!raised) {
            setColor(darker);
        } else if (p != c) {
            setColor(c);
        } 
        fillRect((x + 1), (y + 1), (width - 2), (height - 2));
        setColor((raised ? brighter : darker));
        fillRect(x, y, 1, height);
        fillRect((x + 1), y, (width - 2), 1);
        setColor((raised ? darker : brighter));
        fillRect((x + 1), ((y + height) - 1), (width - 1), 1);
        fillRect(((x + width) - 1), y, 1, (height - 1));
        setPaint(p);
    }

    public abstract void draw(java.awt.Shape s);

    public abstract boolean drawImage(java.awt.Image img, java.awt.geom.AffineTransform xform, java.awt.image.ImageObserver obs);

    public abstract void drawImage(java.awt.image.BufferedImage img, java.awt.image.BufferedImageOp op, int x, int y);

    public abstract void drawRenderedImage(java.awt.image.RenderedImage img, java.awt.geom.AffineTransform xform);

    public abstract void drawRenderableImage(java.awt.image.renderable.RenderableImage img, java.awt.geom.AffineTransform xform);

    public abstract void drawString(java.lang.String str, int x, int y);

    public abstract void drawString(java.lang.String str, float x, float y);

    public abstract void drawString(java.text.AttributedCharacterIterator iterator, int x, int y);

    public abstract void drawString(java.text.AttributedCharacterIterator iterator, float x, float y);

    public abstract void drawGlyphVector(java.awt.font.GlyphVector g, float x, float y);

    public abstract void fill(java.awt.Shape s);

    public abstract boolean hit(java.awt.Rectangle rect, java.awt.Shape s, boolean onStroke);

    public abstract java.awt.GraphicsConfiguration getDeviceConfiguration();

    public abstract void setComposite(java.awt.Composite comp);

    public abstract void setPaint(java.awt.Paint paint);

    public abstract void setStroke(java.awt.Stroke s);

    public abstract void setRenderingHint(java.awt.RenderingHints.Key hintKey, java.lang.Object hintValue);

    public abstract java.lang.Object getRenderingHint(java.awt.RenderingHints.Key hintKey);

    public abstract void setRenderingHints(java.util.Map<?, ?> hints);

    public abstract void addRenderingHints(java.util.Map<?, ?> hints);

    public abstract java.awt.RenderingHints getRenderingHints();

    public abstract void translate(int x, int y);

    public abstract void translate(double tx, double ty);

    public abstract void rotate(double theta);

    public abstract void rotate(double theta, double x, double y);

    public abstract void scale(double sx, double sy);

    public abstract void shear(double shx, double shy);

    public abstract void transform(java.awt.geom.AffineTransform Tx);

    public abstract void setTransform(java.awt.geom.AffineTransform Tx);

    public abstract java.awt.geom.AffineTransform getTransform();

    public abstract java.awt.Paint getPaint();

    public abstract java.awt.Composite getComposite();

    public abstract void setBackground(java.awt.Color color);

    public abstract java.awt.Color getBackground();

    public abstract java.awt.Stroke getStroke();

    public abstract void clip(java.awt.Shape s);

    public abstract java.awt.font.FontRenderContext getFontRenderContext();
}


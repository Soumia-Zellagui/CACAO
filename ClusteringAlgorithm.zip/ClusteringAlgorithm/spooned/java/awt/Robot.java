package java.awt;


public class Robot {
    private static final int MAX_DELAY = 60000;

    private java.awt.peer.RobotPeer peer;

    private boolean isAutoWaitForIdle = false;

    private int autoDelay = 0;

    private static int LEGAL_BUTTON_MASK = 0;

    private java.awt.image.DirectColorModel screenCapCM = null;

    public Robot() throws java.awt.AWTException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.AWTException("headless environment");
        } 
        init(java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice());
    }

    public Robot(java.awt.GraphicsDevice screen) throws java.awt.AWTException {
        checkIsScreenDevice(screen);
        init(screen);
    }

    private void init(java.awt.GraphicsDevice screen) throws java.awt.AWTException {
        checkRobotAllowed();
        java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        if (toolkit instanceof sun.awt.ComponentFactory) {
            peer = ((sun.awt.ComponentFactory)(toolkit)).createRobot(java.awt.Robot.this, screen);
            disposer = new java.awt.Robot.RobotDisposer(peer);
            sun.java2d.Disposer.addRecord(anchor, disposer);
        } 
        java.awt.Robot.initLegalButtonMask();
    }

    private static synchronized void initLegalButtonMask() {
        if ((java.awt.Robot.LEGAL_BUTTON_MASK) != 0)
            return ;
        
        int tmpMask = 0;
        if (java.awt.Toolkit.getDefaultToolkit().areExtraMouseButtonsEnabled()) {
            if ((java.awt.Toolkit.getDefaultToolkit()) instanceof sun.awt.SunToolkit) {
                final int buttonsNumber = ((sun.awt.SunToolkit)(java.awt.Toolkit.getDefaultToolkit())).getNumberOfButtons();
                for (int i = 0 ; i < buttonsNumber ; i++) {
                    tmpMask |= java.awt.event.InputEvent.getMaskForButton((i + 1));
                }
            } 
        } 
        tmpMask |= (((((java.awt.event.InputEvent.BUTTON1_MASK) | (java.awt.event.InputEvent.BUTTON2_MASK)) | (java.awt.event.InputEvent.BUTTON3_MASK)) | (java.awt.event.InputEvent.BUTTON1_DOWN_MASK)) | (java.awt.event.InputEvent.BUTTON2_DOWN_MASK)) | (java.awt.event.InputEvent.BUTTON3_DOWN_MASK);
        java.awt.Robot.LEGAL_BUTTON_MASK = tmpMask;
    }

    private void checkRobotAllowed() {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.CREATE_ROBOT_PERMISSION);
        } 
    }

    private void checkIsScreenDevice(java.awt.GraphicsDevice device) {
        if ((device == null) || ((device.getType()) != (java.awt.GraphicsDevice.TYPE_RASTER_SCREEN))) {
            throw new java.lang.IllegalArgumentException("not a valid screen device");
        } 
    }

    private transient java.lang.Object anchor = new java.lang.Object();

    static class RobotDisposer implements sun.java2d.DisposerRecord {
        private final java.awt.peer.RobotPeer peer;

        public RobotDisposer(java.awt.peer.RobotPeer peer) {
            this.peer = peer;
        }

        public void dispose() {
            if ((peer) != null) {
                peer.dispose();
            } 
        }
    }

    private transient java.awt.Robot.RobotDisposer disposer;

    public synchronized void mouseMove(int x, int y) {
        peer.mouseMove(x, y);
        afterEvent();
    }

    public synchronized void mousePress(int buttons) {
        checkButtonsArgument(buttons);
        peer.mousePress(buttons);
        afterEvent();
    }

    public synchronized void mouseRelease(int buttons) {
        checkButtonsArgument(buttons);
        peer.mouseRelease(buttons);
        afterEvent();
    }

    private void checkButtonsArgument(int buttons) {
        if ((buttons | (java.awt.Robot.LEGAL_BUTTON_MASK)) != (java.awt.Robot.LEGAL_BUTTON_MASK)) {
            throw new java.lang.IllegalArgumentException("Invalid combination of button flags");
        } 
    }

    public synchronized void mouseWheel(int wheelAmt) {
        peer.mouseWheel(wheelAmt);
        afterEvent();
    }

    public synchronized void keyPress(int keycode) {
        checkKeycodeArgument(keycode);
        peer.keyPress(keycode);
        afterEvent();
    }

    public synchronized void keyRelease(int keycode) {
        checkKeycodeArgument(keycode);
        peer.keyRelease(keycode);
        afterEvent();
    }

    private void checkKeycodeArgument(int keycode) {
        if (keycode == (java.awt.event.KeyEvent.VK_UNDEFINED)) {
            throw new java.lang.IllegalArgumentException("Invalid key code");
        } 
    }

    public synchronized java.awt.Color getPixelColor(int x, int y) {
        java.awt.Color color = new java.awt.Color(peer.getRGBPixel(x, y));
        return color;
    }

    public synchronized java.awt.image.BufferedImage createScreenCapture(java.awt.Rectangle screenRect) {
        java.awt.Robot.checkScreenCaptureAllowed();
        java.awt.Robot.checkValidRect(screenRect);
        java.awt.image.BufferedImage image;
        java.awt.image.DataBufferInt buffer;
        java.awt.image.WritableRaster raster;
        if ((screenCapCM) == null) {
            screenCapCM = new java.awt.image.DirectColorModel(24 , 16711680 , 65280 , 255);
        } 
        java.awt.Toolkit.getDefaultToolkit().sync();
        int[] pixels;
        int[] bandmasks = new int[3];
        pixels = peer.getRGBPixels(screenRect);
        buffer = new java.awt.image.DataBufferInt(pixels , pixels.length);
        bandmasks[0] = screenCapCM.getRedMask();
        bandmasks[1] = screenCapCM.getGreenMask();
        bandmasks[2] = screenCapCM.getBlueMask();
        raster = java.awt.image.Raster.createPackedRaster(buffer, screenRect.width, screenRect.height, screenRect.width, bandmasks, null);
        sun.awt.image.SunWritableRaster.makeTrackable(buffer);
        image = new java.awt.image.BufferedImage(screenCapCM , raster , false , null);
        return image;
    }

    private static void checkValidRect(java.awt.Rectangle rect) {
        if (((rect.width) <= 0) || ((rect.height) <= 0)) {
            throw new java.lang.IllegalArgumentException("Rectangle width and height must be > 0");
        } 
    }

    private static void checkScreenCaptureAllowed() {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.READ_DISPLAY_PIXELS_PERMISSION);
        } 
    }

    private void afterEvent() {
        autoWaitForIdle();
        autoDelay();
    }

    public synchronized boolean isAutoWaitForIdle() {
        return isAutoWaitForIdle;
    }

    public synchronized void setAutoWaitForIdle(boolean isOn) {
        isAutoWaitForIdle = isOn;
    }

    private void autoWaitForIdle() {
        if (isAutoWaitForIdle) {
            waitForIdle();
        } 
    }

    public synchronized int getAutoDelay() {
        return autoDelay;
    }

    public synchronized void setAutoDelay(int ms) {
        checkDelayArgument(ms);
        autoDelay = ms;
    }

    private void autoDelay() {
        delay(autoDelay);
    }

    public synchronized void delay(int ms) {
        checkDelayArgument(ms);
        try {
            java.lang.Thread.sleep(ms);
        } catch (java.lang.InterruptedException ite) {
            ite.printStackTrace();
        }
    }

    private void checkDelayArgument(int ms) {
        if ((ms < 0) || (ms > (java.awt.Robot.MAX_DELAY))) {
            throw new java.lang.IllegalArgumentException("Delay must be to 0 to 60,000ms");
        } 
    }

    public synchronized void waitForIdle() {
        checkNotDispatchThread();
        try {
            sun.awt.SunToolkit.flushPendingEvents();
            java.awt.EventQueue.invokeAndWait(new java.lang.Runnable() {
                public void run() {
                }
            });
        } catch (java.lang.InterruptedException ite) {
            java.lang.System.err.println("Robot.waitForIdle, non-fatal exception caught:");
            ite.printStackTrace();
        } catch (java.lang.reflect.InvocationTargetException ine) {
            java.lang.System.err.println("Robot.waitForIdle, non-fatal exception caught:");
            ine.printStackTrace();
        }
    }

    private void checkNotDispatchThread() {
        if (java.awt.EventQueue.isDispatchThread()) {
            throw new java.lang.IllegalThreadStateException("Cannot call method from the event dispatcher thread");
        } 
    }

    public synchronized java.lang.String toString() {
        java.lang.String params = ((("autoDelay = " + (getAutoDelay())) + ", ") + "autoWaitForIdle = ") + (isAutoWaitForIdle());
        return (((getClass().getName()) + "[ ") + params) + " ]";
    }
}


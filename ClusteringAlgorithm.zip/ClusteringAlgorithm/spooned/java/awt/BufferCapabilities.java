package java.awt;


public class BufferCapabilities implements java.lang.Cloneable {
    private java.awt.ImageCapabilities frontCaps;

    private java.awt.ImageCapabilities backCaps;

    private java.awt.BufferCapabilities.FlipContents flipContents;

    public BufferCapabilities(java.awt.ImageCapabilities frontCaps ,java.awt.ImageCapabilities backCaps ,java.awt.BufferCapabilities.FlipContents flipContents) {
        if ((frontCaps == null) || (backCaps == null)) {
            throw new java.lang.IllegalArgumentException("Image capabilities specified cannot be null");
        } 
        java.awt.BufferCapabilities.this.frontCaps = frontCaps;
        java.awt.BufferCapabilities.this.backCaps = backCaps;
        java.awt.BufferCapabilities.this.flipContents = flipContents;
    }

    public java.awt.ImageCapabilities getFrontBufferCapabilities() {
        return frontCaps;
    }

    public java.awt.ImageCapabilities getBackBufferCapabilities() {
        return backCaps;
    }

    public boolean isPageFlipping() {
        return (getFlipContents()) != null;
    }

    public java.awt.BufferCapabilities.FlipContents getFlipContents() {
        return flipContents;
    }

    public boolean isFullScreenRequired() {
        return false;
    }

    public boolean isMultiBufferAvailable() {
        return false;
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }

    public static final class FlipContents extends java.awt.AttributeValue {
        private static int I_UNDEFINED = 0;

        private static int I_BACKGROUND = 1;

        private static int I_PRIOR = 2;

        private static int I_COPIED = 3;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "undefined" , "background" , "prior" , "copied" };

        public static final java.awt.BufferCapabilities.FlipContents UNDEFINED = new java.awt.BufferCapabilities.FlipContents(java.awt.BufferCapabilities.FlipContents.I_UNDEFINED);

        public static final java.awt.BufferCapabilities.FlipContents BACKGROUND = new java.awt.BufferCapabilities.FlipContents(java.awt.BufferCapabilities.FlipContents.I_BACKGROUND);

        public static final java.awt.BufferCapabilities.FlipContents PRIOR = new java.awt.BufferCapabilities.FlipContents(java.awt.BufferCapabilities.FlipContents.I_PRIOR);

        public static final java.awt.BufferCapabilities.FlipContents COPIED = new java.awt.BufferCapabilities.FlipContents(java.awt.BufferCapabilities.FlipContents.I_COPIED);

        private FlipContents(int type) {
            super(type, java.awt.BufferCapabilities.FlipContents.NAMES);
        }
    }
}


package java.awt;


public class CheckboxMenuItem extends java.awt.MenuItem implements java.awt.ItemSelectable , javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.CheckboxMenuItem.initIDs();
        } 
        sun.awt.AWTAccessor.setCheckboxMenuItemAccessor(new sun.awt.AWTAccessor.CheckboxMenuItemAccessor() {
            public boolean getState(java.awt.CheckboxMenuItem cmi) {
                return cmi.state;
            }
        });
    }

    boolean state = false;

    transient java.awt.event.ItemListener itemListener;

    private static final java.lang.String base = "chkmenuitem";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 6190621106981774043L;

    public CheckboxMenuItem() throws java.awt.HeadlessException {
        this("", false);
    }

    public CheckboxMenuItem(java.lang.String label) throws java.awt.HeadlessException {
        this(label, false);
    }

    public CheckboxMenuItem(java.lang.String label ,boolean state) throws java.awt.HeadlessException {
        super(label);
        java.awt.CheckboxMenuItem.this.state = state;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.CheckboxMenuItem.class) {
            return (java.awt.CheckboxMenuItem.base) + ((java.awt.CheckboxMenuItem.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = java.awt.Toolkit.getDefaultToolkit().createCheckboxMenuItem(java.awt.CheckboxMenuItem.this);
            
            super.addNotify();
        }
    }

    public boolean getState() {
        return state;
    }

    public synchronized void setState(boolean b) {
        state = b;
        java.awt.peer.CheckboxMenuItemPeer peer = ((java.awt.peer.CheckboxMenuItemPeer)(java.awt.CheckboxMenuItem.this.peer));
        if (peer != null) {
            peer.setState(b);
        } 
    }

    public synchronized java.lang.Object[] getSelectedObjects() {
        if (state) {
            java.lang.Object[] items = new java.lang.Object[1];
            items[0] = label;
            return items;
        } 
        return null;
    }

    public synchronized void addItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.add(itemListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.remove(itemListener, l);
    }

    public synchronized java.awt.event.ItemListener[] getItemListeners() {
        return getListeners(java.awt.event.ItemListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ItemListener.class)) {
            l = itemListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ItemEvent.ITEM_STATE_CHANGED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) || ((itemListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ItemEvent) {
            processItemEvent(((java.awt.event.ItemEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processItemEvent(java.awt.event.ItemEvent e) {
        java.awt.event.ItemListener listener = itemListener;
        if (listener != null) {
            listener.itemStateChanged(e);
        } 
    }

    void doMenuEvent(long when, int modifiers) {
        setState((!(state)));
        java.awt.Toolkit.getEventQueue().postEvent(new java.awt.event.ItemEvent(java.awt.CheckboxMenuItem.this , java.awt.event.ItemEvent.ITEM_STATE_CHANGED , getLabel() , (state ? java.awt.event.ItemEvent.SELECTED : java.awt.event.ItemEvent.DESELECTED)));
    }

    public java.lang.String paramString() {
        return ((super.paramString()) + ",state=") + (state);
    }

    private int checkboxMenuItemSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.MenuComponent.itemListenerK, itemListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.MenuComponent.itemListenerK) == key)
                addItemListener(((java.awt.event.ItemListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.CheckboxMenuItem.AccessibleAWTCheckboxMenuItem();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTCheckboxMenuItem extends java.awt.MenuItem.AccessibleAWTMenuItem implements javax.accessibility.AccessibleAction , javax.accessibility.AccessibleValue {
        private static final long serialVersionUID = -1122642964303476L;

        public javax.accessibility.AccessibleAction getAccessibleAction() {
            return java.awt.CheckboxMenuItem.AccessibleAWTCheckboxMenuItem.this;
        }

        public javax.accessibility.AccessibleValue getAccessibleValue() {
            return java.awt.CheckboxMenuItem.AccessibleAWTCheckboxMenuItem.this;
        }

        public int getAccessibleActionCount() {
            return 0;
        }

        public java.lang.String getAccessibleActionDescription(int i) {
            return null;
        }

        public boolean doAccessibleAction(int i) {
            return false;
        }

        public java.lang.Number getCurrentAccessibleValue() {
            return null;
        }

        public boolean setCurrentAccessibleValue(java.lang.Number n) {
            return false;
        }

        public java.lang.Number getMinimumAccessibleValue() {
            return null;
        }

        public java.lang.Number getMaximumAccessibleValue() {
            return null;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.CHECK_BOX;
        }
    }
}


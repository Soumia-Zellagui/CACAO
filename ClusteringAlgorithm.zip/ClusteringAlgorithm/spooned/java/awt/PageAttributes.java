package java.awt;


public final class PageAttributes implements java.lang.Cloneable {
    public static final class ColorType extends java.awt.AttributeValue {
        private static final int I_COLOR = 0;

        private static final int I_MONOCHROME = 1;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "color" , "monochrome" };

        public static final java.awt.PageAttributes.ColorType COLOR = new java.awt.PageAttributes.ColorType(java.awt.PageAttributes.ColorType.I_COLOR);

        public static final java.awt.PageAttributes.ColorType MONOCHROME = new java.awt.PageAttributes.ColorType(java.awt.PageAttributes.ColorType.I_MONOCHROME);

        private ColorType(int type) {
            super(type, java.awt.PageAttributes.ColorType.NAMES);
        }
    }

    public static final class MediaType extends java.awt.AttributeValue {
        private static final int I_ISO_4A0 = 0;

        private static final int I_ISO_2A0 = 1;

        private static final int I_ISO_A0 = 2;

        private static final int I_ISO_A1 = 3;

        private static final int I_ISO_A2 = 4;

        private static final int I_ISO_A3 = 5;

        private static final int I_ISO_A4 = 6;

        private static final int I_ISO_A5 = 7;

        private static final int I_ISO_A6 = 8;

        private static final int I_ISO_A7 = 9;

        private static final int I_ISO_A8 = 10;

        private static final int I_ISO_A9 = 11;

        private static final int I_ISO_A10 = 12;

        private static final int I_ISO_B0 = 13;

        private static final int I_ISO_B1 = 14;

        private static final int I_ISO_B2 = 15;

        private static final int I_ISO_B3 = 16;

        private static final int I_ISO_B4 = 17;

        private static final int I_ISO_B5 = 18;

        private static final int I_ISO_B6 = 19;

        private static final int I_ISO_B7 = 20;

        private static final int I_ISO_B8 = 21;

        private static final int I_ISO_B9 = 22;

        private static final int I_ISO_B10 = 23;

        private static final int I_JIS_B0 = 24;

        private static final int I_JIS_B1 = 25;

        private static final int I_JIS_B2 = 26;

        private static final int I_JIS_B3 = 27;

        private static final int I_JIS_B4 = 28;

        private static final int I_JIS_B5 = 29;

        private static final int I_JIS_B6 = 30;

        private static final int I_JIS_B7 = 31;

        private static final int I_JIS_B8 = 32;

        private static final int I_JIS_B9 = 33;

        private static final int I_JIS_B10 = 34;

        private static final int I_ISO_C0 = 35;

        private static final int I_ISO_C1 = 36;

        private static final int I_ISO_C2 = 37;

        private static final int I_ISO_C3 = 38;

        private static final int I_ISO_C4 = 39;

        private static final int I_ISO_C5 = 40;

        private static final int I_ISO_C6 = 41;

        private static final int I_ISO_C7 = 42;

        private static final int I_ISO_C8 = 43;

        private static final int I_ISO_C9 = 44;

        private static final int I_ISO_C10 = 45;

        private static final int I_ISO_DESIGNATED_LONG = 46;

        private static final int I_EXECUTIVE = 47;

        private static final int I_FOLIO = 48;

        private static final int I_INVOICE = 49;

        private static final int I_LEDGER = 50;

        private static final int I_NA_LETTER = 51;

        private static final int I_NA_LEGAL = 52;

        private static final int I_QUARTO = 53;

        private static final int I_A = 54;

        private static final int I_B = 55;

        private static final int I_C = 56;

        private static final int I_D = 57;

        private static final int I_E = 58;

        private static final int I_NA_10X15_ENVELOPE = 59;

        private static final int I_NA_10X14_ENVELOPE = 60;

        private static final int I_NA_10X13_ENVELOPE = 61;

        private static final int I_NA_9X12_ENVELOPE = 62;

        private static final int I_NA_9X11_ENVELOPE = 63;

        private static final int I_NA_7X9_ENVELOPE = 64;

        private static final int I_NA_6X9_ENVELOPE = 65;

        private static final int I_NA_NUMBER_9_ENVELOPE = 66;

        private static final int I_NA_NUMBER_10_ENVELOPE = 67;

        private static final int I_NA_NUMBER_11_ENVELOPE = 68;

        private static final int I_NA_NUMBER_12_ENVELOPE = 69;

        private static final int I_NA_NUMBER_14_ENVELOPE = 70;

        private static final int I_INVITE_ENVELOPE = 71;

        private static final int I_ITALY_ENVELOPE = 72;

        private static final int I_MONARCH_ENVELOPE = 73;

        private static final int I_PERSONAL_ENVELOPE = 74;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "iso-4a0" , "iso-2a0" , "iso-a0" , "iso-a1" , "iso-a2" , "iso-a3" , "iso-a4" , "iso-a5" , "iso-a6" , "iso-a7" , "iso-a8" , "iso-a9" , "iso-a10" , "iso-b0" , "iso-b1" , "iso-b2" , "iso-b3" , "iso-b4" , "iso-b5" , "iso-b6" , "iso-b7" , "iso-b8" , "iso-b9" , "iso-b10" , "jis-b0" , "jis-b1" , "jis-b2" , "jis-b3" , "jis-b4" , "jis-b5" , "jis-b6" , "jis-b7" , "jis-b8" , "jis-b9" , "jis-b10" , "iso-c0" , "iso-c1" , "iso-c2" , "iso-c3" , "iso-c4" , "iso-c5" , "iso-c6" , "iso-c7" , "iso-c8" , "iso-c9" , "iso-c10" , "iso-designated-long" , "executive" , "folio" , "invoice" , "ledger" , "na-letter" , "na-legal" , "quarto" , "a" , "b" , "c" , "d" , "e" , "na-10x15-envelope" , "na-10x14-envelope" , "na-10x13-envelope" , "na-9x12-envelope" , "na-9x11-envelope" , "na-7x9-envelope" , "na-6x9-envelope" , "na-number-9-envelope" , "na-number-10-envelope" , "na-number-11-envelope" , "na-number-12-envelope" , "na-number-14-envelope" , "invite-envelope" , "italy-envelope" , "monarch-envelope" , "personal-envelope" };

        public static final java.awt.PageAttributes.MediaType ISO_4A0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_4A0);

        public static final java.awt.PageAttributes.MediaType ISO_2A0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_2A0);

        public static final java.awt.PageAttributes.MediaType ISO_A0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A0);

        public static final java.awt.PageAttributes.MediaType ISO_A1 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A1);

        public static final java.awt.PageAttributes.MediaType ISO_A2 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A2);

        public static final java.awt.PageAttributes.MediaType ISO_A3 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A3);

        public static final java.awt.PageAttributes.MediaType ISO_A4 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A4);

        public static final java.awt.PageAttributes.MediaType ISO_A5 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A5);

        public static final java.awt.PageAttributes.MediaType ISO_A6 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A6);

        public static final java.awt.PageAttributes.MediaType ISO_A7 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A7);

        public static final java.awt.PageAttributes.MediaType ISO_A8 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A8);

        public static final java.awt.PageAttributes.MediaType ISO_A9 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A9);

        public static final java.awt.PageAttributes.MediaType ISO_A10 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_A10);

        public static final java.awt.PageAttributes.MediaType ISO_B0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B0);

        public static final java.awt.PageAttributes.MediaType ISO_B1 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B1);

        public static final java.awt.PageAttributes.MediaType ISO_B2 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B2);

        public static final java.awt.PageAttributes.MediaType ISO_B3 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B3);

        public static final java.awt.PageAttributes.MediaType ISO_B4 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B4);

        public static final java.awt.PageAttributes.MediaType ISO_B5 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B5);

        public static final java.awt.PageAttributes.MediaType ISO_B6 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B6);

        public static final java.awt.PageAttributes.MediaType ISO_B7 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B7);

        public static final java.awt.PageAttributes.MediaType ISO_B8 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B8);

        public static final java.awt.PageAttributes.MediaType ISO_B9 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B9);

        public static final java.awt.PageAttributes.MediaType ISO_B10 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_B10);

        public static final java.awt.PageAttributes.MediaType JIS_B0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B0);

        public static final java.awt.PageAttributes.MediaType JIS_B1 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B1);

        public static final java.awt.PageAttributes.MediaType JIS_B2 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B2);

        public static final java.awt.PageAttributes.MediaType JIS_B3 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B3);

        public static final java.awt.PageAttributes.MediaType JIS_B4 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B4);

        public static final java.awt.PageAttributes.MediaType JIS_B5 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B5);

        public static final java.awt.PageAttributes.MediaType JIS_B6 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B6);

        public static final java.awt.PageAttributes.MediaType JIS_B7 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B7);

        public static final java.awt.PageAttributes.MediaType JIS_B8 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B8);

        public static final java.awt.PageAttributes.MediaType JIS_B9 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B9);

        public static final java.awt.PageAttributes.MediaType JIS_B10 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_JIS_B10);

        public static final java.awt.PageAttributes.MediaType ISO_C0 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C0);

        public static final java.awt.PageAttributes.MediaType ISO_C1 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C1);

        public static final java.awt.PageAttributes.MediaType ISO_C2 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C2);

        public static final java.awt.PageAttributes.MediaType ISO_C3 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C3);

        public static final java.awt.PageAttributes.MediaType ISO_C4 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C4);

        public static final java.awt.PageAttributes.MediaType ISO_C5 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C5);

        public static final java.awt.PageAttributes.MediaType ISO_C6 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C6);

        public static final java.awt.PageAttributes.MediaType ISO_C7 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C7);

        public static final java.awt.PageAttributes.MediaType ISO_C8 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C8);

        public static final java.awt.PageAttributes.MediaType ISO_C9 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C9);

        public static final java.awt.PageAttributes.MediaType ISO_C10 = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_C10);

        public static final java.awt.PageAttributes.MediaType ISO_DESIGNATED_LONG = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ISO_DESIGNATED_LONG);

        public static final java.awt.PageAttributes.MediaType EXECUTIVE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_EXECUTIVE);

        public static final java.awt.PageAttributes.MediaType FOLIO = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_FOLIO);

        public static final java.awt.PageAttributes.MediaType INVOICE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_INVOICE);

        public static final java.awt.PageAttributes.MediaType LEDGER = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_LEDGER);

        public static final java.awt.PageAttributes.MediaType NA_LETTER = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_LETTER);

        public static final java.awt.PageAttributes.MediaType NA_LEGAL = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_LEGAL);

        public static final java.awt.PageAttributes.MediaType QUARTO = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_QUARTO);

        public static final java.awt.PageAttributes.MediaType A = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_A);

        public static final java.awt.PageAttributes.MediaType B = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_B);

        public static final java.awt.PageAttributes.MediaType C = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_C);

        public static final java.awt.PageAttributes.MediaType D = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_D);

        public static final java.awt.PageAttributes.MediaType E = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_E);

        public static final java.awt.PageAttributes.MediaType NA_10X15_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_10X15_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_10X14_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_10X14_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_10X13_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_10X13_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_9X12_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_9X12_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_9X11_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_9X11_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_7X9_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_7X9_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_6X9_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_6X9_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_NUMBER_9_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_NUMBER_9_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_NUMBER_10_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_NUMBER_10_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_NUMBER_11_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_NUMBER_11_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_NUMBER_12_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_NUMBER_12_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType NA_NUMBER_14_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_NA_NUMBER_14_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType INVITE_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_INVITE_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType ITALY_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_ITALY_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType MONARCH_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_MONARCH_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType PERSONAL_ENVELOPE = new java.awt.PageAttributes.MediaType(java.awt.PageAttributes.MediaType.I_PERSONAL_ENVELOPE);

        public static final java.awt.PageAttributes.MediaType A0 = java.awt.PageAttributes.MediaType.ISO_A0;

        public static final java.awt.PageAttributes.MediaType A1 = java.awt.PageAttributes.MediaType.ISO_A1;

        public static final java.awt.PageAttributes.MediaType A2 = java.awt.PageAttributes.MediaType.ISO_A2;

        public static final java.awt.PageAttributes.MediaType A3 = java.awt.PageAttributes.MediaType.ISO_A3;

        public static final java.awt.PageAttributes.MediaType A4 = java.awt.PageAttributes.MediaType.ISO_A4;

        public static final java.awt.PageAttributes.MediaType A5 = java.awt.PageAttributes.MediaType.ISO_A5;

        public static final java.awt.PageAttributes.MediaType A6 = java.awt.PageAttributes.MediaType.ISO_A6;

        public static final java.awt.PageAttributes.MediaType A7 = java.awt.PageAttributes.MediaType.ISO_A7;

        public static final java.awt.PageAttributes.MediaType A8 = java.awt.PageAttributes.MediaType.ISO_A8;

        public static final java.awt.PageAttributes.MediaType A9 = java.awt.PageAttributes.MediaType.ISO_A9;

        public static final java.awt.PageAttributes.MediaType A10 = java.awt.PageAttributes.MediaType.ISO_A10;

        public static final java.awt.PageAttributes.MediaType B0 = java.awt.PageAttributes.MediaType.ISO_B0;

        public static final java.awt.PageAttributes.MediaType B1 = java.awt.PageAttributes.MediaType.ISO_B1;

        public static final java.awt.PageAttributes.MediaType B2 = java.awt.PageAttributes.MediaType.ISO_B2;

        public static final java.awt.PageAttributes.MediaType B3 = java.awt.PageAttributes.MediaType.ISO_B3;

        public static final java.awt.PageAttributes.MediaType B4 = java.awt.PageAttributes.MediaType.ISO_B4;

        public static final java.awt.PageAttributes.MediaType ISO_B4_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_B4;

        public static final java.awt.PageAttributes.MediaType B5 = java.awt.PageAttributes.MediaType.ISO_B5;

        public static final java.awt.PageAttributes.MediaType ISO_B5_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_B5;

        public static final java.awt.PageAttributes.MediaType B6 = java.awt.PageAttributes.MediaType.ISO_B6;

        public static final java.awt.PageAttributes.MediaType B7 = java.awt.PageAttributes.MediaType.ISO_B7;

        public static final java.awt.PageAttributes.MediaType B8 = java.awt.PageAttributes.MediaType.ISO_B8;

        public static final java.awt.PageAttributes.MediaType B9 = java.awt.PageAttributes.MediaType.ISO_B9;

        public static final java.awt.PageAttributes.MediaType B10 = java.awt.PageAttributes.MediaType.ISO_B10;

        public static final java.awt.PageAttributes.MediaType C0 = java.awt.PageAttributes.MediaType.ISO_C0;

        public static final java.awt.PageAttributes.MediaType ISO_C0_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C0;

        public static final java.awt.PageAttributes.MediaType C1 = java.awt.PageAttributes.MediaType.ISO_C1;

        public static final java.awt.PageAttributes.MediaType ISO_C1_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C1;

        public static final java.awt.PageAttributes.MediaType C2 = java.awt.PageAttributes.MediaType.ISO_C2;

        public static final java.awt.PageAttributes.MediaType ISO_C2_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C2;

        public static final java.awt.PageAttributes.MediaType C3 = java.awt.PageAttributes.MediaType.ISO_C3;

        public static final java.awt.PageAttributes.MediaType ISO_C3_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C3;

        public static final java.awt.PageAttributes.MediaType C4 = java.awt.PageAttributes.MediaType.ISO_C4;

        public static final java.awt.PageAttributes.MediaType ISO_C4_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C4;

        public static final java.awt.PageAttributes.MediaType C5 = java.awt.PageAttributes.MediaType.ISO_C5;

        public static final java.awt.PageAttributes.MediaType ISO_C5_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C5;

        public static final java.awt.PageAttributes.MediaType C6 = java.awt.PageAttributes.MediaType.ISO_C6;

        public static final java.awt.PageAttributes.MediaType ISO_C6_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C6;

        public static final java.awt.PageAttributes.MediaType C7 = java.awt.PageAttributes.MediaType.ISO_C7;

        public static final java.awt.PageAttributes.MediaType ISO_C7_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C7;

        public static final java.awt.PageAttributes.MediaType C8 = java.awt.PageAttributes.MediaType.ISO_C8;

        public static final java.awt.PageAttributes.MediaType ISO_C8_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C8;

        public static final java.awt.PageAttributes.MediaType C9 = java.awt.PageAttributes.MediaType.ISO_C9;

        public static final java.awt.PageAttributes.MediaType ISO_C9_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C9;

        public static final java.awt.PageAttributes.MediaType C10 = java.awt.PageAttributes.MediaType.ISO_C10;

        public static final java.awt.PageAttributes.MediaType ISO_C10_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_C10;

        public static final java.awt.PageAttributes.MediaType ISO_DESIGNATED_LONG_ENVELOPE = java.awt.PageAttributes.MediaType.ISO_DESIGNATED_LONG;

        public static final java.awt.PageAttributes.MediaType STATEMENT = java.awt.PageAttributes.MediaType.INVOICE;

        public static final java.awt.PageAttributes.MediaType TABLOID = java.awt.PageAttributes.MediaType.LEDGER;

        public static final java.awt.PageAttributes.MediaType LETTER = java.awt.PageAttributes.MediaType.NA_LETTER;

        public static final java.awt.PageAttributes.MediaType NOTE = java.awt.PageAttributes.MediaType.NA_LETTER;

        public static final java.awt.PageAttributes.MediaType LEGAL = java.awt.PageAttributes.MediaType.NA_LEGAL;

        public static final java.awt.PageAttributes.MediaType ENV_10X15 = java.awt.PageAttributes.MediaType.NA_10X15_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_10X14 = java.awt.PageAttributes.MediaType.NA_10X14_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_10X13 = java.awt.PageAttributes.MediaType.NA_10X13_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_9X12 = java.awt.PageAttributes.MediaType.NA_9X12_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_9X11 = java.awt.PageAttributes.MediaType.NA_9X11_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_7X9 = java.awt.PageAttributes.MediaType.NA_7X9_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_6X9 = java.awt.PageAttributes.MediaType.NA_6X9_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_9 = java.awt.PageAttributes.MediaType.NA_NUMBER_9_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_10 = java.awt.PageAttributes.MediaType.NA_NUMBER_10_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_11 = java.awt.PageAttributes.MediaType.NA_NUMBER_11_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_12 = java.awt.PageAttributes.MediaType.NA_NUMBER_12_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_14 = java.awt.PageAttributes.MediaType.NA_NUMBER_14_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_INVITE = java.awt.PageAttributes.MediaType.INVITE_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_ITALY = java.awt.PageAttributes.MediaType.ITALY_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_MONARCH = java.awt.PageAttributes.MediaType.MONARCH_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ENV_PERSONAL = java.awt.PageAttributes.MediaType.PERSONAL_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType INVITE = java.awt.PageAttributes.MediaType.INVITE_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType ITALY = java.awt.PageAttributes.MediaType.ITALY_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType MONARCH = java.awt.PageAttributes.MediaType.MONARCH_ENVELOPE;

        public static final java.awt.PageAttributes.MediaType PERSONAL = java.awt.PageAttributes.MediaType.PERSONAL_ENVELOPE;

        private MediaType(int type) {
            super(type, java.awt.PageAttributes.MediaType.NAMES);
        }
    }

    public static final class OrientationRequestedType extends java.awt.AttributeValue {
        private static final int I_PORTRAIT = 0;

        private static final int I_LANDSCAPE = 1;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "portrait" , "landscape" };

        public static final java.awt.PageAttributes.OrientationRequestedType PORTRAIT = new java.awt.PageAttributes.OrientationRequestedType(java.awt.PageAttributes.OrientationRequestedType.I_PORTRAIT);

        public static final java.awt.PageAttributes.OrientationRequestedType LANDSCAPE = new java.awt.PageAttributes.OrientationRequestedType(java.awt.PageAttributes.OrientationRequestedType.I_LANDSCAPE);

        private OrientationRequestedType(int type) {
            super(type, java.awt.PageAttributes.OrientationRequestedType.NAMES);
        }
    }

    public static final class OriginType extends java.awt.AttributeValue {
        private static final int I_PHYSICAL = 0;

        private static final int I_PRINTABLE = 1;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "physical" , "printable" };

        public static final java.awt.PageAttributes.OriginType PHYSICAL = new java.awt.PageAttributes.OriginType(java.awt.PageAttributes.OriginType.I_PHYSICAL);

        public static final java.awt.PageAttributes.OriginType PRINTABLE = new java.awt.PageAttributes.OriginType(java.awt.PageAttributes.OriginType.I_PRINTABLE);

        private OriginType(int type) {
            super(type, java.awt.PageAttributes.OriginType.NAMES);
        }
    }

    public static final class PrintQualityType extends java.awt.AttributeValue {
        private static final int I_HIGH = 0;

        private static final int I_NORMAL = 1;

        private static final int I_DRAFT = 2;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "high" , "normal" , "draft" };

        public static final java.awt.PageAttributes.PrintQualityType HIGH = new java.awt.PageAttributes.PrintQualityType(java.awt.PageAttributes.PrintQualityType.I_HIGH);

        public static final java.awt.PageAttributes.PrintQualityType NORMAL = new java.awt.PageAttributes.PrintQualityType(java.awt.PageAttributes.PrintQualityType.I_NORMAL);

        public static final java.awt.PageAttributes.PrintQualityType DRAFT = new java.awt.PageAttributes.PrintQualityType(java.awt.PageAttributes.PrintQualityType.I_DRAFT);

        private PrintQualityType(int type) {
            super(type, java.awt.PageAttributes.PrintQualityType.NAMES);
        }
    }

    private java.awt.PageAttributes.ColorType color;

    private java.awt.PageAttributes.MediaType media;

    private java.awt.PageAttributes.OrientationRequestedType orientationRequested;

    private java.awt.PageAttributes.OriginType origin;

    private java.awt.PageAttributes.PrintQualityType printQuality;

    private int[] printerResolution;

    public PageAttributes() {
        setColor(java.awt.PageAttributes.ColorType.MONOCHROME);
        setMediaToDefault();
        setOrientationRequestedToDefault();
        setOrigin(java.awt.PageAttributes.OriginType.PHYSICAL);
        setPrintQualityToDefault();
        setPrinterResolutionToDefault();
    }

    public PageAttributes(java.awt.PageAttributes obj) {
        set(obj);
    }

    public PageAttributes(java.awt.PageAttributes.ColorType color ,java.awt.PageAttributes.MediaType media ,java.awt.PageAttributes.OrientationRequestedType orientationRequested ,java.awt.PageAttributes.OriginType origin ,java.awt.PageAttributes.PrintQualityType printQuality ,int[] printerResolution) {
        setColor(color);
        setMedia(media);
        setOrientationRequested(orientationRequested);
        setOrigin(origin);
        setPrintQuality(printQuality);
        setPrinterResolution(printerResolution);
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }

    public void set(java.awt.PageAttributes obj) {
        color = obj.color;
        media = obj.media;
        orientationRequested = obj.orientationRequested;
        origin = obj.origin;
        printQuality = obj.printQuality;
        printerResolution = obj.printerResolution;
    }

    public java.awt.PageAttributes.ColorType getColor() {
        return color;
    }

    public void setColor(java.awt.PageAttributes.ColorType color) {
        if (color == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "color"));
        } 
        java.awt.PageAttributes.this.color = color;
    }

    public java.awt.PageAttributes.MediaType getMedia() {
        return media;
    }

    public void setMedia(java.awt.PageAttributes.MediaType media) {
        if (media == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "media"));
        } 
        java.awt.PageAttributes.this.media = media;
    }

    public void setMediaToDefault() {
        java.lang.String defaultCountry = java.util.Locale.getDefault().getCountry();
        if ((defaultCountry != null) && ((defaultCountry.equals(java.util.Locale.US.getCountry())) || (defaultCountry.equals(java.util.Locale.CANADA.getCountry())))) {
            setMedia(java.awt.PageAttributes.MediaType.NA_LETTER);
        } else {
            setMedia(java.awt.PageAttributes.MediaType.ISO_A4);
        }
    }

    public java.awt.PageAttributes.OrientationRequestedType getOrientationRequested() {
        return orientationRequested;
    }

    public void setOrientationRequested(java.awt.PageAttributes.OrientationRequestedType orientationRequested) {
        if (orientationRequested == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "orientationRequested"));
        } 
        java.awt.PageAttributes.this.orientationRequested = orientationRequested;
    }

    public void setOrientationRequested(int orientationRequested) {
        switch (orientationRequested) {
            case 3 :
                setOrientationRequested(java.awt.PageAttributes.OrientationRequestedType.PORTRAIT);
                break;
            case 4 :
                setOrientationRequested(java.awt.PageAttributes.OrientationRequestedType.LANDSCAPE);
                break;
            default :
                setOrientationRequested(null);
                break;
        }
    }

    public void setOrientationRequestedToDefault() {
        setOrientationRequested(java.awt.PageAttributes.OrientationRequestedType.PORTRAIT);
    }

    public java.awt.PageAttributes.OriginType getOrigin() {
        return origin;
    }

    public void setOrigin(java.awt.PageAttributes.OriginType origin) {
        if (origin == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "origin"));
        } 
        java.awt.PageAttributes.this.origin = origin;
    }

    public java.awt.PageAttributes.PrintQualityType getPrintQuality() {
        return printQuality;
    }

    public void setPrintQuality(java.awt.PageAttributes.PrintQualityType printQuality) {
        if (printQuality == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "printQuality"));
        } 
        java.awt.PageAttributes.this.printQuality = printQuality;
    }

    public void setPrintQuality(int printQuality) {
        switch (printQuality) {
            case 3 :
                setPrintQuality(java.awt.PageAttributes.PrintQualityType.DRAFT);
                break;
            case 4 :
                setPrintQuality(java.awt.PageAttributes.PrintQualityType.NORMAL);
                break;
            case 5 :
                setPrintQuality(java.awt.PageAttributes.PrintQualityType.HIGH);
                break;
            default :
                setPrintQuality(null);
                break;
        }
    }

    public void setPrintQualityToDefault() {
        setPrintQuality(java.awt.PageAttributes.PrintQualityType.NORMAL);
    }

    public int[] getPrinterResolution() {
        int[] copy = new int[3];
        copy[0] = printerResolution[0];
        copy[1] = printerResolution[1];
        copy[2] = printerResolution[2];
        return copy;
    }

    public void setPrinterResolution(int[] printerResolution) {
        if (((((printerResolution == null) || ((printerResolution.length) != 3)) || ((printerResolution[0]) <= 0)) || ((printerResolution[1]) <= 0)) || (((printerResolution[2]) != 3) && ((printerResolution[2]) != 4))) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "printerResolution"));
        } 
        int[] copy = new int[3];
        copy[0] = printerResolution[0];
        copy[1] = printerResolution[1];
        copy[2] = printerResolution[2];
        java.awt.PageAttributes.this.printerResolution = copy;
    }

    public void setPrinterResolution(int printerResolution) {
        setPrinterResolution(new int[]{ printerResolution , printerResolution , 3 });
    }

    public void setPrinterResolutionToDefault() {
        setPrinterResolution(72);
    }

    public boolean equals(java.lang.Object obj) {
        if (!(obj instanceof java.awt.PageAttributes)) {
            return false;
        } 
        java.awt.PageAttributes rhs = ((java.awt.PageAttributes)(obj));
        return ((((((((color) == (rhs.color)) && ((media) == (rhs.media))) && ((orientationRequested) == (rhs.orientationRequested))) && ((origin) == (rhs.origin))) && ((printQuality) == (rhs.printQuality))) && ((printerResolution[0]) == (rhs.printerResolution[0]))) && ((printerResolution[1]) == (rhs.printerResolution[1]))) && ((printerResolution[2]) == (rhs.printerResolution[2]));
    }

    public int hashCode() {
        return ((((((((color.hashCode()) << 31) ^ ((media.hashCode()) << 24)) ^ ((orientationRequested.hashCode()) << 23)) ^ ((origin.hashCode()) << 22)) ^ ((printQuality.hashCode()) << 20)) ^ (((printerResolution[2]) >> 2) << 19)) ^ ((printerResolution[1]) << 10)) ^ (printerResolution[0]);
    }

    public java.lang.String toString() {
        return ((((((((((((((("color=" + (getColor())) + ",media=") + (getMedia())) + ",orientation-requested=") + (getOrientationRequested())) + ",origin=") + (getOrigin())) + ",print-quality=") + (getPrintQuality())) + ",printer-resolution=[") + (printerResolution[0])) + ",") + (printerResolution[1])) + ",") + (printerResolution[2])) + "]";
    }
}


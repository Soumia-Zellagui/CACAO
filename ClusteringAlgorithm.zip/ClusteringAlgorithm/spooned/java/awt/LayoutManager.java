package java.awt;


public interface LayoutManager {
    void addLayoutComponent(java.lang.String name, java.awt.Component comp);

    void removeLayoutComponent(java.awt.Component comp);

    java.awt.Dimension preferredLayoutSize(java.awt.Container parent);

    java.awt.Dimension minimumLayoutSize(java.awt.Container parent);

    void layoutContainer(java.awt.Container parent);
}


package java.awt;


public final class JobAttributes implements java.lang.Cloneable {
    public static final class DefaultSelectionType extends java.awt.AttributeValue {
        private static final int I_ALL = 0;

        private static final int I_RANGE = 1;

        private static final int I_SELECTION = 2;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "all" , "range" , "selection" };

        public static final java.awt.JobAttributes.DefaultSelectionType ALL = new java.awt.JobAttributes.DefaultSelectionType(java.awt.JobAttributes.DefaultSelectionType.I_ALL);

        public static final java.awt.JobAttributes.DefaultSelectionType RANGE = new java.awt.JobAttributes.DefaultSelectionType(java.awt.JobAttributes.DefaultSelectionType.I_RANGE);

        public static final java.awt.JobAttributes.DefaultSelectionType SELECTION = new java.awt.JobAttributes.DefaultSelectionType(java.awt.JobAttributes.DefaultSelectionType.I_SELECTION);

        private DefaultSelectionType(int type) {
            super(type, java.awt.JobAttributes.DefaultSelectionType.NAMES);
        }
    }

    public static final class DestinationType extends java.awt.AttributeValue {
        private static final int I_FILE = 0;

        private static final int I_PRINTER = 1;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "file" , "printer" };

        public static final java.awt.JobAttributes.DestinationType FILE = new java.awt.JobAttributes.DestinationType(java.awt.JobAttributes.DestinationType.I_FILE);

        public static final java.awt.JobAttributes.DestinationType PRINTER = new java.awt.JobAttributes.DestinationType(java.awt.JobAttributes.DestinationType.I_PRINTER);

        private DestinationType(int type) {
            super(type, java.awt.JobAttributes.DestinationType.NAMES);
        }
    }

    public static final class DialogType extends java.awt.AttributeValue {
        private static final int I_COMMON = 0;

        private static final int I_NATIVE = 1;

        private static final int I_NONE = 2;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "common" , "native" , "none" };

        public static final java.awt.JobAttributes.DialogType COMMON = new java.awt.JobAttributes.DialogType(java.awt.JobAttributes.DialogType.I_COMMON);

        public static final java.awt.JobAttributes.DialogType NATIVE = new java.awt.JobAttributes.DialogType(java.awt.JobAttributes.DialogType.I_NATIVE);

        public static final java.awt.JobAttributes.DialogType NONE = new java.awt.JobAttributes.DialogType(java.awt.JobAttributes.DialogType.I_NONE);

        private DialogType(int type) {
            super(type, java.awt.JobAttributes.DialogType.NAMES);
        }
    }

    public static final class MultipleDocumentHandlingType extends java.awt.AttributeValue {
        private static final int I_SEPARATE_DOCUMENTS_COLLATED_COPIES = 0;

        private static final int I_SEPARATE_DOCUMENTS_UNCOLLATED_COPIES = 1;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "separate-documents-collated-copies" , "separate-documents-uncollated-copies" };

        public static final java.awt.JobAttributes.MultipleDocumentHandlingType SEPARATE_DOCUMENTS_COLLATED_COPIES = new java.awt.JobAttributes.MultipleDocumentHandlingType(java.awt.JobAttributes.MultipleDocumentHandlingType.I_SEPARATE_DOCUMENTS_COLLATED_COPIES);

        public static final java.awt.JobAttributes.MultipleDocumentHandlingType SEPARATE_DOCUMENTS_UNCOLLATED_COPIES = new java.awt.JobAttributes.MultipleDocumentHandlingType(java.awt.JobAttributes.MultipleDocumentHandlingType.I_SEPARATE_DOCUMENTS_UNCOLLATED_COPIES);

        private MultipleDocumentHandlingType(int type) {
            super(type, java.awt.JobAttributes.MultipleDocumentHandlingType.NAMES);
        }
    }

    public static final class SidesType extends java.awt.AttributeValue {
        private static final int I_ONE_SIDED = 0;

        private static final int I_TWO_SIDED_LONG_EDGE = 1;

        private static final int I_TWO_SIDED_SHORT_EDGE = 2;

        private static final java.lang.String[] NAMES = new java.lang.String[]{ "one-sided" , "two-sided-long-edge" , "two-sided-short-edge" };

        public static final java.awt.JobAttributes.SidesType ONE_SIDED = new java.awt.JobAttributes.SidesType(java.awt.JobAttributes.SidesType.I_ONE_SIDED);

        public static final java.awt.JobAttributes.SidesType TWO_SIDED_LONG_EDGE = new java.awt.JobAttributes.SidesType(java.awt.JobAttributes.SidesType.I_TWO_SIDED_LONG_EDGE);

        public static final java.awt.JobAttributes.SidesType TWO_SIDED_SHORT_EDGE = new java.awt.JobAttributes.SidesType(java.awt.JobAttributes.SidesType.I_TWO_SIDED_SHORT_EDGE);

        private SidesType(int type) {
            super(type, java.awt.JobAttributes.SidesType.NAMES);
        }
    }

    private int copies;

    private java.awt.JobAttributes.DefaultSelectionType defaultSelection;

    private java.awt.JobAttributes.DestinationType destination;

    private java.awt.JobAttributes.DialogType dialog;

    private java.lang.String fileName;

    private int fromPage;

    private int maxPage;

    private int minPage;

    private java.awt.JobAttributes.MultipleDocumentHandlingType multipleDocumentHandling;

    private int[][] pageRanges;

    private int prFirst;

    private int prLast;

    private java.lang.String printer;

    private java.awt.JobAttributes.SidesType sides;

    private int toPage;

    public JobAttributes() {
        setCopiesToDefault();
        setDefaultSelection(java.awt.JobAttributes.DefaultSelectionType.ALL);
        setDestination(java.awt.JobAttributes.DestinationType.PRINTER);
        setDialog(java.awt.JobAttributes.DialogType.NATIVE);
        setMaxPage(java.lang.Integer.MAX_VALUE);
        setMinPage(1);
        setMultipleDocumentHandlingToDefault();
        setSidesToDefault();
    }

    public JobAttributes(java.awt.JobAttributes obj) {
        set(obj);
    }

    public JobAttributes(int copies ,java.awt.JobAttributes.DefaultSelectionType defaultSelection ,java.awt.JobAttributes.DestinationType destination ,java.awt.JobAttributes.DialogType dialog ,java.lang.String fileName ,int maxPage ,int minPage ,java.awt.JobAttributes.MultipleDocumentHandlingType multipleDocumentHandling ,int[][] pageRanges ,java.lang.String printer ,java.awt.JobAttributes.SidesType sides) {
        setCopies(copies);
        setDefaultSelection(defaultSelection);
        setDestination(destination);
        setDialog(dialog);
        setFileName(fileName);
        setMaxPage(maxPage);
        setMinPage(minPage);
        setMultipleDocumentHandling(multipleDocumentHandling);
        setPageRanges(pageRanges);
        setPrinter(printer);
        setSides(sides);
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }

    public void set(java.awt.JobAttributes obj) {
        copies = obj.copies;
        defaultSelection = obj.defaultSelection;
        destination = obj.destination;
        dialog = obj.dialog;
        fileName = obj.fileName;
        fromPage = obj.fromPage;
        maxPage = obj.maxPage;
        minPage = obj.minPage;
        multipleDocumentHandling = obj.multipleDocumentHandling;
        pageRanges = obj.pageRanges;
        prFirst = obj.prFirst;
        prLast = obj.prLast;
        printer = obj.printer;
        sides = obj.sides;
        toPage = obj.toPage;
    }

    public int getCopies() {
        return copies;
    }

    public void setCopies(int copies) {
        if (copies <= 0) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "copies"));
        } 
        java.awt.JobAttributes.this.copies = copies;
    }

    public void setCopiesToDefault() {
        setCopies(1);
    }

    public java.awt.JobAttributes.DefaultSelectionType getDefaultSelection() {
        return defaultSelection;
    }

    public void setDefaultSelection(java.awt.JobAttributes.DefaultSelectionType defaultSelection) {
        if (defaultSelection == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "defaultSelection"));
        } 
        java.awt.JobAttributes.this.defaultSelection = defaultSelection;
    }

    public java.awt.JobAttributes.DestinationType getDestination() {
        return destination;
    }

    public void setDestination(java.awt.JobAttributes.DestinationType destination) {
        if (destination == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "destination"));
        } 
        java.awt.JobAttributes.this.destination = destination;
    }

    public java.awt.JobAttributes.DialogType getDialog() {
        return dialog;
    }

    public void setDialog(java.awt.JobAttributes.DialogType dialog) {
        if (dialog == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "dialog"));
        } 
        java.awt.JobAttributes.this.dialog = dialog;
    }

    public java.lang.String getFileName() {
        return fileName;
    }

    public void setFileName(java.lang.String fileName) {
        java.awt.JobAttributes.this.fileName = fileName;
    }

    public int getFromPage() {
        if ((fromPage) != 0) {
            return fromPage;
        } else if ((toPage) != 0) {
            return getMinPage();
        } else if ((pageRanges) != null) {
            return prFirst;
        } else {
            return getMinPage();
        }
    }

    public void setFromPage(int fromPage) {
        if ((((fromPage <= 0) || (((toPage) != 0) && (fromPage > (toPage)))) || (fromPage < (minPage))) || (fromPage > (maxPage))) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "fromPage"));
        } 
        java.awt.JobAttributes.this.fromPage = fromPage;
    }

    public int getMaxPage() {
        return maxPage;
    }

    public void setMaxPage(int maxPage) {
        if ((maxPage <= 0) || (maxPage < (minPage))) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "maxPage"));
        } 
        java.awt.JobAttributes.this.maxPage = maxPage;
    }

    public int getMinPage() {
        return minPage;
    }

    public void setMinPage(int minPage) {
        if ((minPage <= 0) || (minPage > (maxPage))) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "minPage"));
        } 
        java.awt.JobAttributes.this.minPage = minPage;
    }

    public java.awt.JobAttributes.MultipleDocumentHandlingType getMultipleDocumentHandling() {
        return multipleDocumentHandling;
    }

    public void setMultipleDocumentHandling(java.awt.JobAttributes.MultipleDocumentHandlingType multipleDocumentHandling) {
        if (multipleDocumentHandling == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "multipleDocumentHandling"));
        } 
        java.awt.JobAttributes.this.multipleDocumentHandling = multipleDocumentHandling;
    }

    public void setMultipleDocumentHandlingToDefault() {
        setMultipleDocumentHandling(java.awt.JobAttributes.MultipleDocumentHandlingType.SEPARATE_DOCUMENTS_UNCOLLATED_COPIES);
    }

    public int[][] getPageRanges() {
        if ((pageRanges) != null) {
            int[][] copy = new int[pageRanges.length][2];
            for (int i = 0 ; i < (pageRanges.length) ; i++) {
                copy[i][0] = pageRanges[i][0];
                copy[i][1] = pageRanges[i][1];
            }
            return copy;
        } else if (((fromPage) != 0) || ((toPage) != 0)) {
            int fromPage = getFromPage();
            int toPage = getToPage();
            return new int[][]{ new int[]{ fromPage , toPage } };
        } else {
            int minPage = getMinPage();
            return new int[][]{ new int[]{ minPage , minPage } };
        }
    }

    public void setPageRanges(int[][] pageRanges) {
        java.lang.String xcp = "Invalid value for attribute pageRanges";
        int first = 0;
        int last = 0;
        if (pageRanges == null) {
            throw new java.lang.IllegalArgumentException(xcp);
        } 
        for (int i = 0 ; i < (pageRanges.length) ; i++) {
            if (((((pageRanges[i]) == null) || ((pageRanges[i].length) != 2)) || ((pageRanges[i][0]) <= last)) || ((pageRanges[i][1]) < (pageRanges[i][0]))) {
                throw new java.lang.IllegalArgumentException(xcp);
            } 
            last = pageRanges[i][1];
            if (first == 0) {
                first = pageRanges[i][0];
            } 
        }
        if ((first < (minPage)) || (last > (maxPage))) {
            throw new java.lang.IllegalArgumentException(xcp);
        } 
        int[][] copy = new int[pageRanges.length][2];
        for (int i = 0 ; i < (pageRanges.length) ; i++) {
            copy[i][0] = pageRanges[i][0];
            copy[i][1] = pageRanges[i][1];
        }
        java.awt.JobAttributes.this.pageRanges = copy;
        java.awt.JobAttributes.this.prFirst = first;
        java.awt.JobAttributes.this.prLast = last;
    }

    public java.lang.String getPrinter() {
        return printer;
    }

    public void setPrinter(java.lang.String printer) {
        java.awt.JobAttributes.this.printer = printer;
    }

    public java.awt.JobAttributes.SidesType getSides() {
        return sides;
    }

    public void setSides(java.awt.JobAttributes.SidesType sides) {
        if (sides == null) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "sides"));
        } 
        java.awt.JobAttributes.this.sides = sides;
    }

    public void setSidesToDefault() {
        setSides(java.awt.JobAttributes.SidesType.ONE_SIDED);
    }

    public int getToPage() {
        if ((toPage) != 0) {
            return toPage;
        } else if ((fromPage) != 0) {
            return fromPage;
        } else if ((pageRanges) != null) {
            return prLast;
        } else {
            return getMinPage();
        }
    }

    public void setToPage(int toPage) {
        if ((((toPage <= 0) || (((fromPage) != 0) && (toPage < (fromPage)))) || (toPage < (minPage))) || (toPage > (maxPage))) {
            throw new java.lang.IllegalArgumentException(("Invalid value for attribute " + "toPage"));
        } 
        java.awt.JobAttributes.this.toPage = toPage;
    }

    public boolean equals(java.lang.Object obj) {
        if (!(obj instanceof java.awt.JobAttributes)) {
            return false;
        } 
        java.awt.JobAttributes rhs = ((java.awt.JobAttributes)(obj));
        if ((fileName) == null) {
            if ((rhs.fileName) != null) {
                return false;
            } 
        } else {
            if (!(fileName.equals(rhs.fileName))) {
                return false;
            } 
        }
        if ((pageRanges) == null) {
            if ((rhs.pageRanges) != null) {
                return false;
            } 
        } else {
            if (((rhs.pageRanges) == null) || ((pageRanges.length) != (rhs.pageRanges.length))) {
                return false;
            } 
            for (int i = 0 ; i < (pageRanges.length) ; i++) {
                if (((pageRanges[i][0]) != (rhs.pageRanges[i][0])) || ((pageRanges[i][1]) != (rhs.pageRanges[i][1]))) {
                    return false;
                } 
            }
        }
        if ((printer) == null) {
            if ((rhs.printer) != null) {
                return false;
            } 
        } else {
            if (!(printer.equals(rhs.printer))) {
                return false;
            } 
        }
        return ((((((((((((copies) == (rhs.copies)) && ((defaultSelection) == (rhs.defaultSelection))) && ((destination) == (rhs.destination))) && ((dialog) == (rhs.dialog))) && ((fromPage) == (rhs.fromPage))) && ((maxPage) == (rhs.maxPage))) && ((minPage) == (rhs.minPage))) && ((multipleDocumentHandling) == (rhs.multipleDocumentHandling))) && ((prFirst) == (rhs.prFirst))) && ((prLast) == (rhs.prLast))) && ((sides) == (rhs.sides))) && ((toPage) == (rhs.toPage));
    }

    public int hashCode() {
        int rest = ((((((((copies) + (fromPage)) + (maxPage)) + (minPage)) + (prFirst)) + (prLast)) + (toPage)) * 31) << 21;
        if ((pageRanges) != null) {
            int sum = 0;
            for (int i = 0 ; i < (pageRanges.length) ; i++) {
                sum += (pageRanges[i][0]) + (pageRanges[i][1]);
            }
            rest ^= (sum * 31) << 11;
        } 
        if ((fileName) != null) {
            rest ^= fileName.hashCode();
        } 
        if ((printer) != null) {
            rest ^= printer.hashCode();
        } 
        return ((((((defaultSelection.hashCode()) << 6) ^ ((destination.hashCode()) << 5)) ^ ((dialog.hashCode()) << 3)) ^ ((multipleDocumentHandling.hashCode()) << 2)) ^ (sides.hashCode())) ^ rest;
    }

    public java.lang.String toString() {
        int[][] pageRanges = getPageRanges();
        java.lang.String prStr = "[";
        boolean first = true;
        for (int i = 0 ; i < (pageRanges.length) ; i++) {
            if (first) {
                first = false;
            } else {
                prStr += ",";
            }
            prStr += ((pageRanges[i][0]) + ":") + (pageRanges[i][1]);
        }
        prStr += "]";
        return (((((((((((((((((((((((("copies=" + (getCopies())) + ",defaultSelection=") + (getDefaultSelection())) + ",destination=") + (getDestination())) + ",dialog=") + (getDialog())) + ",fileName=") + (getFileName())) + ",fromPage=") + (getFromPage())) + ",maxPage=") + (getMaxPage())) + ",minPage=") + (getMinPage())) + ",multiple-document-handling=") + (getMultipleDocumentHandling())) + ",page-ranges=") + prStr) + ",printer=") + (getPrinter())) + ",sides=") + (getSides())) + ",toPage=") + (getToPage());
    }
}


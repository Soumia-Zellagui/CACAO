package java.awt;


@java.lang.FunctionalInterface
public interface KeyEventPostProcessor {
    boolean postProcessKeyEvent(java.awt.event.KeyEvent e);
}


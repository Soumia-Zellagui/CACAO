package java.awt;


class WaitDispatchSupport implements java.awt.SecondaryLoop {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.event.WaitDispatchSupport");

    private java.awt.EventDispatchThread dispatchThread;

    private java.awt.EventFilter filter;

    private volatile java.awt.Conditional extCondition;

    private volatile java.awt.Conditional condition;

    private long interval;

    private static java.util.Timer timer;

    private java.util.TimerTask timerTask;

    private java.util.concurrent.atomic.AtomicBoolean keepBlockingEDT = new java.util.concurrent.atomic.AtomicBoolean(false);

    private java.util.concurrent.atomic.AtomicBoolean keepBlockingCT = new java.util.concurrent.atomic.AtomicBoolean(false);

    private static synchronized void initializeTimer() {
        if ((java.awt.WaitDispatchSupport.timer) == null) {
            java.awt.WaitDispatchSupport.timer = new java.util.Timer("AWT-WaitDispatchSupport-Timer" , true);
        } 
    }

    public WaitDispatchSupport(java.awt.EventDispatchThread dispatchThread) {
        this(dispatchThread, null);
    }

    public WaitDispatchSupport(java.awt.EventDispatchThread dispatchThread ,java.awt.Conditional extCond) {
        if (dispatchThread == null) {
            throw new java.lang.IllegalArgumentException("The dispatchThread can not be null");
        } 
        java.awt.WaitDispatchSupport.this.dispatchThread = dispatchThread;
        java.awt.WaitDispatchSupport.this.extCondition = extCond;
        java.awt.WaitDispatchSupport.this.condition = new java.awt.Conditional() {
            @java.lang.Override
            public boolean evaluate() {
                if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.WaitDispatchSupport.log.finest(((("evaluate(): blockingEDT=" + (keepBlockingEDT.get())) + ", blockingCT=") + (keepBlockingCT.get())));
                } 
                boolean extEvaluate = (extCondition) != null ? extCondition.evaluate() : true;
                if ((!(keepBlockingEDT.get())) || (!extEvaluate)) {
                    if ((timerTask) != null) {
                        timerTask.cancel();
                        timerTask = null;
                    } 
                    return false;
                } 
                return true;
            }
        };
    }

    public WaitDispatchSupport(java.awt.EventDispatchThread dispatchThread ,java.awt.Conditional extCondition ,java.awt.EventFilter filter ,long interval) {
        this(dispatchThread, extCondition);
        java.awt.WaitDispatchSupport.this.filter = filter;
        if (interval < 0) {
            throw new java.lang.IllegalArgumentException("The interval value must be >= 0");
        } 
        java.awt.WaitDispatchSupport.this.interval = interval;
        if (interval != 0) {
            java.awt.WaitDispatchSupport.initializeTimer();
        } 
    }

    @java.lang.Override
    public boolean enter() {
        if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.WaitDispatchSupport.log.fine(((("enter(): blockingEDT=" + (keepBlockingEDT.get())) + ", blockingCT=") + (keepBlockingCT.get())));
        } 
        if (!(keepBlockingEDT.compareAndSet(false, true))) {
            java.awt.WaitDispatchSupport.log.fine("The secondary loop is already running, aborting");
            return false;
        } 
        final java.lang.Runnable run = new java.lang.Runnable() {
            public void run() {
                java.awt.WaitDispatchSupport.log.fine("Starting a new event pump");
                if ((filter) == null) {
                    dispatchThread.pumpEvents(condition);
                } else {
                    dispatchThread.pumpEventsForFilter(condition, filter);
                }
            }
        };
        java.lang.Thread currentThread = java.lang.Thread.currentThread();
        if (currentThread == (dispatchThread)) {
            if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.WaitDispatchSupport.log.finest(("On dispatch thread: " + (dispatchThread)));
            } 
            if ((interval) != 0) {
                if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.WaitDispatchSupport.log.finest((("scheduling the timer for " + (interval)) + " ms"));
                } 
                java.awt.WaitDispatchSupport.timer.schedule((timerTask = new java.util.TimerTask() {
                    @java.lang.Override
                    public void run() {
                        if (keepBlockingEDT.compareAndSet(true, false)) {
                            wakeupEDT();
                        } 
                    }
                }), interval);
            } 
            java.awt.SequencedEvent currentSE = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getCurrentSequencedEvent();
            if (currentSE != null) {
                if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.WaitDispatchSupport.log.fine(("Dispose current SequencedEvent: " + currentSE));
                } 
                currentSE.dispose();
            } 
            java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
                public java.lang.Void run() {
                    run.run();
                    return null;
                }
            });
        } else {
            if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.WaitDispatchSupport.log.finest(("On non-dispatch thread: " + currentThread));
            } 
            synchronized(java.awt.WaitDispatchSupport.getTreeLock()) {
                if ((filter) != null) {
                    dispatchThread.addEventFilter(filter);
                } 
                try {
                    java.awt.EventQueue eq = dispatchThread.getEventQueue();
                    eq.postEvent(new sun.awt.PeerEvent(java.awt.WaitDispatchSupport.this , run , sun.awt.PeerEvent.PRIORITY_EVENT));
                    keepBlockingCT.set(true);
                    if ((interval) > 0) {
                        long currTime = java.lang.System.currentTimeMillis();
                        while (((keepBlockingCT.get()) && ((extCondition) != null ? extCondition.evaluate() : true)) && ((currTime + (interval)) > (java.lang.System.currentTimeMillis()))) {
                            java.awt.WaitDispatchSupport.getTreeLock().wait(interval);
                        }
                    } else {
                        while ((keepBlockingCT.get()) && ((extCondition) != null ? extCondition.evaluate() : true)) {
                            java.awt.WaitDispatchSupport.getTreeLock().wait();
                        }
                    }
                    if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.WaitDispatchSupport.log.fine(((("waitDone " + (keepBlockingEDT.get())) + " ") + (keepBlockingCT.get())));
                    } 
                } catch (java.lang.InterruptedException e) {
                    if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.WaitDispatchSupport.log.fine(("Exception caught while waiting: " + e));
                    } 
                } finally {
                    if ((filter) != null) {
                        dispatchThread.removeEventFilter(filter);
                    } 
                }
                keepBlockingEDT.set(false);
                keepBlockingCT.set(false);
            }
        }
        return true;
    }

    public boolean exit() {
        if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.WaitDispatchSupport.log.fine(((("exit(): blockingEDT=" + (keepBlockingEDT.get())) + ", blockingCT=") + (keepBlockingCT.get())));
        } 
        if (keepBlockingEDT.compareAndSet(true, false)) {
            wakeupEDT();
            return true;
        } 
        return false;
    }

    private static final java.lang.Object getTreeLock() {
        return java.awt.Component.LOCK;
    }

    private final java.lang.Runnable wakingRunnable = new java.lang.Runnable() {
        public void run() {
            java.awt.WaitDispatchSupport.log.fine("Wake up EDT");
            synchronized(java.awt.WaitDispatchSupport.getTreeLock()) {
                keepBlockingCT.set(false);
                java.awt.WaitDispatchSupport.getTreeLock().notifyAll();
            }
            java.awt.WaitDispatchSupport.log.fine("Wake up EDT done");
        }
    };

    private void wakeupEDT() {
        if (java.awt.WaitDispatchSupport.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.WaitDispatchSupport.log.finest(("wakeupEDT(): EDT == " + (dispatchThread)));
        } 
        java.awt.EventQueue eq = dispatchThread.getEventQueue();
        eq.postEvent(new sun.awt.PeerEvent(java.awt.WaitDispatchSupport.this , wakingRunnable , sun.awt.PeerEvent.PRIORITY_EVENT));
    }
}


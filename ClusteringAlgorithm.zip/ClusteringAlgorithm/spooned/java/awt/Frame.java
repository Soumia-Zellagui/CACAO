package java.awt;


public class Frame extends java.awt.Window implements java.awt.MenuContainer {
    @java.lang.Deprecated
    public static final int DEFAULT_CURSOR = java.awt.Cursor.DEFAULT_CURSOR;

    @java.lang.Deprecated
    public static final int CROSSHAIR_CURSOR = java.awt.Cursor.CROSSHAIR_CURSOR;

    @java.lang.Deprecated
    public static final int TEXT_CURSOR = java.awt.Cursor.TEXT_CURSOR;

    @java.lang.Deprecated
    public static final int WAIT_CURSOR = java.awt.Cursor.WAIT_CURSOR;

    @java.lang.Deprecated
    public static final int SW_RESIZE_CURSOR = java.awt.Cursor.SW_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int SE_RESIZE_CURSOR = java.awt.Cursor.SE_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int NW_RESIZE_CURSOR = java.awt.Cursor.NW_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int NE_RESIZE_CURSOR = java.awt.Cursor.NE_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int N_RESIZE_CURSOR = java.awt.Cursor.N_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int S_RESIZE_CURSOR = java.awt.Cursor.S_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int W_RESIZE_CURSOR = java.awt.Cursor.W_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int E_RESIZE_CURSOR = java.awt.Cursor.E_RESIZE_CURSOR;

    @java.lang.Deprecated
    public static final int HAND_CURSOR = java.awt.Cursor.HAND_CURSOR;

    @java.lang.Deprecated
    public static final int MOVE_CURSOR = java.awt.Cursor.MOVE_CURSOR;

    public static final int NORMAL = 0;

    public static final int ICONIFIED = 1;

    public static final int MAXIMIZED_HORIZ = 2;

    public static final int MAXIMIZED_VERT = 4;

    public static final int MAXIMIZED_BOTH = (java.awt.Frame.MAXIMIZED_VERT) | (java.awt.Frame.MAXIMIZED_HORIZ);

    java.awt.Rectangle maximizedBounds;

    java.lang.String title = "Untitled";

    java.awt.MenuBar menuBar;

    boolean resizable = true;

    boolean undecorated = false;

    boolean mbManagement = false;

    private int state = java.awt.Frame.NORMAL;

    java.util.Vector<java.awt.Window> ownedWindows;

    private static final java.lang.String base = "frame";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 2673458971256075116L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Frame.initIDs();
        } 
    }

    public Frame() throws java.awt.HeadlessException {
        this("");
    }

    public Frame(java.awt.GraphicsConfiguration gc) {
        this("", gc);
    }

    public Frame(java.lang.String title) throws java.awt.HeadlessException {
        init(title, null);
    }

    public Frame(java.lang.String title ,java.awt.GraphicsConfiguration gc) {
        super(gc);
        init(title, gc);
    }

    private void init(java.lang.String title, java.awt.GraphicsConfiguration gc) {
        java.awt.Frame.this.title = title;
        sun.awt.SunToolkit.checkAndSetPolicy(java.awt.Frame.this);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Frame.class) {
            return (java.awt.Frame.base) + ((java.awt.Frame.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null) {
                peer = getToolkit().createFrame(java.awt.Frame.this);
            } 
            java.awt.peer.FramePeer p = ((java.awt.peer.FramePeer)(peer));
            java.awt.MenuBar menuBar = java.awt.Frame.this.menuBar;
            if (menuBar != null) {
                mbManagement = true;
                menuBar.addNotify();
                p.setMenuBar(menuBar);
            } 
            p.setMaximizedBounds(maximizedBounds);
            super.addNotify();
        }
    }

    public java.lang.String getTitle() {
        return title;
    }

    public void setTitle(java.lang.String title) {
        java.lang.String oldTitle = java.awt.Frame.this.title;
        if (title == null) {
            title = "";
        } 
        synchronized(java.awt.Frame.this) {
            java.awt.Frame.this.title = title;
            java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
            if (peer != null) {
                peer.setTitle(title);
            } 
        }
        firePropertyChange("title", oldTitle, title);
    }

    public java.awt.Image getIconImage() {
        java.util.List<java.awt.Image> icons = java.awt.Frame.this.icons;
        if (icons != null) {
            if ((icons.size()) > 0) {
                return icons.get(0);
            } 
        } 
        return null;
    }

    public void setIconImage(java.awt.Image image) {
        super.setIconImage(image);
    }

    public java.awt.MenuBar getMenuBar() {
        return menuBar;
    }

    public void setMenuBar(java.awt.MenuBar mb) {
        synchronized(getTreeLock()) {
            if ((menuBar) == mb) {
                return ;
            } 
            if ((mb != null) && ((mb.parent) != null)) {
                mb.parent.remove(mb);
            } 
            if ((menuBar) != null) {
                remove(menuBar);
            } 
            menuBar = mb;
            if ((menuBar) != null) {
                menuBar.parent = java.awt.Frame.this;
                java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
                if (peer != null) {
                    mbManagement = true;
                    menuBar.addNotify();
                    invalidateIfValid();
                    peer.setMenuBar(menuBar);
                } 
            } 
        }
    }

    public boolean isResizable() {
        return resizable;
    }

    public void setResizable(boolean resizable) {
        boolean oldResizable = java.awt.Frame.this.resizable;
        boolean testvalid = false;
        synchronized(java.awt.Frame.this) {
            java.awt.Frame.this.resizable = resizable;
            java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
            if (peer != null) {
                peer.setResizable(resizable);
                testvalid = true;
            } 
        }
        if (testvalid) {
            invalidateIfValid();
        } 
        firePropertyChange("resizable", oldResizable, resizable);
    }

    public synchronized void setState(int state) {
        int current = getExtendedState();
        if ((state == (java.awt.Frame.ICONIFIED)) && ((current & (java.awt.Frame.ICONIFIED)) == 0)) {
            setExtendedState((current | (java.awt.Frame.ICONIFIED)));
        } else if ((state == (java.awt.Frame.NORMAL)) && ((current & (java.awt.Frame.ICONIFIED)) != 0)) {
            setExtendedState((current & (~(java.awt.Frame.ICONIFIED))));
        } 
    }

    public void setExtendedState(int state) {
        if (!(isFrameStateSupported(state))) {
            return ;
        } 
        synchronized(getObjectLock()) {
            java.awt.Frame.this.state = state;
        }
        java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
        if (peer != null) {
            peer.setState(state);
        } 
    }

    private boolean isFrameStateSupported(int state) {
        if (!(getToolkit().isFrameStateSupported(state))) {
            if (((state & (java.awt.Frame.ICONIFIED)) != 0) && (!(getToolkit().isFrameStateSupported(java.awt.Frame.ICONIFIED)))) {
                return false;
            } else {
                state &= ~(java.awt.Frame.ICONIFIED);
            }
            return getToolkit().isFrameStateSupported(state);
        } 
        return true;
    }

    public synchronized int getState() {
        return ((getExtendedState()) & (java.awt.Frame.ICONIFIED)) != 0 ? java.awt.Frame.ICONIFIED : java.awt.Frame.NORMAL;
    }

    public int getExtendedState() {
        synchronized(getObjectLock()) {
            return state;
        }
    }

    static {
        sun.awt.AWTAccessor.setFrameAccessor(new sun.awt.AWTAccessor.FrameAccessor() {
            public void setExtendedState(java.awt.Frame frame, int state) {
                synchronized(frame.getObjectLock()) {
                    frame.state = state;
                }
            }

            public int getExtendedState(java.awt.Frame frame) {
                synchronized(frame.getObjectLock()) {
                    return frame.state;
                }
            }

            public java.awt.Rectangle getMaximizedBounds(java.awt.Frame frame) {
                synchronized(frame.getObjectLock()) {
                    return frame.maximizedBounds;
                }
            }
        });
    }

    public void setMaximizedBounds(java.awt.Rectangle bounds) {
        synchronized(getObjectLock()) {
            java.awt.Frame.this.maximizedBounds = bounds;
        }
        java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
        if (peer != null) {
            peer.setMaximizedBounds(bounds);
        } 
    }

    public java.awt.Rectangle getMaximizedBounds() {
        synchronized(getObjectLock()) {
            return maximizedBounds;
        }
    }

    public void setUndecorated(boolean undecorated) {
        synchronized(getTreeLock()) {
            if (isDisplayable()) {
                throw new java.awt.IllegalComponentStateException("The frame is displayable.");
            } 
            if (!undecorated) {
                if ((getOpacity()) < 1.0F) {
                    throw new java.awt.IllegalComponentStateException("The frame is not opaque");
                } 
                if ((getShape()) != null) {
                    throw new java.awt.IllegalComponentStateException("The frame does not have a default shape");
                } 
                java.awt.Color bg = getBackground();
                if ((bg != null) && ((bg.getAlpha()) < 255)) {
                    throw new java.awt.IllegalComponentStateException("The frame background color is not opaque");
                } 
            } 
            java.awt.Frame.this.undecorated = undecorated;
        }
    }

    public boolean isUndecorated() {
        return undecorated;
    }

    @java.lang.Override
    public void setOpacity(float opacity) {
        synchronized(getTreeLock()) {
            if ((opacity < 1.0F) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The frame is decorated");
            } 
            super.setOpacity(opacity);
        }
    }

    @java.lang.Override
    public void setShape(java.awt.Shape shape) {
        synchronized(getTreeLock()) {
            if ((shape != null) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The frame is decorated");
            } 
            super.setShape(shape);
        }
    }

    @java.lang.Override
    public void setBackground(java.awt.Color bgColor) {
        synchronized(getTreeLock()) {
            if (((bgColor != null) && ((bgColor.getAlpha()) < 255)) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The frame is decorated");
            } 
            super.setBackground(bgColor);
        }
    }

    public void remove(java.awt.MenuComponent m) {
        if (m == null) {
            return ;
        } 
        synchronized(getTreeLock()) {
            if (m == (menuBar)) {
                menuBar = null;
                java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
                if (peer != null) {
                    mbManagement = true;
                    invalidateIfValid();
                    peer.setMenuBar(null);
                    m.removeNotify();
                } 
                m.parent = null;
            } else {
                super.remove(m);
            }
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            java.awt.peer.FramePeer peer = ((java.awt.peer.FramePeer)(java.awt.Frame.this.peer));
            if (peer != null) {
                getState();
                if ((menuBar) != null) {
                    mbManagement = true;
                    peer.setMenuBar(null);
                    menuBar.removeNotify();
                } 
            } 
            super.removeNotify();
        }
    }

    void postProcessKeyEvent(java.awt.event.KeyEvent e) {
        if (((menuBar) != null) && (menuBar.handleShortcut(e))) {
            e.consume();
            return ;
        } 
        super.postProcessKeyEvent(e);
    }

    protected java.lang.String paramString() {
        java.lang.String str = super.paramString();
        if ((title) != null) {
            str += ",title=" + (title);
        } 
        if (resizable) {
            str += ",resizable";
        } 
        int state = getExtendedState();
        if (state == (java.awt.Frame.NORMAL)) {
            str += ",normal";
        } else {
            if ((state & (java.awt.Frame.ICONIFIED)) != 0) {
                str += ",iconified";
            } 
            if ((state & (java.awt.Frame.MAXIMIZED_BOTH)) == (java.awt.Frame.MAXIMIZED_BOTH)) {
                str += ",maximized";
            } else if ((state & (java.awt.Frame.MAXIMIZED_HORIZ)) != 0) {
                str += ",maximized_horiz";
            } else if ((state & (java.awt.Frame.MAXIMIZED_VERT)) != 0) {
                str += ",maximized_vert";
            } 
        }
        return str;
    }

    @java.lang.Deprecated
    public void setCursor(int cursorType) {
        if ((cursorType < (java.awt.Frame.DEFAULT_CURSOR)) || (cursorType > (java.awt.Frame.MOVE_CURSOR))) {
            throw new java.lang.IllegalArgumentException("illegal cursor type");
        } 
        setCursor(java.awt.Cursor.getPredefinedCursor(cursorType));
    }

    @java.lang.Deprecated
    public int getCursorType() {
        return getCursor().getType();
    }

    public static java.awt.Frame[] getFrames() {
        java.awt.Window[] allWindows = java.awt.Window.getWindows();
        int frameCount = 0;
        for (java.awt.Window w : allWindows) {
            if (w instanceof java.awt.Frame) {
                frameCount++;
            } 
        }
        java.awt.Frame[] frames = new java.awt.Frame[frameCount];
        int c = 0;
        for (java.awt.Window w : allWindows) {
            if (w instanceof java.awt.Frame) {
                frames[(c++)] = ((java.awt.Frame)(w));
            } 
        }
        return frames;
    }

    private int frameSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        if (((icons) != null) && ((icons.size()) > 0)) {
            java.awt.Image icon1 = icons.get(0);
            if (icon1 instanceof java.io.Serializable) {
                s.writeObject(icon1);
                return ;
            } 
        } 
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        try {
            java.awt.Image icon = ((java.awt.Image)(s.readObject()));
            if ((icons) == null) {
                icons = new java.util.ArrayList<java.awt.Image>();
                icons.add(icon);
            } 
        } catch (java.io.OptionalDataException e) {
            if (!(e.eof)) {
                throw e;
            } 
        }
        if ((menuBar) != null)
            menuBar.parent = java.awt.Frame.this;
        
        if ((ownedWindows) != null) {
            for (int i = 0 ; i < (ownedWindows.size()) ; i++) {
                connectOwnedWindow(ownedWindows.elementAt(i));
            }
            ownedWindows = null;
        } 
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Frame.AccessibleAWTFrame();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTFrame extends java.awt.Window.AccessibleAWTWindow {
        private static final long serialVersionUID = -6172960752956030250L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.FRAME;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if ((getFocusOwner()) != null) {
                states.add(javax.accessibility.AccessibleState.ACTIVE);
            } 
            if (isResizable()) {
                states.add(javax.accessibility.AccessibleState.RESIZABLE);
            } 
            return states;
        }
    }
}


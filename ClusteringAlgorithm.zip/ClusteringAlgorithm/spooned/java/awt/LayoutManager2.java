package java.awt;


public interface LayoutManager2 extends java.awt.LayoutManager {
    void addLayoutComponent(java.awt.Component comp, java.lang.Object constraints);

    public java.awt.Dimension maximumLayoutSize(java.awt.Container target);

    public float getLayoutAlignmentX(java.awt.Container target);

    public float getLayoutAlignmentY(java.awt.Container target);

    public void invalidateLayout(java.awt.Container target);
}


package java.awt;


public class Button extends java.awt.Component implements javax.accessibility.Accessible {
    java.lang.String label;

    java.lang.String actionCommand;

    transient java.awt.event.ActionListener actionListener;

    private static final java.lang.String base = "button";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -8774683716313001058L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Button.initIDs();
        } 
    }

    private static native void initIDs();

    public Button() throws java.awt.HeadlessException {
        this("");
    }

    public Button(java.lang.String label) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.Button.this.label = label;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Button.class) {
            return (java.awt.Button.base) + ((java.awt.Button.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createButton(java.awt.Button.this);
            
            super.addNotify();
        }
    }

    public java.lang.String getLabel() {
        return label;
    }

    public void setLabel(java.lang.String label) {
        boolean testvalid = false;
        synchronized(java.awt.Button.this) {
            if ((label != (java.awt.Button.this.label)) && (((java.awt.Button.this.label) == null) || (!(java.awt.Button.this.label.equals(label))))) {
                java.awt.Button.this.label = label;
                java.awt.peer.ButtonPeer peer = ((java.awt.peer.ButtonPeer)(java.awt.Button.this.peer));
                if (peer != null) {
                    peer.setLabel(label);
                } 
                testvalid = true;
            } 
        }
        if (testvalid) {
            invalidateIfValid();
        } 
    }

    public void setActionCommand(java.lang.String command) {
        actionCommand = command;
    }

    public java.lang.String getActionCommand() {
        return (actionCommand) == null ? label : actionCommand;
    }

    public synchronized void addActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.add(actionListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.remove(actionListener, l);
    }

    public synchronized java.awt.event.ActionListener[] getActionListeners() {
        return getListeners(java.awt.event.ActionListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ActionListener.class)) {
            l = actionListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ActionEvent.ACTION_PERFORMED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) || ((actionListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ActionEvent) {
            processActionEvent(((java.awt.event.ActionEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processActionEvent(java.awt.event.ActionEvent e) {
        java.awt.event.ActionListener listener = actionListener;
        if (listener != null) {
            listener.actionPerformed(e);
        } 
    }

    protected java.lang.String paramString() {
        return ((super.paramString()) + ",label=") + (label);
    }

    private int buttonSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.actionListenerK, actionListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.actionListenerK) == key)
                addActionListener(((java.awt.event.ActionListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Button.AccessibleAWTButton();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTButton extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleAction , javax.accessibility.AccessibleValue {
        private static final long serialVersionUID = -5932203980244017102L;

        public java.lang.String getAccessibleName() {
            if ((accessibleName) != null) {
                return accessibleName;
            } else {
                if ((getLabel()) == null) {
                    return super.getAccessibleName();
                } else {
                    return getLabel();
                }
            }
        }

        public javax.accessibility.AccessibleAction getAccessibleAction() {
            return java.awt.Button.AccessibleAWTButton.this;
        }

        public javax.accessibility.AccessibleValue getAccessibleValue() {
            return java.awt.Button.AccessibleAWTButton.this;
        }

        public int getAccessibleActionCount() {
            return 1;
        }

        public java.lang.String getAccessibleActionDescription(int i) {
            if (i == 0) {
                return "click";
            } else {
                return null;
            }
        }

        public boolean doAccessibleAction(int i) {
            if (i == 0) {
                java.awt.Toolkit.getEventQueue().postEvent(new java.awt.event.ActionEvent(java.awt.Button.this , java.awt.event.ActionEvent.ACTION_PERFORMED , java.awt.Button.this.getActionCommand()));
                return true;
            } else {
                return false;
            }
        }

        public java.lang.Number getCurrentAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }

        public boolean setCurrentAccessibleValue(java.lang.Number n) {
            return false;
        }

        public java.lang.Number getMinimumAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }

        public java.lang.Number getMaximumAccessibleValue() {
            return java.lang.Integer.valueOf(0);
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.PUSH_BUTTON;
        }
    }
}


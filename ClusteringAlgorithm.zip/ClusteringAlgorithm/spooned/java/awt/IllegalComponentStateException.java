package java.awt;


public class IllegalComponentStateException extends java.lang.IllegalStateException {
    private static final long serialVersionUID = -1889339587208144238L;

    public IllegalComponentStateException() {
        super();
    }

    public IllegalComponentStateException(java.lang.String s) {
        super(s);
    }
}


package java.awt;


public interface SecondaryLoop {
    public boolean enter();

    public boolean exit();
}


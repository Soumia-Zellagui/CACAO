package java.awt;


public class Event implements java.io.Serializable {
    private transient long data;

    public static final int SHIFT_MASK = 1 << 0;

    public static final int CTRL_MASK = 1 << 1;

    public static final int META_MASK = 1 << 2;

    public static final int ALT_MASK = 1 << 3;

    public static final int HOME = 1000;

    public static final int END = 1001;

    public static final int PGUP = 1002;

    public static final int PGDN = 1003;

    public static final int UP = 1004;

    public static final int DOWN = 1005;

    public static final int LEFT = 1006;

    public static final int RIGHT = 1007;

    public static final int F1 = 1008;

    public static final int F2 = 1009;

    public static final int F3 = 1010;

    public static final int F4 = 1011;

    public static final int F5 = 1012;

    public static final int F6 = 1013;

    public static final int F7 = 1014;

    public static final int F8 = 1015;

    public static final int F9 = 1016;

    public static final int F10 = 1017;

    public static final int F11 = 1018;

    public static final int F12 = 1019;

    public static final int PRINT_SCREEN = 1020;

    public static final int SCROLL_LOCK = 1021;

    public static final int CAPS_LOCK = 1022;

    public static final int NUM_LOCK = 1023;

    public static final int PAUSE = 1024;

    public static final int INSERT = 1025;

    public static final int ENTER = '\n';

    public static final int BACK_SPACE = '\b';

    public static final int TAB = '\t';

    public static final int ESCAPE = 27;

    public static final int DELETE = 127;

    private static final int WINDOW_EVENT = 200;

    public static final int WINDOW_DESTROY = 1 + (java.awt.Event.WINDOW_EVENT);

    public static final int WINDOW_EXPOSE = 2 + (java.awt.Event.WINDOW_EVENT);

    public static final int WINDOW_ICONIFY = 3 + (java.awt.Event.WINDOW_EVENT);

    public static final int WINDOW_DEICONIFY = 4 + (java.awt.Event.WINDOW_EVENT);

    public static final int WINDOW_MOVED = 5 + (java.awt.Event.WINDOW_EVENT);

    private static final int KEY_EVENT = 400;

    public static final int KEY_PRESS = 1 + (java.awt.Event.KEY_EVENT);

    public static final int KEY_RELEASE = 2 + (java.awt.Event.KEY_EVENT);

    public static final int KEY_ACTION = 3 + (java.awt.Event.KEY_EVENT);

    public static final int KEY_ACTION_RELEASE = 4 + (java.awt.Event.KEY_EVENT);

    private static final int MOUSE_EVENT = 500;

    public static final int MOUSE_DOWN = 1 + (java.awt.Event.MOUSE_EVENT);

    public static final int MOUSE_UP = 2 + (java.awt.Event.MOUSE_EVENT);

    public static final int MOUSE_MOVE = 3 + (java.awt.Event.MOUSE_EVENT);

    public static final int MOUSE_ENTER = 4 + (java.awt.Event.MOUSE_EVENT);

    public static final int MOUSE_EXIT = 5 + (java.awt.Event.MOUSE_EVENT);

    public static final int MOUSE_DRAG = 6 + (java.awt.Event.MOUSE_EVENT);

    private static final int SCROLL_EVENT = 600;

    public static final int SCROLL_LINE_UP = 1 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_LINE_DOWN = 2 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_PAGE_UP = 3 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_PAGE_DOWN = 4 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_ABSOLUTE = 5 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_BEGIN = 6 + (java.awt.Event.SCROLL_EVENT);

    public static final int SCROLL_END = 7 + (java.awt.Event.SCROLL_EVENT);

    private static final int LIST_EVENT = 700;

    public static final int LIST_SELECT = 1 + (java.awt.Event.LIST_EVENT);

    public static final int LIST_DESELECT = 2 + (java.awt.Event.LIST_EVENT);

    private static final int MISC_EVENT = 1000;

    public static final int ACTION_EVENT = 1 + (java.awt.Event.MISC_EVENT);

    public static final int LOAD_FILE = 2 + (java.awt.Event.MISC_EVENT);

    public static final int SAVE_FILE = 3 + (java.awt.Event.MISC_EVENT);

    public static final int GOT_FOCUS = 4 + (java.awt.Event.MISC_EVENT);

    public static final int LOST_FOCUS = 5 + (java.awt.Event.MISC_EVENT);

    public java.lang.Object target;

    public long when;

    public int id;

    public int x;

    public int y;

    public int key;

    public int modifiers;

    public int clickCount;

    public java.lang.Object arg;

    public java.awt.Event evt;

    private static final int[][] actionKeyCodes = new int[][]{ new int[]{ java.awt.event.KeyEvent.VK_HOME , java.awt.Event.HOME } , new int[]{ java.awt.event.KeyEvent.VK_END , java.awt.Event.END } , new int[]{ java.awt.event.KeyEvent.VK_PAGE_UP , java.awt.Event.PGUP } , new int[]{ java.awt.event.KeyEvent.VK_PAGE_DOWN , java.awt.Event.PGDN } , new int[]{ java.awt.event.KeyEvent.VK_UP , java.awt.Event.UP } , new int[]{ java.awt.event.KeyEvent.VK_DOWN , java.awt.Event.DOWN } , new int[]{ java.awt.event.KeyEvent.VK_LEFT , java.awt.Event.LEFT } , new int[]{ java.awt.event.KeyEvent.VK_RIGHT , java.awt.Event.RIGHT } , new int[]{ java.awt.event.KeyEvent.VK_F1 , java.awt.Event.F1 } , new int[]{ java.awt.event.KeyEvent.VK_F2 , java.awt.Event.F2 } , new int[]{ java.awt.event.KeyEvent.VK_F3 , java.awt.Event.F3 } , new int[]{ java.awt.event.KeyEvent.VK_F4 , java.awt.Event.F4 } , new int[]{ java.awt.event.KeyEvent.VK_F5 , java.awt.Event.F5 } , new int[]{ java.awt.event.KeyEvent.VK_F6 , java.awt.Event.F6 } , new int[]{ java.awt.event.KeyEvent.VK_F7 , java.awt.Event.F7 } , new int[]{ java.awt.event.KeyEvent.VK_F8 , java.awt.Event.F8 } , new int[]{ java.awt.event.KeyEvent.VK_F9 , java.awt.Event.F9 } , new int[]{ java.awt.event.KeyEvent.VK_F10 , java.awt.Event.F10 } , new int[]{ java.awt.event.KeyEvent.VK_F11 , java.awt.Event.F11 } , new int[]{ java.awt.event.KeyEvent.VK_F12 , java.awt.Event.F12 } , new int[]{ java.awt.event.KeyEvent.VK_PRINTSCREEN , java.awt.Event.PRINT_SCREEN } , new int[]{ java.awt.event.KeyEvent.VK_SCROLL_LOCK , java.awt.Event.SCROLL_LOCK } , new int[]{ java.awt.event.KeyEvent.VK_CAPS_LOCK , java.awt.Event.CAPS_LOCK } , new int[]{ java.awt.event.KeyEvent.VK_NUM_LOCK , java.awt.Event.NUM_LOCK } , new int[]{ java.awt.event.KeyEvent.VK_PAUSE , java.awt.Event.PAUSE } , new int[]{ java.awt.event.KeyEvent.VK_INSERT , java.awt.Event.INSERT } };

    private boolean consumed = false;

    private static final long serialVersionUID = 5488922509400504703L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Event.initIDs();
        } 
    }

    private static native void initIDs();

    public Event(java.lang.Object target ,long when ,int id ,int x ,int y ,int key ,int modifiers ,java.lang.Object arg) {
        java.awt.Event.this.target = target;
        java.awt.Event.this.when = when;
        java.awt.Event.this.id = id;
        java.awt.Event.this.x = x;
        java.awt.Event.this.y = y;
        java.awt.Event.this.key = key;
        java.awt.Event.this.modifiers = modifiers;
        java.awt.Event.this.arg = arg;
        java.awt.Event.this.data = 0;
        java.awt.Event.this.clickCount = 0;
        switch (id) {
            case java.awt.Event.ACTION_EVENT :
            case java.awt.Event.WINDOW_DESTROY :
            case java.awt.Event.WINDOW_ICONIFY :
            case java.awt.Event.WINDOW_DEICONIFY :
            case java.awt.Event.WINDOW_MOVED :
            case java.awt.Event.SCROLL_LINE_UP :
            case java.awt.Event.SCROLL_LINE_DOWN :
            case java.awt.Event.SCROLL_PAGE_UP :
            case java.awt.Event.SCROLL_PAGE_DOWN :
            case java.awt.Event.SCROLL_ABSOLUTE :
            case java.awt.Event.SCROLL_BEGIN :
            case java.awt.Event.SCROLL_END :
            case java.awt.Event.LIST_SELECT :
            case java.awt.Event.LIST_DESELECT :
                consumed = true;
                break;
            default :
        }
    }

    public Event(java.lang.Object target ,long when ,int id ,int x ,int y ,int key ,int modifiers) {
        this(target, when, id, x, y, key, modifiers, null);
    }

    public Event(java.lang.Object target ,int id ,java.lang.Object arg) {
        this(target, 0, id, 0, 0, 0, 0, arg);
    }

    public void translate(int dx, int dy) {
        java.awt.Event.this.x += dx;
        java.awt.Event.this.y += dy;
    }

    public boolean shiftDown() {
        return ((modifiers) & (java.awt.Event.SHIFT_MASK)) != 0;
    }

    public boolean controlDown() {
        return ((modifiers) & (java.awt.Event.CTRL_MASK)) != 0;
    }

    public boolean metaDown() {
        return ((modifiers) & (java.awt.Event.META_MASK)) != 0;
    }

    void consume() {
        switch (id) {
            case java.awt.Event.KEY_PRESS :
            case java.awt.Event.KEY_RELEASE :
            case java.awt.Event.KEY_ACTION :
            case java.awt.Event.KEY_ACTION_RELEASE :
                consumed = true;
                break;
            default :
        }
    }

    boolean isConsumed() {
        return consumed;
    }

    static int getOldEventKey(java.awt.event.KeyEvent e) {
        int keyCode = e.getKeyCode();
        for (int i = 0 ; i < (java.awt.Event.actionKeyCodes.length) ; i++) {
            if ((java.awt.Event.actionKeyCodes[i][0]) == keyCode) {
                return java.awt.Event.actionKeyCodes[i][1];
            } 
        }
        return ((int)(e.getKeyChar()));
    }

    char getKeyEventChar() {
        for (int i = 0 ; i < (java.awt.Event.actionKeyCodes.length) ; i++) {
            if ((java.awt.Event.actionKeyCodes[i][1]) == (key)) {
                return java.awt.event.KeyEvent.CHAR_UNDEFINED;
            } 
        }
        return ((char)(key));
    }

    protected java.lang.String paramString() {
        java.lang.String str = (((("id=" + (id)) + ",x=") + (x)) + ",y=") + (y);
        if ((key) != 0) {
            str += ",key=" + (key);
        } 
        if (shiftDown()) {
            str += ",shift";
        } 
        if (controlDown()) {
            str += ",control";
        } 
        if (metaDown()) {
            str += ",meta";
        } 
        if ((target) != null) {
            str += ",target=" + (target);
        } 
        if ((arg) != null) {
            str += ",arg=" + (arg);
        } 
        return str;
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[") + (paramString())) + "]";
    }
}


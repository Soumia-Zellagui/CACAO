package java.awt;


public abstract class MenuComponent implements java.io.Serializable {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.MenuComponent.initIDs();
        } 
    }

    transient java.awt.peer.MenuComponentPeer peer;

    transient java.awt.MenuContainer parent;

    transient sun.awt.AppContext appContext;

    java.awt.Font font;

    private java.lang.String name;

    private boolean nameExplicitlySet = false;

    boolean newEventsOnly = false;

    private transient volatile java.security.AccessControlContext acc = java.security.AccessController.getContext();

    final java.security.AccessControlContext getAccessControlContext() {
        if ((acc) == null) {
            throw new java.lang.SecurityException("MenuComponent is missing AccessControlContext");
        } 
        return acc;
    }

    static final java.lang.String actionListenerK = java.awt.Component.actionListenerK;

    static final java.lang.String itemListenerK = java.awt.Component.itemListenerK;

    private static final long serialVersionUID = -4536902356223894379L;

    public MenuComponent() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        appContext = sun.awt.AppContext.getAppContext();
    }

    java.lang.String constructComponentName() {
        return null;
    }

    public java.lang.String getName() {
        if (((name) == null) && (!(nameExplicitlySet))) {
            synchronized(java.awt.MenuComponent.this) {
                if (((name) == null) && (!(nameExplicitlySet)))
                    name = constructComponentName();
                
            }
        } 
        return name;
    }

    public void setName(java.lang.String name) {
        synchronized(java.awt.MenuComponent.this) {
            java.awt.MenuComponent.this.name = name;
            nameExplicitlySet = true;
        }
    }

    public java.awt.MenuContainer getParent() {
        return getParent_NoClientCode();
    }

    final java.awt.MenuContainer getParent_NoClientCode() {
        return parent;
    }

    @java.lang.Deprecated
    public java.awt.peer.MenuComponentPeer getPeer() {
        return peer;
    }

    public java.awt.Font getFont() {
        java.awt.Font font = java.awt.MenuComponent.this.font;
        if (font != null) {
            return font;
        } 
        java.awt.MenuContainer parent = java.awt.MenuComponent.this.parent;
        if (parent != null) {
            return parent.getFont();
        } 
        return null;
    }

    final java.awt.Font getFont_NoClientCode() {
        java.awt.Font font = java.awt.MenuComponent.this.font;
        if (font != null) {
            return font;
        } 
        java.lang.Object parent = java.awt.MenuComponent.this.parent;
        if (parent != null) {
            if (parent instanceof java.awt.Component) {
                font = ((java.awt.Component)(parent)).getFont_NoClientCode();
            } else if (parent instanceof java.awt.MenuComponent) {
                font = ((java.awt.MenuComponent)(parent)).getFont_NoClientCode();
            } 
        } 
        return font;
    }

    public void setFont(java.awt.Font f) {
        font = f;
        java.awt.peer.MenuComponentPeer peer = java.awt.MenuComponent.this.peer;
        if (peer != null) {
            peer.setFont(f);
        } 
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            java.awt.peer.MenuComponentPeer p = java.awt.MenuComponent.this.peer;
            if (p != null) {
                java.awt.Toolkit.getEventQueue().removeSourceEvents(java.awt.MenuComponent.this, true);
                java.awt.MenuComponent.this.peer = null;
                p.dispose();
            } 
        }
    }

    @java.lang.Deprecated
    public boolean postEvent(java.awt.Event evt) {
        java.awt.MenuContainer parent = java.awt.MenuComponent.this.parent;
        if (parent != null) {
            parent.postEvent(evt);
        } 
        return false;
    }

    public final void dispatchEvent(java.awt.AWTEvent e) {
        dispatchEventImpl(e);
    }

    void dispatchEventImpl(java.awt.AWTEvent e) {
        java.awt.EventQueue.setCurrentEventAndMostRecentTime(e);
        java.awt.Toolkit.getDefaultToolkit().notifyAWTEventListeners(e);
        if ((newEventsOnly) || ((((parent) != null) && ((parent) instanceof java.awt.MenuComponent)) && (((java.awt.MenuComponent)(parent)).newEventsOnly))) {
            if (eventEnabled(e)) {
                processEvent(e);
            } else if ((e instanceof java.awt.event.ActionEvent) && ((parent) != null)) {
                e.setSource(parent);
                ((java.awt.MenuComponent)(parent)).dispatchEvent(e);
            } 
        } else {
            java.awt.Event olde = e.convertToOld();
            if (olde != null) {
                postEvent(olde);
            } 
        }
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        return false;
    }

    protected void processEvent(java.awt.AWTEvent e) {
    }

    protected java.lang.String paramString() {
        java.lang.String thisName = getName();
        return thisName != null ? thisName : "";
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[") + (paramString())) + "]";
    }

    protected final java.lang.Object getTreeLock() {
        return java.awt.Component.LOCK;
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        acc = java.security.AccessController.getContext();
        s.defaultReadObject();
        appContext = sun.awt.AppContext.getAppContext();
    }

    private static native void initIDs();

    javax.accessibility.AccessibleContext accessibleContext = null;

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        return accessibleContext;
    }

    protected abstract class AccessibleAWTMenuComponent extends javax.accessibility.AccessibleContext implements java.io.Serializable , javax.accessibility.AccessibleComponent , javax.accessibility.AccessibleSelection {
        private static final long serialVersionUID = -4269533416223798698L;

        protected AccessibleAWTMenuComponent() {
        }

        public javax.accessibility.AccessibleSelection getAccessibleSelection() {
            return java.awt.MenuComponent.AccessibleAWTMenuComponent.this;
        }

        public java.lang.String getAccessibleName() {
            return accessibleName;
        }

        public java.lang.String getAccessibleDescription() {
            return accessibleDescription;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.AWT_COMPONENT;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            return java.awt.MenuComponent.this.getAccessibleStateSet();
        }

        public javax.accessibility.Accessible getAccessibleParent() {
            if ((accessibleParent) != null) {
                return accessibleParent;
            } else {
                java.awt.MenuContainer parent = java.awt.MenuComponent.this.getParent();
                if (parent instanceof javax.accessibility.Accessible) {
                    return ((javax.accessibility.Accessible)(parent));
                } 
            }
            return null;
        }

        public int getAccessibleIndexInParent() {
            return java.awt.MenuComponent.this.getAccessibleIndexInParent();
        }

        public int getAccessibleChildrenCount() {
            return 0;
        }

        public javax.accessibility.Accessible getAccessibleChild(int i) {
            return null;
        }

        public java.util.Locale getLocale() {
            java.awt.MenuContainer parent = java.awt.MenuComponent.this.getParent();
            if (parent instanceof java.awt.Component)
                return ((java.awt.Component)(parent)).getLocale();
            else
                return java.util.Locale.getDefault();
            
        }

        public javax.accessibility.AccessibleComponent getAccessibleComponent() {
            return java.awt.MenuComponent.AccessibleAWTMenuComponent.this;
        }

        public java.awt.Color getBackground() {
            return null;
        }

        public void setBackground(java.awt.Color c) {
        }

        public java.awt.Color getForeground() {
            return null;
        }

        public void setForeground(java.awt.Color c) {
        }

        public java.awt.Cursor getCursor() {
            return null;
        }

        public void setCursor(java.awt.Cursor cursor) {
        }

        public java.awt.Font getFont() {
            return java.awt.MenuComponent.this.getFont();
        }

        public void setFont(java.awt.Font f) {
            java.awt.MenuComponent.this.setFont(f);
        }

        public java.awt.FontMetrics getFontMetrics(java.awt.Font f) {
            return null;
        }

        public boolean isEnabled() {
            return true;
        }

        public void setEnabled(boolean b) {
        }

        public boolean isVisible() {
            return true;
        }

        public void setVisible(boolean b) {
        }

        public boolean isShowing() {
            return true;
        }

        public boolean contains(java.awt.Point p) {
            return false;
        }

        public java.awt.Point getLocationOnScreen() {
            return null;
        }

        public java.awt.Point getLocation() {
            return null;
        }

        public void setLocation(java.awt.Point p) {
        }

        public java.awt.Rectangle getBounds() {
            return null;
        }

        public void setBounds(java.awt.Rectangle r) {
        }

        public java.awt.Dimension getSize() {
            return null;
        }

        public void setSize(java.awt.Dimension d) {
        }

        public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
            return null;
        }

        public boolean isFocusTraversable() {
            return true;
        }

        public void requestFocus() {
        }

        public void addFocusListener(java.awt.event.FocusListener l) {
        }

        public void removeFocusListener(java.awt.event.FocusListener l) {
        }

        public int getAccessibleSelectionCount() {
            return 0;
        }

        public javax.accessibility.Accessible getAccessibleSelection(int i) {
            return null;
        }

        public boolean isAccessibleChildSelected(int i) {
            return false;
        }

        public void addAccessibleSelection(int i) {
        }

        public void removeAccessibleSelection(int i) {
        }

        public void clearAccessibleSelection() {
        }

        public void selectAllAccessibleSelection() {
        }
    }

    int getAccessibleIndexInParent() {
        java.awt.MenuContainer localParent = parent;
        if (!(localParent instanceof java.awt.MenuComponent)) {
            return -1;
        } 
        java.awt.MenuComponent localParentMenu = ((java.awt.MenuComponent)(localParent));
        return localParentMenu.getAccessibleChildIndex(java.awt.MenuComponent.this);
    }

    int getAccessibleChildIndex(java.awt.MenuComponent child) {
        return -1;
    }

    javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
        javax.accessibility.AccessibleStateSet states = new javax.accessibility.AccessibleStateSet();
        return states;
    }
}


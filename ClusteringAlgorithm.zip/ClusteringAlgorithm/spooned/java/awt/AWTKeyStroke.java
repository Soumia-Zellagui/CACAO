package java.awt;


public class AWTKeyStroke implements java.io.Serializable {
    static final long serialVersionUID = -6430539691155161871L;

    private static java.util.Map<java.lang.String, java.lang.Integer> modifierKeywords;

    private static java.awt.VKCollection vks;

    private static java.lang.Object APP_CONTEXT_CACHE_KEY = new java.lang.Object();

    private static java.awt.AWTKeyStroke APP_CONTEXT_KEYSTROKE_KEY = new java.awt.AWTKeyStroke();

    private static java.lang.Class<java.awt.AWTKeyStroke> getAWTKeyStrokeClass() {
        java.lang.Class<java.awt.AWTKeyStroke> clazz = ((java.lang.Class)(sun.awt.AppContext.getAppContext().get(java.awt.AWTKeyStroke.class)));
        if (clazz == null) {
            clazz = java.awt.AWTKeyStroke.class;
            sun.awt.AppContext.getAppContext().put(java.awt.AWTKeyStroke.class, java.awt.AWTKeyStroke.class);
        } 
        return clazz;
    }

    private char keyChar = java.awt.event.KeyEvent.CHAR_UNDEFINED;

    private int keyCode = java.awt.event.KeyEvent.VK_UNDEFINED;

    private int modifiers;

    private boolean onKeyRelease;

    static {
        java.awt.Toolkit.loadLibraries();
    }

    protected AWTKeyStroke() {
    }

    protected AWTKeyStroke(char keyChar ,int keyCode ,int modifiers ,boolean onKeyRelease) {
        java.awt.AWTKeyStroke.this.keyChar = keyChar;
        java.awt.AWTKeyStroke.this.keyCode = keyCode;
        java.awt.AWTKeyStroke.this.modifiers = modifiers;
        java.awt.AWTKeyStroke.this.onKeyRelease = onKeyRelease;
    }

    protected static void registerSubclass(java.lang.Class<?> subclass) {
        if (subclass == null) {
            throw new java.lang.IllegalArgumentException("subclass cannot be null");
        } 
        synchronized(java.awt.AWTKeyStroke.class) {
            java.lang.Class<java.awt.AWTKeyStroke> keyStrokeClass = ((java.lang.Class)(sun.awt.AppContext.getAppContext().get(java.awt.AWTKeyStroke.class)));
            if ((keyStrokeClass != null) && (keyStrokeClass.equals(subclass))) {
                return ;
            } 
        }
        if (!(java.awt.AWTKeyStroke.class.isAssignableFrom(subclass))) {
            throw new java.lang.ClassCastException("subclass is not derived from AWTKeyStroke");
        } 
        java.lang.reflect.Constructor ctor = java.awt.AWTKeyStroke.getCtor(subclass);
        java.lang.String couldNotInstantiate = "subclass could not be instantiated";
        if (ctor == null) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        } 
        try {
            java.awt.AWTKeyStroke stroke = ((java.awt.AWTKeyStroke)(ctor.newInstance(((java.lang.Object[])(null)))));
            if (stroke == null) {
                throw new java.lang.IllegalArgumentException(couldNotInstantiate);
            } 
        } catch (java.lang.NoSuchMethodError e) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        } catch (java.lang.ExceptionInInitializerError e) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        } catch (java.lang.InstantiationException e) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        } catch (java.lang.IllegalAccessException e) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        } catch (java.lang.reflect.InvocationTargetException e) {
            throw new java.lang.IllegalArgumentException(couldNotInstantiate);
        }
        synchronized(java.awt.AWTKeyStroke.class) {
            sun.awt.AppContext.getAppContext().put(java.awt.AWTKeyStroke.class, subclass);
            sun.awt.AppContext.getAppContext().remove(java.awt.AWTKeyStroke.APP_CONTEXT_CACHE_KEY);
            sun.awt.AppContext.getAppContext().remove(java.awt.AWTKeyStroke.APP_CONTEXT_KEYSTROKE_KEY);
        }
    }

    private static java.lang.reflect.Constructor getCtor(final java.lang.Class clazz) {
        java.lang.reflect.Constructor ctor = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.reflect.Constructor>() {
            public java.lang.reflect.Constructor run() {
                try {
                    java.lang.reflect.Constructor ctor = clazz.getDeclaredConstructor(((java.lang.Class[])(null)));
                    if (ctor != null) {
                        ctor.setAccessible(true);
                    } 
                    return ctor;
                } catch (java.lang.SecurityException e) {
                } catch (java.lang.NoSuchMethodException e) {
                }
                return null;
            }
        });
        return ((java.lang.reflect.Constructor)(ctor));
    }

    private static synchronized java.awt.AWTKeyStroke getCachedStroke(char keyChar, int keyCode, int modifiers, boolean onKeyRelease) {
        java.util.Map<java.awt.AWTKeyStroke, java.awt.AWTKeyStroke> cache = ((java.util.Map)(sun.awt.AppContext.getAppContext().get(java.awt.AWTKeyStroke.APP_CONTEXT_CACHE_KEY)));
        java.awt.AWTKeyStroke cacheKey = ((java.awt.AWTKeyStroke)(sun.awt.AppContext.getAppContext().get(java.awt.AWTKeyStroke.APP_CONTEXT_KEYSTROKE_KEY)));
        if (cache == null) {
            cache = new java.util.HashMap<>();
            sun.awt.AppContext.getAppContext().put(java.awt.AWTKeyStroke.APP_CONTEXT_CACHE_KEY, cache);
        } 
        if (cacheKey == null) {
            try {
                java.lang.Class<java.awt.AWTKeyStroke> clazz = java.awt.AWTKeyStroke.getAWTKeyStrokeClass();
                cacheKey = ((java.awt.AWTKeyStroke)(java.awt.AWTKeyStroke.getCtor(clazz).newInstance(((java.lang.Object[])(null)))));
                sun.awt.AppContext.getAppContext().put(java.awt.AWTKeyStroke.APP_CONTEXT_KEYSTROKE_KEY, cacheKey);
            } catch (java.lang.InstantiationException e) {
                assert false;
            } catch (java.lang.IllegalAccessException e) {
                assert false;
            } catch (java.lang.reflect.InvocationTargetException e) {
                assert false;
            }
        } 
        cacheKey.keyChar = keyChar;
        cacheKey.keyCode = keyCode;
        cacheKey.modifiers = java.awt.AWTKeyStroke.mapNewModifiers(java.awt.AWTKeyStroke.mapOldModifiers(modifiers));
        cacheKey.onKeyRelease = onKeyRelease;
        java.awt.AWTKeyStroke stroke = ((java.awt.AWTKeyStroke)(cache.get(cacheKey)));
        if (stroke == null) {
            stroke = cacheKey;
            cache.put(stroke, stroke);
            sun.awt.AppContext.getAppContext().remove(java.awt.AWTKeyStroke.APP_CONTEXT_KEYSTROKE_KEY);
        } 
        return stroke;
    }

    public static java.awt.AWTKeyStroke getAWTKeyStroke(char keyChar) {
        return java.awt.AWTKeyStroke.getCachedStroke(keyChar, java.awt.event.KeyEvent.VK_UNDEFINED, 0, false);
    }

    public static java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.Character keyChar, int modifiers) {
        if (keyChar == null) {
            throw new java.lang.IllegalArgumentException("keyChar cannot be null");
        } 
        return java.awt.AWTKeyStroke.getCachedStroke(keyChar.charValue(), java.awt.event.KeyEvent.VK_UNDEFINED, modifiers, false);
    }

    public static java.awt.AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers, boolean onKeyRelease) {
        return java.awt.AWTKeyStroke.getCachedStroke(java.awt.event.KeyEvent.CHAR_UNDEFINED, keyCode, modifiers, onKeyRelease);
    }

    public static java.awt.AWTKeyStroke getAWTKeyStroke(int keyCode, int modifiers) {
        return java.awt.AWTKeyStroke.getCachedStroke(java.awt.event.KeyEvent.CHAR_UNDEFINED, keyCode, modifiers, false);
    }

    public static java.awt.AWTKeyStroke getAWTKeyStrokeForEvent(java.awt.event.KeyEvent anEvent) {
        int id = anEvent.getID();
        switch (id) {
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
                return java.awt.AWTKeyStroke.getCachedStroke(java.awt.event.KeyEvent.CHAR_UNDEFINED, anEvent.getKeyCode(), anEvent.getModifiers(), (id == (java.awt.event.KeyEvent.KEY_RELEASED)));
            case java.awt.event.KeyEvent.KEY_TYPED :
                return java.awt.AWTKeyStroke.getCachedStroke(anEvent.getKeyChar(), java.awt.event.KeyEvent.VK_UNDEFINED, anEvent.getModifiers(), false);
            default :
                return null;
        }
    }

    public static java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.String s) {
        if (s == null) {
            throw new java.lang.IllegalArgumentException("String cannot be null");
        } 
        final java.lang.String errmsg = "String formatted incorrectly";
        java.util.StringTokenizer st = new java.util.StringTokenizer(s , " ");
        int mask = 0;
        boolean released = false;
        boolean typed = false;
        boolean pressed = false;
        synchronized(java.awt.AWTKeyStroke.class) {
            if ((java.awt.AWTKeyStroke.modifierKeywords) == null) {
                java.util.Map<java.lang.String, java.lang.Integer> uninitializedMap = new java.util.HashMap<>(8 , 1.0F);
                uninitializedMap.put("shift", java.lang.Integer.valueOf(((java.awt.event.InputEvent.SHIFT_DOWN_MASK) | (java.awt.event.InputEvent.SHIFT_MASK))));
                uninitializedMap.put("control", java.lang.Integer.valueOf(((java.awt.event.InputEvent.CTRL_DOWN_MASK) | (java.awt.event.InputEvent.CTRL_MASK))));
                uninitializedMap.put("ctrl", java.lang.Integer.valueOf(((java.awt.event.InputEvent.CTRL_DOWN_MASK) | (java.awt.event.InputEvent.CTRL_MASK))));
                uninitializedMap.put("meta", java.lang.Integer.valueOf(((java.awt.event.InputEvent.META_DOWN_MASK) | (java.awt.event.InputEvent.META_MASK))));
                uninitializedMap.put("alt", java.lang.Integer.valueOf(((java.awt.event.InputEvent.ALT_DOWN_MASK) | (java.awt.event.InputEvent.ALT_MASK))));
                uninitializedMap.put("altGraph", java.lang.Integer.valueOf(((java.awt.event.InputEvent.ALT_GRAPH_DOWN_MASK) | (java.awt.event.InputEvent.ALT_GRAPH_MASK))));
                uninitializedMap.put("button1", java.lang.Integer.valueOf(java.awt.event.InputEvent.BUTTON1_DOWN_MASK));
                uninitializedMap.put("button2", java.lang.Integer.valueOf(java.awt.event.InputEvent.BUTTON2_DOWN_MASK));
                uninitializedMap.put("button3", java.lang.Integer.valueOf(java.awt.event.InputEvent.BUTTON3_DOWN_MASK));
                java.awt.AWTKeyStroke.modifierKeywords = java.util.Collections.synchronizedMap(uninitializedMap);
            } 
        }
        int count = st.countTokens();
        for (int i = 1 ; i <= count ; i++) {
            java.lang.String token = st.nextToken();
            if (typed) {
                if (((token.length()) != 1) || (i != count)) {
                    throw new java.lang.IllegalArgumentException(errmsg);
                } 
                return java.awt.AWTKeyStroke.getCachedStroke(token.charAt(0), java.awt.event.KeyEvent.VK_UNDEFINED, mask, false);
            } 
            if ((pressed || released) || (i == count)) {
                if (i != count) {
                    throw new java.lang.IllegalArgumentException(errmsg);
                } 
                java.lang.String keyCodeName = "VK_" + token;
                int keyCode = java.awt.AWTKeyStroke.getVKValue(keyCodeName);
                return java.awt.AWTKeyStroke.getCachedStroke(java.awt.event.KeyEvent.CHAR_UNDEFINED, keyCode, mask, released);
            } 
            if (token.equals("released")) {
                released = true;
                continue;
            } 
            if (token.equals("pressed")) {
                pressed = true;
                continue;
            } 
            if (token.equals("typed")) {
                typed = true;
                continue;
            } 
            java.lang.Integer tokenMask = ((java.lang.Integer)(java.awt.AWTKeyStroke.modifierKeywords.get(token)));
            if (tokenMask != null) {
                mask |= tokenMask.intValue();
            } else {
                throw new java.lang.IllegalArgumentException(errmsg);
            }
        }
        throw new java.lang.IllegalArgumentException(errmsg);
    }

    private static java.awt.VKCollection getVKCollection() {
        if ((java.awt.AWTKeyStroke.vks) == null) {
            java.awt.AWTKeyStroke.vks = new java.awt.VKCollection();
        } 
        return java.awt.AWTKeyStroke.vks;
    }

    private static int getVKValue(java.lang.String key) {
        java.awt.VKCollection vkCollect = java.awt.AWTKeyStroke.getVKCollection();
        java.lang.Integer value = vkCollect.findCode(key);
        if (value == null) {
            int keyCode = 0;
            final java.lang.String errmsg = "String formatted incorrectly";
            try {
                keyCode = java.awt.event.KeyEvent.class.getField(key).getInt(java.awt.event.KeyEvent.class);
            } catch (java.lang.NoSuchFieldException nsfe) {
                throw new java.lang.IllegalArgumentException(errmsg);
            } catch (java.lang.IllegalAccessException iae) {
                throw new java.lang.IllegalArgumentException(errmsg);
            }
            value = java.lang.Integer.valueOf(keyCode);
            vkCollect.put(key, value);
        } 
        return value.intValue();
    }

    public final char getKeyChar() {
        return keyChar;
    }

    public final int getKeyCode() {
        return keyCode;
    }

    public final int getModifiers() {
        return modifiers;
    }

    public final boolean isOnKeyRelease() {
        return onKeyRelease;
    }

    public final int getKeyEventType() {
        if ((keyCode) == (java.awt.event.KeyEvent.VK_UNDEFINED)) {
            return java.awt.event.KeyEvent.KEY_TYPED;
        } else {
            return onKeyRelease ? java.awt.event.KeyEvent.KEY_RELEASED : java.awt.event.KeyEvent.KEY_PRESSED;
        }
    }

    public int hashCode() {
        return (((((int)(keyChar)) + 1) * (2 * ((keyCode) + 1))) * ((modifiers) + 1)) + (onKeyRelease ? 1 : 2);
    }

    public final boolean equals(java.lang.Object anObject) {
        if (anObject instanceof java.awt.AWTKeyStroke) {
            java.awt.AWTKeyStroke ks = ((java.awt.AWTKeyStroke)(anObject));
            return ((((ks.keyChar) == (keyChar)) && ((ks.keyCode) == (keyCode))) && ((ks.onKeyRelease) == (onKeyRelease))) && ((ks.modifiers) == (modifiers));
        } 
        return false;
    }

    public java.lang.String toString() {
        if ((keyCode) == (java.awt.event.KeyEvent.VK_UNDEFINED)) {
            return ((java.awt.AWTKeyStroke.getModifiersText(modifiers)) + "typed ") + (keyChar);
        } else {
            return (((java.awt.AWTKeyStroke.getModifiersText(modifiers)) + (onKeyRelease ? "released" : "pressed")) + " ") + (java.awt.AWTKeyStroke.getVKText(keyCode));
        }
    }

    static java.lang.String getModifiersText(int modifiers) {
        java.lang.StringBuilder buf = new java.lang.StringBuilder();
        if ((modifiers & (java.awt.event.InputEvent.SHIFT_DOWN_MASK)) != 0) {
            buf.append("shift ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.CTRL_DOWN_MASK)) != 0) {
            buf.append("ctrl ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.META_DOWN_MASK)) != 0) {
            buf.append("meta ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_DOWN_MASK)) != 0) {
            buf.append("alt ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_GRAPH_DOWN_MASK)) != 0) {
            buf.append("altGraph ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.BUTTON1_DOWN_MASK)) != 0) {
            buf.append("button1 ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.BUTTON2_DOWN_MASK)) != 0) {
            buf.append("button2 ");
        } 
        if ((modifiers & (java.awt.event.InputEvent.BUTTON3_DOWN_MASK)) != 0) {
            buf.append("button3 ");
        } 
        return buf.toString();
    }

    static java.lang.String getVKText(int keyCode) {
        java.awt.VKCollection vkCollect = java.awt.AWTKeyStroke.getVKCollection();
        java.lang.Integer key = java.lang.Integer.valueOf(keyCode);
        java.lang.String name = vkCollect.findName(key);
        if (name != null) {
            return name.substring(3);
        } 
        int expected_modifiers = ((java.lang.reflect.Modifier.PUBLIC) | (java.lang.reflect.Modifier.STATIC)) | (java.lang.reflect.Modifier.FINAL);
        java.lang.reflect.Field[] fields = java.awt.event.KeyEvent.class.getDeclaredFields();
        for (int i = 0 ; i < (fields.length) ; i++) {
            try {
                if (((((fields[i].getModifiers()) == expected_modifiers) && ((fields[i].getType()) == (java.lang.Integer.TYPE))) && (fields[i].getName().startsWith("VK_"))) && ((fields[i].getInt(java.awt.event.KeyEvent.class)) == keyCode)) {
                    name = fields[i].getName();
                    vkCollect.put(name, key);
                    return name.substring(3);
                } 
            } catch (java.lang.IllegalAccessException e) {
                assert false;
            }
        }
        return "UNKNOWN";
    }

    protected java.lang.Object readResolve() throws java.io.ObjectStreamException {
        synchronized(java.awt.AWTKeyStroke.class) {
            if (getClass().equals(java.awt.AWTKeyStroke.getAWTKeyStrokeClass())) {
                return java.awt.AWTKeyStroke.getCachedStroke(keyChar, keyCode, modifiers, onKeyRelease);
            } 
        }
        return java.awt.AWTKeyStroke.this;
    }

    private static int mapOldModifiers(int modifiers) {
        if ((modifiers & (java.awt.event.InputEvent.SHIFT_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.SHIFT_DOWN_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.ALT_DOWN_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_GRAPH_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.ALT_GRAPH_DOWN_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.CTRL_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.CTRL_DOWN_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.META_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.META_DOWN_MASK;
        } 
        modifiers &= (((((((java.awt.event.InputEvent.SHIFT_DOWN_MASK) | (java.awt.event.InputEvent.ALT_DOWN_MASK)) | (java.awt.event.InputEvent.ALT_GRAPH_DOWN_MASK)) | (java.awt.event.InputEvent.CTRL_DOWN_MASK)) | (java.awt.event.InputEvent.META_DOWN_MASK)) | (java.awt.event.InputEvent.BUTTON1_DOWN_MASK)) | (java.awt.event.InputEvent.BUTTON2_DOWN_MASK)) | (java.awt.event.InputEvent.BUTTON3_DOWN_MASK);
        return modifiers;
    }

    private static int mapNewModifiers(int modifiers) {
        if ((modifiers & (java.awt.event.InputEvent.SHIFT_DOWN_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.SHIFT_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_DOWN_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.ALT_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.ALT_GRAPH_DOWN_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.ALT_GRAPH_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.CTRL_DOWN_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.CTRL_MASK;
        } 
        if ((modifiers & (java.awt.event.InputEvent.META_DOWN_MASK)) != 0) {
            modifiers |= java.awt.event.InputEvent.META_MASK;
        } 
        return modifiers;
    }
}


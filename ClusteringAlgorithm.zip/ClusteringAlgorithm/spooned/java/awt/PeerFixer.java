package java.awt;


class PeerFixer implements java.awt.event.AdjustmentListener , java.io.Serializable {
    private static final long serialVersionUID = 7051237413532574756L;

    PeerFixer(java.awt.ScrollPane scroller) {
        java.awt.PeerFixer.this.scroller = scroller;
    }

    public void adjustmentValueChanged(java.awt.event.AdjustmentEvent e) {
        java.awt.Adjustable adj = e.getAdjustable();
        int value = e.getValue();
        java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(scroller.peer));
        if (peer != null) {
            peer.setValue(adj, value);
        } 
        java.awt.Component c = scroller.getComponent(0);
        switch (adj.getOrientation()) {
            case java.awt.Adjustable.VERTICAL :
                c.move(c.getLocation().x, (-value));
                break;
            case java.awt.Adjustable.HORIZONTAL :
                c.move((-value), c.getLocation().y);
                break;
            default :
                throw new java.lang.IllegalArgumentException("Illegal adjustable orientation");
        }
    }

    private java.awt.ScrollPane scroller;
}


package java.awt;


class Queue {
    java.awt.EventQueueItem head;

    java.awt.EventQueueItem tail;
}


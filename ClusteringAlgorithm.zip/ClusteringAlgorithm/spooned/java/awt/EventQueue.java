package java.awt;


public class EventQueue {
    private static final java.util.concurrent.atomic.AtomicInteger threadInitNumber = new java.util.concurrent.atomic.AtomicInteger(0);

    private static final int LOW_PRIORITY = 0;

    private static final int NORM_PRIORITY = 1;

    private static final int HIGH_PRIORITY = 2;

    private static final int ULTIMATE_PRIORITY = 3;

    private static final int NUM_PRIORITIES = (java.awt.EventQueue.ULTIMATE_PRIORITY) + 1;

    private java.awt.Queue[] queues = new java.awt.Queue[java.awt.EventQueue.NUM_PRIORITIES];

    private java.awt.EventQueue nextQueue;

    private java.awt.EventQueue previousQueue;

    private final java.util.concurrent.locks.Lock pushPopLock;

    private final java.util.concurrent.locks.Condition pushPopCond;

    private static final java.lang.Runnable dummyRunnable = new java.lang.Runnable() {
        public void run() {
        }
    };

    private java.awt.EventDispatchThread dispatchThread;

    private final java.lang.ThreadGroup threadGroup = java.lang.Thread.currentThread().getThreadGroup();

    private final java.lang.ClassLoader classLoader = java.lang.Thread.currentThread().getContextClassLoader();

    private long mostRecentEventTime = java.lang.System.currentTimeMillis();

    private long mostRecentKeyEventTime = java.lang.System.currentTimeMillis();

    private java.lang.ref.WeakReference<java.awt.AWTEvent> currentEvent;

    private volatile int waitForID;

    private final sun.awt.AppContext appContext;

    private final java.lang.String name = "AWT-EventQueue-" + (java.awt.EventQueue.threadInitNumber.getAndIncrement());

    private sun.awt.FwDispatcher fwDispatcher;

    private static volatile sun.util.logging.PlatformLogger eventLog;

    private static final sun.util.logging.PlatformLogger getEventLog() {
        if ((java.awt.EventQueue.eventLog) == null) {
            java.awt.EventQueue.eventLog = sun.util.logging.PlatformLogger.getLogger("java.awt.event.EventQueue");
        } 
        return java.awt.EventQueue.eventLog;
    }

    static {
        sun.awt.AWTAccessor.setEventQueueAccessor(new sun.awt.AWTAccessor.EventQueueAccessor() {
            public java.lang.Thread getDispatchThread(java.awt.EventQueue eventQueue) {
                return eventQueue.getDispatchThread();
            }

            public boolean isDispatchThreadImpl(java.awt.EventQueue eventQueue) {
                return eventQueue.isDispatchThreadImpl();
            }

            public void removeSourceEvents(java.awt.EventQueue eventQueue, java.lang.Object source, boolean removeAllEvents) {
                eventQueue.removeSourceEvents(source, removeAllEvents);
            }

            public boolean noEvents(java.awt.EventQueue eventQueue) {
                return eventQueue.noEvents();
            }

            public void wakeup(java.awt.EventQueue eventQueue, boolean isShutdown) {
                eventQueue.wakeup(isShutdown);
            }

            public void invokeAndWait(java.lang.Object source, java.lang.Runnable r) throws java.lang.InterruptedException, java.lang.reflect.InvocationTargetException {
                java.awt.EventQueue.invokeAndWait(source, r);
            }

            public void setFwDispatcher(java.awt.EventQueue eventQueue, sun.awt.FwDispatcher dispatcher) {
                eventQueue.setFwDispatcher(dispatcher);
            }

            @java.lang.Override
            public long getMostRecentEventTime(java.awt.EventQueue eventQueue) {
                return eventQueue.getMostRecentEventTimeImpl();
            }
        });
    }

    public EventQueue() {
        for (int i = 0 ; i < (java.awt.EventQueue.NUM_PRIORITIES) ; i++) {
            queues[i] = new java.awt.Queue();
        }
        appContext = sun.awt.AppContext.getAppContext();
        pushPopLock = ((java.util.concurrent.locks.Lock)(appContext.get(sun.awt.AppContext.EVENT_QUEUE_LOCK_KEY)));
        pushPopCond = ((java.util.concurrent.locks.Condition)(appContext.get(sun.awt.AppContext.EVENT_QUEUE_COND_KEY)));
    }

    public void postEvent(java.awt.AWTEvent theEvent) {
        postEventPrivate(theEvent);
    }

    private final void postEventPrivate(java.awt.AWTEvent theEvent) {
        theEvent.isPosted = true;
        pushPopLock.lock();
        try {
            if ((nextQueue) != null) {
                nextQueue.postEventPrivate(theEvent);
                return ;
            } 
            if ((dispatchThread) == null) {
                if ((theEvent.getSource()) == (sun.awt.AWTAutoShutdown.getInstance())) {
                    return ;
                } else {
                    initDispatchThread();
                }
            } 
            postEvent(theEvent, java.awt.EventQueue.getPriority(theEvent));
        } finally {
            pushPopLock.unlock();
        }
    }

    private static int getPriority(java.awt.AWTEvent theEvent) {
        if (theEvent instanceof sun.awt.PeerEvent) {
            sun.awt.PeerEvent peerEvent = ((sun.awt.PeerEvent)(theEvent));
            if (((peerEvent.getFlags()) & (sun.awt.PeerEvent.ULTIMATE_PRIORITY_EVENT)) != 0) {
                return java.awt.EventQueue.ULTIMATE_PRIORITY;
            } 
            if (((peerEvent.getFlags()) & (sun.awt.PeerEvent.PRIORITY_EVENT)) != 0) {
                return java.awt.EventQueue.HIGH_PRIORITY;
            } 
            if (((peerEvent.getFlags()) & (sun.awt.PeerEvent.LOW_PRIORITY_EVENT)) != 0) {
                return java.awt.EventQueue.LOW_PRIORITY;
            } 
        } 
        int id = theEvent.getID();
        if ((id >= (java.awt.event.PaintEvent.PAINT_FIRST)) && (id <= (java.awt.event.PaintEvent.PAINT_LAST))) {
            return java.awt.EventQueue.LOW_PRIORITY;
        } 
        return java.awt.EventQueue.NORM_PRIORITY;
    }

    private void postEvent(java.awt.AWTEvent theEvent, int priority) {
        if (coalesceEvent(theEvent, priority)) {
            return ;
        } 
        sun.awt.EventQueueItem newItem = new sun.awt.EventQueueItem(theEvent);
        boolean notifyID = (theEvent.getID()) == (java.awt.EventQueue.this.waitForID);
        if ((queues[priority].head) == null) {
            boolean shouldNotify = noEvents();
            if (shouldNotify) {
                if ((theEvent.getSource()) != (sun.awt.AWTAutoShutdown.getInstance())) {
                    sun.awt.AWTAutoShutdown.getInstance().notifyThreadBusy(dispatchThread);
                } 
                pushPopCond.signalAll();
            } else if (notifyID) {
                pushPopCond.signalAll();
            } 
        } else {
            if (notifyID) {
                pushPopCond.signalAll();
            } 
        }
    }

    private boolean coalescePaintEvent(java.awt.event.PaintEvent e) {
        java.awt.peer.ComponentPeer sourcePeer = ((java.awt.Component)(e.getSource())).peer;
        if (sourcePeer != null) {
            sourcePeer.coalescePaintEvent(e);
        } 
        java.awt.EventQueueItem[] cache = null;
        if (cache == null) {
            return false;
        } 
        int index = java.awt.EventQueue.eventToCacheIndex(e);
        if ((index != (-1)) && ((cache[index]) != null)) {
            java.awt.event.PaintEvent merged = mergePaintEvents(e, ((java.awt.event.PaintEvent)(cache[index].event)));
            if (merged != null) {
                cache[index].event = merged;
                return true;
            } 
        } 
        return false;
    }

    private java.awt.event.PaintEvent mergePaintEvents(java.awt.event.PaintEvent a, java.awt.event.PaintEvent b) {
        java.awt.Rectangle aRect = a.getUpdateRect();
        java.awt.Rectangle bRect = b.getUpdateRect();
        if (bRect.contains(aRect)) {
            return b;
        } 
        if (aRect.contains(bRect)) {
            return a;
        } 
        return null;
    }

    private boolean coalesceMouseEvent(java.awt.event.MouseEvent e) {
        java.awt.EventQueueItem[] cache = null;
        if (cache == null) {
            return false;
        } 
        int index = java.awt.EventQueue.eventToCacheIndex(e);
        if ((index != (-1)) && ((cache[index]) != null)) {
            cache[index].event = e;
            return true;
        } 
        return false;
    }

    private boolean coalescePeerEvent(sun.awt.PeerEvent e) {
        java.awt.EventQueueItem[] cache = null;
        if (cache == null) {
            return false;
        } 
        int index = java.awt.EventQueue.eventToCacheIndex(e);
        if ((index != (-1)) && ((cache[index]) != null)) {
            e = e.coalesceEvents(((sun.awt.PeerEvent)(cache[index].event)));
            if (e != null) {
                cache[index].event = e;
                return true;
            } else {
                cache[index] = null;
            }
        } 
        return false;
    }

    private boolean coalesceOtherEvent(java.awt.AWTEvent e, int priority) {
        int id = e.getID();
        java.awt.Component source = ((java.awt.Component)(e.getSource()));
        for (java.awt.EventQueueItem entry = queues[priority].head ; entry != null ; entry = entry.next) {
            if (((entry.event.getSource()) == source) && ((entry.event.getID()) == id)) {
                java.awt.AWTEvent coalescedEvent = source.coalesceEvents(entry.event, e);
                if (coalescedEvent != null) {
                    entry.event = coalescedEvent;
                    return true;
                } 
            } 
        }
        return false;
    }

    private boolean coalesceEvent(java.awt.AWTEvent e, int priority) {
        if (!((e.getSource()) instanceof java.awt.Component)) {
            return false;
        } 
        if (e instanceof sun.awt.PeerEvent) {
            return coalescePeerEvent(((sun.awt.PeerEvent)(e)));
        } 
        if ((((java.awt.Component)(e.getSource())).isCoalescingEnabled()) && (coalesceOtherEvent(e, priority))) {
            return true;
        } 
        if (e instanceof java.awt.event.PaintEvent) {
            return coalescePaintEvent(((java.awt.event.PaintEvent)(e)));
        } 
        if (e instanceof java.awt.event.MouseEvent) {
            return coalesceMouseEvent(((java.awt.event.MouseEvent)(e)));
        } 
        return false;
    }

    private void cacheEQItem(java.awt.EventQueueItem entry) {
        int index = java.awt.EventQueue.eventToCacheIndex(entry.event);
        if ((index != (-1)) && ((entry.event.getSource()) instanceof java.awt.Component)) {
            java.awt.Component source = ((java.awt.Component)(entry.event.getSource()));
        } 
    }

    private void uncacheEQItem(java.awt.EventQueueItem entry) {
        int index = java.awt.EventQueue.eventToCacheIndex(entry.event);
        if ((index != (-1)) && ((entry.event.getSource()) instanceof java.awt.Component)) {
            java.awt.Component source = ((java.awt.Component)(entry.event.getSource()));
        } 
    }

    private static final int PAINT = 0;

    private static final int UPDATE = 1;

    private static final int MOVE = 2;

    private static final int DRAG = 3;

    private static final int PEER = 4;

    private static final int CACHE_LENGTH = 5;

    private static int eventToCacheIndex(java.awt.AWTEvent e) {
        switch (e.getID()) {
            case java.awt.event.PaintEvent.PAINT :
                return java.awt.EventQueue.PAINT;
            case java.awt.event.PaintEvent.UPDATE :
                return java.awt.EventQueue.UPDATE;
            case java.awt.event.MouseEvent.MOUSE_MOVED :
                return java.awt.EventQueue.MOVE;
            case java.awt.event.MouseEvent.MOUSE_DRAGGED :
                return e instanceof sun.awt.dnd.SunDropTargetEvent ? -1 : java.awt.EventQueue.DRAG;
            default :
                return e instanceof sun.awt.PeerEvent ? java.awt.EventQueue.PEER : -1;
        }
    }

    private boolean noEvents() {
        for (int i = 0 ; i < (java.awt.EventQueue.NUM_PRIORITIES) ; i++) {
            if ((queues[i].head) != null) {
                return false;
            } 
        }
        return true;
    }

    public java.awt.AWTEvent getNextEvent() throws java.lang.InterruptedException {
        do {
            sun.awt.SunToolkit.flushPendingEvents(appContext);
            pushPopLock.lock();
            try {
                java.awt.AWTEvent event = getNextEventPrivate();
                if (event != null) {
                    return event;
                } 
                sun.awt.AWTAutoShutdown.getInstance().notifyThreadFree(dispatchThread);
                pushPopCond.await();
            } finally {
                pushPopLock.unlock();
            }
        } while (true );
    }

    java.awt.AWTEvent getNextEventPrivate() throws java.lang.InterruptedException {
        for (int i = (java.awt.EventQueue.NUM_PRIORITIES) - 1 ; i >= 0 ; i--) {
            if ((queues[i].head) != null) {
                java.awt.EventQueueItem entry = queues[i].head;
                queues[i].head = entry.next;
                if ((entry.next) == null) {
                    queues[i].tail = null;
                } 
                uncacheEQItem(entry);
                return entry.event;
            } 
        }
        return null;
    }

    java.awt.AWTEvent getNextEvent(int id) throws java.lang.InterruptedException {
        do {
            sun.awt.SunToolkit.flushPendingEvents(appContext);
            pushPopLock.lock();
            try {
                for (int i = 0 ; i < (java.awt.EventQueue.NUM_PRIORITIES) ; i++) {
                    for (java.awt.EventQueueItem entry = queues[i].head, prev = null ; entry != null ; prev = entry , entry = entry.next) {
                        if ((entry.event.getID()) == id) {
                            if (prev == null) {
                                queues[i].head = entry.next;
                            } else {
                                prev.next = entry.next;
                            }
                            if ((queues[i].tail) == entry) {
                                queues[i].tail = prev;
                            } 
                            uncacheEQItem(entry);
                            return entry.event;
                        } 
                    }
                }
                waitForID = id;
                pushPopCond.await();
                waitForID = 0;
            } finally {
                pushPopLock.unlock();
            }
        } while (true );
    }

    public java.awt.AWTEvent peekEvent() {
        pushPopLock.lock();
        try {
            for (int i = (java.awt.EventQueue.NUM_PRIORITIES) - 1 ; i >= 0 ; i--) {
                if ((queues[i].head) != null) {
                    return queues[i].head.event;
                } 
            }
        } finally {
            pushPopLock.unlock();
        }
        return null;
    }

    public java.awt.AWTEvent peekEvent(int id) {
        pushPopLock.lock();
        try {
            for (int i = (java.awt.EventQueue.NUM_PRIORITIES) - 1 ; i >= 0 ; i--) {
                java.awt.EventQueueItem q = queues[i].head;
                for ( ; q != null ; q = q.next) {
                    if ((q.event.getID()) == id) {
                        return q.event;
                    } 
                }
            }
        } finally {
            pushPopLock.unlock();
        }
        return null;
    }

    private static final sun.misc.JavaSecurityAccess javaSecurityAccess = sun.misc.SharedSecrets.getJavaSecurityAccess();

    protected void dispatchEvent(final java.awt.AWTEvent event) {
        final java.lang.Object src = event.getSource();
        final java.security.PrivilegedAction<java.lang.Void> action = new java.security.PrivilegedAction<java.lang.Void>() {
            public java.lang.Void run() {
                if (((fwDispatcher) == null) || (isDispatchThreadImpl())) {
                    dispatchEventImpl(event, src);
                } else {
                    fwDispatcher.scheduleDispatch(new java.lang.Runnable() {
                        @java.lang.Override
                        public void run() {
                            dispatchEventImpl(event, src);
                        }
                    });
                }
                return null;
            }
        };
        final java.security.AccessControlContext stack = java.security.AccessController.getContext();
        final java.security.AccessControlContext srcAcc = java.awt.EventQueue.getAccessControlContextFrom(src);
        final java.security.AccessControlContext eventAcc = event.getAccessControlContext();
        if (srcAcc == null) {
            java.awt.EventQueue.javaSecurityAccess.doIntersectionPrivilege(action, stack, eventAcc);
        } else {
            java.awt.EventQueue.javaSecurityAccess.doIntersectionPrivilege(new java.security.PrivilegedAction<java.lang.Void>() {
                public java.lang.Void run() {
                    java.awt.EventQueue.javaSecurityAccess.doIntersectionPrivilege(action, eventAcc);
                    return null;
                }
            }, stack, srcAcc);
        }
    }

    private static java.security.AccessControlContext getAccessControlContextFrom(java.lang.Object src) {
        return src instanceof java.awt.Component ? ((java.awt.Component)(src)).getAccessControlContext() : src instanceof java.awt.MenuComponent ? ((java.awt.MenuComponent)(src)).getAccessControlContext() : src instanceof java.awt.TrayIcon ? ((java.awt.TrayIcon)(src)).getAccessControlContext() : null;
    }

    private void dispatchEventImpl(final java.awt.AWTEvent event, final java.lang.Object src) {
        event.isPosted = true;
        if (event instanceof java.awt.ActiveEvent) {
            setCurrentEventAndMostRecentTimeImpl(event);
            ((java.awt.ActiveEvent)(event)).dispatch();
        } else if (src instanceof java.awt.Component) {
            ((java.awt.Component)(src)).dispatchEvent(event);
            event.dispatched();
        } else if (src instanceof java.awt.MenuComponent) {
            ((java.awt.MenuComponent)(src)).dispatchEvent(event);
        } else if (src instanceof java.awt.TrayIcon) {
            ((java.awt.TrayIcon)(src)).dispatchEvent(event);
        } else if (src instanceof sun.awt.AWTAutoShutdown) {
            if (noEvents()) {
                dispatchThread.stopDispatching();
            } 
        } else {
            if (java.awt.EventQueue.getEventLog().isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.EventQueue.getEventLog().fine(("Unable to dispatch event: " + event));
            } 
        }
    }

    public static long getMostRecentEventTime() {
        return java.awt.Toolkit.getEventQueue().getMostRecentEventTimeImpl();
    }

    private long getMostRecentEventTimeImpl() {
        pushPopLock.lock();
        try {
            return (java.lang.Thread.currentThread()) == (dispatchThread) ? mostRecentEventTime : java.lang.System.currentTimeMillis();
        } finally {
            pushPopLock.unlock();
        }
    }

    long getMostRecentEventTimeEx() {
        pushPopLock.lock();
        try {
            return mostRecentEventTime;
        } finally {
            pushPopLock.unlock();
        }
    }

    public static java.awt.AWTEvent getCurrentEvent() {
        return java.awt.Toolkit.getEventQueue().getCurrentEventImpl();
    }

    private java.awt.AWTEvent getCurrentEventImpl() {
        pushPopLock.lock();
        try {
            return (java.lang.Thread.currentThread()) == (dispatchThread) ? currentEvent.get() : null;
        } finally {
            pushPopLock.unlock();
        }
    }

    public void push(java.awt.EventQueue newEventQueue) {
        if (java.awt.EventQueue.getEventLog().isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.EventQueue.getEventLog().fine((("EventQueue.push(" + newEventQueue) + ")"));
        } 
        pushPopLock.lock();
        try {
            java.awt.EventQueue topQueue = java.awt.EventQueue.this;
            while ((topQueue.nextQueue) != null) {
                topQueue = topQueue.nextQueue;
            }
            if ((topQueue.fwDispatcher) != null) {
                throw new java.lang.RuntimeException("push() to queue with fwDispatcher");
            } 
            if (((topQueue.dispatchThread) != null) && ((topQueue.dispatchThread.getEventQueue()) == (java.awt.EventQueue.this))) {
                newEventQueue.dispatchThread = topQueue.dispatchThread;
                topQueue.dispatchThread.setEventQueue(newEventQueue);
            } 
            while ((topQueue.peekEvent()) != null) {
                try {
                    newEventQueue.postEventPrivate(topQueue.getNextEventPrivate());
                } catch (java.lang.InterruptedException ie) {
                    if (java.awt.EventQueue.getEventLog().isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.EventQueue.getEventLog().fine("Interrupted push", ie);
                    } 
                }
            }
            if ((topQueue.dispatchThread) != null) {
                topQueue.postEventPrivate(new java.awt.event.InvocationEvent(topQueue , java.awt.EventQueue.dummyRunnable));
            } 
            newEventQueue.previousQueue = topQueue;
            topQueue.nextQueue = newEventQueue;
            if ((appContext.get(sun.awt.AppContext.EVENT_QUEUE_KEY)) == topQueue) {
                appContext.put(sun.awt.AppContext.EVENT_QUEUE_KEY, newEventQueue);
            } 
            pushPopCond.signalAll();
        } finally {
            pushPopLock.unlock();
        }
    }

    protected void pop() throws java.util.EmptyStackException {
        if (java.awt.EventQueue.getEventLog().isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.EventQueue.getEventLog().fine((("EventQueue.pop(" + (java.awt.EventQueue.this)) + ")"));
        } 
        pushPopLock.lock();
        try {
            java.awt.EventQueue topQueue = java.awt.EventQueue.this;
            while ((topQueue.nextQueue) != null) {
                topQueue = topQueue.nextQueue;
            }
            java.awt.EventQueue prevQueue = topQueue.previousQueue;
            if (prevQueue == null) {
                throw new java.util.EmptyStackException();
            } 
            topQueue.previousQueue = null;
            prevQueue.nextQueue = null;
            while ((topQueue.peekEvent()) != null) {
                try {
                    prevQueue.postEventPrivate(topQueue.getNextEventPrivate());
                } catch (java.lang.InterruptedException ie) {
                    if (java.awt.EventQueue.getEventLog().isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.EventQueue.getEventLog().fine("Interrupted pop", ie);
                    } 
                }
            }
            if (((topQueue.dispatchThread) != null) && ((topQueue.dispatchThread.getEventQueue()) == (java.awt.EventQueue.this))) {
                prevQueue.dispatchThread = topQueue.dispatchThread;
                topQueue.dispatchThread.setEventQueue(prevQueue);
            } 
            if ((appContext.get(sun.awt.AppContext.EVENT_QUEUE_KEY)) == (java.awt.EventQueue.this)) {
                appContext.put(sun.awt.AppContext.EVENT_QUEUE_KEY, prevQueue);
            } 
            topQueue.postEventPrivate(new java.awt.event.InvocationEvent(topQueue , java.awt.EventQueue.dummyRunnable));
            pushPopCond.signalAll();
        } finally {
            pushPopLock.unlock();
        }
    }

    public java.awt.SecondaryLoop createSecondaryLoop() {
        return createSecondaryLoop(null, null, 0);
    }

    java.awt.SecondaryLoop createSecondaryLoop(java.awt.Conditional cond, java.awt.EventFilter filter, long interval) {
        pushPopLock.lock();
        try {
            if ((nextQueue) != null) {
                return nextQueue.createSecondaryLoop(cond, filter, interval);
            } 
            if ((fwDispatcher) != null) {
                return fwDispatcher.createSecondaryLoop();
            } 
            if ((dispatchThread) == null) {
                initDispatchThread();
            } 
            return new java.awt.WaitDispatchSupport(dispatchThread , cond , filter , interval);
        } finally {
            pushPopLock.unlock();
        }
    }

    public static boolean isDispatchThread() {
        java.awt.EventQueue eq = java.awt.Toolkit.getEventQueue();
        return eq.isDispatchThreadImpl();
    }

    final boolean isDispatchThreadImpl() {
        java.awt.EventQueue eq = java.awt.EventQueue.this;
        pushPopLock.lock();
        try {
            java.awt.EventQueue next = eq.nextQueue;
            while (next != null) {
                eq = next;
                next = eq.nextQueue;
            }
            if ((eq.fwDispatcher) != null) {
                return eq.fwDispatcher.isDispatchThread();
            } 
            return (java.lang.Thread.currentThread()) == (eq.dispatchThread);
        } finally {
            pushPopLock.unlock();
        }
    }

    final void initDispatchThread() {
        pushPopLock.lock();
        try {
            if ((((dispatchThread) == null) && (!(threadGroup.isDestroyed()))) && (!(appContext.isDisposed()))) {
                dispatchThread = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.awt.EventDispatchThread>() {
                    public java.awt.EventDispatchThread run() {
                        java.awt.EventDispatchThread t = new java.awt.EventDispatchThread(threadGroup , name , java.awt.EventQueue.this);
                        t.setContextClassLoader(classLoader);
                        t.setPriority(((java.lang.Thread.NORM_PRIORITY) + 1));
                        t.setDaemon(false);
                        sun.awt.AWTAutoShutdown.getInstance().notifyThreadBusy(t);
                        return t;
                    }
                });
                dispatchThread.start();
            } 
        } finally {
            pushPopLock.unlock();
        }
    }

    final void detachDispatchThread(java.awt.EventDispatchThread edt) {
        sun.awt.SunToolkit.flushPendingEvents(appContext);
        pushPopLock.lock();
        try {
            if (edt == (dispatchThread)) {
                dispatchThread = null;
            } 
            sun.awt.AWTAutoShutdown.getInstance().notifyThreadFree(edt);
            if ((peekEvent()) != null) {
                initDispatchThread();
            } 
        } finally {
            pushPopLock.unlock();
        }
    }

    final java.awt.EventDispatchThread getDispatchThread() {
        pushPopLock.lock();
        try {
            return dispatchThread;
        } finally {
            pushPopLock.unlock();
        }
    }

    final void removeSourceEvents(java.lang.Object source, boolean removeAllEvents) {
        sun.awt.SunToolkit.flushPendingEvents(appContext);
        pushPopLock.lock();
        try {
            for (int i = 0 ; i < (java.awt.EventQueue.NUM_PRIORITIES) ; i++) {
                java.awt.EventQueueItem entry = queues[i].head;
                java.awt.EventQueueItem prev = null;
                while (entry != null) {
                    if (((entry.event.getSource()) == source) && (removeAllEvents || (!(((((((entry.event) instanceof java.awt.SequencedEvent) || ((entry.event) instanceof java.awt.SentEvent)) || ((entry.event) instanceof java.awt.event.FocusEvent)) || ((entry.event) instanceof java.awt.event.WindowEvent)) || ((entry.event) instanceof java.awt.event.KeyEvent)) || ((entry.event) instanceof java.awt.event.InputMethodEvent))))) {
                        if ((entry.event) instanceof java.awt.SequencedEvent) {
                            ((java.awt.SequencedEvent)(entry.event)).dispose();
                        } 
                        if ((entry.event) instanceof java.awt.SentEvent) {
                            ((java.awt.SentEvent)(entry.event)).dispose();
                        } 
                        if ((entry.event) instanceof java.awt.event.InvocationEvent) {
                            sun.awt.AWTAccessor.getInvocationEventAccessor().dispose(((java.awt.event.InvocationEvent)(entry.event)));
                        } 
                        if (prev == null) {
                            queues[i].head = entry.next;
                        } else {
                            prev.next = entry.next;
                        }
                        uncacheEQItem(entry);
                    } else {
                        prev = entry;
                    }
                    entry = entry.next;
                }
                queues[i].tail = prev;
            }
        } finally {
            pushPopLock.unlock();
        }
    }

    synchronized long getMostRecentKeyEventTime() {
        pushPopLock.lock();
        try {
            return mostRecentKeyEventTime;
        } finally {
            pushPopLock.unlock();
        }
    }

    static void setCurrentEventAndMostRecentTime(java.awt.AWTEvent e) {
        java.awt.Toolkit.getEventQueue().setCurrentEventAndMostRecentTimeImpl(e);
    }

    private void setCurrentEventAndMostRecentTimeImpl(java.awt.AWTEvent e) {
        pushPopLock.lock();
        try {
            if ((java.lang.Thread.currentThread()) != (dispatchThread)) {
                return ;
            } 
            currentEvent = new java.lang.ref.WeakReference<>(e);
            long mostRecentEventTime2 = java.lang.Long.MIN_VALUE;
            if (e instanceof java.awt.event.InputEvent) {
                java.awt.event.InputEvent ie = ((java.awt.event.InputEvent)(e));
                mostRecentEventTime2 = ie.getWhen();
                if (e instanceof java.awt.event.KeyEvent) {
                    mostRecentKeyEventTime = ie.getWhen();
                } 
            } else if (e instanceof java.awt.event.InputMethodEvent) {
                java.awt.event.InputMethodEvent ime = ((java.awt.event.InputMethodEvent)(e));
                mostRecentEventTime2 = ime.getWhen();
            } else if (e instanceof java.awt.event.ActionEvent) {
                java.awt.event.ActionEvent ae = ((java.awt.event.ActionEvent)(e));
                mostRecentEventTime2 = ae.getWhen();
            } else if (e instanceof java.awt.event.InvocationEvent) {
                java.awt.event.InvocationEvent ie = ((java.awt.event.InvocationEvent)(e));
                mostRecentEventTime2 = ie.getWhen();
            } 
            mostRecentEventTime = java.lang.Math.max(mostRecentEventTime, mostRecentEventTime2);
        } finally {
            pushPopLock.unlock();
        }
    }

    public static void invokeLater(java.lang.Runnable runnable) {
        java.awt.Toolkit.getEventQueue().postEvent(new java.awt.event.InvocationEvent(java.awt.Toolkit.getDefaultToolkit() , runnable));
    }

    public static void invokeAndWait(java.lang.Runnable runnable) throws java.lang.InterruptedException, java.lang.reflect.InvocationTargetException {
        java.awt.EventQueue.invokeAndWait(java.awt.Toolkit.getDefaultToolkit(), runnable);
    }

    static void invokeAndWait(java.lang.Object source, java.lang.Runnable runnable) throws java.lang.InterruptedException, java.lang.reflect.InvocationTargetException {
        if (java.awt.EventQueue.isDispatchThread()) {
            throw new java.lang.Error("Cannot call invokeAndWait from the event dispatcher thread");
        } 
        class AWTInvocationLock {        }
        java.lang.Object lock = new AWTInvocationLock();
        java.awt.event.InvocationEvent event = new java.awt.event.InvocationEvent(source , runnable , lock , true);
        synchronized(lock) {
            java.awt.Toolkit.getEventQueue().postEvent(event);
            while (!(event.isDispatched())) {
                lock.wait();
            }
        }
        java.lang.Throwable eventThrowable = event.getThrowable();
        if (eventThrowable != null) {
            throw new java.lang.reflect.InvocationTargetException(eventThrowable);
        } 
    }

    private void wakeup(boolean isShutdown) {
        pushPopLock.lock();
        try {
            if ((nextQueue) != null) {
                nextQueue.wakeup(isShutdown);
            } else if ((dispatchThread) != null) {
                pushPopCond.signalAll();
            } else if (!isShutdown) {
                initDispatchThread();
            } 
        } finally {
            pushPopLock.unlock();
        }
    }

    private void setFwDispatcher(sun.awt.FwDispatcher dispatcher) {
        if ((nextQueue) != null) {
            nextQueue.setFwDispatcher(dispatcher);
        } else {
            fwDispatcher = dispatcher;
        }
    }
}


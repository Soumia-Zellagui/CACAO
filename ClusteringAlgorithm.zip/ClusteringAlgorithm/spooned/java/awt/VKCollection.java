package java.awt;


class VKCollection {
    java.util.Map<java.lang.Integer, java.lang.String> code2name;

    java.util.Map<java.lang.String, java.lang.Integer> name2code;

    public VKCollection() {
        code2name = new java.util.HashMap<>();
        name2code = new java.util.HashMap<>();
    }

    public synchronized void put(java.lang.String name, java.lang.Integer code) {
        assert (name != null) && (code != null);
        assert (findName(code)) == null;
        assert (findCode(name)) == null;
        code2name.put(code, name);
        name2code.put(name, code);
    }

    public synchronized java.lang.Integer findCode(java.lang.String name) {
        assert name != null;
        return ((java.lang.Integer)(name2code.get(name)));
    }

    public synchronized java.lang.String findName(java.lang.Integer code) {
        assert code != null;
        return ((java.lang.String)(code2name.get(code)));
    }
}


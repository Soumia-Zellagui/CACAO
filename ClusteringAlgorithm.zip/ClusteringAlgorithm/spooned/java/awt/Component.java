package java.awt;


public abstract class Component implements java.awt.MenuContainer , java.awt.image.ImageObserver , java.io.Serializable {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.Component");

    private static final sun.util.logging.PlatformLogger eventLog = sun.util.logging.PlatformLogger.getLogger("java.awt.event.Component");

    private static final sun.util.logging.PlatformLogger focusLog = sun.util.logging.PlatformLogger.getLogger("java.awt.focus.Component");

    private static final sun.util.logging.PlatformLogger mixingLog = sun.util.logging.PlatformLogger.getLogger("java.awt.mixing.Component");

    transient java.awt.peer.ComponentPeer peer;

    transient java.awt.Container parent;

    transient sun.awt.AppContext appContext;

    int x;

    int y;

    int width;

    int height;

    java.awt.Color foreground;

    java.awt.Color background;

    volatile java.awt.Font font;

    java.awt.Font peerFont;

    java.awt.Cursor cursor;

    java.util.Locale locale;

    private transient java.awt.GraphicsConfiguration graphicsConfig = null;

    transient java.awt.image.BufferStrategy bufferStrategy = null;

    boolean ignoreRepaint = false;

    boolean visible = true;

    boolean enabled = true;

    private volatile boolean valid = false;

    java.awt.dnd.DropTarget dropTarget;

    java.util.Vector<java.awt.PopupMenu> popups;

    private java.lang.String name;

    private boolean nameExplicitlySet = false;

    private boolean focusable = true;

    private static final int FOCUS_TRAVERSABLE_UNKNOWN = 0;

    private static final int FOCUS_TRAVERSABLE_DEFAULT = 1;

    private static final int FOCUS_TRAVERSABLE_SET = 2;

    private int isFocusTraversableOverridden = java.awt.Component.FOCUS_TRAVERSABLE_UNKNOWN;

    java.util.Set<java.awt.AWTKeyStroke>[] focusTraversalKeys;

    private static final java.lang.String[] focusTraversalKeyPropertyNames = new java.lang.String[]{ "forwardFocusTraversalKeys" , "backwardFocusTraversalKeys" , "upCycleFocusTraversalKeys" , "downCycleFocusTraversalKeys" };

    private boolean focusTraversalKeysEnabled = true;

    static final java.lang.Object LOCK = new java.awt.Component.AWTTreeLock();

    static class AWTTreeLock {    }

    private transient volatile java.security.AccessControlContext acc = java.security.AccessController.getContext();

    java.awt.Dimension minSize;

    boolean minSizeSet;

    java.awt.Dimension prefSize;

    boolean prefSizeSet;

    java.awt.Dimension maxSize;

    boolean maxSizeSet;

    transient java.awt.ComponentOrientation componentOrientation = java.awt.ComponentOrientation.UNKNOWN;

    boolean newEventsOnly = false;

    transient java.awt.event.ComponentListener componentListener;

    transient java.awt.event.FocusListener focusListener;

    transient java.awt.event.HierarchyListener hierarchyListener;

    transient java.awt.event.HierarchyBoundsListener hierarchyBoundsListener;

    transient java.awt.event.KeyListener keyListener;

    transient java.awt.event.MouseListener mouseListener;

    transient java.awt.event.MouseMotionListener mouseMotionListener;

    transient java.awt.event.MouseWheelListener mouseWheelListener;

    transient java.awt.event.InputMethodListener inputMethodListener;

    transient java.lang.RuntimeException windowClosingException = null;

    static final java.lang.String actionListenerK = "actionL";

    static final java.lang.String adjustmentListenerK = "adjustmentL";

    static final java.lang.String componentListenerK = "componentL";

    static final java.lang.String containerListenerK = "containerL";

    static final java.lang.String focusListenerK = "focusL";

    static final java.lang.String itemListenerK = "itemL";

    static final java.lang.String keyListenerK = "keyL";

    static final java.lang.String mouseListenerK = "mouseL";

    static final java.lang.String mouseMotionListenerK = "mouseMotionL";

    static final java.lang.String mouseWheelListenerK = "mouseWheelL";

    static final java.lang.String textListenerK = "textL";

    static final java.lang.String ownedWindowK = "ownedL";

    static final java.lang.String windowListenerK = "windowL";

    static final java.lang.String inputMethodListenerK = "inputMethodL";

    static final java.lang.String hierarchyListenerK = "hierarchyL";

    static final java.lang.String hierarchyBoundsListenerK = "hierarchyBoundsL";

    static final java.lang.String windowStateListenerK = "windowStateL";

    static final java.lang.String windowFocusListenerK = "windowFocusL";

    long eventMask = java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK;

    static boolean isInc;

    static int incRate;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Component.initIDs();
        } 
        java.lang.String s = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("awt.image.incrementaldraw"));
        isInc = (s == null) || (s.equals("true"));
        s = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("awt.image.redrawrate"));
        incRate = s != null ? java.lang.Integer.parseInt(s) : 100;
    }

    public static final float TOP_ALIGNMENT = 0.0F;

    public static final float CENTER_ALIGNMENT = 0.5F;

    public static final float BOTTOM_ALIGNMENT = 1.0F;

    public static final float LEFT_ALIGNMENT = 0.0F;

    public static final float RIGHT_ALIGNMENT = 1.0F;

    private static final long serialVersionUID = -7644114512714619750L;

    private java.beans.PropertyChangeSupport changeSupport;

    private transient java.lang.Object objectLock = new java.lang.Object();

    java.lang.Object getObjectLock() {
        return objectLock;
    }

    final java.security.AccessControlContext getAccessControlContext() {
        if ((acc) == null) {
            throw new java.lang.SecurityException("Component is missing AccessControlContext");
        } 
        return acc;
    }

    boolean isPacked = false;

    private int boundsOp = java.awt.peer.ComponentPeer.DEFAULT_OPERATION;

    public enum BaselineResizeBehavior {
CONSTANT_ASCENT, CONSTANT_DESCENT, CENTER_OFFSET, OTHER;    }

    private transient sun.java2d.pipe.Region compoundShape = null;

    private transient sun.java2d.pipe.Region mixingCutoutRegion = null;

    private transient boolean isAddNotifyComplete = false;

    int getBoundsOp() {
        assert java.lang.Thread.holdsLock(getTreeLock());
        return boundsOp;
    }

    void setBoundsOp(int op) {
        assert java.lang.Thread.holdsLock(getTreeLock());
        if (op == (java.awt.peer.ComponentPeer.RESET_OPERATION)) {
            boundsOp = java.awt.peer.ComponentPeer.DEFAULT_OPERATION;
        } else if ((boundsOp) == (java.awt.peer.ComponentPeer.DEFAULT_OPERATION)) {
            boundsOp = op;
        } 
    }

    transient boolean backgroundEraseDisabled;

    static {
        sun.awt.AWTAccessor.setComponentAccessor(new sun.awt.AWTAccessor.ComponentAccessor() {
            public void setBackgroundEraseDisabled(java.awt.Component comp, boolean disabled) {
                comp.backgroundEraseDisabled = disabled;
            }

            public boolean getBackgroundEraseDisabled(java.awt.Component comp) {
                return comp.backgroundEraseDisabled;
            }

            public java.awt.Rectangle getBounds(java.awt.Component comp) {
                return new java.awt.Rectangle(comp.x , comp.y , comp.width , comp.height);
            }

            public void setMixingCutoutShape(java.awt.Component comp, java.awt.Shape shape) {
                sun.java2d.pipe.Region region = shape == null ? null : null;
                synchronized(comp.getTreeLock()) {
                    boolean needShowing = false;
                    boolean needHiding = false;
                    if (!(comp.isNonOpaqueForMixing())) {
                        needHiding = true;
                    } 
                    comp.mixingCutoutRegion = region;
                    if (!(comp.isNonOpaqueForMixing())) {
                        needShowing = true;
                    } 
                    if (comp.isMixingNeeded()) {
                        if (needHiding) {
                            comp.mixOnHiding(comp.isLightweight());
                        } 
                        if (needShowing) {
                            comp.mixOnShowing();
                        } 
                    } 
                }
            }

            public void setGraphicsConfiguration(java.awt.Component comp, java.awt.GraphicsConfiguration gc) {
                comp.setGraphicsConfiguration(gc);
            }

            public boolean requestFocus(java.awt.Component comp, sun.awt.CausedFocusEvent.Cause cause) {
                return comp.requestFocus(cause);
            }

            public boolean canBeFocusOwner(java.awt.Component comp) {
                return comp.canBeFocusOwner();
            }

            public boolean isVisible(java.awt.Component comp) {
                return comp.isVisible_NoClientCode();
            }

            public void setRequestFocusController(sun.awt.RequestFocusController requestController) {
                java.awt.Component.setRequestFocusController(requestController);
            }

            public sun.awt.AppContext getAppContext(java.awt.Component comp) {
                return comp.appContext;
            }

            public void setAppContext(java.awt.Component comp, sun.awt.AppContext appContext) {
                comp.appContext = appContext;
            }

            public java.awt.Container getParent(java.awt.Component comp) {
                return comp.getParent_NoClientCode();
            }

            public void setParent(java.awt.Component comp, java.awt.Container parent) {
                comp.parent = parent;
            }

            public void setSize(java.awt.Component comp, int width, int height) {
                comp.width = width;
                comp.height = height;
            }

            public java.awt.Point getLocation(java.awt.Component comp) {
                return comp.location_NoClientCode();
            }

            public void setLocation(java.awt.Component comp, int x, int y) {
                comp.x = x;
                comp.y = y;
            }

            public boolean isEnabled(java.awt.Component comp) {
                return comp.isEnabledImpl();
            }

            public boolean isDisplayable(java.awt.Component comp) {
                return (comp.peer) != null;
            }

            public java.awt.Cursor getCursor(java.awt.Component comp) {
                return comp.getCursor_NoClientCode();
            }

            public java.awt.peer.ComponentPeer getPeer(java.awt.Component comp) {
                return comp.peer;
            }

            public void setPeer(java.awt.Component comp, java.awt.peer.ComponentPeer peer) {
                comp.peer = peer;
            }

            public boolean isLightweight(java.awt.Component comp) {
                return (comp.peer) instanceof java.awt.peer.LightweightPeer;
            }

            public boolean getIgnoreRepaint(java.awt.Component comp) {
                return comp.ignoreRepaint;
            }

            public int getWidth(java.awt.Component comp) {
                return comp.width;
            }

            public int getHeight(java.awt.Component comp) {
                return comp.height;
            }

            public int getX(java.awt.Component comp) {
                return comp.x;
            }

            public int getY(java.awt.Component comp) {
                return comp.y;
            }

            public java.awt.Color getForeground(java.awt.Component comp) {
                return comp.foreground;
            }

            public java.awt.Color getBackground(java.awt.Component comp) {
                return comp.background;
            }

            public void setBackground(java.awt.Component comp, java.awt.Color background) {
                comp.background = background;
            }

            public java.awt.Font getFont(java.awt.Component comp) {
                return comp.getFont_NoClientCode();
            }

            public void processEvent(java.awt.Component comp, java.awt.AWTEvent e) {
                comp.processEvent(e);
            }

            public java.security.AccessControlContext getAccessControlContext(java.awt.Component comp) {
                return comp.getAccessControlContext();
            }

            public void revalidateSynchronously(java.awt.Component comp) {
                comp.revalidateSynchronously();
            }
        });
    }

    protected Component() {
        appContext = sun.awt.AppContext.getAppContext();
    }

    @java.lang.SuppressWarnings(value = { "rawtypes" , "unchecked" })
    void initializeFocusTraversalKeys() {
        focusTraversalKeys = new java.util.Set[3];
    }

    java.lang.String constructComponentName() {
        return null;
    }

    public java.lang.String getName() {
        if (((name) == null) && (!(nameExplicitlySet))) {
            synchronized(getObjectLock()) {
                if (((name) == null) && (!(nameExplicitlySet)))
                    name = constructComponentName();
                
            }
        } 
        return name;
    }

    public void setName(java.lang.String name) {
        java.lang.String oldName;
        synchronized(getObjectLock()) {
            oldName = java.awt.Component.this.name;
            java.awt.Component.this.name = name;
            nameExplicitlySet = true;
        }
        firePropertyChange("name", oldName, name);
    }

    public java.awt.Container getParent() {
        return getParent_NoClientCode();
    }

    final java.awt.Container getParent_NoClientCode() {
        return parent;
    }

    java.awt.Container getContainer() {
        return getParent_NoClientCode();
    }

    @java.lang.Deprecated
    public java.awt.peer.ComponentPeer getPeer() {
        return peer;
    }

    public synchronized void setDropTarget(java.awt.dnd.DropTarget dt) {
        if ((dt == (dropTarget)) || (((dropTarget) != null) && (dropTarget.equals(dt))))
            return ;
        
        java.awt.dnd.DropTarget old;
        if ((old = dropTarget) != null) {
            if ((peer) != null)
                dropTarget.removeNotify(peer);
            
            java.awt.dnd.DropTarget t = dropTarget;
            dropTarget = null;
            try {
                t.setComponent(null);
            } catch (java.lang.IllegalArgumentException iae) {
            }
        } 
        if ((dropTarget = dt) != null) {
            try {
                dropTarget.setComponent(java.awt.Component.this);
                if ((peer) != null)
                    dropTarget.addNotify(peer);
                
            } catch (java.lang.IllegalArgumentException iae) {
                if (old != null) {
                    try {
                        old.setComponent(java.awt.Component.this);
                        if ((peer) != null)
                            dropTarget.addNotify(peer);
                        
                    } catch (java.lang.IllegalArgumentException iae1) {
                    }
                } 
            }
        } 
    }

    public synchronized java.awt.dnd.DropTarget getDropTarget() {
        return dropTarget;
    }

    public java.awt.GraphicsConfiguration getGraphicsConfiguration() {
        synchronized(getTreeLock()) {
            return getGraphicsConfiguration_NoClientCode();
        }
    }

    final java.awt.GraphicsConfiguration getGraphicsConfiguration_NoClientCode() {
        return graphicsConfig;
    }

    void setGraphicsConfiguration(java.awt.GraphicsConfiguration gc) {
        synchronized(getTreeLock()) {
            if (updateGraphicsData(gc)) {
                removeNotify();
                addNotify();
            } 
        }
    }

    boolean updateGraphicsData(java.awt.GraphicsConfiguration gc) {
        checkTreeLock();
        if ((graphicsConfig) == gc) {
            return false;
        } 
        graphicsConfig = gc;
        java.awt.peer.ComponentPeer peer = getPeer();
        if (peer != null) {
            return peer.updateGraphicsData(gc);
        } 
        return false;
    }

    void checkGD(java.lang.String stringID) {
        if ((graphicsConfig) != null) {
            if (!(graphicsConfig.getDevice().getIDstring().equals(stringID))) {
                throw new java.lang.IllegalArgumentException("adding a container to a container on a different GraphicsDevice");
            } 
        } 
    }

    public final java.lang.Object getTreeLock() {
        return java.awt.Component.LOCK;
    }

    final void checkTreeLock() {
        if (!(java.lang.Thread.holdsLock(getTreeLock()))) {
            throw new java.lang.IllegalStateException("This function should be called while holding treeLock");
        } 
    }

    public java.awt.Toolkit getToolkit() {
        return getToolkitImpl();
    }

    final java.awt.Toolkit getToolkitImpl() {
        java.awt.Container parent = java.awt.Component.this.parent;
        if (parent != null) {
            return parent.getToolkitImpl();
        } 
        return java.awt.Toolkit.getDefaultToolkit();
    }

    public boolean isValid() {
        return ((peer) != null) && (valid);
    }

    public boolean isDisplayable() {
        return (getPeer()) != null;
    }

    @java.beans.Transient
    public boolean isVisible() {
        return isVisible_NoClientCode();
    }

    final boolean isVisible_NoClientCode() {
        return visible;
    }

    boolean isRecursivelyVisible() {
        return (visible) && (((parent) == null) || (parent.isRecursivelyVisible()));
    }

    private java.awt.Rectangle getRecursivelyVisibleBounds() {
        final java.awt.Component container = getContainer();
        final java.awt.Rectangle bounds = getBounds();
        if (container == null) {
            return bounds;
        } 
        final java.awt.Rectangle parentsBounds = container.getRecursivelyVisibleBounds();
        parentsBounds.setLocation(0, 0);
        return parentsBounds.intersection(bounds);
    }

    java.awt.Point pointRelativeToComponent(java.awt.Point absolute) {
        java.awt.Point compCoords = getLocationOnScreen();
        return new java.awt.Point(((absolute.x) - (compCoords.x)) , ((absolute.y) - (compCoords.y)));
    }

    java.awt.Component findUnderMouseInWindow(java.awt.PointerInfo pi) {
        if (!(isShowing())) {
            return null;
        } 
        java.awt.Window win = getContainingWindow();
        if (!(java.awt.Toolkit.getDefaultToolkit().getMouseInfoPeer().isWindowUnderMouse(win))) {
            return null;
        } 
        final boolean INCLUDE_DISABLED = true;
        java.awt.Point relativeToWindow = win.pointRelativeToComponent(pi.getLocation());
        java.awt.Component inTheSameWindow = win.findComponentAt(relativeToWindow.x, relativeToWindow.y, INCLUDE_DISABLED);
        return inTheSameWindow;
    }

    public java.awt.Point getMousePosition() throws java.awt.HeadlessException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        java.awt.PointerInfo pi = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.awt.PointerInfo>() {
            public java.awt.PointerInfo run() {
                return java.awt.MouseInfo.getPointerInfo();
            }
        });
        synchronized(getTreeLock()) {
            java.awt.Component inTheSameWindow = findUnderMouseInWindow(pi);
            if (!(isSameOrAncestorOf(inTheSameWindow, true))) {
                return null;
            } 
            return pointRelativeToComponent(pi.getLocation());
        }
    }

    boolean isSameOrAncestorOf(java.awt.Component comp, boolean allowChildren) {
        return comp == (java.awt.Component.this);
    }

    public boolean isShowing() {
        if ((visible) && ((peer) != null)) {
            java.awt.Container parent = java.awt.Component.this.parent;
            return (parent == null) || (parent.isShowing());
        } 
        return false;
    }

    public boolean isEnabled() {
        return isEnabledImpl();
    }

    final boolean isEnabledImpl() {
        return enabled;
    }

    public void setEnabled(boolean b) {
        enable(b);
    }

    @java.lang.Deprecated
    public void enable() {
        if (!(enabled)) {
            synchronized(getTreeLock()) {
                enabled = true;
                java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
                if (peer != null) {
                    peer.setEnabled(true);
                    if ((visible) && (!(getRecursivelyVisibleBounds().isEmpty()))) {
                        updateCursorImmediately();
                    } 
                } 
            }
            if ((accessibleContext) != null) {
                accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.ENABLED);
            } 
        } 
    }

    @java.lang.Deprecated
    public void enable(boolean b) {
        if (b) {
            enable();
        } else {
            disable();
        }
    }

    @java.lang.Deprecated
    public void disable() {
        if (enabled) {
            java.awt.KeyboardFocusManager.clearMostRecentFocusOwner(java.awt.Component.this);
            synchronized(getTreeLock()) {
                enabled = false;
                if (((isFocusOwner()) || ((containsFocus()) && (!(isLightweight())))) && (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled())) {
                    transferFocus(false);
                } 
                java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
                if (peer != null) {
                    peer.setEnabled(false);
                    if ((visible) && (!(getRecursivelyVisibleBounds().isEmpty()))) {
                        updateCursorImmediately();
                    } 
                } 
            }
            if ((accessibleContext) != null) {
                accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.ENABLED);
            } 
        } 
    }

    public boolean isDoubleBuffered() {
        return false;
    }

    public void enableInputMethods(boolean enable) {
        if (enable) {
            if (((eventMask) & (java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK)) != 0)
                return ;
            
            if (isFocusOwner()) {
                java.awt.im.InputContext inputContext = getInputContext();
                if (inputContext != null) {
                    java.awt.event.FocusEvent focusGainedEvent = new java.awt.event.FocusEvent(java.awt.Component.this , java.awt.event.FocusEvent.FOCUS_GAINED);
                    inputContext.dispatchEvent(focusGainedEvent);
                } 
            } 
            eventMask |= java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK;
        } else {
            if (((eventMask) & (java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK)) != 0) {
                java.awt.im.InputContext inputContext = getInputContext();
                if (inputContext != null) {
                    inputContext.endComposition();
                    inputContext.removeNotify(java.awt.Component.this);
                } 
            } 
            eventMask &= ~(java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK);
        }
    }

    public void setVisible(boolean b) {
        show(b);
    }

    @java.lang.Deprecated
    public void show() {
        if (!(visible)) {
            synchronized(getTreeLock()) {
                visible = true;
                mixOnShowing();
                java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
                if (peer != null) {
                    peer.setVisible(true);
                    createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, java.awt.Component.this, parent, java.awt.event.HierarchyEvent.SHOWING_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
                    if (peer instanceof java.awt.peer.LightweightPeer) {
                        repaint();
                    } 
                    updateCursorImmediately();
                } 
                if ((((componentListener) != null) || (((eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.COMPONENT_EVENT_MASK))) {
                    java.awt.event.ComponentEvent e = new java.awt.event.ComponentEvent(java.awt.Component.this , java.awt.event.ComponentEvent.COMPONENT_SHOWN);
                    java.awt.Toolkit.getEventQueue().postEvent(e);
                } 
            }
            java.awt.Container parent = java.awt.Component.this.parent;
            if (parent != null) {
                parent.invalidate();
            } 
        } 
    }

    @java.lang.Deprecated
    public void show(boolean b) {
        if (b) {
            show();
        } else {
            hide();
        }
    }

    boolean containsFocus() {
        return isFocusOwner();
    }

    void clearMostRecentFocusOwnerOnHide() {
        java.awt.KeyboardFocusManager.clearMostRecentFocusOwner(java.awt.Component.this);
    }

    void clearCurrentFocusCycleRootOnHide() {
    }

    @java.lang.Deprecated
    public void hide() {
        isPacked = false;
        if (visible) {
            clearCurrentFocusCycleRootOnHide();
            clearMostRecentFocusOwnerOnHide();
            synchronized(getTreeLock()) {
                visible = false;
                mixOnHiding(isLightweight());
                if ((containsFocus()) && (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled())) {
                    transferFocus(true);
                } 
                java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
                if (peer != null) {
                    peer.setVisible(false);
                    createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, java.awt.Component.this, parent, java.awt.event.HierarchyEvent.SHOWING_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
                    if (peer instanceof java.awt.peer.LightweightPeer) {
                        repaint();
                    } 
                    updateCursorImmediately();
                } 
                if ((((componentListener) != null) || (((eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.COMPONENT_EVENT_MASK))) {
                    java.awt.event.ComponentEvent e = new java.awt.event.ComponentEvent(java.awt.Component.this , java.awt.event.ComponentEvent.COMPONENT_HIDDEN);
                    java.awt.Toolkit.getEventQueue().postEvent(e);
                } 
            }
            java.awt.Container parent = java.awt.Component.this.parent;
            if (parent != null) {
                parent.invalidate();
            } 
        } 
    }

    @java.beans.Transient
    public java.awt.Color getForeground() {
        java.awt.Color foreground = java.awt.Component.this.foreground;
        if (foreground != null) {
            return foreground;
        } 
        java.awt.Container parent = java.awt.Component.this.parent;
        return parent != null ? parent.getForeground() : null;
    }

    public void setForeground(java.awt.Color c) {
        java.awt.Color oldColor = foreground;
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        foreground = c;
        if (peer != null) {
            c = getForeground();
            if (c != null) {
                peer.setForeground(c);
            } 
        } 
        firePropertyChange("foreground", oldColor, c);
    }

    public boolean isForegroundSet() {
        return (foreground) != null;
    }

    @java.beans.Transient
    public java.awt.Color getBackground() {
        java.awt.Color background = java.awt.Component.this.background;
        if (background != null) {
            return background;
        } 
        java.awt.Container parent = java.awt.Component.this.parent;
        return parent != null ? parent.getBackground() : null;
    }

    public void setBackground(java.awt.Color c) {
        java.awt.Color oldColor = background;
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        background = c;
        if (peer != null) {
            c = getBackground();
            if (c != null) {
                peer.setBackground(c);
            } 
        } 
        firePropertyChange("background", oldColor, c);
    }

    public boolean isBackgroundSet() {
        return (background) != null;
    }

    @java.beans.Transient
    public java.awt.Font getFont() {
        return getFont_NoClientCode();
    }

    final java.awt.Font getFont_NoClientCode() {
        java.awt.Font font = java.awt.Component.this.font;
        if (font != null) {
            return font;
        } 
        java.awt.Container parent = java.awt.Component.this.parent;
        return parent != null ? parent.getFont_NoClientCode() : null;
    }

    public void setFont(java.awt.Font f) {
        java.awt.Font oldFont;
        java.awt.Font newFont;
        synchronized(getTreeLock()) {
            oldFont = font;
            newFont = font = f;
            java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
            if (peer != null) {
                f = getFont();
                if (f != null) {
                    peer.setFont(f);
                    peerFont = f;
                } 
            } 
        }
        firePropertyChange("font", oldFont, newFont);
        if ((f != oldFont) && ((oldFont == null) || (!(oldFont.equals(f))))) {
            invalidateIfValid();
        } 
    }

    public boolean isFontSet() {
        return (font) != null;
    }

    public java.util.Locale getLocale() {
        java.util.Locale locale = java.awt.Component.this.locale;
        if (locale != null) {
            return locale;
        } 
        java.awt.Container parent = java.awt.Component.this.parent;
        if (parent == null) {
            throw new java.awt.IllegalComponentStateException("This component must have a parent in order to determine its locale");
        } else {
            return parent.getLocale();
        }
    }

    public void setLocale(java.util.Locale l) {
        java.util.Locale oldValue = locale;
        locale = l;
        firePropertyChange("locale", oldValue, l);
        invalidateIfValid();
    }

    public java.awt.image.ColorModel getColorModel() {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if ((peer != null) && (!(peer instanceof java.awt.peer.LightweightPeer))) {
            return peer.getColorModel();
        } else if (java.awt.GraphicsEnvironment.isHeadless()) {
            return java.awt.image.ColorModel.getRGBdefault();
        } 
        return getToolkit().getColorModel();
    }

    public java.awt.Point getLocation() {
        return location();
    }

    public java.awt.Point getLocationOnScreen() {
        synchronized(getTreeLock()) {
            return getLocationOnScreen_NoTreeLock();
        }
    }

    final java.awt.Point getLocationOnScreen_NoTreeLock() {
        if (((peer) != null) && (isShowing())) {
            if ((peer) instanceof java.awt.peer.LightweightPeer) {
                java.awt.Container host = getNativeContainer();
                java.awt.Point pt = host.peer.getLocationOnScreen();
                for (java.awt.Component c = java.awt.Component.this ; c != host ; c = c.getParent()) {
                    pt.x += c.x;
                    pt.y += c.y;
                }
                return pt;
            } else {
                java.awt.Point pt = peer.getLocationOnScreen();
                return pt;
            }
        } else {
            throw new java.awt.IllegalComponentStateException("component must be showing on the screen to determine its location");
        }
    }

    @java.lang.Deprecated
    public java.awt.Point location() {
        return location_NoClientCode();
    }

    private java.awt.Point location_NoClientCode() {
        return new java.awt.Point(x , y);
    }

    public void setLocation(int x, int y) {
        move(x, y);
    }

    @java.lang.Deprecated
    public void move(int x, int y) {
        synchronized(getTreeLock()) {
            setBoundsOp(java.awt.peer.ComponentPeer.SET_LOCATION);
            setBounds(x, y, width, height);
        }
    }

    public void setLocation(java.awt.Point p) {
        setLocation(p.x, p.y);
    }

    public java.awt.Dimension getSize() {
        return size();
    }

    @java.lang.Deprecated
    public java.awt.Dimension size() {
        return new java.awt.Dimension(width , height);
    }

    public void setSize(int width, int height) {
        resize(width, height);
    }

    @java.lang.Deprecated
    public void resize(int width, int height) {
        synchronized(getTreeLock()) {
            setBoundsOp(java.awt.peer.ComponentPeer.SET_SIZE);
            setBounds(x, y, width, height);
        }
    }

    public void setSize(java.awt.Dimension d) {
        resize(d);
    }

    @java.lang.Deprecated
    public void resize(java.awt.Dimension d) {
        setSize(d.width, d.height);
    }

    public java.awt.Rectangle getBounds() {
        return bounds();
    }

    @java.lang.Deprecated
    public java.awt.Rectangle bounds() {
        return new java.awt.Rectangle(x , y , width , height);
    }

    public void setBounds(int x, int y, int width, int height) {
        reshape(x, y, width, height);
    }

    @java.lang.Deprecated
    public void reshape(int x, int y, int width, int height) {
        synchronized(getTreeLock()) {
            try {
                setBoundsOp(java.awt.peer.ComponentPeer.SET_BOUNDS);
                boolean resized = ((java.awt.Component.this.width) != width) || ((java.awt.Component.this.height) != height);
                boolean moved = ((java.awt.Component.this.x) != x) || ((java.awt.Component.this.y) != y);
                if ((!resized) && (!moved)) {
                    return ;
                } 
                int oldX = java.awt.Component.this.x;
                int oldY = java.awt.Component.this.y;
                int oldWidth = java.awt.Component.this.width;
                int oldHeight = java.awt.Component.this.height;
                java.awt.Component.this.x = x;
                java.awt.Component.this.y = y;
                java.awt.Component.this.width = width;
                java.awt.Component.this.height = height;
                if (resized) {
                    isPacked = false;
                } 
                boolean needNotify = true;
                mixOnReshaping();
                if ((peer) != null) {
                    if (!((peer) instanceof java.awt.peer.LightweightPeer)) {
                        reshapeNativePeer(x, y, width, height, getBoundsOp());
                        resized = (oldWidth != (java.awt.Component.this.width)) || (oldHeight != (java.awt.Component.this.height));
                        moved = (oldX != (java.awt.Component.this.x)) || (oldY != (java.awt.Component.this.y));
                        if ((java.awt.Component.this) instanceof java.awt.Window) {
                            needNotify = false;
                        } 
                    } 
                    if (resized) {
                        invalidate();
                    } 
                    if ((parent) != null) {
                        parent.invalidateIfValid();
                    } 
                } 
                if (needNotify) {
                    notifyNewBounds(resized, moved);
                } 
                repaintParentIfNeeded(oldX, oldY, oldWidth, oldHeight);
            } finally {
                setBoundsOp(java.awt.peer.ComponentPeer.RESET_OPERATION);
            }
        }
    }

    private void repaintParentIfNeeded(int oldX, int oldY, int oldWidth, int oldHeight) {
        if ((((parent) != null) && ((peer) instanceof java.awt.peer.LightweightPeer)) && (isShowing())) {
            parent.repaint(oldX, oldY, oldWidth, oldHeight);
            repaint();
        } 
    }

    private void reshapeNativePeer(int x, int y, int width, int height, int op) {
        int nativeX = x;
        int nativeY = y;
        for (java.awt.Component c = parent ; (c != null) && ((c.peer) instanceof java.awt.peer.LightweightPeer) ; c = c.parent) {
            nativeX += c.x;
            nativeY += c.y;
        }
        peer.setBounds(nativeX, nativeY, width, height, op);
    }

    @java.lang.SuppressWarnings(value = "deprecation")
    private void notifyNewBounds(boolean resized, boolean moved) {
        if ((((componentListener) != null) || (((eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.COMPONENT_EVENT_MASK))) {
            if (resized) {
                java.awt.event.ComponentEvent e = new java.awt.event.ComponentEvent(java.awt.Component.this , java.awt.event.ComponentEvent.COMPONENT_RESIZED);
                java.awt.Toolkit.getEventQueue().postEvent(e);
            } 
            if (moved) {
                java.awt.event.ComponentEvent e = new java.awt.event.ComponentEvent(java.awt.Component.this , java.awt.event.ComponentEvent.COMPONENT_MOVED);
                java.awt.Toolkit.getEventQueue().postEvent(e);
            } 
        } else {
            if (((java.awt.Component.this) instanceof java.awt.Container) && ((((java.awt.Container)(java.awt.Component.this)).countComponents()) > 0)) {
                boolean enabledOnToolkit = java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK);
                if (resized) {
                    ((java.awt.Container)(java.awt.Component.this)).createChildHierarchyEvents(java.awt.event.HierarchyEvent.ANCESTOR_RESIZED, 0, enabledOnToolkit);
                } 
                if (moved) {
                    ((java.awt.Container)(java.awt.Component.this)).createChildHierarchyEvents(java.awt.event.HierarchyEvent.ANCESTOR_MOVED, 0, enabledOnToolkit);
                } 
            } 
        }
    }

    public void setBounds(java.awt.Rectangle r) {
        setBounds(r.x, r.y, r.width, r.height);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public java.awt.Rectangle getBounds(java.awt.Rectangle rv) {
        if (rv == null) {
            return new java.awt.Rectangle(getX() , getY() , getWidth() , getHeight());
        } else {
            rv.setBounds(getX(), getY(), getWidth(), getHeight());
            return rv;
        }
    }

    public java.awt.Dimension getSize(java.awt.Dimension rv) {
        if (rv == null) {
            return new java.awt.Dimension(getWidth() , getHeight());
        } else {
            rv.setSize(getWidth(), getHeight());
            return rv;
        }
    }

    public java.awt.Point getLocation(java.awt.Point rv) {
        if (rv == null) {
            return new java.awt.Point(getX() , getY());
        } else {
            rv.setLocation(getX(), getY());
            return rv;
        }
    }

    public boolean isOpaque() {
        if ((getPeer()) == null) {
            return false;
        } else {
            return !(isLightweight());
        }
    }

    public boolean isLightweight() {
        return (getPeer()) instanceof java.awt.peer.LightweightPeer;
    }

    public void setPreferredSize(java.awt.Dimension preferredSize) {
        java.awt.Dimension old;
        if (prefSizeSet) {
            old = java.awt.Component.this.prefSize;
        } else {
            old = null;
        }
        java.awt.Component.this.prefSize = preferredSize;
        prefSizeSet = preferredSize != null;
        firePropertyChange("preferredSize", old, preferredSize);
    }

    public boolean isPreferredSizeSet() {
        return prefSizeSet;
    }

    public java.awt.Dimension getPreferredSize() {
        return preferredSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize() {
        java.awt.Dimension dim = prefSize;
        if ((dim == null) || (!((isPreferredSizeSet()) || (isValid())))) {
            synchronized(getTreeLock()) {
                prefSize = (peer) != null ? peer.getPreferredSize() : getMinimumSize();
                dim = prefSize;
            }
        } 
        return new java.awt.Dimension(dim);
    }

    public void setMinimumSize(java.awt.Dimension minimumSize) {
        java.awt.Dimension old;
        if (minSizeSet) {
            old = java.awt.Component.this.minSize;
        } else {
            old = null;
        }
        java.awt.Component.this.minSize = minimumSize;
        minSizeSet = minimumSize != null;
        firePropertyChange("minimumSize", old, minimumSize);
    }

    public boolean isMinimumSizeSet() {
        return minSizeSet;
    }

    public java.awt.Dimension getMinimumSize() {
        return minimumSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize() {
        java.awt.Dimension dim = minSize;
        if ((dim == null) || (!((isMinimumSizeSet()) || (isValid())))) {
            synchronized(getTreeLock()) {
                minSize = (peer) != null ? peer.getMinimumSize() : size();
                dim = minSize;
            }
        } 
        return new java.awt.Dimension(dim);
    }

    public void setMaximumSize(java.awt.Dimension maximumSize) {
        java.awt.Dimension old;
        if (maxSizeSet) {
            old = java.awt.Component.this.maxSize;
        } else {
            old = null;
        }
        java.awt.Component.this.maxSize = maximumSize;
        maxSizeSet = maximumSize != null;
        firePropertyChange("maximumSize", old, maximumSize);
    }

    public boolean isMaximumSizeSet() {
        return maxSizeSet;
    }

    public java.awt.Dimension getMaximumSize() {
        if (isMaximumSizeSet()) {
            return new java.awt.Dimension(maxSize);
        } 
        return new java.awt.Dimension(java.lang.Short.MAX_VALUE , java.lang.Short.MAX_VALUE);
    }

    public float getAlignmentX() {
        return java.awt.Component.CENTER_ALIGNMENT;
    }

    public float getAlignmentY() {
        return java.awt.Component.CENTER_ALIGNMENT;
    }

    public int getBaseline(int width, int height) {
        if ((width < 0) || (height < 0)) {
            throw new java.lang.IllegalArgumentException("Width and height must be >= 0");
        } 
        return -1;
    }

    public java.awt.Component.BaselineResizeBehavior getBaselineResizeBehavior() {
        return java.awt.Component.BaselineResizeBehavior.OTHER;
    }

    public void doLayout() {
        layout();
    }

    @java.lang.Deprecated
    public void layout() {
    }

    public void validate() {
        synchronized(getTreeLock()) {
            java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
            boolean wasValid = isValid();
            if ((!wasValid) && (peer != null)) {
                java.awt.Font newfont = getFont();
                java.awt.Font oldfont = peerFont;
                if ((newfont != oldfont) && ((oldfont == null) || (!(oldfont.equals(newfont))))) {
                    peer.setFont(newfont);
                    peerFont = newfont;
                } 
                peer.layout();
            } 
            valid = true;
            if (!wasValid) {
                mixOnValidating();
            } 
        }
    }

    public void invalidate() {
        synchronized(getTreeLock()) {
            valid = false;
            if (!(isPreferredSizeSet())) {
                prefSize = null;
            } 
            if (!(isMinimumSizeSet())) {
                minSize = null;
            } 
            if (!(isMaximumSizeSet())) {
                maxSize = null;
            } 
            invalidateParent();
        }
    }

    void invalidateParent() {
        if ((parent) != null) {
            parent.invalidateIfValid();
        } 
    }

    final void invalidateIfValid() {
        if (isValid()) {
            invalidate();
        } 
    }

    public void revalidate() {
        revalidateSynchronously();
    }

    final void revalidateSynchronously() {
        synchronized(getTreeLock()) {
            invalidate();
            java.awt.Container root = getContainer();
            if (root == null) {
                validate();
            } else {
                while (!(root.isValidateRoot())) {
                    if ((root.getContainer()) == null) {
                        break;
                    } 
                    root = root.getContainer();
                }
                root.validate();
            }
        }
    }

    public java.awt.Graphics getGraphics() {
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            if ((parent) == null)
                return null;
            
            java.awt.Graphics g = parent.getGraphics();
            if (g == null)
                return null;
            
            if (g instanceof sun.awt.ConstrainableGraphics) {
                ((sun.awt.ConstrainableGraphics)(g)).constrain(x, y, width, height);
            } else {
                g.translate(x, y);
                g.setClip(0, 0, width, height);
            }
            g.setFont(getFont());
            return g;
        } else {
            java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
            return peer != null ? peer.getGraphics() : null;
        }
    }

    final java.awt.Graphics getGraphics_NoClientCode() {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.LightweightPeer) {
            java.awt.Container parent = java.awt.Component.this.parent;
            if (parent == null)
                return null;
            
            java.awt.Graphics g = parent.getGraphics_NoClientCode();
            if (g == null)
                return null;
            
            if (g instanceof sun.awt.ConstrainableGraphics) {
                ((sun.awt.ConstrainableGraphics)(g)).constrain(x, y, width, height);
            } else {
                g.translate(x, y);
                g.setClip(0, 0, width, height);
            }
            g.setFont(getFont_NoClientCode());
            return g;
        } else {
            return peer != null ? peer.getGraphics() : null;
        }
    }

    public java.awt.FontMetrics getFontMetrics(java.awt.Font font) {
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        if ((fm instanceof sun.font.SunFontManager) && (((sun.font.SunFontManager)(fm)).usePlatformFontMetrics())) {
            if (((peer) != null) && (!((peer) instanceof java.awt.peer.LightweightPeer))) {
                return peer.getFontMetrics(font);
            } 
        } 
        return sun.font.FontDesignMetrics.getMetrics(font);
    }

    public void setCursor(java.awt.Cursor cursor) {
        java.awt.Component.this.cursor = cursor;
        updateCursorImmediately();
    }

    final void updateCursorImmediately() {
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            java.awt.Container nativeContainer = getNativeContainer();
            if (nativeContainer == null)
                return ;
            
            java.awt.peer.ComponentPeer cPeer = nativeContainer.getPeer();
            if (cPeer != null) {
                cPeer.updateCursorImmediately();
            } 
        } else if ((peer) != null) {
            peer.updateCursorImmediately();
        } 
    }

    public java.awt.Cursor getCursor() {
        return getCursor_NoClientCode();
    }

    final java.awt.Cursor getCursor_NoClientCode() {
        java.awt.Cursor cursor = java.awt.Component.this.cursor;
        if (cursor != null) {
            return cursor;
        } 
        java.awt.Container parent = java.awt.Component.this.parent;
        if (parent != null) {
            return parent.getCursor_NoClientCode();
        } else {
            return java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR);
        }
    }

    public boolean isCursorSet() {
        return (cursor) != null;
    }

    public void paint(java.awt.Graphics g) {
    }

    public void update(java.awt.Graphics g) {
        paint(g);
    }

    public void paintAll(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PeerPaintCallback.getInstance().runOneComponent(java.awt.Component.this, new java.awt.Rectangle(0 , 0 , width , height), g, g.getClip(), ((java.awt.GraphicsCallback.LIGHTWEIGHTS) | (java.awt.GraphicsCallback.HEAVYWEIGHTS)));
        } 
    }

    void lightweightPaint(java.awt.Graphics g) {
        paint(g);
    }

    void paintHeavyweightComponents(java.awt.Graphics g) {
    }

    public void repaint() {
        repaint(0, 0, 0, width, height);
    }

    public void repaint(long tm) {
        repaint(tm, 0, 0, width, height);
    }

    public void repaint(int x, int y, int width, int height) {
        repaint(0, x, y, width, height);
    }

    public void repaint(long tm, int x, int y, int width, int height) {
        if ((java.awt.Component.this.peer) instanceof java.awt.peer.LightweightPeer) {
            if ((parent) != null) {
                if (x < 0) {
                    width += x;
                    x = 0;
                } 
                if (y < 0) {
                    height += y;
                    y = 0;
                } 
                int pwidth = width > (java.awt.Component.this.width) ? java.awt.Component.this.width : width;
                int pheight = height > (java.awt.Component.this.height) ? java.awt.Component.this.height : height;
                if ((pwidth <= 0) || (pheight <= 0)) {
                    return ;
                } 
                int px = (java.awt.Component.this.x) + x;
                int py = (java.awt.Component.this.y) + y;
                parent.repaint(tm, px, py, pwidth, pheight);
            } 
        } else {
            if ((((isVisible()) && ((java.awt.Component.this.peer) != null)) && (width > 0)) && (height > 0)) {
                java.awt.event.PaintEvent e = new java.awt.event.PaintEvent(java.awt.Component.this , java.awt.event.PaintEvent.UPDATE , new java.awt.Rectangle(x , y , width , height));
                sun.awt.SunToolkit.postEvent(sun.awt.SunToolkit.targetToAppContext(java.awt.Component.this), e);
            } 
        }
    }

    public void print(java.awt.Graphics g) {
        paint(g);
    }

    public void printAll(java.awt.Graphics g) {
        if (isShowing()) {
            java.awt.GraphicsCallback.PeerPrintCallback.getInstance().runOneComponent(java.awt.Component.this, new java.awt.Rectangle(0 , 0 , width , height), g, g.getClip(), ((java.awt.GraphicsCallback.LIGHTWEIGHTS) | (java.awt.GraphicsCallback.HEAVYWEIGHTS)));
        } 
    }

    void lightweightPrint(java.awt.Graphics g) {
        print(g);
    }

    void printHeavyweightComponents(java.awt.Graphics g) {
    }

    private java.awt.Insets getInsets_NoClientCode() {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.ContainerPeer) {
            return ((java.awt.Insets)(((java.awt.peer.ContainerPeer)(peer)).getInsets().clone()));
        } 
        return new java.awt.Insets(0 , 0 , 0 , 0);
    }

    public boolean imageUpdate(java.awt.Image img, int infoflags, int x, int y, int w, int h) {
        int rate = -1;
        if ((infoflags & ((java.awt.image.ImageObserver.FRAMEBITS) | (java.awt.image.ImageObserver.ALLBITS))) != 0) {
            rate = 0;
        } else if ((infoflags & (java.awt.image.ImageObserver.SOMEBITS)) != 0) {
            if (java.awt.Component.isInc) {
                rate = java.awt.Component.incRate;
                if (rate < 0) {
                    rate = 0;
                } 
            } 
        } 
        if (rate >= 0) {
            repaint(rate, 0, 0, width, height);
        } 
        return (infoflags & ((java.awt.image.ImageObserver.ALLBITS) | (java.awt.image.ImageObserver.ABORT))) == 0;
    }

    public java.awt.Image createImage(java.awt.image.ImageProducer producer) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if ((peer != null) && (!(peer instanceof java.awt.peer.LightweightPeer))) {
            return peer.createImage(producer);
        } 
        return getToolkit().createImage(producer);
    }

    public java.awt.Image createImage(int width, int height) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.LightweightPeer) {
            if ((parent) != null) {
                return parent.createImage(width, height);
            } else {
                return null;
            }
        } else {
            return peer != null ? peer.createImage(width, height) : null;
        }
    }

    public java.awt.image.VolatileImage createVolatileImage(int width, int height) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.LightweightPeer) {
            if ((parent) != null) {
                return parent.createVolatileImage(width, height);
            } else {
                return null;
            }
        } else {
            return peer != null ? peer.createVolatileImage(width, height) : null;
        }
    }

    public java.awt.image.VolatileImage createVolatileImage(int width, int height, java.awt.ImageCapabilities caps) throws java.awt.AWTException {
        return createVolatileImage(width, height);
    }

    public boolean prepareImage(java.awt.Image image, java.awt.image.ImageObserver observer) {
        return prepareImage(image, (-1), (-1), observer);
    }

    public boolean prepareImage(java.awt.Image image, int width, int height, java.awt.image.ImageObserver observer) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.LightweightPeer) {
            return (parent) != null ? parent.prepareImage(image, width, height, observer) : getToolkit().prepareImage(image, width, height, observer);
        } else {
            return peer != null ? peer.prepareImage(image, width, height, observer) : getToolkit().prepareImage(image, width, height, observer);
        }
    }

    public int checkImage(java.awt.Image image, java.awt.image.ImageObserver observer) {
        return checkImage(image, (-1), (-1), observer);
    }

    public int checkImage(java.awt.Image image, int width, int height, java.awt.image.ImageObserver observer) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer instanceof java.awt.peer.LightweightPeer) {
            return (parent) != null ? parent.checkImage(image, width, height, observer) : getToolkit().checkImage(image, width, height, observer);
        } else {
            return peer != null ? peer.checkImage(image, width, height, observer) : getToolkit().checkImage(image, width, height, observer);
        }
    }

    void createBufferStrategy(int numBuffers) {
        java.awt.BufferCapabilities bufferCaps;
        if (numBuffers > 1) {
            bufferCaps = new java.awt.BufferCapabilities(new java.awt.ImageCapabilities(true) , new java.awt.ImageCapabilities(true) , java.awt.BufferCapabilities.FlipContents.UNDEFINED);
            try {
                createBufferStrategy(numBuffers, bufferCaps);
                return ;
            } catch (java.awt.AWTException e) {
            }
        } 
        bufferCaps = new java.awt.BufferCapabilities(new java.awt.ImageCapabilities(true) , new java.awt.ImageCapabilities(true) , null);
        try {
            createBufferStrategy(numBuffers, bufferCaps);
            return ;
        } catch (java.awt.AWTException e) {
        }
        bufferCaps = new java.awt.BufferCapabilities(new java.awt.ImageCapabilities(false) , new java.awt.ImageCapabilities(false) , null);
        try {
            createBufferStrategy(numBuffers, bufferCaps);
            return ;
        } catch (java.awt.AWTException e) {
            throw new java.lang.InternalError("Could not create a buffer strategy" , e);
        }
    }

    void createBufferStrategy(int numBuffers, java.awt.BufferCapabilities caps) throws java.awt.AWTException {
        if (numBuffers < 1) {
            throw new java.lang.IllegalArgumentException("Number of buffers must be at least 1");
        } 
        if (caps == null) {
            throw new java.lang.IllegalArgumentException("No capabilities specified");
        } 
        if ((bufferStrategy) != null) {
            bufferStrategy.dispose();
        } 
        if (numBuffers == 1) {
            bufferStrategy = new java.awt.Component.SingleBufferStrategy(caps);
        } else {
            sun.java2d.SunGraphicsEnvironment sge = ((sun.java2d.SunGraphicsEnvironment)(java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment()));
            if ((!(caps.isPageFlipping())) && (sge.isFlipStrategyPreferred(peer))) {
                caps = new java.awt.Component.ProxyCapabilities(caps);
            } 
            if (caps.isPageFlipping()) {
                bufferStrategy = new java.awt.Component.FlipSubRegionBufferStrategy(numBuffers , caps);
            } else {
                bufferStrategy = new java.awt.Component.BltSubRegionBufferStrategy(numBuffers , caps);
            }
        }
    }

    private class ProxyCapabilities extends sun.java2d.pipe.hw.ExtendedBufferCapabilities {
        private java.awt.BufferCapabilities orig;

        private ProxyCapabilities(java.awt.BufferCapabilities orig) {
            super(orig.getFrontBufferCapabilities(), orig.getBackBufferCapabilities(), ((orig.getFlipContents()) == (java.awt.BufferCapabilities.FlipContents.BACKGROUND) ? java.awt.BufferCapabilities.FlipContents.BACKGROUND : java.awt.BufferCapabilities.FlipContents.COPIED));
            java.awt.Component.ProxyCapabilities.this.orig = orig;
        }
    }

    java.awt.image.BufferStrategy getBufferStrategy() {
        return bufferStrategy;
    }

    java.awt.Image getBackBuffer() {
        if ((bufferStrategy) != null) {
            if ((bufferStrategy) instanceof java.awt.Component.BltBufferStrategy) {
                java.awt.Component.BltBufferStrategy bltBS = ((java.awt.Component.BltBufferStrategy)(bufferStrategy));
                return bltBS.getBackBuffer();
            } else if ((bufferStrategy) instanceof java.awt.Component.FlipBufferStrategy) {
                java.awt.Component.FlipBufferStrategy flipBS = ((java.awt.Component.FlipBufferStrategy)(bufferStrategy));
                return flipBS.getBackBuffer();
            } 
        } 
        return null;
    }

    protected class FlipBufferStrategy extends java.awt.image.BufferStrategy {
        protected int numBuffers;

        protected java.awt.BufferCapabilities caps;

        protected java.awt.Image drawBuffer;

        protected java.awt.image.VolatileImage drawVBuffer;

        protected boolean validatedContents;

        int width;

        int height;

        protected FlipBufferStrategy(int numBuffers ,java.awt.BufferCapabilities caps) throws java.awt.AWTException {
            if ((!((java.awt.Component.this) instanceof java.awt.Window)) && (!((java.awt.Component.this) instanceof java.awt.Canvas))) {
                throw new java.lang.ClassCastException("Component must be a Canvas or Window");
            } 
            java.awt.Component.FlipBufferStrategy.this.numBuffers = numBuffers;
            java.awt.Component.FlipBufferStrategy.this.caps = caps;
            createBuffers(numBuffers, caps);
        }

        protected void createBuffers(int numBuffers, java.awt.BufferCapabilities caps) throws java.awt.AWTException {
            if (numBuffers < 2) {
                throw new java.lang.IllegalArgumentException("Number of buffers cannot be less than two");
            } else if ((peer) == null) {
                throw new java.lang.IllegalStateException("Component must have a valid peer");
            } else if ((caps == null) || (!(caps.isPageFlipping()))) {
                throw new java.lang.IllegalArgumentException("Page flipping capabilities must be specified");
            } 
            width = getWidth();
            height = getHeight();
            if ((drawBuffer) != null) {
                drawBuffer = null;
                drawVBuffer = null;
                destroyBuffers();
            } 
            if (caps instanceof sun.java2d.pipe.hw.ExtendedBufferCapabilities) {
                sun.java2d.pipe.hw.ExtendedBufferCapabilities ebc = ((sun.java2d.pipe.hw.ExtendedBufferCapabilities)(caps));
                if ((ebc.getVSync()) == (sun.java2d.pipe.hw.ExtendedBufferCapabilities.VSyncType.VSYNC_ON)) {
                    if (!(sun.awt.image.VSyncedBSManager.vsyncAllowed(java.awt.Component.FlipBufferStrategy.this))) {
                        caps = ebc.derive(sun.java2d.pipe.hw.ExtendedBufferCapabilities.VSyncType.VSYNC_DEFAULT);
                    } 
                } 
            } 
            peer.createBuffers(numBuffers, caps);
            updateInternalBuffers();
        }

        private void updateInternalBuffers() {
            drawBuffer = getBackBuffer();
            if ((drawBuffer) instanceof java.awt.image.VolatileImage) {
                drawVBuffer = ((java.awt.image.VolatileImage)(drawBuffer));
            } else {
                drawVBuffer = null;
            }
        }

        protected java.awt.Image getBackBuffer() {
            if ((peer) != null) {
                return peer.getBackBuffer();
            } else {
                throw new java.lang.IllegalStateException("Component must have a valid peer");
            }
        }

        protected void flip(java.awt.BufferCapabilities.FlipContents flipAction) {
            if ((peer) != null) {
                java.awt.Image backBuffer = getBackBuffer();
                if (backBuffer != null) {
                    peer.flip(0, 0, backBuffer.getWidth(null), backBuffer.getHeight(null), flipAction);
                } 
            } else {
                throw new java.lang.IllegalStateException("Component must have a valid peer");
            }
        }

        void flipSubRegion(int x1, int y1, int x2, int y2, java.awt.BufferCapabilities.FlipContents flipAction) {
            if ((peer) != null) {
                peer.flip(x1, y1, x2, y2, flipAction);
            } else {
                throw new java.lang.IllegalStateException("Component must have a valid peer");
            }
        }

        protected void destroyBuffers() {
            sun.awt.image.VSyncedBSManager.releaseVsync(java.awt.Component.FlipBufferStrategy.this);
            if ((peer) != null) {
                peer.destroyBuffers();
            } else {
                throw new java.lang.IllegalStateException("Component must have a valid peer");
            }
        }

        public java.awt.BufferCapabilities getCapabilities() {
            if ((caps) instanceof java.awt.Component.ProxyCapabilities) {
                return ((java.awt.Component.ProxyCapabilities)(caps)).orig;
            } else {
                return caps;
            }
        }

        public java.awt.Graphics getDrawGraphics() {
            revalidate();
            return drawBuffer.getGraphics();
        }

        protected void revalidate() {
            revalidate(true);
        }

        void revalidate(boolean checkSize) {
            validatedContents = false;
            if (checkSize && (((getWidth()) != (width)) || ((getHeight()) != (height)))) {
                try {
                    createBuffers(numBuffers, caps);
                } catch (java.awt.AWTException e) {
                }
                validatedContents = true;
            } 
            updateInternalBuffers();
            if ((drawVBuffer) != null) {
                java.awt.GraphicsConfiguration gc = getGraphicsConfiguration_NoClientCode();
                int returnCode = drawVBuffer.validate(gc);
                if (returnCode == (java.awt.image.VolatileImage.IMAGE_INCOMPATIBLE)) {
                    try {
                        createBuffers(numBuffers, caps);
                    } catch (java.awt.AWTException e) {
                    }
                    if ((drawVBuffer) != null) {
                        drawVBuffer.validate(gc);
                    } 
                    validatedContents = true;
                } else if (returnCode == (java.awt.image.VolatileImage.IMAGE_RESTORED)) {
                    validatedContents = true;
                } 
            } 
        }

        public boolean contentsLost() {
            if ((drawVBuffer) == null) {
                return false;
            } 
            return drawVBuffer.contentsLost();
        }

        public boolean contentsRestored() {
            return validatedContents;
        }

        public void show() {
            flip(caps.getFlipContents());
        }

        void showSubRegion(int x1, int y1, int x2, int y2) {
            flipSubRegion(x1, y1, x2, y2, caps.getFlipContents());
        }

        public void dispose() {
            if ((java.awt.Component.this.bufferStrategy) == (java.awt.Component.FlipBufferStrategy.this)) {
                java.awt.Component.this.bufferStrategy = null;
                if ((peer) != null) {
                    destroyBuffers();
                } 
            } 
        }
    }

    protected class BltBufferStrategy extends java.awt.image.BufferStrategy {
        protected java.awt.BufferCapabilities caps;

        protected java.awt.image.VolatileImage[] backBuffers;

        protected boolean validatedContents;

        protected int width;

        protected int height;

        private java.awt.Insets insets;

        protected BltBufferStrategy(int numBuffers ,java.awt.BufferCapabilities caps) {
            java.awt.Component.BltBufferStrategy.this.caps = caps;
            createBackBuffers((numBuffers - 1));
        }

        public void dispose() {
            if ((backBuffers) != null) {
                for (int counter = (backBuffers.length) - 1 ; counter >= 0 ; counter--) {
                    if ((backBuffers[counter]) != null) {
                        backBuffers[counter].flush();
                        backBuffers[counter] = null;
                    } 
                }
            } 
            if ((java.awt.Component.this.bufferStrategy) == (java.awt.Component.BltBufferStrategy.this)) {
                java.awt.Component.this.bufferStrategy = null;
            } 
        }

        protected void createBackBuffers(int numBuffers) {
            if (numBuffers == 0) {
                backBuffers = null;
            } else {
                width = getWidth();
                height = getHeight();
                insets = getInsets_NoClientCode();
                int iWidth = ((width) - (insets.left)) - (insets.right);
                int iHeight = ((height) - (insets.top)) - (insets.bottom);
                iWidth = java.lang.Math.max(1, iWidth);
                iHeight = java.lang.Math.max(1, iHeight);
                if ((backBuffers) == null) {
                    backBuffers = new java.awt.image.VolatileImage[numBuffers];
                } else {
                    for (int i = 0 ; i < numBuffers ; i++) {
                        if ((backBuffers[i]) != null) {
                            backBuffers[i].flush();
                            backBuffers[i] = null;
                        } 
                    }
                }
                for (int i = 0 ; i < numBuffers ; i++) {
                    backBuffers[i] = createVolatileImage(iWidth, iHeight);
                }
            }
        }

        public java.awt.BufferCapabilities getCapabilities() {
            return caps;
        }

        public java.awt.Graphics getDrawGraphics() {
            revalidate();
            java.awt.Image backBuffer = getBackBuffer();
            if (backBuffer == null) {
                return getGraphics();
            } 
            sun.java2d.SunGraphics2D g = ((sun.java2d.SunGraphics2D)(backBuffer.getGraphics()));
            g.constrain((-(insets.left)), (-(insets.top)), ((backBuffer.getWidth(null)) + (insets.left)), ((backBuffer.getHeight(null)) + (insets.top)));
            return g;
        }

        java.awt.Image getBackBuffer() {
            if ((backBuffers) != null) {
                return backBuffers[((backBuffers.length) - 1)];
            } else {
                return null;
            }
        }

        public void show() {
            showSubRegion(insets.left, insets.top, ((width) - (insets.right)), ((height) - (insets.bottom)));
        }

        void showSubRegion(int x1, int y1, int x2, int y2) {
            if ((backBuffers) == null) {
                return ;
            } 
            x1 -= insets.left;
            x2 -= insets.left;
            y1 -= insets.top;
            y2 -= insets.top;
            java.awt.Graphics g = getGraphics_NoClientCode();
            if (g == null) {
                return ;
            } 
            try {
                g.translate(insets.left, insets.top);
                for (int i = 0 ; i < (backBuffers.length) ; i++) {
                    g.drawImage(backBuffers[i], x1, y1, x2, y2, x1, y1, x2, y2, null);
                    g.dispose();
                    g = null;
                    g = backBuffers[i].getGraphics();
                }
            } finally {
                if (g != null) {
                    g.dispose();
                } 
            }
        }

        protected void revalidate() {
            revalidate(true);
        }

        void revalidate(boolean checkSize) {
            validatedContents = false;
            if ((backBuffers) == null) {
                return ;
            } 
            if (checkSize) {
                java.awt.Insets insets = getInsets_NoClientCode();
                if ((((getWidth()) != (width)) || ((getHeight()) != (height))) || (!(insets.equals(java.awt.Component.BltBufferStrategy.this.insets)))) {
                    createBackBuffers(backBuffers.length);
                    validatedContents = true;
                } 
            } 
            java.awt.GraphicsConfiguration gc = getGraphicsConfiguration_NoClientCode();
            int returnCode = backBuffers[((backBuffers.length) - 1)].validate(gc);
            if (returnCode == (java.awt.image.VolatileImage.IMAGE_INCOMPATIBLE)) {
                if (checkSize) {
                    createBackBuffers(backBuffers.length);
                    backBuffers[((backBuffers.length) - 1)].validate(gc);
                } 
                validatedContents = true;
            } else if (returnCode == (java.awt.image.VolatileImage.IMAGE_RESTORED)) {
                validatedContents = true;
            } 
        }

        public boolean contentsLost() {
            if ((backBuffers) == null) {
                return false;
            } else {
                return backBuffers[((backBuffers.length) - 1)].contentsLost();
            }
        }

        public boolean contentsRestored() {
            return validatedContents;
        }
    }

    private class FlipSubRegionBufferStrategy extends java.awt.Component.FlipBufferStrategy implements sun.awt.SubRegionShowable {
        protected FlipSubRegionBufferStrategy(int numBuffers ,java.awt.BufferCapabilities caps) throws java.awt.AWTException {
            super(numBuffers, caps);
        }

        public void show(int x1, int y1, int x2, int y2) {
            showSubRegion(x1, y1, x2, y2);
        }

        public boolean showIfNotLost(int x1, int y1, int x2, int y2) {
            if (!(contentsLost())) {
                showSubRegion(x1, y1, x2, y2);
                return !(contentsLost());
            } 
            return false;
        }
    }

    private class BltSubRegionBufferStrategy extends java.awt.Component.BltBufferStrategy implements sun.awt.SubRegionShowable {
        protected BltSubRegionBufferStrategy(int numBuffers ,java.awt.BufferCapabilities caps) {
            super(numBuffers, caps);
        }

        public void show(int x1, int y1, int x2, int y2) {
            showSubRegion(x1, y1, x2, y2);
        }

        public boolean showIfNotLost(int x1, int y1, int x2, int y2) {
            if (!(contentsLost())) {
                showSubRegion(x1, y1, x2, y2);
                return !(contentsLost());
            } 
            return false;
        }
    }

    private class SingleBufferStrategy extends java.awt.image.BufferStrategy {
        private java.awt.BufferCapabilities caps;

        public SingleBufferStrategy(java.awt.BufferCapabilities caps) {
            java.awt.Component.SingleBufferStrategy.this.caps = caps;
        }

        public java.awt.BufferCapabilities getCapabilities() {
            return caps;
        }

        public java.awt.Graphics getDrawGraphics() {
            return getGraphics();
        }

        public boolean contentsLost() {
            return false;
        }

        public boolean contentsRestored() {
            return false;
        }

        public void show() {
        }
    }

    public void setIgnoreRepaint(boolean ignoreRepaint) {
        java.awt.Component.this.ignoreRepaint = ignoreRepaint;
    }

    public boolean getIgnoreRepaint() {
        return ignoreRepaint;
    }

    public boolean contains(int x, int y) {
        return inside(x, y);
    }

    @java.lang.Deprecated
    public boolean inside(int x, int y) {
        return (((x >= 0) && (x < (width))) && (y >= 0)) && (y < (height));
    }

    public boolean contains(java.awt.Point p) {
        return contains(p.x, p.y);
    }

    public java.awt.Component getComponentAt(int x, int y) {
        return locate(x, y);
    }

    @java.lang.Deprecated
    public java.awt.Component locate(int x, int y) {
        return contains(x, y) ? java.awt.Component.this : null;
    }

    public java.awt.Component getComponentAt(java.awt.Point p) {
        return getComponentAt(p.x, p.y);
    }

    @java.lang.Deprecated
    public void deliverEvent(java.awt.Event e) {
        postEvent(e);
    }

    public final void dispatchEvent(java.awt.AWTEvent e) {
        dispatchEventImpl(e);
    }

    @java.lang.SuppressWarnings(value = "deprecation")
    void dispatchEventImpl(java.awt.AWTEvent e) {
        int id = e.getID();
        sun.awt.AppContext compContext = appContext;
        if ((compContext != null) && (!(compContext.equals(sun.awt.AppContext.getAppContext())))) {
            if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.eventLog.fine((("Event " + e) + " is being dispatched on the wrong AppContext"));
            } 
        } 
        if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.Component.eventLog.finest("{0}", e);
        } 
        if (!(e instanceof java.awt.event.KeyEvent)) {
            java.awt.EventQueue.setCurrentEventAndMostRecentTime(e);
        } 
        if (e instanceof sun.awt.dnd.SunDropTargetEvent) {
            ((sun.awt.dnd.SunDropTargetEvent)(e)).dispatch();
            return ;
        } 
        if (!(e.focusManagerIsDispatching)) {
            if (e.isPosted) {
                e = java.awt.KeyboardFocusManager.retargetFocusEvent(e);
                e.isPosted = true;
            } 
            if (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().dispatchEvent(e)) {
                return ;
            } 
        } 
        if ((e instanceof java.awt.event.FocusEvent) && (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST))) {
            java.awt.Component.focusLog.finest(("" + e));
        } 
        if ((((id == (java.awt.event.MouseEvent.MOUSE_WHEEL)) && (!(eventTypeEnabled(id)))) && (((peer) != null) && (!(peer.handlesWheelScrolling())))) && (dispatchMouseWheelToAncestor(((java.awt.event.MouseWheelEvent)(e))))) {
            return ;
        } 
        java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        toolkit.notifyAWTEventListeners(e);
        if (!(e.isConsumed())) {
            if (e instanceof java.awt.event.KeyEvent) {
                java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().processKeyEvent(java.awt.Component.this, ((java.awt.event.KeyEvent)(e)));
                if (e.isConsumed()) {
                    return ;
                } 
            } 
        } 
        if (areInputMethodsEnabled()) {
            if ((((e instanceof java.awt.event.InputMethodEvent) && (!((java.awt.Component.this) instanceof sun.awt.im.CompositionArea))) || (e instanceof java.awt.event.InputEvent)) || (e instanceof java.awt.event.FocusEvent)) {
                java.awt.im.InputContext inputContext = getInputContext();
                if (inputContext != null) {
                    inputContext.dispatchEvent(e);
                    if (e.isConsumed()) {
                        if ((e instanceof java.awt.event.FocusEvent) && (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST))) {
                            java.awt.Component.focusLog.finest(("3579: Skipping " + e));
                        } 
                        return ;
                    } 
                } 
            } 
        } else {
            if (id == (java.awt.event.FocusEvent.FOCUS_GAINED)) {
                java.awt.im.InputContext inputContext = getInputContext();
                if ((inputContext != null) && (inputContext instanceof sun.awt.im.InputContext)) {
                    ((sun.awt.im.InputContext)(inputContext)).disableNativeIM();
                } 
            } 
        }
        switch (id) {
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
                java.awt.Container p = ((java.awt.Container)((java.awt.Component.this) instanceof java.awt.Container ? java.awt.Component.this : parent));
                if (p != null) {
                    p.preProcessKeyEvent(((java.awt.event.KeyEvent)(e)));
                    if (e.isConsumed()) {
                        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                            java.awt.Component.focusLog.finest("Pre-process consumed event");
                        } 
                        return ;
                    } 
                } 
                break;
            case java.awt.event.WindowEvent.WINDOW_CLOSING :
                if (toolkit instanceof sun.awt.WindowClosingListener) {
                    windowClosingException = ((sun.awt.WindowClosingListener)(toolkit)).windowClosingNotify(((java.awt.event.WindowEvent)(e)));
                    if (checkWindowClosingException()) {
                        return ;
                    } 
                } 
                break;
            default :
                break;
        }
        if (newEventsOnly) {
            if (eventEnabled(e)) {
                processEvent(e);
            } 
        } else if (id == (java.awt.event.MouseEvent.MOUSE_WHEEL)) {
            autoProcessMouseWheel(((java.awt.event.MouseWheelEvent)(e)));
        } else if (!((e instanceof java.awt.event.MouseEvent) && (!(postsOldMouseEvents())))) {
            java.awt.Event olde = e.convertToOld();
            if (olde != null) {
                int key = olde.key;
                int modifiers = olde.modifiers;
                postEvent(olde);
                if (olde.isConsumed()) {
                    e.consume();
                } 
                switch (olde.id) {
                    case java.awt.Event.KEY_PRESS :
                    case java.awt.Event.KEY_RELEASE :
                    case java.awt.Event.KEY_ACTION :
                    case java.awt.Event.KEY_ACTION_RELEASE :
                        if ((olde.key) != key) {
                            ((java.awt.event.KeyEvent)(e)).setKeyChar(olde.getKeyEventChar());
                        } 
                        if ((olde.modifiers) != modifiers) {
                            ((java.awt.event.KeyEvent)(e)).setModifiers(olde.modifiers);
                        } 
                        break;
                    default :
                        break;
                }
            } 
        } 
        if ((id == (java.awt.event.WindowEvent.WINDOW_CLOSING)) && (!(e.isConsumed()))) {
            if (toolkit instanceof sun.awt.WindowClosingListener) {
                windowClosingException = ((sun.awt.WindowClosingListener)(toolkit)).windowClosingDelivered(((java.awt.event.WindowEvent)(e)));
                if (checkWindowClosingException()) {
                    return ;
                } 
            } 
        } 
        if (!(e instanceof java.awt.event.KeyEvent)) {
            java.awt.peer.ComponentPeer tpeer = peer;
            if ((e instanceof java.awt.event.FocusEvent) && ((tpeer == null) || (tpeer instanceof java.awt.peer.LightweightPeer))) {
                java.awt.Component source = ((java.awt.Component)(e.getSource()));
                if (source != null) {
                    java.awt.Container target = source.getNativeContainer();
                    if (target != null) {
                        tpeer = target.getPeer();
                    } 
                } 
            } 
            if (tpeer != null) {
                tpeer.handleEvent(e);
            } 
        } 
    }

    void autoProcessMouseWheel(java.awt.event.MouseWheelEvent e) {
    }

    boolean dispatchMouseWheelToAncestor(java.awt.event.MouseWheelEvent e) {
        int newX;
        int newY;
        newX = (e.getX()) + (getX());
        newY = (e.getY()) + (getY());
        java.awt.event.MouseWheelEvent newMWE;
        if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.Component.eventLog.finest("dispatchMouseWheelToAncestor");
            java.awt.Component.eventLog.finest(("orig event src is of " + (e.getSource().getClass())));
        } 
        synchronized(getTreeLock()) {
            java.awt.Container anc = getParent();
            while ((anc != null) && (!(anc.eventEnabled(e)))) {
                newX += anc.getX();
                newY += anc.getY();
                if (!(anc instanceof java.awt.Window)) {
                    anc = anc.getParent();
                } else {
                    break;
                }
            }
            if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.eventLog.finest(("new event src is " + (anc.getClass())));
            } 
            if ((anc != null) && (anc.eventEnabled(e))) {
                newMWE = new java.awt.event.MouseWheelEvent(anc , e.getID() , e.getWhen() , e.getModifiers() , newX , newY , e.getXOnScreen() , e.getYOnScreen() , e.getClickCount() , e.isPopupTrigger() , e.getScrollType() , e.getScrollAmount() , e.getWheelRotation() , e.getPreciseWheelRotation());
                ((java.awt.AWTEvent)(e)).copyPrivateDataInto(newMWE);
                anc.dispatchEventToSelf(newMWE);
                if (newMWE.isConsumed()) {
                    e.consume();
                } 
                return true;
            } 
        }
        return false;
    }

    boolean checkWindowClosingException() {
        if ((windowClosingException) != null) {
            if ((java.awt.Component.this) instanceof java.awt.Dialog) {
                ((java.awt.Dialog)(java.awt.Component.this)).interruptBlocking();
            } else {
                windowClosingException.fillInStackTrace();
                windowClosingException.printStackTrace();
                windowClosingException = null;
            }
            return true;
        } 
        return false;
    }

    boolean areInputMethodsEnabled() {
        return (((eventMask) & (java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK)) != 0) && ((((eventMask) & (java.awt.AWTEvent.KEY_EVENT_MASK)) != 0) || ((keyListener) != null));
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        return eventTypeEnabled(e.id);
    }

    boolean eventTypeEnabled(int type) {
        switch (type) {
            case java.awt.event.ComponentEvent.COMPONENT_MOVED :
            case java.awt.event.ComponentEvent.COMPONENT_RESIZED :
            case java.awt.event.ComponentEvent.COMPONENT_SHOWN :
            case java.awt.event.ComponentEvent.COMPONENT_HIDDEN :
                if ((((eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0) || ((componentListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.FocusEvent.FOCUS_GAINED :
            case java.awt.event.FocusEvent.FOCUS_LOST :
                if ((((eventMask) & (java.awt.AWTEvent.FOCUS_EVENT_MASK)) != 0) || ((focusListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
            case java.awt.event.KeyEvent.KEY_TYPED :
                if ((((eventMask) & (java.awt.AWTEvent.KEY_EVENT_MASK)) != 0) || ((keyListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.MouseEvent.MOUSE_PRESSED :
            case java.awt.event.MouseEvent.MOUSE_RELEASED :
            case java.awt.event.MouseEvent.MOUSE_ENTERED :
            case java.awt.event.MouseEvent.MOUSE_EXITED :
            case java.awt.event.MouseEvent.MOUSE_CLICKED :
                if ((((eventMask) & (java.awt.AWTEvent.MOUSE_EVENT_MASK)) != 0) || ((mouseListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.MouseEvent.MOUSE_MOVED :
            case java.awt.event.MouseEvent.MOUSE_DRAGGED :
                if ((((eventMask) & (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) != 0) || ((mouseMotionListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.MouseEvent.MOUSE_WHEEL :
                if ((((eventMask) & (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK)) != 0) || ((mouseWheelListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.InputMethodEvent.INPUT_METHOD_TEXT_CHANGED :
            case java.awt.event.InputMethodEvent.CARET_POSITION_CHANGED :
                if ((((eventMask) & (java.awt.AWTEvent.INPUT_METHOD_EVENT_MASK)) != 0) || ((inputMethodListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.HierarchyEvent.HIERARCHY_CHANGED :
                if ((((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0) || ((hierarchyListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.HierarchyEvent.ANCESTOR_MOVED :
            case java.awt.event.HierarchyEvent.ANCESTOR_RESIZED :
                if ((((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0) || ((hierarchyBoundsListener) != null)) {
                    return true;
                } 
                break;
            case java.awt.event.ActionEvent.ACTION_PERFORMED :
                if (((eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) {
                    return true;
                } 
                break;
            case java.awt.event.TextEvent.TEXT_VALUE_CHANGED :
                if (((eventMask) & (java.awt.AWTEvent.TEXT_EVENT_MASK)) != 0) {
                    return true;
                } 
                break;
            case java.awt.event.ItemEvent.ITEM_STATE_CHANGED :
                if (((eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) {
                    return true;
                } 
                break;
            case java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED :
                if (((eventMask) & (java.awt.AWTEvent.ADJUSTMENT_EVENT_MASK)) != 0) {
                    return true;
                } 
                break;
            default :
                break;
        }
        if (type > (java.awt.AWTEvent.RESERVED_ID_MAX)) {
            return true;
        } 
        return false;
    }

    @java.lang.Deprecated
    public boolean postEvent(java.awt.Event e) {
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (handleEvent(e)) {
            e.consume();
            return true;
        } 
        java.awt.Component parent = java.awt.Component.this.parent;
        int eventx = e.x;
        int eventy = e.y;
        if (parent != null) {
            e.translate(x, y);
            if (parent.postEvent(e)) {
                e.consume();
                return true;
            } 
            e.x = eventx;
            e.y = eventy;
        } 
        return false;
    }

    public synchronized void addComponentListener(java.awt.event.ComponentListener l) {
        if (l == null) {
            return ;
        } 
        componentListener = java.awt.AWTEventMulticaster.add(componentListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeComponentListener(java.awt.event.ComponentListener l) {
        if (l == null) {
            return ;
        } 
        componentListener = java.awt.AWTEventMulticaster.remove(componentListener, l);
    }

    public synchronized java.awt.event.ComponentListener[] getComponentListeners() {
        return getListeners(java.awt.event.ComponentListener.class);
    }

    public synchronized void addFocusListener(java.awt.event.FocusListener l) {
        if (l == null) {
            return ;
        } 
        focusListener = java.awt.AWTEventMulticaster.add(focusListener, l);
        newEventsOnly = true;
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(java.awt.AWTEvent.FOCUS_EVENT_MASK);
        } 
    }

    public synchronized void removeFocusListener(java.awt.event.FocusListener l) {
        if (l == null) {
            return ;
        } 
        focusListener = java.awt.AWTEventMulticaster.remove(focusListener, l);
    }

    public synchronized java.awt.event.FocusListener[] getFocusListeners() {
        return getListeners(java.awt.event.FocusListener.class);
    }

    public void addHierarchyListener(java.awt.event.HierarchyListener l) {
        if (l == null) {
            return ;
        } 
        boolean notifyAncestors;
        synchronized(java.awt.Component.this) {
            notifyAncestors = ((hierarchyListener) == null) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) == 0);
            hierarchyListener = java.awt.AWTEventMulticaster.add(hierarchyListener, l);
            notifyAncestors = notifyAncestors && ((hierarchyListener) != null);
            newEventsOnly = true;
        }
        if (notifyAncestors) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, 1);
            }
        } 
    }

    public void removeHierarchyListener(java.awt.event.HierarchyListener l) {
        if (l == null) {
            return ;
        } 
        boolean notifyAncestors;
        synchronized(java.awt.Component.this) {
            notifyAncestors = ((hierarchyListener) != null) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) == 0);
            hierarchyListener = java.awt.AWTEventMulticaster.remove(hierarchyListener, l);
            notifyAncestors = notifyAncestors && ((hierarchyListener) == null);
        }
        if (notifyAncestors) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(java.awt.AWTEvent.HIERARCHY_EVENT_MASK, (-1));
            }
        } 
    }

    public synchronized java.awt.event.HierarchyListener[] getHierarchyListeners() {
        return getListeners(java.awt.event.HierarchyListener.class);
    }

    public void addHierarchyBoundsListener(java.awt.event.HierarchyBoundsListener l) {
        if (l == null) {
            return ;
        } 
        boolean notifyAncestors;
        synchronized(java.awt.Component.this) {
            notifyAncestors = ((hierarchyBoundsListener) == null) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) == 0);
            hierarchyBoundsListener = java.awt.AWTEventMulticaster.add(hierarchyBoundsListener, l);
            notifyAncestors = notifyAncestors && ((hierarchyBoundsListener) != null);
            newEventsOnly = true;
        }
        if (notifyAncestors) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, 1);
            }
        } 
    }

    public void removeHierarchyBoundsListener(java.awt.event.HierarchyBoundsListener l) {
        if (l == null) {
            return ;
        } 
        boolean notifyAncestors;
        synchronized(java.awt.Component.this) {
            notifyAncestors = ((hierarchyBoundsListener) != null) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) == 0);
            hierarchyBoundsListener = java.awt.AWTEventMulticaster.remove(hierarchyBoundsListener, l);
            notifyAncestors = notifyAncestors && ((hierarchyBoundsListener) == null);
        }
        if (notifyAncestors) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK, (-1));
            }
        } 
    }

    int numListening(long mask) {
        if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            if ((mask != (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) && (mask != (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK))) {
                java.awt.Component.eventLog.fine("Assertion failed");
            } 
        } 
        if (((mask == (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) && (((hierarchyListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0))) || ((mask == (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) && (((hierarchyBoundsListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0)))) {
            return 1;
        } else {
            return 0;
        }
    }

    int countHierarchyMembers() {
        return 1;
    }

    int createHierarchyEvents(int id, java.awt.Component changed, java.awt.Container changedParent, long changeFlags, boolean enabledOnToolkit) {
        switch (id) {
            case java.awt.event.HierarchyEvent.HIERARCHY_CHANGED :
                if ((((hierarchyListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0)) || enabledOnToolkit) {
                    java.awt.event.HierarchyEvent e = new java.awt.event.HierarchyEvent(java.awt.Component.this , id , changed , changedParent , changeFlags);
                    dispatchEvent(e);
                    return 1;
                } 
                break;
            case java.awt.event.HierarchyEvent.ANCESTOR_MOVED :
            case java.awt.event.HierarchyEvent.ANCESTOR_RESIZED :
                if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    if (changeFlags != 0) {
                        java.awt.Component.eventLog.fine("Assertion (changeFlags == 0) failed");
                    } 
                } 
                if ((((hierarchyBoundsListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0)) || enabledOnToolkit) {
                    java.awt.event.HierarchyEvent e = new java.awt.event.HierarchyEvent(java.awt.Component.this , id , changed , changedParent);
                    dispatchEvent(e);
                    return 1;
                } 
                break;
            default :
                if (java.awt.Component.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.Component.eventLog.fine("This code must never be reached");
                } 
                break;
        }
        return 0;
    }

    public synchronized java.awt.event.HierarchyBoundsListener[] getHierarchyBoundsListeners() {
        return getListeners(java.awt.event.HierarchyBoundsListener.class);
    }

    void adjustListeningChildrenOnParent(long mask, int num) {
        if ((parent) != null) {
            parent.adjustListeningChildren(mask, num);
        } 
    }

    public synchronized void addKeyListener(java.awt.event.KeyListener l) {
        if (l == null) {
            return ;
        } 
        keyListener = java.awt.AWTEventMulticaster.add(keyListener, l);
        newEventsOnly = true;
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(java.awt.AWTEvent.KEY_EVENT_MASK);
        } 
    }

    public synchronized void removeKeyListener(java.awt.event.KeyListener l) {
        if (l == null) {
            return ;
        } 
        keyListener = java.awt.AWTEventMulticaster.remove(keyListener, l);
    }

    public synchronized java.awt.event.KeyListener[] getKeyListeners() {
        return getListeners(java.awt.event.KeyListener.class);
    }

    public synchronized void addMouseListener(java.awt.event.MouseListener l) {
        if (l == null) {
            return ;
        } 
        mouseListener = java.awt.AWTEventMulticaster.add(mouseListener, l);
        newEventsOnly = true;
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(java.awt.AWTEvent.MOUSE_EVENT_MASK);
        } 
    }

    public synchronized void removeMouseListener(java.awt.event.MouseListener l) {
        if (l == null) {
            return ;
        } 
        mouseListener = java.awt.AWTEventMulticaster.remove(mouseListener, l);
    }

    public synchronized java.awt.event.MouseListener[] getMouseListeners() {
        return getListeners(java.awt.event.MouseListener.class);
    }

    public synchronized void addMouseMotionListener(java.awt.event.MouseMotionListener l) {
        if (l == null) {
            return ;
        } 
        mouseMotionListener = java.awt.AWTEventMulticaster.add(mouseMotionListener, l);
        newEventsOnly = true;
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK);
        } 
    }

    public synchronized void removeMouseMotionListener(java.awt.event.MouseMotionListener l) {
        if (l == null) {
            return ;
        } 
        mouseMotionListener = java.awt.AWTEventMulticaster.remove(mouseMotionListener, l);
    }

    public synchronized java.awt.event.MouseMotionListener[] getMouseMotionListeners() {
        return getListeners(java.awt.event.MouseMotionListener.class);
    }

    public synchronized void addMouseWheelListener(java.awt.event.MouseWheelListener l) {
        if (l == null) {
            return ;
        } 
        mouseWheelListener = java.awt.AWTEventMulticaster.add(mouseWheelListener, l);
        newEventsOnly = true;
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK);
        } 
    }

    public synchronized void removeMouseWheelListener(java.awt.event.MouseWheelListener l) {
        if (l == null) {
            return ;
        } 
        mouseWheelListener = java.awt.AWTEventMulticaster.remove(mouseWheelListener, l);
    }

    public synchronized java.awt.event.MouseWheelListener[] getMouseWheelListeners() {
        return getListeners(java.awt.event.MouseWheelListener.class);
    }

    public synchronized void addInputMethodListener(java.awt.event.InputMethodListener l) {
        if (l == null) {
            return ;
        } 
        inputMethodListener = java.awt.AWTEventMulticaster.add(inputMethodListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeInputMethodListener(java.awt.event.InputMethodListener l) {
        if (l == null) {
            return ;
        } 
        inputMethodListener = java.awt.AWTEventMulticaster.remove(inputMethodListener, l);
    }

    public synchronized java.awt.event.InputMethodListener[] getInputMethodListeners() {
        return getListeners(java.awt.event.InputMethodListener.class);
    }

    @java.lang.SuppressWarnings(value = "unchecked")
    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ComponentListener.class)) {
            l = componentListener;
        } else if (listenerType == (java.awt.event.FocusListener.class)) {
            l = focusListener;
        } else if (listenerType == (java.awt.event.HierarchyListener.class)) {
            l = hierarchyListener;
        } else if (listenerType == (java.awt.event.HierarchyBoundsListener.class)) {
            l = hierarchyBoundsListener;
        } else if (listenerType == (java.awt.event.KeyListener.class)) {
            l = keyListener;
        } else if (listenerType == (java.awt.event.MouseListener.class)) {
            l = mouseListener;
        } else if (listenerType == (java.awt.event.MouseMotionListener.class)) {
            l = mouseMotionListener;
        } else if (listenerType == (java.awt.event.MouseWheelListener.class)) {
            l = mouseWheelListener;
        } else if (listenerType == (java.awt.event.InputMethodListener.class)) {
            l = inputMethodListener;
        } else if (listenerType == (java.beans.PropertyChangeListener.class)) {
            return ((T[])(getPropertyChangeListeners()));
        } 
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    public java.awt.im.InputMethodRequests getInputMethodRequests() {
        return null;
    }

    public java.awt.im.InputContext getInputContext() {
        java.awt.Container parent = java.awt.Component.this.parent;
        if (parent == null) {
            return null;
        } else {
            return parent.getInputContext();
        }
    }

    protected final void enableEvents(long eventsToEnable) {
        long notifyAncestors = 0;
        synchronized(java.awt.Component.this) {
            if ((((eventsToEnable & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0) && ((hierarchyListener) == null)) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) == 0)) {
                notifyAncestors |= java.awt.AWTEvent.HIERARCHY_EVENT_MASK;
            } 
            if ((((eventsToEnable & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0) && ((hierarchyBoundsListener) == null)) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) == 0)) {
                notifyAncestors |= java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK;
            } 
            eventMask |= eventsToEnable;
            newEventsOnly = true;
        }
        if ((peer) instanceof java.awt.peer.LightweightPeer) {
            parent.proxyEnableEvents(eventMask);
        } 
        if (notifyAncestors != 0) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(notifyAncestors, 1);
            }
        } 
    }

    protected final void disableEvents(long eventsToDisable) {
        long notifyAncestors = 0;
        synchronized(java.awt.Component.this) {
            if ((((eventsToDisable & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0) && ((hierarchyListener) == null)) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0)) {
                notifyAncestors |= java.awt.AWTEvent.HIERARCHY_EVENT_MASK;
            } 
            if ((((eventsToDisable & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0) && ((hierarchyBoundsListener) == null)) && (((eventMask) & (java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK)) != 0)) {
                notifyAncestors |= java.awt.AWTEvent.HIERARCHY_BOUNDS_EVENT_MASK;
            } 
            eventMask &= ~eventsToDisable;
        }
        if (notifyAncestors != 0) {
            synchronized(getTreeLock()) {
                adjustListeningChildrenOnParent(notifyAncestors, (-1));
            }
        } 
    }

    private transient boolean coalescingEnabled = checkCoalescing();

    private static final java.util.Map<java.lang.Class<?>, java.lang.Boolean> coalesceMap = new java.util.WeakHashMap<java.lang.Class<?>, java.lang.Boolean>();

    private boolean checkCoalescing() {
        if ((getClass().getClassLoader()) == null) {
            return false;
        } 
        final java.lang.Class<? extends java.awt.Component> clazz = getClass();
        synchronized(java.awt.Component.coalesceMap) {
            java.lang.Boolean value = java.awt.Component.coalesceMap.get(clazz);
            if (value != null) {
                return value;
            } 
            java.lang.Boolean enabled = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Boolean>() {
                public java.lang.Boolean run() {
                    return java.awt.Component.isCoalesceEventsOverriden(clazz);
                }
            });
            java.awt.Component.coalesceMap.put(clazz, enabled);
            return enabled;
        }
    }

    private static final java.lang.Class[] coalesceEventsParams = new java.lang.Class[]{ java.awt.AWTEvent.class , java.awt.AWTEvent.class };

    private static boolean isCoalesceEventsOverriden(java.lang.Class<?> clazz) {
        assert java.lang.Thread.holdsLock(java.awt.Component.coalesceMap);
        java.lang.Class<?> superclass = clazz.getSuperclass();
        if (superclass == null) {
            return false;
        } 
        if ((superclass.getClassLoader()) != null) {
            java.lang.Boolean value = java.awt.Component.coalesceMap.get(superclass);
            if (value == null) {
                if (java.awt.Component.isCoalesceEventsOverriden(superclass)) {
                    java.awt.Component.coalesceMap.put(superclass, true);
                    return true;
                } 
            } else if (value) {
                return true;
            } 
        } 
        try {
            clazz.getDeclaredMethod("coalesceEvents", java.awt.Component.coalesceEventsParams);
            return true;
        } catch (java.lang.NoSuchMethodException e) {
            return false;
        }
    }

    final boolean isCoalescingEnabled() {
        return coalescingEnabled;
    }

    protected java.awt.AWTEvent coalesceEvents(java.awt.AWTEvent existingEvent, java.awt.AWTEvent newEvent) {
        return null;
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.FocusEvent) {
            processFocusEvent(((java.awt.event.FocusEvent)(e)));
        } else if (e instanceof java.awt.event.MouseEvent) {
            switch (e.getID()) {
                case java.awt.event.MouseEvent.MOUSE_PRESSED :
                case java.awt.event.MouseEvent.MOUSE_RELEASED :
                case java.awt.event.MouseEvent.MOUSE_CLICKED :
                case java.awt.event.MouseEvent.MOUSE_ENTERED :
                case java.awt.event.MouseEvent.MOUSE_EXITED :
                    processMouseEvent(((java.awt.event.MouseEvent)(e)));
                    break;
                case java.awt.event.MouseEvent.MOUSE_MOVED :
                case java.awt.event.MouseEvent.MOUSE_DRAGGED :
                    processMouseMotionEvent(((java.awt.event.MouseEvent)(e)));
                    break;
                case java.awt.event.MouseEvent.MOUSE_WHEEL :
                    processMouseWheelEvent(((java.awt.event.MouseWheelEvent)(e)));
                    break;
            }
        } else if (e instanceof java.awt.event.KeyEvent) {
            processKeyEvent(((java.awt.event.KeyEvent)(e)));
        } else if (e instanceof java.awt.event.ComponentEvent) {
            processComponentEvent(((java.awt.event.ComponentEvent)(e)));
        } else if (e instanceof java.awt.event.InputMethodEvent) {
            processInputMethodEvent(((java.awt.event.InputMethodEvent)(e)));
        } else if (e instanceof java.awt.event.HierarchyEvent) {
            switch (e.getID()) {
                case java.awt.event.HierarchyEvent.HIERARCHY_CHANGED :
                    processHierarchyEvent(((java.awt.event.HierarchyEvent)(e)));
                    break;
                case java.awt.event.HierarchyEvent.ANCESTOR_MOVED :
                case java.awt.event.HierarchyEvent.ANCESTOR_RESIZED :
                    processHierarchyBoundsEvent(((java.awt.event.HierarchyEvent)(e)));
                    break;
            }
        } 
    }

    protected void processComponentEvent(java.awt.event.ComponentEvent e) {
        java.awt.event.ComponentListener listener = componentListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.ComponentEvent.COMPONENT_RESIZED :
                    listener.componentResized(e);
                    break;
                case java.awt.event.ComponentEvent.COMPONENT_MOVED :
                    listener.componentMoved(e);
                    break;
                case java.awt.event.ComponentEvent.COMPONENT_SHOWN :
                    listener.componentShown(e);
                    break;
                case java.awt.event.ComponentEvent.COMPONENT_HIDDEN :
                    listener.componentHidden(e);
                    break;
            }
        } 
    }

    protected void processFocusEvent(java.awt.event.FocusEvent e) {
        java.awt.event.FocusListener listener = focusListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.FocusEvent.FOCUS_GAINED :
                    listener.focusGained(e);
                    break;
                case java.awt.event.FocusEvent.FOCUS_LOST :
                    listener.focusLost(e);
                    break;
            }
        } 
    }

    protected void processKeyEvent(java.awt.event.KeyEvent e) {
        java.awt.event.KeyListener listener = keyListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.KeyEvent.KEY_TYPED :
                    listener.keyTyped(e);
                    break;
                case java.awt.event.KeyEvent.KEY_PRESSED :
                    listener.keyPressed(e);
                    break;
                case java.awt.event.KeyEvent.KEY_RELEASED :
                    listener.keyReleased(e);
                    break;
            }
        } 
    }

    protected void processMouseEvent(java.awt.event.MouseEvent e) {
        java.awt.event.MouseListener listener = mouseListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.MouseEvent.MOUSE_PRESSED :
                    listener.mousePressed(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_RELEASED :
                    listener.mouseReleased(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_CLICKED :
                    listener.mouseClicked(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_EXITED :
                    listener.mouseExited(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_ENTERED :
                    listener.mouseEntered(e);
                    break;
            }
        } 
    }

    protected void processMouseMotionEvent(java.awt.event.MouseEvent e) {
        java.awt.event.MouseMotionListener listener = mouseMotionListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.MouseEvent.MOUSE_MOVED :
                    listener.mouseMoved(e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_DRAGGED :
                    listener.mouseDragged(e);
                    break;
            }
        } 
    }

    protected void processMouseWheelEvent(java.awt.event.MouseWheelEvent e) {
        java.awt.event.MouseWheelListener listener = mouseWheelListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.MouseEvent.MOUSE_WHEEL :
                    listener.mouseWheelMoved(e);
                    break;
            }
        } 
    }

    boolean postsOldMouseEvents() {
        return false;
    }

    protected void processInputMethodEvent(java.awt.event.InputMethodEvent e) {
        java.awt.event.InputMethodListener listener = inputMethodListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.InputMethodEvent.INPUT_METHOD_TEXT_CHANGED :
                    listener.inputMethodTextChanged(e);
                    break;
                case java.awt.event.InputMethodEvent.CARET_POSITION_CHANGED :
                    listener.caretPositionChanged(e);
                    break;
            }
        } 
    }

    protected void processHierarchyEvent(java.awt.event.HierarchyEvent e) {
        java.awt.event.HierarchyListener listener = hierarchyListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.HierarchyEvent.HIERARCHY_CHANGED :
                    listener.hierarchyChanged(e);
                    break;
            }
        } 
    }

    protected void processHierarchyBoundsEvent(java.awt.event.HierarchyEvent e) {
        java.awt.event.HierarchyBoundsListener listener = hierarchyBoundsListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.HierarchyEvent.ANCESTOR_MOVED :
                    listener.ancestorMoved(e);
                    break;
                case java.awt.event.HierarchyEvent.ANCESTOR_RESIZED :
                    listener.ancestorResized(e);
                    break;
            }
        } 
    }

    @java.lang.Deprecated
    public boolean handleEvent(java.awt.Event evt) {
        switch (evt.id) {
            case java.awt.Event.MOUSE_ENTER :
                return mouseEnter(evt, evt.x, evt.y);
            case java.awt.Event.MOUSE_EXIT :
                return mouseExit(evt, evt.x, evt.y);
            case java.awt.Event.MOUSE_MOVE :
                return mouseMove(evt, evt.x, evt.y);
            case java.awt.Event.MOUSE_DOWN :
                return mouseDown(evt, evt.x, evt.y);
            case java.awt.Event.MOUSE_DRAG :
                return mouseDrag(evt, evt.x, evt.y);
            case java.awt.Event.MOUSE_UP :
                return mouseUp(evt, evt.x, evt.y);
            case java.awt.Event.KEY_PRESS :
            case java.awt.Event.KEY_ACTION :
                return keyDown(evt, evt.key);
            case java.awt.Event.KEY_RELEASE :
            case java.awt.Event.KEY_ACTION_RELEASE :
                return keyUp(evt, evt.key);
            case java.awt.Event.ACTION_EVENT :
                return action(evt, evt.arg);
            case java.awt.Event.GOT_FOCUS :
                return gotFocus(evt, evt.arg);
            case java.awt.Event.LOST_FOCUS :
                return lostFocus(evt, evt.arg);
        }
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseDown(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseDrag(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseUp(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseMove(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseEnter(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean mouseExit(java.awt.Event evt, int x, int y) {
        return false;
    }

    @java.lang.Deprecated
    public boolean keyDown(java.awt.Event evt, int key) {
        return false;
    }

    @java.lang.Deprecated
    public boolean keyUp(java.awt.Event evt, int key) {
        return false;
    }

    @java.lang.Deprecated
    public boolean action(java.awt.Event evt, java.lang.Object what) {
        return false;
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
            if ((peer == null) || (peer instanceof java.awt.peer.LightweightPeer)) {
                if (peer == null) {
                    java.awt.Component.this.peer = peer = getToolkit().createComponent(java.awt.Component.this);
                } 
                if ((parent) != null) {
                    long mask = 0;
                    if (((mouseListener) != null) || (((eventMask) & (java.awt.AWTEvent.MOUSE_EVENT_MASK)) != 0)) {
                        mask |= java.awt.AWTEvent.MOUSE_EVENT_MASK;
                    } 
                    if (((mouseMotionListener) != null) || (((eventMask) & (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) != 0)) {
                        mask |= java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK;
                    } 
                    if (((mouseWheelListener) != null) || (((eventMask) & (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK)) != 0)) {
                        mask |= java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK;
                    } 
                    if (((focusListener) != null) || (((eventMask) & (java.awt.AWTEvent.FOCUS_EVENT_MASK)) != 0)) {
                        mask |= java.awt.AWTEvent.FOCUS_EVENT_MASK;
                    } 
                    if (((keyListener) != null) || (((eventMask) & (java.awt.AWTEvent.KEY_EVENT_MASK)) != 0)) {
                        mask |= java.awt.AWTEvent.KEY_EVENT_MASK;
                    } 
                    if (mask != 0) {
                        parent.proxyEnableEvents(mask);
                    } 
                } 
            } else {
                java.awt.Container parent = getContainer();
                if ((parent != null) && (parent.isLightweight())) {
                    relocateComponent();
                    if (!(parent.isRecursivelyVisibleUpToHeavyweightContainer())) {
                        peer.setVisible(false);
                    } 
                } 
            }
            invalidate();
            int npopups = (popups) != null ? popups.size() : 0;
            for (int i = 0 ; i < npopups ; i++) {
                java.awt.PopupMenu popup = popups.elementAt(i);
                popup.addNotify();
            }
            if ((dropTarget) != null)
                dropTarget.addNotify(peer);
            
            peerFont = getFont();
            if (((getContainer()) != null) && (!(isAddNotifyComplete))) {
                getContainer().increaseComponentCount(java.awt.Component.this);
            } 
            updateZOrder();
            if (!(isAddNotifyComplete)) {
                mixOnShowing();
            } 
            isAddNotifyComplete = true;
            if ((((hierarchyListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK))) {
                java.awt.event.HierarchyEvent e = new java.awt.event.HierarchyEvent(java.awt.Component.this , java.awt.event.HierarchyEvent.HIERARCHY_CHANGED , java.awt.Component.this , parent , ((java.awt.event.HierarchyEvent.DISPLAYABILITY_CHANGED) | (isRecursivelyVisible() ? java.awt.event.HierarchyEvent.SHOWING_CHANGED : 0)));
                dispatchEvent(e);
            } 
        }
    }

    public void removeNotify() {
        java.awt.KeyboardFocusManager.clearMostRecentFocusOwner(java.awt.Component.this);
        if ((java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getPermanentFocusOwner()) == (java.awt.Component.this)) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setGlobalPermanentFocusOwner(null);
        } 
        synchronized(getTreeLock()) {
            if ((isFocusOwner()) && (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabledFor(java.awt.Component.this))) {
                transferFocus(true);
            } 
            if (((getContainer()) != null) && (isAddNotifyComplete)) {
                getContainer().decreaseComponentCount(java.awt.Component.this);
            } 
            int npopups = (popups) != null ? popups.size() : 0;
            for (int i = 0 ; i < npopups ; i++) {
                java.awt.PopupMenu popup = popups.elementAt(i);
                popup.removeNotify();
            }
            if (((eventMask) & (java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK)) != 0) {
                java.awt.im.InputContext inputContext = getInputContext();
                if (inputContext != null) {
                    inputContext.removeNotify(java.awt.Component.this);
                } 
            } 
            java.awt.peer.ComponentPeer p = peer;
            if (p != null) {
                boolean isLightweight = isLightweight();
                if ((bufferStrategy) instanceof java.awt.Component.FlipBufferStrategy) {
                    ((java.awt.Component.FlipBufferStrategy)(bufferStrategy)).destroyBuffers();
                } 
                if ((dropTarget) != null)
                    dropTarget.removeNotify(peer);
                
                if (visible) {
                    p.setVisible(false);
                } 
                peer = null;
                peerFont = null;
                java.awt.Toolkit.getEventQueue().removeSourceEvents(java.awt.Component.this, false);
                java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().discardKeyEvents(java.awt.Component.this);
                p.dispose();
                mixOnHiding(isLightweight);
                isAddNotifyComplete = false;
                java.awt.Component.this.compoundShape = null;
            } 
            if ((((hierarchyListener) != null) || (((eventMask) & (java.awt.AWTEvent.HIERARCHY_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK))) {
                java.awt.event.HierarchyEvent e = new java.awt.event.HierarchyEvent(java.awt.Component.this , java.awt.event.HierarchyEvent.HIERARCHY_CHANGED , java.awt.Component.this , parent , ((java.awt.event.HierarchyEvent.DISPLAYABILITY_CHANGED) | (isRecursivelyVisible() ? java.awt.event.HierarchyEvent.SHOWING_CHANGED : 0)));
                dispatchEvent(e);
            } 
        }
    }

    @java.lang.Deprecated
    public boolean gotFocus(java.awt.Event evt, java.lang.Object what) {
        return false;
    }

    @java.lang.Deprecated
    public boolean lostFocus(java.awt.Event evt, java.lang.Object what) {
        return false;
    }

    @java.lang.Deprecated
    public boolean isFocusTraversable() {
        if ((isFocusTraversableOverridden) == (java.awt.Component.FOCUS_TRAVERSABLE_UNKNOWN)) {
            isFocusTraversableOverridden = java.awt.Component.FOCUS_TRAVERSABLE_DEFAULT;
        } 
        return focusable;
    }

    public boolean isFocusable() {
        return isFocusTraversable();
    }

    public void setFocusable(boolean focusable) {
        boolean oldFocusable;
        synchronized(java.awt.Component.this) {
            oldFocusable = java.awt.Component.this.focusable;
            java.awt.Component.this.focusable = focusable;
        }
        isFocusTraversableOverridden = java.awt.Component.FOCUS_TRAVERSABLE_SET;
        firePropertyChange("focusable", oldFocusable, focusable);
        if (oldFocusable && (!focusable)) {
            if ((isFocusOwner()) && (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled())) {
                transferFocus(true);
            } 
            java.awt.KeyboardFocusManager.clearMostRecentFocusOwner(java.awt.Component.this);
        } 
    }

    final boolean isFocusTraversableOverridden() {
        return (isFocusTraversableOverridden) != (java.awt.Component.FOCUS_TRAVERSABLE_DEFAULT);
    }

    public void setFocusTraversalKeys(int id, java.util.Set<? extends java.awt.AWTKeyStroke> keystrokes) {
        if ((id < 0) || (id >= ((java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH) - 1))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        setFocusTraversalKeys_NoIDCheck(id, keystrokes);
    }

    public java.util.Set<java.awt.AWTKeyStroke> getFocusTraversalKeys(int id) {
        if ((id < 0) || (id >= ((java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH) - 1))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        return getFocusTraversalKeys_NoIDCheck(id);
    }

    final void setFocusTraversalKeys_NoIDCheck(int id, java.util.Set<? extends java.awt.AWTKeyStroke> keystrokes) {
        java.util.Set<java.awt.AWTKeyStroke> oldKeys;
        synchronized(java.awt.Component.this) {
            if ((focusTraversalKeys) == null) {
                initializeFocusTraversalKeys();
            } 
            if (keystrokes != null) {
                for (java.awt.AWTKeyStroke keystroke : keystrokes) {
                    if (keystroke == null) {
                        throw new java.lang.IllegalArgumentException("cannot set null focus traversal key");
                    } 
                    if ((keystroke.getKeyChar()) != (java.awt.event.KeyEvent.CHAR_UNDEFINED)) {
                        throw new java.lang.IllegalArgumentException("focus traversal keys cannot map to KEY_TYPED events");
                    } 
                    for (int i = 0 ; i < (focusTraversalKeys.length) ; i++) {
                        if (i == id) {
                            continue;
                        } 
                        if (getFocusTraversalKeys_NoIDCheck(i).contains(keystroke)) {
                            throw new java.lang.IllegalArgumentException("focus traversal keys must be unique for a Component");
                        } 
                    }
                }
            } 
            oldKeys = focusTraversalKeys[id];
            focusTraversalKeys[id] = keystrokes != null ? java.util.Collections.unmodifiableSet(new java.util.HashSet<java.awt.AWTKeyStroke>(keystrokes)) : null;
        }
        firePropertyChange(java.awt.Component.focusTraversalKeyPropertyNames[id], oldKeys, keystrokes);
    }

    final java.util.Set<java.awt.AWTKeyStroke> getFocusTraversalKeys_NoIDCheck(int id) {
        @java.lang.SuppressWarnings(value = "unchecked")
        java.util.Set<java.awt.AWTKeyStroke> keystrokes = (focusTraversalKeys) != null ? focusTraversalKeys[id] : null;
        if (keystrokes != null) {
            return keystrokes;
        } else {
            java.awt.Container parent = java.awt.Component.this.parent;
            if (parent != null) {
                return parent.getFocusTraversalKeys(id);
            } else {
                return java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getDefaultFocusTraversalKeys(id);
            }
        }
    }

    public boolean areFocusTraversalKeysSet(int id) {
        if ((id < 0) || (id >= ((java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH) - 1))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        return ((focusTraversalKeys) != null) && ((focusTraversalKeys[id]) != null);
    }

    public void setFocusTraversalKeysEnabled(boolean focusTraversalKeysEnabled) {
        boolean oldFocusTraversalKeysEnabled;
        synchronized(java.awt.Component.this) {
            oldFocusTraversalKeysEnabled = java.awt.Component.this.focusTraversalKeysEnabled;
            java.awt.Component.this.focusTraversalKeysEnabled = focusTraversalKeysEnabled;
        }
        firePropertyChange("focusTraversalKeysEnabled", oldFocusTraversalKeysEnabled, focusTraversalKeysEnabled);
    }

    public boolean getFocusTraversalKeysEnabled() {
        return focusTraversalKeysEnabled;
    }

    public void requestFocus() {
        requestFocusHelper(false, true);
    }

    boolean requestFocus(sun.awt.CausedFocusEvent.Cause cause) {
        return requestFocusHelper(false, true, cause);
    }

    protected boolean requestFocus(boolean temporary) {
        return requestFocusHelper(temporary, true);
    }

    boolean requestFocus(boolean temporary, sun.awt.CausedFocusEvent.Cause cause) {
        return requestFocusHelper(temporary, true, cause);
    }

    public boolean requestFocusInWindow() {
        return requestFocusHelper(false, false);
    }

    boolean requestFocusInWindow(sun.awt.CausedFocusEvent.Cause cause) {
        return requestFocusHelper(false, false, cause);
    }

    protected boolean requestFocusInWindow(boolean temporary) {
        return requestFocusHelper(temporary, false);
    }

    boolean requestFocusInWindow(boolean temporary, sun.awt.CausedFocusEvent.Cause cause) {
        return requestFocusHelper(temporary, false, cause);
    }

    final boolean requestFocusHelper(boolean temporary, boolean focusedWindowChangeAllowed) {
        return requestFocusHelper(temporary, focusedWindowChangeAllowed, sun.awt.CausedFocusEvent.Cause.UNKNOWN);
    }

    final boolean requestFocusHelper(boolean temporary, boolean focusedWindowChangeAllowed, sun.awt.CausedFocusEvent.Cause cause) {
        java.awt.AWTEvent currentEvent = java.awt.EventQueue.getCurrentEvent();
        if (currentEvent instanceof java.awt.event.MouseEvent) {
            java.awt.Component source = ((java.awt.event.MouseEvent)(currentEvent)).getComponent();
            if ((source == null) || ((source.getContainingWindow()) == (getContainingWindow()))) {
                java.awt.Component.focusLog.finest("requesting focus by mouse event \"in window\"");
                focusedWindowChangeAllowed = false;
            } 
        } 
        if (!(isRequestFocusAccepted(temporary, focusedWindowChangeAllowed, cause))) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("requestFocus is not accepted");
            } 
            return false;
        } 
        java.awt.KeyboardFocusManager.setMostRecentFocusOwner(java.awt.Component.this);
        java.awt.Component window = java.awt.Component.this;
        while ((window != null) && (!(window instanceof java.awt.Window))) {
            if (!(window.isVisible())) {
                if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.Component.focusLog.finest("component is recurively invisible");
                } 
                return false;
            } 
            window = window.parent;
        }
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        java.awt.Component heavyweight = peer instanceof java.awt.peer.LightweightPeer ? getNativeContainer() : java.awt.Component.this;
        if ((heavyweight == null) || (!(heavyweight.isVisible()))) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("Component is not a part of visible hierarchy");
            } 
            return false;
        } 
        peer = heavyweight.peer;
        if (peer == null) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("Peer is null");
            } 
            return false;
        } 
        long time = 0;
        if (java.awt.EventQueue.isDispatchThread()) {
            time = java.awt.Toolkit.getEventQueue().getMostRecentKeyEventTime();
        } else {
            time = java.lang.System.currentTimeMillis();
        }
        boolean success = peer.requestFocus(java.awt.Component.this, temporary, focusedWindowChangeAllowed, time, cause);
        if (!success) {
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager(appContext).dequeueKeyEvents(time, java.awt.Component.this);
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("Peer request failed");
            } 
        } else {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest(("Pass for " + (java.awt.Component.this)));
            } 
        }
        return success;
    }

    private boolean isRequestFocusAccepted(boolean temporary, boolean focusedWindowChangeAllowed, sun.awt.CausedFocusEvent.Cause cause) {
        if ((!(isFocusable())) || (!(isVisible()))) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("Not focusable or not visible");
            } 
            return false;
        } 
        java.awt.peer.ComponentPeer peer = java.awt.Component.this.peer;
        if (peer == null) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("peer is null");
            } 
            return false;
        } 
        java.awt.Window window = getContainingWindow();
        if ((window == null) || (!(window.isFocusableWindow()))) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("Component doesn't have toplevel");
            } 
            return false;
        } 
        java.awt.Component focusOwner = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(window);
        if (focusOwner == null) {
            focusOwner = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
            if ((focusOwner != null) && ((focusOwner.getContainingWindow()) != window)) {
                focusOwner = null;
            } 
        } 
        if ((focusOwner == (java.awt.Component.this)) || (focusOwner == null)) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("focus owner is null or this");
            } 
            return true;
        } 
        if ((sun.awt.CausedFocusEvent.Cause.ACTIVATION) == cause) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.Component.focusLog.finest("cause is activation");
            } 
            return true;
        } 
        boolean ret = java.awt.Component.requestFocusController.acceptRequestFocus(focusOwner, java.awt.Component.this, temporary, focusedWindowChangeAllowed, cause);
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.Component.focusLog.finest("RequestFocusController returns {0}", ret);
        } 
        return ret;
    }

    private static sun.awt.RequestFocusController requestFocusController = new java.awt.Component.DummyRequestFocusController();

    private static class DummyRequestFocusController implements sun.awt.RequestFocusController {
        public boolean acceptRequestFocus(java.awt.Component from, java.awt.Component to, boolean temporary, boolean focusedWindowChangeAllowed, sun.awt.CausedFocusEvent.Cause cause) {
            return true;
        }
    }

    static synchronized void setRequestFocusController(sun.awt.RequestFocusController requestController) {
        if (requestController == null) {
            java.awt.Component.requestFocusController = new java.awt.Component.DummyRequestFocusController();
        } else {
            java.awt.Component.requestFocusController = requestController;
        }
    }

    public java.awt.Container getFocusCycleRootAncestor() {
        java.awt.Container rootAncestor = java.awt.Component.this.parent;
        while ((rootAncestor != null) && (!(rootAncestor.isFocusCycleRoot()))) {
            rootAncestor = rootAncestor.parent;
        }
        return rootAncestor;
    }

    public boolean isFocusCycleRoot(java.awt.Container container) {
        java.awt.Container rootAncestor = getFocusCycleRootAncestor();
        return rootAncestor == container;
    }

    java.awt.Container getTraversalRoot() {
        return getFocusCycleRootAncestor();
    }

    public void transferFocus() {
        nextFocus();
    }

    @java.lang.Deprecated
    public void nextFocus() {
        transferFocus(false);
    }

    boolean transferFocus(boolean clearOnFailure) {
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.Component.focusLog.finer(("clearOnFailure = " + clearOnFailure));
        } 
        java.awt.Component toFocus = getNextFocusCandidate();
        boolean res = false;
        if (((toFocus != null) && (!(toFocus.isFocusOwner()))) && (toFocus != (java.awt.Component.this))) {
            res = toFocus.requestFocusInWindow(sun.awt.CausedFocusEvent.Cause.TRAVERSAL_FORWARD);
        } 
        if (clearOnFailure && (!res)) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                java.awt.Component.focusLog.finer("clear global focus owner");
            } 
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwnerPriv();
        } 
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.Component.focusLog.finer(("returning result: " + res));
        } 
        return res;
    }

    final java.awt.Component getNextFocusCandidate() {
        java.awt.Container rootAncestor = getTraversalRoot();
        java.awt.Component comp = java.awt.Component.this;
        while ((rootAncestor != null) && (!((rootAncestor.isShowing()) && (rootAncestor.canBeFocusOwner())))) {
            comp = rootAncestor;
            rootAncestor = comp.getFocusCycleRootAncestor();
        }
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.Component.focusLog.finer(((("comp = " + comp) + ", root = ") + rootAncestor));
        } 
        java.awt.Component candidate = null;
        if (rootAncestor != null) {
            java.awt.FocusTraversalPolicy policy = rootAncestor.getFocusTraversalPolicy();
            java.awt.Component toFocus = policy.getComponentAfter(rootAncestor, comp);
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                java.awt.Component.focusLog.finer(("component after is " + toFocus));
            } 
            if (toFocus == null) {
                toFocus = policy.getDefaultComponent(rootAncestor);
                if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                    java.awt.Component.focusLog.finer(("default component is " + toFocus));
                } 
            } 
            if (toFocus == null) {
                java.applet.Applet applet = null;
                if (applet != null) {
                    toFocus = applet;
                } 
            } 
            candidate = toFocus;
        } 
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.Component.focusLog.finer(("Focus transfer candidate: " + candidate));
        } 
        return candidate;
    }

    public void transferFocusBackward() {
        transferFocusBackward(false);
    }

    boolean transferFocusBackward(boolean clearOnFailure) {
        java.awt.Container rootAncestor = getTraversalRoot();
        java.awt.Component comp = java.awt.Component.this;
        while ((rootAncestor != null) && (!((rootAncestor.isShowing()) && (rootAncestor.canBeFocusOwner())))) {
            comp = rootAncestor;
            rootAncestor = comp.getFocusCycleRootAncestor();
        }
        boolean res = false;
        if (rootAncestor != null) {
            java.awt.FocusTraversalPolicy policy = rootAncestor.getFocusTraversalPolicy();
            java.awt.Component toFocus = policy.getComponentBefore(rootAncestor, comp);
            if (toFocus == null) {
                toFocus = policy.getDefaultComponent(rootAncestor);
            } 
            if (toFocus != null) {
                res = toFocus.requestFocusInWindow(sun.awt.CausedFocusEvent.Cause.TRAVERSAL_BACKWARD);
            } 
        } 
        if (clearOnFailure && (!res)) {
            if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                java.awt.Component.focusLog.finer("clear global focus owner");
            } 
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwnerPriv();
        } 
        if (java.awt.Component.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.Component.focusLog.finer(("returning result: " + res));
        } 
        return res;
    }

    public void transferFocusUpCycle() {
        java.awt.Container rootAncestor;
        for (rootAncestor = getFocusCycleRootAncestor() ; (rootAncestor != null) && (!(((rootAncestor.isShowing()) && (rootAncestor.isFocusable())) && (rootAncestor.isEnabled()))) ; rootAncestor = rootAncestor.getFocusCycleRootAncestor()) {
        }
        if (rootAncestor != null) {
            java.awt.Container rootAncestorRootAncestor = rootAncestor.getFocusCycleRootAncestor();
            java.awt.Container fcr = rootAncestorRootAncestor != null ? rootAncestorRootAncestor : rootAncestor;
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setGlobalCurrentFocusCycleRootPriv(fcr);
            rootAncestor.requestFocus(sun.awt.CausedFocusEvent.Cause.TRAVERSAL_UP);
        } else {
            java.awt.Window window = getContainingWindow();
            if (window != null) {
                java.awt.Component toFocus = window.getFocusTraversalPolicy().getDefaultComponent(window);
                if (toFocus != null) {
                    java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setGlobalCurrentFocusCycleRootPriv(window);
                    toFocus.requestFocus(sun.awt.CausedFocusEvent.Cause.TRAVERSAL_UP);
                } 
            } 
        }
    }

    public boolean hasFocus() {
        return (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner()) == (java.awt.Component.this);
    }

    public boolean isFocusOwner() {
        return hasFocus();
    }

    private boolean autoFocusTransferOnDisposal = true;

    void setAutoFocusTransferOnDisposal(boolean value) {
        autoFocusTransferOnDisposal = value;
    }

    boolean isAutoFocusTransferOnDisposal() {
        return autoFocusTransferOnDisposal;
    }

    public void add(java.awt.PopupMenu popup) {
        synchronized(getTreeLock()) {
            if ((popup.parent) != null) {
                popup.parent.remove(popup);
            } 
            if ((popups) == null) {
                popups = new java.util.Vector<java.awt.PopupMenu>();
            } 
            popups.addElement(popup);
            popup.parent = java.awt.Component.this;
            if ((peer) != null) {
                if ((popup.peer) == null) {
                    popup.addNotify();
                } 
            } 
        }
    }

    @java.lang.SuppressWarnings(value = "unchecked")
    public void remove(java.awt.MenuComponent popup) {
        synchronized(getTreeLock()) {
            if ((popups) == null) {
                return ;
            } 
            int index = popups.indexOf(popup);
            if (index >= 0) {
                java.awt.PopupMenu pmenu = ((java.awt.PopupMenu)(popup));
                if ((pmenu.peer) != null) {
                    pmenu.removeNotify();
                } 
                pmenu.parent = null;
                popups.removeElementAt(index);
                if ((popups.size()) == 0) {
                    popups = null;
                } 
            } 
        }
    }

    protected java.lang.String paramString() {
        final java.lang.String thisName = java.util.Objects.toString(getName(), "");
        final java.lang.String invalid = isValid() ? "" : ",invalid";
        final java.lang.String hidden = visible ? "" : ",hidden";
        final java.lang.String disabled = enabled ? "" : ",disabled";
        return ((((((((((thisName + ',') + (x)) + ',') + (y)) + ',') + (width)) + 'x') + (height)) + invalid) + hidden) + disabled;
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + '[') + (paramString())) + ']';
    }

    public void list() {
        list(java.lang.System.out, 0);
    }

    public void list(java.io.PrintStream out) {
        list(out, 0);
    }

    public void list(java.io.PrintStream out, int indent) {
        for (int i = 0 ; i < indent ; i++) {
            out.print(" ");
        }
        out.println(java.awt.Component.this);
    }

    public void list(java.io.PrintWriter out) {
        list(out, 0);
    }

    public void list(java.io.PrintWriter out, int indent) {
        for (int i = 0 ; i < indent ; i++) {
            out.print(" ");
        }
        out.println(java.awt.Component.this);
    }

    final java.awt.Container getNativeContainer() {
        java.awt.Container p = getContainer();
        while ((p != null) && ((p.peer) instanceof java.awt.peer.LightweightPeer)) {
            p = p.getContainer();
        }
        return p;
    }

    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        synchronized(getObjectLock()) {
            if (listener == null) {
                return ;
            } 
            if ((changeSupport) == null) {
                changeSupport = new java.beans.PropertyChangeSupport(java.awt.Component.this);
            } 
            changeSupport.addPropertyChangeListener(listener);
        }
    }

    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
        synchronized(getObjectLock()) {
            if ((listener == null) || ((changeSupport) == null)) {
                return ;
            } 
            changeSupport.removePropertyChangeListener(listener);
        }
    }

    public java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
        synchronized(getObjectLock()) {
            if ((changeSupport) == null) {
                return new java.beans.PropertyChangeListener[0];
            } 
            return changeSupport.getPropertyChangeListeners();
        }
    }

    public void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        synchronized(getObjectLock()) {
            if (listener == null) {
                return ;
            } 
            if ((changeSupport) == null) {
                changeSupport = new java.beans.PropertyChangeSupport(java.awt.Component.this);
            } 
            changeSupport.addPropertyChangeListener(propertyName, listener);
        }
    }

    public void removePropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        synchronized(getObjectLock()) {
            if ((listener == null) || ((changeSupport) == null)) {
                return ;
            } 
            changeSupport.removePropertyChangeListener(propertyName, listener);
        }
    }

    public java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String propertyName) {
        synchronized(getObjectLock()) {
            if ((changeSupport) == null) {
                return new java.beans.PropertyChangeListener[0];
            } 
            return changeSupport.getPropertyChangeListeners(propertyName);
        }
    }

    protected void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue) {
        java.beans.PropertyChangeSupport changeSupport;
        synchronized(getObjectLock()) {
            changeSupport = java.awt.Component.this.changeSupport;
        }
        if ((changeSupport == null) || (((oldValue != null) && (newValue != null)) && (oldValue.equals(newValue)))) {
            return ;
        } 
        changeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }

    protected void firePropertyChange(java.lang.String propertyName, boolean oldValue, boolean newValue) {
        java.beans.PropertyChangeSupport changeSupport = java.awt.Component.this.changeSupport;
        if ((changeSupport == null) || (oldValue == newValue)) {
            return ;
        } 
        changeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }

    protected void firePropertyChange(java.lang.String propertyName, int oldValue, int newValue) {
        java.beans.PropertyChangeSupport changeSupport = java.awt.Component.this.changeSupport;
        if ((changeSupport == null) || (oldValue == newValue)) {
            return ;
        } 
        changeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }

    public void firePropertyChange(java.lang.String propertyName, byte oldValue, byte newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, java.lang.Byte.valueOf(oldValue), java.lang.Byte.valueOf(newValue));
    }

    public void firePropertyChange(java.lang.String propertyName, char oldValue, char newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, new java.lang.Character(oldValue), new java.lang.Character(newValue));
    }

    public void firePropertyChange(java.lang.String propertyName, short oldValue, short newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, java.lang.Short.valueOf(oldValue), java.lang.Short.valueOf(newValue));
    }

    public void firePropertyChange(java.lang.String propertyName, long oldValue, long newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, java.lang.Long.valueOf(oldValue), java.lang.Long.valueOf(newValue));
    }

    public void firePropertyChange(java.lang.String propertyName, float oldValue, float newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, java.lang.Float.valueOf(oldValue), java.lang.Float.valueOf(newValue));
    }

    public void firePropertyChange(java.lang.String propertyName, double oldValue, double newValue) {
        if (((changeSupport) == null) || (oldValue == newValue)) {
            return ;
        } 
        firePropertyChange(propertyName, java.lang.Double.valueOf(oldValue), java.lang.Double.valueOf(newValue));
    }

    private int componentSerializedDataVersion = 4;

    private void doSwingSerialization() {
        java.lang.Package swingPackage = java.lang.Package.getPackage("javax.swing");
        for (java.lang.Class<?> klass = java.awt.Component.this.getClass() ; klass != null ; klass = klass.getSuperclass()) {
            if (((klass.getPackage()) == swingPackage) && ((klass.getClassLoader()) == null)) {
                final java.lang.Class<?> swingClass = klass;
                java.lang.reflect.Method[] methods = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.reflect.Method[]>() {
                    public java.lang.reflect.Method[] run() {
                        return swingClass.getDeclaredMethods();
                    }
                });
                for (int counter = (methods.length) - 1 ; counter >= 0 ; counter--) {
                    final java.lang.reflect.Method method = methods[counter];
                    if (method.getName().equals("compWriteObjectNotify")) {
                        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
                            public java.lang.Void run() {
                                method.setAccessible(true);
                                return null;
                            }
                        });
                        try {
                            method.invoke(java.awt.Component.this, ((java.lang.Object[])(null)));
                        } catch (java.lang.IllegalAccessException iae) {
                        } catch (java.lang.reflect.InvocationTargetException ite) {
                        }
                        return ;
                    } 
                }
            } 
        }
    }

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        doSwingSerialization();
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.componentListenerK, componentListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.focusListenerK, focusListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.keyListenerK, keyListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.mouseListenerK, mouseListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.mouseMotionListenerK, mouseMotionListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.inputMethodListenerK, inputMethodListener);
        s.writeObject(null);
        s.writeObject(componentOrientation);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.hierarchyListenerK, hierarchyListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.hierarchyBoundsListenerK, hierarchyBoundsListener);
        s.writeObject(null);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.mouseWheelListenerK, mouseWheelListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        objectLock = new java.lang.Object();
        acc = java.security.AccessController.getContext();
        s.defaultReadObject();
        appContext = sun.awt.AppContext.getAppContext();
        coalescingEnabled = checkCoalescing();
        if ((componentSerializedDataVersion) < 4) {
            focusable = true;
            isFocusTraversableOverridden = java.awt.Component.FOCUS_TRAVERSABLE_UNKNOWN;
            initializeFocusTraversalKeys();
            focusTraversalKeysEnabled = true;
        } 
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.componentListenerK) == key)
                addComponentListener(((java.awt.event.ComponentListener)(s.readObject())));
            else if ((java.awt.Component.focusListenerK) == key)
                addFocusListener(((java.awt.event.FocusListener)(s.readObject())));
            else if ((java.awt.Component.keyListenerK) == key)
                addKeyListener(((java.awt.event.KeyListener)(s.readObject())));
            else if ((java.awt.Component.mouseListenerK) == key)
                addMouseListener(((java.awt.event.MouseListener)(s.readObject())));
            else if ((java.awt.Component.mouseMotionListenerK) == key)
                addMouseMotionListener(((java.awt.event.MouseMotionListener)(s.readObject())));
            else if ((java.awt.Component.inputMethodListenerK) == key)
                addInputMethodListener(((java.awt.event.InputMethodListener)(s.readObject())));
            else
                s.readObject();
            
        }
        java.lang.Object orient = null;
        try {
            orient = s.readObject();
        } catch (java.io.OptionalDataException e) {
            if (!(e.eof)) {
                throw e;
            } 
        }
        if (orient != null) {
            componentOrientation = ((java.awt.ComponentOrientation)(orient));
        } else {
            componentOrientation = java.awt.ComponentOrientation.UNKNOWN;
        }
        try {
            while (null != (keyOrNull = s.readObject())) {
                java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
                if ((java.awt.Component.hierarchyListenerK) == key) {
                    addHierarchyListener(((java.awt.event.HierarchyListener)(s.readObject())));
                } else if ((java.awt.Component.hierarchyBoundsListenerK) == key) {
                    addHierarchyBoundsListener(((java.awt.event.HierarchyBoundsListener)(s.readObject())));
                } else {
                    s.readObject();
                }
            }
        } catch (java.io.OptionalDataException e) {
            if (!(e.eof)) {
                throw e;
            } 
        }
        try {
            while (null != (keyOrNull = s.readObject())) {
                java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
                if ((java.awt.Component.mouseWheelListenerK) == key) {
                    addMouseWheelListener(((java.awt.event.MouseWheelListener)(s.readObject())));
                } else {
                    s.readObject();
                }
            }
        } catch (java.io.OptionalDataException e) {
            if (!(e.eof)) {
                throw e;
            } 
        }
        if ((popups) != null) {
            int npopups = popups.size();
            for (int i = 0 ; i < npopups ; i++) {
                java.awt.PopupMenu popup = popups.elementAt(i);
                popup.parent = java.awt.Component.this;
            }
        } 
    }

    public void setComponentOrientation(java.awt.ComponentOrientation o) {
        java.awt.ComponentOrientation oldValue = componentOrientation;
        componentOrientation = o;
        firePropertyChange("componentOrientation", oldValue, o);
        invalidateIfValid();
    }

    public java.awt.ComponentOrientation getComponentOrientation() {
        return componentOrientation;
    }

    public void applyComponentOrientation(java.awt.ComponentOrientation orientation) {
        if (orientation == null) {
            throw new java.lang.NullPointerException();
        } 
        setComponentOrientation(orientation);
    }

    final boolean canBeFocusOwner() {
        if ((((isEnabled()) && (isDisplayable())) && (isVisible())) && (isFocusable())) {
            return true;
        } 
        return false;
    }

    final boolean canBeFocusOwnerRecursively() {
        if (!(canBeFocusOwner())) {
            return false;
        } 
        synchronized(getTreeLock()) {
            if ((parent) != null) {
                return parent.canContainFocusOwner(java.awt.Component.this);
            } 
        }
        return true;
    }

    final void relocateComponent() {
        synchronized(getTreeLock()) {
            if ((peer) == null) {
                return ;
            } 
            int nativeX = x;
            int nativeY = y;
            for (java.awt.Component cont = getContainer() ; (cont != null) && (cont.isLightweight()) ; cont = cont.getContainer()) {
                nativeX += cont.x;
                nativeY += cont.y;
            }
            peer.setBounds(nativeX, nativeY, width, height, java.awt.peer.ComponentPeer.SET_LOCATION);
        }
    }

    java.awt.Window getContainingWindow() {
        return null;
    }

    private static native void initIDs();

    protected javax.accessibility.AccessibleContext accessibleContext = null;

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        return accessibleContext;
    }

    protected abstract class AccessibleAWTComponent extends javax.accessibility.AccessibleContext implements java.io.Serializable , javax.accessibility.AccessibleComponent {
        private static final long serialVersionUID = 642321655757800191L;

        protected AccessibleAWTComponent() {
        }

        private transient volatile int propertyListenersCount = 0;

        protected java.awt.event.ComponentListener accessibleAWTComponentHandler = null;

        protected java.awt.event.FocusListener accessibleAWTFocusHandler = null;

        protected class AccessibleAWTComponentHandler implements java.awt.event.ComponentListener {
            public void componentHidden(java.awt.event.ComponentEvent e) {
                if ((accessibleContext) != null) {
                    accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, javax.accessibility.AccessibleState.VISIBLE, null);
                } 
            }

            public void componentShown(java.awt.event.ComponentEvent e) {
                if ((accessibleContext) != null) {
                    accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.VISIBLE);
                } 
            }

            public void componentMoved(java.awt.event.ComponentEvent e) {
            }

            public void componentResized(java.awt.event.ComponentEvent e) {
            }
        }

        protected class AccessibleAWTFocusHandler implements java.awt.event.FocusListener {
            public void focusGained(java.awt.event.FocusEvent event) {
                if ((accessibleContext) != null) {
                    accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.FOCUSED);
                } 
            }

            public void focusLost(java.awt.event.FocusEvent event) {
                if ((accessibleContext) != null) {
                    accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, javax.accessibility.AccessibleState.FOCUSED, null);
                } 
            }
        }

        public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
            if ((accessibleAWTComponentHandler) == null) {
                accessibleAWTComponentHandler = new java.awt.Component.AccessibleAWTComponent.AccessibleAWTComponentHandler();
            } 
            if ((accessibleAWTFocusHandler) == null) {
                accessibleAWTFocusHandler = new java.awt.Component.AccessibleAWTComponent.AccessibleAWTFocusHandler();
            } 
            if (((propertyListenersCount)++) == 0) {
                java.awt.Component.this.addComponentListener(accessibleAWTComponentHandler);
                java.awt.Component.this.addFocusListener(accessibleAWTFocusHandler);
            } 
            super.addPropertyChangeListener(listener);
        }

        public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
            if ((--(propertyListenersCount)) == 0) {
                java.awt.Component.this.removeComponentListener(accessibleAWTComponentHandler);
                java.awt.Component.this.removeFocusListener(accessibleAWTFocusHandler);
            } 
            super.removePropertyChangeListener(listener);
        }

        public java.lang.String getAccessibleName() {
            return accessibleName;
        }

        public java.lang.String getAccessibleDescription() {
            return accessibleDescription;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.AWT_COMPONENT;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            return java.awt.Component.this.getAccessibleStateSet();
        }

        public javax.accessibility.Accessible getAccessibleParent() {
            if ((accessibleParent) != null) {
                return accessibleParent;
            } else {
                java.awt.Container parent = getParent();
                if (parent instanceof javax.accessibility.Accessible) {
                    return ((javax.accessibility.Accessible)(parent));
                } 
            }
            return null;
        }

        public int getAccessibleIndexInParent() {
            return java.awt.Component.this.getAccessibleIndexInParent();
        }

        public int getAccessibleChildrenCount() {
            return 0;
        }

        public javax.accessibility.Accessible getAccessibleChild(int i) {
            return null;
        }

        public java.util.Locale getLocale() {
            return java.awt.Component.this.getLocale();
        }

        public javax.accessibility.AccessibleComponent getAccessibleComponent() {
            return java.awt.Component.AccessibleAWTComponent.this;
        }

        public java.awt.Color getBackground() {
            return java.awt.Component.this.getBackground();
        }

        public void setBackground(java.awt.Color c) {
            java.awt.Component.this.setBackground(c);
        }

        public java.awt.Color getForeground() {
            return java.awt.Component.this.getForeground();
        }

        public void setForeground(java.awt.Color c) {
            java.awt.Component.this.setForeground(c);
        }

        public java.awt.Cursor getCursor() {
            return java.awt.Component.this.getCursor();
        }

        public void setCursor(java.awt.Cursor cursor) {
            java.awt.Component.this.setCursor(cursor);
        }

        public java.awt.Font getFont() {
            return java.awt.Component.this.getFont();
        }

        public void setFont(java.awt.Font f) {
            java.awt.Component.this.setFont(f);
        }

        public java.awt.FontMetrics getFontMetrics(java.awt.Font f) {
            if (f == null) {
                return null;
            } else {
                return java.awt.Component.this.getFontMetrics(f);
            }
        }

        public boolean isEnabled() {
            return java.awt.Component.this.isEnabled();
        }

        public void setEnabled(boolean b) {
            boolean old = java.awt.Component.this.isEnabled();
            java.awt.Component.this.setEnabled(b);
            if (b != old) {
                if ((accessibleContext) != null) {
                    if (b) {
                        accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.ENABLED);
                    } else {
                        accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, javax.accessibility.AccessibleState.ENABLED, null);
                    }
                } 
            } 
        }

        public boolean isVisible() {
            return java.awt.Component.this.isVisible();
        }

        public void setVisible(boolean b) {
            boolean old = java.awt.Component.this.isVisible();
            java.awt.Component.this.setVisible(b);
            if (b != old) {
                if ((accessibleContext) != null) {
                    if (b) {
                        accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, null, javax.accessibility.AccessibleState.VISIBLE);
                    } else {
                        accessibleContext.firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_STATE_PROPERTY, javax.accessibility.AccessibleState.VISIBLE, null);
                    }
                } 
            } 
        }

        public boolean isShowing() {
            return java.awt.Component.this.isShowing();
        }

        public boolean contains(java.awt.Point p) {
            return java.awt.Component.this.contains(p);
        }

        public java.awt.Point getLocationOnScreen() {
            synchronized(java.awt.Component.this.getTreeLock()) {
                if (java.awt.Component.this.isShowing()) {
                    return java.awt.Component.this.getLocationOnScreen();
                } else {
                    return null;
                }
            }
        }

        public java.awt.Point getLocation() {
            return java.awt.Component.this.getLocation();
        }

        public void setLocation(java.awt.Point p) {
            java.awt.Component.this.setLocation(p);
        }

        public java.awt.Rectangle getBounds() {
            return java.awt.Component.this.getBounds();
        }

        public void setBounds(java.awt.Rectangle r) {
            java.awt.Component.this.setBounds(r);
        }

        public java.awt.Dimension getSize() {
            return java.awt.Component.this.getSize();
        }

        public void setSize(java.awt.Dimension d) {
            java.awt.Component.this.setSize(d);
        }

        public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
            return null;
        }

        public boolean isFocusTraversable() {
            return java.awt.Component.this.isFocusTraversable();
        }

        public void requestFocus() {
            java.awt.Component.this.requestFocus();
        }

        public void addFocusListener(java.awt.event.FocusListener l) {
            java.awt.Component.this.addFocusListener(l);
        }

        public void removeFocusListener(java.awt.event.FocusListener l) {
            java.awt.Component.this.removeFocusListener(l);
        }
    }

    int getAccessibleIndexInParent() {
        synchronized(getTreeLock()) {
            int index = -1;
            java.awt.Container parent = java.awt.Component.this.getParent();
            if ((parent != null) && (parent instanceof javax.accessibility.Accessible)) {
                java.awt.Component[] ca = parent.getComponents();
                for (int i = 0 ; i < (ca.length) ; i++) {
                    if ((ca[i]) instanceof javax.accessibility.Accessible) {
                        index++;
                    } 
                    if (java.awt.Component.this.equals(ca[i])) {
                        return index;
                    } 
                }
            } 
            return -1;
        }
    }

    javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
        synchronized(getTreeLock()) {
            javax.accessibility.AccessibleStateSet states = new javax.accessibility.AccessibleStateSet();
            if (java.awt.Component.this.isEnabled()) {
                states.add(javax.accessibility.AccessibleState.ENABLED);
            } 
            if (java.awt.Component.this.isFocusTraversable()) {
                states.add(javax.accessibility.AccessibleState.FOCUSABLE);
            } 
            if (java.awt.Component.this.isVisible()) {
                states.add(javax.accessibility.AccessibleState.VISIBLE);
            } 
            if (java.awt.Component.this.isShowing()) {
                states.add(javax.accessibility.AccessibleState.SHOWING);
            } 
            if (java.awt.Component.this.isFocusOwner()) {
                states.add(javax.accessibility.AccessibleState.FOCUSED);
            } 
            if ((java.awt.Component.this) instanceof javax.accessibility.Accessible) {
                javax.accessibility.AccessibleContext ac = ((javax.accessibility.Accessible)(java.awt.Component.this)).getAccessibleContext();
                if (ac != null) {
                    javax.accessibility.Accessible ap = ac.getAccessibleParent();
                    if (ap != null) {
                        javax.accessibility.AccessibleContext pac = ap.getAccessibleContext();
                        if (pac != null) {
                            javax.accessibility.AccessibleSelection as = pac.getAccessibleSelection();
                            if (as != null) {
                                states.add(javax.accessibility.AccessibleState.SELECTABLE);
                                int i = ac.getAccessibleIndexInParent();
                                if (i >= 0) {
                                    if (as.isAccessibleChildSelected(i)) {
                                        states.add(javax.accessibility.AccessibleState.SELECTED);
                                    } 
                                } 
                            } 
                        } 
                    } 
                } 
            } 
            if (java.awt.Component.isInstanceOf(java.awt.Component.this, "javax.swing.JComponent")) {
                if (((javax.swing.JComponent)(java.awt.Component.this)).isOpaque()) {
                    states.add(javax.accessibility.AccessibleState.OPAQUE);
                } 
            } 
            return states;
        }
    }

    static boolean isInstanceOf(java.lang.Object obj, java.lang.String className) {
        if (obj == null)
            return false;
        
        if (className == null)
            return false;
        
        java.lang.Class<?> cls = obj.getClass();
        while (cls != null) {
            if (cls.getName().equals(className)) {
                return true;
            } 
            cls = cls.getSuperclass();
        }
        return false;
    }

    final boolean areBoundsValid() {
        java.awt.Container cont = getContainer();
        return ((cont == null) || (cont.isValid())) || ((cont.getLayout()) == null);
    }

    void applyCompoundShape(sun.java2d.pipe.Region shape) {
        checkTreeLock();
        if (!(areBoundsValid())) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; areBoundsValid = ") + (areBoundsValid())));
            } 
            return ;
        } 
        if (!(isLightweight())) {
            java.awt.peer.ComponentPeer peer = getPeer();
            if (peer != null) {
                if (shape.isEmpty()) {
                } 
                if (shape.equals(getNormalShape())) {
                    if ((java.awt.Component.this.compoundShape) == null) {
                        return ;
                    } 
                    java.awt.Component.this.compoundShape = null;
                    peer.applyShape(null);
                } else {
                    if (shape.equals(getAppliedShape())) {
                        return ;
                    } 
                    java.awt.Component.this.compoundShape = shape;
                    java.awt.Point compAbsolute = getLocationOnWindow();
                    if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                        java.awt.Component.mixingLog.fine(((((("this = " + (java.awt.Component.this)) + "; compAbsolute=") + compAbsolute) + "; shape=") + shape));
                    } 
                }
            } 
        } 
    }

    private sun.java2d.pipe.Region getAppliedShape() {
        checkTreeLock();
        return ((java.awt.Component.this.compoundShape) == null) || (isLightweight()) ? getNormalShape() : java.awt.Component.this.compoundShape;
    }

    java.awt.Point getLocationOnWindow() {
        checkTreeLock();
        java.awt.Point curLocation = getLocation();
        for (java.awt.Container parent = getContainer() ; (parent != null) && (!(parent instanceof java.awt.Window)) ; parent = parent.getContainer()) {
            curLocation.x += parent.getX();
            curLocation.y += parent.getY();
        }
        return curLocation;
    }

    final sun.java2d.pipe.Region getNormalShape() {
        checkTreeLock();
        java.awt.Point compAbsolute = getLocationOnWindow();
        return sun.java2d.pipe.Region.getInstanceXYWH(compAbsolute.x, compAbsolute.y, getWidth(), getHeight());
    }

    sun.java2d.pipe.Region getOpaqueShape() {
        checkTreeLock();
        if ((mixingCutoutRegion) != null) {
            return mixingCutoutRegion;
        } else {
            return getNormalShape();
        }
    }

    final int getSiblingIndexAbove() {
        checkTreeLock();
        java.awt.Container parent = getContainer();
        if (parent == null) {
            return -1;
        } 
        int nextAbove = (parent.getComponentZOrder(java.awt.Component.this)) - 1;
        return nextAbove < 0 ? -1 : nextAbove;
    }

    final java.awt.peer.ComponentPeer getHWPeerAboveMe() {
        checkTreeLock();
        java.awt.Container cont = getContainer();
        int indexAbove = getSiblingIndexAbove();
        while (cont != null) {
            for (int i = indexAbove ; i > (-1) ; i--) {
                java.awt.Component comp = cont.getComponent(i);
                if (((comp != null) && (comp.isDisplayable())) && (!(comp.isLightweight()))) {
                    return comp.getPeer();
                } 
            }
            if (!(cont.isLightweight())) {
                break;
            } 
            indexAbove = cont.getSiblingIndexAbove();
            cont = cont.getContainer();
        }
        return null;
    }

    final int getSiblingIndexBelow() {
        checkTreeLock();
        java.awt.Container parent = getContainer();
        if (parent == null) {
            return -1;
        } 
        int nextBelow = (parent.getComponentZOrder(java.awt.Component.this)) + 1;
        return nextBelow >= (parent.getComponentCount()) ? -1 : nextBelow;
    }

    final boolean isNonOpaqueForMixing() {
        return ((mixingCutoutRegion) != null) && (mixingCutoutRegion.isEmpty());
    }

    private sun.java2d.pipe.Region calculateCurrentShape() {
        checkTreeLock();
        sun.java2d.pipe.Region s = getNormalShape();
        if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; normalShape=") + s));
        } 
        if ((getContainer()) != null) {
            java.awt.Component comp = java.awt.Component.this;
            java.awt.Container cont = comp.getContainer();
            while (cont != null) {
                for (int index = comp.getSiblingIndexAbove() ; index != (-1) ; --index) {
                    java.awt.Component c = cont.getComponent(index);
                    if ((c.isLightweight()) && (c.isShowing())) {
                        s = null;
                    } 
                }
                if (cont.isLightweight()) {
                    s = s.getIntersection(cont.getNormalShape());
                } else {
                    break;
                }
                comp = cont;
                cont = cont.getContainer();
            }
        } 
        if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Component.mixingLog.fine(("currentShape=" + s));
        } 
        return s;
    }

    void applyCurrentShape() {
        checkTreeLock();
        if (!(areBoundsValid())) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; areBoundsValid = ") + (areBoundsValid())));
            } 
            return ;
        } 
        if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Component.mixingLog.fine(("this = " + (java.awt.Component.this)));
        } 
        applyCompoundShape(calculateCurrentShape());
    }

    final void subtractAndApplyShape(sun.java2d.pipe.Region s) {
        checkTreeLock();
        if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; s=") + s));
        } 
    }

    private final void applyCurrentShapeBelowMe() {
        checkTreeLock();
        java.awt.Container parent = getContainer();
        if ((parent != null) && (parent.isShowing())) {
            parent.recursiveApplyCurrentShape(getSiblingIndexBelow());
            java.awt.Container parent2 = parent.getContainer();
            while ((!(parent.isOpaque())) && (parent2 != null)) {
                parent2.recursiveApplyCurrentShape(parent.getSiblingIndexBelow());
                parent = parent2;
                parent2 = parent.getContainer();
            }
        } 
    }

    final void subtractAndApplyShapeBelowMe() {
        checkTreeLock();
        java.awt.Container parent = getContainer();
        if ((parent != null) && (isShowing())) {
            sun.java2d.pipe.Region opaqueShape = getOpaqueShape();
            parent.recursiveSubtractAndApplyShape(opaqueShape, getSiblingIndexBelow());
            java.awt.Container parent2 = parent.getContainer();
            while ((!(parent.isOpaque())) && (parent2 != null)) {
                parent2.recursiveSubtractAndApplyShape(opaqueShape, parent.getSiblingIndexBelow());
                parent = parent2;
                parent2 = parent.getContainer();
            }
        } 
    }

    void mixOnShowing() {
        synchronized(getTreeLock()) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(("this = " + (java.awt.Component.this)));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if (isLightweight()) {
                subtractAndApplyShapeBelowMe();
            } else {
                applyCurrentShape();
            }
        }
    }

    void mixOnHiding(boolean isLightweight) {
        synchronized(getTreeLock()) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; isLightweight = ") + isLightweight));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if (isLightweight) {
                applyCurrentShapeBelowMe();
            } 
        }
    }

    void mixOnReshaping() {
        synchronized(getTreeLock()) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(("this = " + (java.awt.Component.this)));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if (isLightweight()) {
                applyCurrentShapeBelowMe();
            } else {
                applyCurrentShape();
            }
        }
    }

    void mixOnZOrderChanging(int oldZorder, int newZorder) {
        synchronized(getTreeLock()) {
            boolean becameHigher = newZorder < oldZorder;
            java.awt.Container parent = getContainer();
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(((((((("this = " + (java.awt.Component.this)) + "; oldZorder=") + oldZorder) + "; newZorder=") + newZorder) + "; parent=") + parent));
            } 
            if (!(isMixingNeeded())) {
                return ;
            } 
            if (isLightweight()) {
                if (becameHigher) {
                    if ((parent != null) && (isShowing())) {
                        parent.recursiveSubtractAndApplyShape(getOpaqueShape(), getSiblingIndexBelow(), oldZorder);
                    } 
                } else {
                    if (parent != null) {
                        parent.recursiveApplyCurrentShape(oldZorder, newZorder);
                    } 
                }
            } else {
                if (becameHigher) {
                    applyCurrentShape();
                } else {
                    if (parent != null) {
                        sun.java2d.pipe.Region shape = getAppliedShape();
                        for (int index = oldZorder ; index < newZorder ; index++) {
                            java.awt.Component c = parent.getComponent(index);
                            if ((c.isLightweight()) && (c.isShowing())) {
                            } 
                        }
                        applyCompoundShape(shape);
                    } 
                }
            }
        }
    }

    void mixOnValidating() {
    }

    final boolean isMixingNeeded() {
        if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.Component.mixingLog.finest((("this = " + (java.awt.Component.this)) + "; Mixing disabled via sun.awt.disableMixing"));
            return false;
        } 
        if (!(areBoundsValid())) {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine(((("this = " + (java.awt.Component.this)) + "; areBoundsValid = ") + (areBoundsValid())));
            } 
            return false;
        } 
        java.awt.Window window = getContainingWindow();
        if (window != null) {
            if (((!(window.hasHeavyweightDescendants())) || (!(window.hasLightweightDescendants()))) || (window.isDisposing())) {
                if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.Component.mixingLog.fine(((((((("containing window = " + window) + "; has h/w descendants = ") + (window.hasHeavyweightDescendants())) + "; has l/w descendants = ") + (window.hasLightweightDescendants())) + "; disposing = ") + (window.isDisposing())));
                } 
                return false;
            } 
        } else {
            if (java.awt.Component.mixingLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.Component.mixingLog.fine((("this = " + (java.awt.Component.this)) + "; containing window is null"));
            } 
            return false;
        }
        return true;
    }

    void updateZOrder() {
        peer.setZOrder(getHWPeerAboveMe());
    }
}


package java.awt;


public class FlowLayout implements java.awt.LayoutManager , java.io.Serializable {
    public static final int LEFT = 0;

    public static final int CENTER = 1;

    public static final int RIGHT = 2;

    public static final int LEADING = 3;

    public static final int TRAILING = 4;

    int align;

    int newAlign;

    int hgap;

    int vgap;

    private boolean alignOnBaseline;

    private static final long serialVersionUID = -7262534875583282631L;

    public FlowLayout() {
        this(java.awt.FlowLayout.CENTER, 5, 5);
    }

    public FlowLayout(int align) {
        this(align, 5, 5);
    }

    public FlowLayout(int align ,int hgap ,int vgap) {
        java.awt.FlowLayout.this.hgap = hgap;
        java.awt.FlowLayout.this.vgap = vgap;
        setAlignment(align);
    }

    public int getAlignment() {
        return newAlign;
    }

    public void setAlignment(int align) {
        java.awt.FlowLayout.this.newAlign = align;
        switch (align) {
            case java.awt.FlowLayout.LEADING :
                java.awt.FlowLayout.this.align = java.awt.FlowLayout.LEFT;
                break;
            case java.awt.FlowLayout.TRAILING :
                java.awt.FlowLayout.this.align = java.awt.FlowLayout.RIGHT;
                break;
            default :
                java.awt.FlowLayout.this.align = align;
                break;
        }
    }

    public int getHgap() {
        return hgap;
    }

    public void setHgap(int hgap) {
        java.awt.FlowLayout.this.hgap = hgap;
    }

    public int getVgap() {
        return vgap;
    }

    public void setVgap(int vgap) {
        java.awt.FlowLayout.this.vgap = vgap;
    }

    public void setAlignOnBaseline(boolean alignOnBaseline) {
        java.awt.FlowLayout.this.alignOnBaseline = alignOnBaseline;
    }

    public boolean getAlignOnBaseline() {
        return alignOnBaseline;
    }

    public void addLayoutComponent(java.lang.String name, java.awt.Component comp) {
    }

    public void removeLayoutComponent(java.awt.Component comp) {
    }

    public java.awt.Dimension preferredLayoutSize(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            java.awt.Dimension dim = new java.awt.Dimension(0 , 0);
            int nmembers = target.getComponentCount();
            boolean firstVisibleComponent = true;
            boolean useBaseline = getAlignOnBaseline();
            int maxAscent = 0;
            int maxDescent = 0;
            for (int i = 0 ; i < nmembers ; i++) {
                java.awt.Component m = target.getComponent(i);
                if (m.isVisible()) {
                    java.awt.Dimension d = m.getPreferredSize();
                    dim.height = java.lang.Math.max(dim.height, d.height);
                    if (firstVisibleComponent) {
                        firstVisibleComponent = false;
                    } else {
                        dim.width += hgap;
                    }
                    dim.width += d.width;
                    if (useBaseline) {
                        int baseline = m.getBaseline(d.width, d.height);
                        if (baseline >= 0) {
                            maxAscent = java.lang.Math.max(maxAscent, baseline);
                            maxDescent = java.lang.Math.max(maxDescent, ((d.height) - baseline));
                        } 
                    } 
                } 
            }
            if (useBaseline) {
                dim.height = java.lang.Math.max((maxAscent + maxDescent), dim.height);
            } 
            java.awt.Insets insets = target.getInsets();
            dim.width += ((insets.left) + (insets.right)) + ((hgap) * 2);
            dim.height += ((insets.top) + (insets.bottom)) + ((vgap) * 2);
            return dim;
        }
    }

    public java.awt.Dimension minimumLayoutSize(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            boolean useBaseline = getAlignOnBaseline();
            java.awt.Dimension dim = new java.awt.Dimension(0 , 0);
            int nmembers = target.getComponentCount();
            int maxAscent = 0;
            int maxDescent = 0;
            boolean firstVisibleComponent = true;
            for (int i = 0 ; i < nmembers ; i++) {
                java.awt.Component m = target.getComponent(i);
                if (m.visible) {
                    java.awt.Dimension d = m.getMinimumSize();
                    dim.height = java.lang.Math.max(dim.height, d.height);
                    if (firstVisibleComponent) {
                        firstVisibleComponent = false;
                    } else {
                        dim.width += hgap;
                    }
                    dim.width += d.width;
                    if (useBaseline) {
                        int baseline = m.getBaseline(d.width, d.height);
                        if (baseline >= 0) {
                            maxAscent = java.lang.Math.max(maxAscent, baseline);
                            maxDescent = java.lang.Math.max(maxDescent, ((dim.height) - baseline));
                        } 
                    } 
                } 
            }
            if (useBaseline) {
                dim.height = java.lang.Math.max((maxAscent + maxDescent), dim.height);
            } 
            java.awt.Insets insets = target.getInsets();
            dim.width += ((insets.left) + (insets.right)) + ((hgap) * 2);
            dim.height += ((insets.top) + (insets.bottom)) + ((vgap) * 2);
            return dim;
        }
    }

    private int moveComponents(java.awt.Container target, int x, int y, int width, int height, int rowStart, int rowEnd, boolean ltr, boolean useBaseline, int[] ascent, int[] descent) {
        switch (newAlign) {
            case java.awt.FlowLayout.LEFT :
                x += ltr ? 0 : width;
                break;
            case java.awt.FlowLayout.CENTER :
                x += width / 2;
                break;
            case java.awt.FlowLayout.RIGHT :
                x += ltr ? width : 0;
                break;
            case java.awt.FlowLayout.LEADING :
                break;
            case java.awt.FlowLayout.TRAILING :
                x += width;
                break;
        }
        int maxAscent = 0;
        int nonbaselineHeight = 0;
        int baselineOffset = 0;
        if (useBaseline) {
            int maxDescent = 0;
            for (int i = rowStart ; i < rowEnd ; i++) {
                java.awt.Component m = target.getComponent(i);
                if (m.visible) {
                    if ((ascent[i]) >= 0) {
                        maxAscent = java.lang.Math.max(maxAscent, ascent[i]);
                        maxDescent = java.lang.Math.max(maxDescent, descent[i]);
                    } else {
                        nonbaselineHeight = java.lang.Math.max(m.getHeight(), nonbaselineHeight);
                    }
                } 
            }
            height = java.lang.Math.max((maxAscent + maxDescent), nonbaselineHeight);
            baselineOffset = ((height - maxAscent) - maxDescent) / 2;
        } 
        for (int i = rowStart ; i < rowEnd ; i++) {
            java.awt.Component m = target.getComponent(i);
            if (m.isVisible()) {
                int cy;
                if (useBaseline && ((ascent[i]) >= 0)) {
                    cy = ((y + baselineOffset) + maxAscent) - (ascent[i]);
                } else {
                    cy = y + ((height - (m.height)) / 2);
                }
                if (ltr) {
                    m.setLocation(x, cy);
                } else {
                    m.setLocation((((target.width) - x) - (m.width)), cy);
                }
                x += (m.width) + (hgap);
            } 
        }
        return height;
    }

    public void layoutContainer(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            java.awt.Insets insets = target.getInsets();
            int maxwidth = (target.width) - (((insets.left) + (insets.right)) + ((hgap) * 2));
            int nmembers = target.getComponentCount();
            int x = 0;
            int y = (insets.top) + (vgap);
            int rowh = 0;
            int start = 0;
            boolean ltr = target.getComponentOrientation().isLeftToRight();
            boolean useBaseline = getAlignOnBaseline();
            int[] ascent = null;
            int[] descent = null;
            if (useBaseline) {
                ascent = new int[nmembers];
                descent = new int[nmembers];
            } 
            for (int i = 0 ; i < nmembers ; i++) {
                java.awt.Component m = target.getComponent(i);
                if (m.isVisible()) {
                    java.awt.Dimension d = m.getPreferredSize();
                    m.setSize(d.width, d.height);
                    if (useBaseline) {
                        int baseline = m.getBaseline(d.width, d.height);
                        if (baseline >= 0) {
                            ascent[i] = baseline;
                            descent[i] = (d.height) - baseline;
                        } else {
                            ascent[i] = -1;
                        }
                    } 
                    if ((x == 0) || ((x + (d.width)) <= maxwidth)) {
                        if (x > 0) {
                            x += hgap;
                        } 
                        x += d.width;
                        rowh = java.lang.Math.max(rowh, d.height);
                    } else {
                        rowh = moveComponents(target, ((insets.left) + (hgap)), y, (maxwidth - x), rowh, start, i, ltr, useBaseline, ascent, descent);
                        x = d.width;
                        y += (vgap) + rowh;
                        rowh = d.height;
                        start = i;
                    }
                } 
            }
            moveComponents(target, ((insets.left) + (hgap)), y, (maxwidth - x), rowh, start, nmembers, ltr, useBaseline, ascent, descent);
        }
    }

    private static final int currentSerialVersion = 1;

    private int serialVersionOnStream = java.awt.FlowLayout.currentSerialVersion;

    private void readObject(java.io.ObjectInputStream stream) throws java.io.IOException, java.lang.ClassNotFoundException {
        stream.defaultReadObject();
        if ((serialVersionOnStream) < 1) {
            setAlignment(java.awt.FlowLayout.this.align);
        } 
        serialVersionOnStream = java.awt.FlowLayout.currentSerialVersion;
    }

    public java.lang.String toString() {
        java.lang.String str = "";
        switch (align) {
            case java.awt.FlowLayout.LEFT :
                str = ",align=left";
                break;
            case java.awt.FlowLayout.CENTER :
                str = ",align=center";
                break;
            case java.awt.FlowLayout.RIGHT :
                str = ",align=right";
                break;
            case java.awt.FlowLayout.LEADING :
                str = ",align=leading";
                break;
            case java.awt.FlowLayout.TRAILING :
                str = ",align=trailing";
                break;
        }
        return ((((((getClass().getName()) + "[hgap=") + (hgap)) + ",vgap=") + (vgap)) + str) + "]";
    }
}


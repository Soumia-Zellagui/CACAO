package java.awt;


public abstract class GraphicsDevice {
    private java.awt.Window fullScreenWindow;

    private sun.awt.AppContext fullScreenAppContext;

    private final java.lang.Object fsAppContextLock = new java.lang.Object();

    private java.awt.Rectangle windowedModeBounds;

    protected GraphicsDevice() {
    }

    public static final int TYPE_RASTER_SCREEN = 0;

    public static final int TYPE_PRINTER = 1;

    public static final int TYPE_IMAGE_BUFFER = 2;

    public static enum WindowTranslucency {
PERPIXEL_TRANSPARENT, TRANSLUCENT, PERPIXEL_TRANSLUCENT;    }

    public abstract int getType();

    public abstract java.lang.String getIDstring();

    public abstract java.awt.GraphicsConfiguration[] getConfigurations();

    public abstract java.awt.GraphicsConfiguration getDefaultConfiguration();

    public java.awt.GraphicsConfiguration getBestConfiguration(java.awt.GraphicsConfigTemplate gct) {
        java.awt.GraphicsConfiguration[] configs = getConfigurations();
        return gct.getBestConfiguration(configs);
    }

    public boolean isFullScreenSupported() {
        return false;
    }

    public void setFullScreenWindow(java.awt.Window w) {
        if (w != null) {
            if ((w.getShape()) != null) {
                w.setShape(null);
            } 
            if ((w.getOpacity()) < 1.0F) {
                w.setOpacity(1.0F);
            } 
            if (!(w.isOpaque())) {
                java.awt.Color bgColor = w.getBackground();
                bgColor = new java.awt.Color(bgColor.getRed() , bgColor.getGreen() , bgColor.getBlue() , 255);
                w.setBackground(bgColor);
            } 
            final java.awt.GraphicsConfiguration gc = w.getGraphicsConfiguration();
            if (((gc != null) && ((gc.getDevice()) != (java.awt.GraphicsDevice.this))) && ((gc.getDevice().getFullScreenWindow()) == w)) {
                gc.getDevice().setFullScreenWindow(null);
            } 
        } 
        if (((fullScreenWindow) != null) && ((windowedModeBounds) != null)) {
            if ((windowedModeBounds.width) == 0)
                windowedModeBounds.width = 1;
            
            if ((windowedModeBounds.height) == 0)
                windowedModeBounds.height = 1;
            
            fullScreenWindow.setBounds(windowedModeBounds);
        } 
        synchronized(fsAppContextLock) {
            if (w == null) {
                fullScreenAppContext = null;
            } else {
                fullScreenAppContext = sun.awt.AppContext.getAppContext();
            }
            fullScreenWindow = w;
        }
        if ((fullScreenWindow) != null) {
            windowedModeBounds = fullScreenWindow.getBounds();
            final java.awt.GraphicsConfiguration gc = getDefaultConfiguration();
            final java.awt.Rectangle screenBounds = gc.getBounds();
            if (sun.awt.SunToolkit.isDispatchThreadForAppContext(fullScreenWindow)) {
                fullScreenWindow.setGraphicsConfiguration(gc);
            } 
            fullScreenWindow.setBounds(screenBounds.x, screenBounds.y, screenBounds.width, screenBounds.height);
            fullScreenWindow.setVisible(true);
            fullScreenWindow.toFront();
        } 
    }

    public java.awt.Window getFullScreenWindow() {
        java.awt.Window returnWindow = null;
        synchronized(fsAppContextLock) {
            if ((fullScreenAppContext) == (sun.awt.AppContext.getAppContext())) {
                returnWindow = fullScreenWindow;
            } 
        }
        return returnWindow;
    }

    public boolean isDisplayChangeSupported() {
        return false;
    }

    public void setDisplayMode(java.awt.DisplayMode dm) {
        throw new java.lang.UnsupportedOperationException("Cannot change display mode");
    }

    public java.awt.DisplayMode getDisplayMode() {
        java.awt.GraphicsConfiguration gc = getDefaultConfiguration();
        java.awt.Rectangle r = gc.getBounds();
        java.awt.image.ColorModel cm = gc.getColorModel();
        return new java.awt.DisplayMode(r.width , r.height , cm.getPixelSize() , 0);
    }

    public java.awt.DisplayMode[] getDisplayModes() {
        return new java.awt.DisplayMode[]{ getDisplayMode() };
    }

    public int getAvailableAcceleratedMemory() {
        return -1;
    }

    public boolean isWindowTranslucencySupported(java.awt.GraphicsDevice.WindowTranslucency translucencyKind) {
        switch (translucencyKind) {
            case PERPIXEL_TRANSPARENT :
                return java.awt.GraphicsDevice.isWindowShapingSupported();
            case TRANSLUCENT :
                return java.awt.GraphicsDevice.isWindowOpacitySupported();
            case PERPIXEL_TRANSLUCENT :
                return isWindowPerpixelTranslucencySupported();
        }
        return false;
    }

    static boolean isWindowShapingSupported() {
        java.awt.Toolkit curToolkit = java.awt.Toolkit.getDefaultToolkit();
        if (!(curToolkit instanceof sun.awt.SunToolkit)) {
            return false;
        } 
        return ((sun.awt.SunToolkit)(curToolkit)).isWindowShapingSupported();
    }

    static boolean isWindowOpacitySupported() {
        java.awt.Toolkit curToolkit = java.awt.Toolkit.getDefaultToolkit();
        if (!(curToolkit instanceof sun.awt.SunToolkit)) {
            return false;
        } 
        return ((sun.awt.SunToolkit)(curToolkit)).isWindowOpacitySupported();
    }

    boolean isWindowPerpixelTranslucencySupported() {
        java.awt.Toolkit curToolkit = java.awt.Toolkit.getDefaultToolkit();
        if (!(curToolkit instanceof sun.awt.SunToolkit)) {
            return false;
        } 
        if (!(((sun.awt.SunToolkit)(curToolkit)).isWindowTranslucencySupported())) {
            return false;
        } 
        return (getTranslucencyCapableGC()) != null;
    }

    java.awt.GraphicsConfiguration getTranslucencyCapableGC() {
        java.awt.GraphicsConfiguration defaultGC = getDefaultConfiguration();
        if (defaultGC.isTranslucencyCapable()) {
            return defaultGC;
        } 
        java.awt.GraphicsConfiguration[] configs = getConfigurations();
        for (int j = 0 ; j < (configs.length) ; j++) {
            if (configs[j].isTranslucencyCapable()) {
                return configs[j];
            } 
        }
        return null;
    }
}


package java.awt;


class ColorPaintContext implements java.awt.PaintContext {
    int color;

    java.awt.image.WritableRaster savedTile;

    protected ColorPaintContext(int color ,java.awt.image.ColorModel cm) {
        java.awt.ColorPaintContext.this.color = color;
    }

    public void dispose() {
    }

    int getRGB() {
        return color;
    }

    public java.awt.image.ColorModel getColorModel() {
        return java.awt.image.ColorModel.getRGBdefault();
    }

    public synchronized java.awt.image.Raster getRaster(int x, int y, int w, int h) {
        java.awt.image.WritableRaster t = savedTile;
        if (((t == null) || (w > (t.getWidth()))) || (h > (t.getHeight()))) {
            t = getColorModel().createCompatibleWritableRaster(w, h);
            sun.awt.image.IntegerComponentRaster icr = ((sun.awt.image.IntegerComponentRaster)(t));
            java.util.Arrays.fill(icr.getDataStorage(), color);
            icr.markDirty();
            if ((w <= 64) && (h <= 64)) {
                savedTile = t;
            } 
        } 
        return t;
    }
}


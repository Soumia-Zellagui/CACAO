package java.awt;


public final class ComponentOrientation implements java.io.Serializable {
    private static final long serialVersionUID = -4113291392143563828L;

    private static final int UNK_BIT = 1;

    private static final int HORIZ_BIT = 2;

    private static final int LTR_BIT = 4;

    public static final java.awt.ComponentOrientation LEFT_TO_RIGHT = new java.awt.ComponentOrientation(((java.awt.ComponentOrientation.HORIZ_BIT) | (java.awt.ComponentOrientation.LTR_BIT)));

    public static final java.awt.ComponentOrientation RIGHT_TO_LEFT = new java.awt.ComponentOrientation(java.awt.ComponentOrientation.HORIZ_BIT);

    public static final java.awt.ComponentOrientation UNKNOWN = new java.awt.ComponentOrientation((((java.awt.ComponentOrientation.HORIZ_BIT) | (java.awt.ComponentOrientation.LTR_BIT)) | (java.awt.ComponentOrientation.UNK_BIT)));

    public boolean isHorizontal() {
        return ((orientation) & (java.awt.ComponentOrientation.HORIZ_BIT)) != 0;
    }

    public boolean isLeftToRight() {
        return ((orientation) & (java.awt.ComponentOrientation.LTR_BIT)) != 0;
    }

    public static java.awt.ComponentOrientation getOrientation(java.util.Locale locale) {
        java.lang.String lang = locale.getLanguage();
        if (((("iw".equals(lang)) || ("ar".equals(lang))) || ("fa".equals(lang))) || ("ur".equals(lang))) {
            return java.awt.ComponentOrientation.RIGHT_TO_LEFT;
        } else {
            return java.awt.ComponentOrientation.LEFT_TO_RIGHT;
        }
    }

    @java.lang.Deprecated
    public static java.awt.ComponentOrientation getOrientation(java.util.ResourceBundle bdl) {
        java.awt.ComponentOrientation result = null;
        try {
            result = ((java.awt.ComponentOrientation)(bdl.getObject("Orientation")));
        } catch (java.lang.Exception e) {
        }
        if (result == null) {
            result = java.awt.ComponentOrientation.getOrientation(bdl.getLocale());
        } 
        if (result == null) {
            result = java.awt.ComponentOrientation.getOrientation(java.util.Locale.getDefault());
        } 
        return result;
    }

    private int orientation;

    private ComponentOrientation(int value) {
        orientation = value;
    }
}


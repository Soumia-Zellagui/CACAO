package java.awt;


public class AWTException extends java.lang.Exception {
    private static final long serialVersionUID = -1900414231151323879L;

    public AWTException(java.lang.String msg) {
        super(msg);
    }
}


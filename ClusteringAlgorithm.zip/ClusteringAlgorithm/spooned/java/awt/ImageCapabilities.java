package java.awt;


public class ImageCapabilities implements java.lang.Cloneable {
    private boolean accelerated = false;

    public ImageCapabilities(boolean accelerated) {
        java.awt.ImageCapabilities.this.accelerated = accelerated;
    }

    public boolean isAccelerated() {
        return accelerated;
    }

    public boolean isTrueVolatile() {
        return false;
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }
}


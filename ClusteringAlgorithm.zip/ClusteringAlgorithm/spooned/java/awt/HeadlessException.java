package java.awt;


public class HeadlessException extends java.lang.UnsupportedOperationException {
    private static final long serialVersionUID = 167183644944358563L;

    public HeadlessException() {
    }

    public HeadlessException(java.lang.String msg) {
        super(msg);
    }

    public java.lang.String getMessage() {
        java.lang.String superMessage = super.getMessage();
        java.lang.String headlessMessage = java.awt.GraphicsEnvironment.getHeadlessMessage();
        if (superMessage == null) {
            return headlessMessage;
        } else if (headlessMessage == null) {
            return superMessage;
        } else {
            return superMessage + headlessMessage;
        }
    }
}


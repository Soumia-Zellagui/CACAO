package java.awt;


public final class SystemColor extends java.awt.Color implements java.io.Serializable {
    @java.lang.annotation.Native
    public static final int DESKTOP = 0;

    @java.lang.annotation.Native
    public static final int ACTIVE_CAPTION = 1;

    @java.lang.annotation.Native
    public static final int ACTIVE_CAPTION_TEXT = 2;

    @java.lang.annotation.Native
    public static final int ACTIVE_CAPTION_BORDER = 3;

    @java.lang.annotation.Native
    public static final int INACTIVE_CAPTION = 4;

    @java.lang.annotation.Native
    public static final int INACTIVE_CAPTION_TEXT = 5;

    @java.lang.annotation.Native
    public static final int INACTIVE_CAPTION_BORDER = 6;

    @java.lang.annotation.Native
    public static final int WINDOW = 7;

    @java.lang.annotation.Native
    public static final int WINDOW_BORDER = 8;

    @java.lang.annotation.Native
    public static final int WINDOW_TEXT = 9;

    @java.lang.annotation.Native
    public static final int MENU = 10;

    @java.lang.annotation.Native
    public static final int MENU_TEXT = 11;

    @java.lang.annotation.Native
    public static final int TEXT = 12;

    @java.lang.annotation.Native
    public static final int TEXT_TEXT = 13;

    @java.lang.annotation.Native
    public static final int TEXT_HIGHLIGHT = 14;

    @java.lang.annotation.Native
    public static final int TEXT_HIGHLIGHT_TEXT = 15;

    @java.lang.annotation.Native
    public static final int TEXT_INACTIVE_TEXT = 16;

    @java.lang.annotation.Native
    public static final int CONTROL = 17;

    @java.lang.annotation.Native
    public static final int CONTROL_TEXT = 18;

    @java.lang.annotation.Native
    public static final int CONTROL_HIGHLIGHT = 19;

    @java.lang.annotation.Native
    public static final int CONTROL_LT_HIGHLIGHT = 20;

    @java.lang.annotation.Native
    public static final int CONTROL_SHADOW = 21;

    @java.lang.annotation.Native
    public static final int CONTROL_DK_SHADOW = 22;

    @java.lang.annotation.Native
    public static final int SCROLLBAR = 23;

    @java.lang.annotation.Native
    public static final int INFO = 24;

    @java.lang.annotation.Native
    public static final int INFO_TEXT = 25;

    @java.lang.annotation.Native
    public static final int NUM_COLORS = 26;

    private static int[] systemColors = new int[]{ -16753572 , -16777088 , -1 , -4144960 , -8355712 , -4144960 , -4144960 , -1 , -16777216 , -16777216 , -4144960 , -16777216 , -4144960 , -16777216 , -16777088 , -1 , -8355712 , -4144960 , -16777216 , -1 , -2039584 , -8355712 , -16777216 , -2039584 , -2039808 , -16777216 };

    public static final java.awt.SystemColor desktop = new java.awt.SystemColor(((byte)(java.awt.SystemColor.DESKTOP)));

    public static final java.awt.SystemColor activeCaption = new java.awt.SystemColor(((byte)(java.awt.SystemColor.ACTIVE_CAPTION)));

    public static final java.awt.SystemColor activeCaptionText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.ACTIVE_CAPTION_TEXT)));

    public static final java.awt.SystemColor activeCaptionBorder = new java.awt.SystemColor(((byte)(java.awt.SystemColor.ACTIVE_CAPTION_BORDER)));

    public static final java.awt.SystemColor inactiveCaption = new java.awt.SystemColor(((byte)(java.awt.SystemColor.INACTIVE_CAPTION)));

    public static final java.awt.SystemColor inactiveCaptionText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.INACTIVE_CAPTION_TEXT)));

    public static final java.awt.SystemColor inactiveCaptionBorder = new java.awt.SystemColor(((byte)(java.awt.SystemColor.INACTIVE_CAPTION_BORDER)));

    public static final java.awt.SystemColor window = new java.awt.SystemColor(((byte)(java.awt.SystemColor.WINDOW)));

    public static final java.awt.SystemColor windowBorder = new java.awt.SystemColor(((byte)(java.awt.SystemColor.WINDOW_BORDER)));

    public static final java.awt.SystemColor windowText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.WINDOW_TEXT)));

    public static final java.awt.SystemColor menu = new java.awt.SystemColor(((byte)(java.awt.SystemColor.MENU)));

    public static final java.awt.SystemColor menuText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.MENU_TEXT)));

    public static final java.awt.SystemColor text = new java.awt.SystemColor(((byte)(java.awt.SystemColor.TEXT)));

    public static final java.awt.SystemColor textText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.TEXT_TEXT)));

    public static final java.awt.SystemColor textHighlight = new java.awt.SystemColor(((byte)(java.awt.SystemColor.TEXT_HIGHLIGHT)));

    public static final java.awt.SystemColor textHighlightText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.TEXT_HIGHLIGHT_TEXT)));

    public static final java.awt.SystemColor textInactiveText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.TEXT_INACTIVE_TEXT)));

    public static final java.awt.SystemColor control = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL)));

    public static final java.awt.SystemColor controlText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL_TEXT)));

    public static final java.awt.SystemColor controlHighlight = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL_HIGHLIGHT)));

    public static final java.awt.SystemColor controlLtHighlight = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL_LT_HIGHLIGHT)));

    public static final java.awt.SystemColor controlShadow = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL_SHADOW)));

    public static final java.awt.SystemColor controlDkShadow = new java.awt.SystemColor(((byte)(java.awt.SystemColor.CONTROL_DK_SHADOW)));

    public static final java.awt.SystemColor scrollbar = new java.awt.SystemColor(((byte)(java.awt.SystemColor.SCROLLBAR)));

    public static final java.awt.SystemColor info = new java.awt.SystemColor(((byte)(java.awt.SystemColor.INFO)));

    public static final java.awt.SystemColor infoText = new java.awt.SystemColor(((byte)(java.awt.SystemColor.INFO_TEXT)));

    private static final long serialVersionUID = 4503142729533789064L;

    private transient int index;

    private static java.awt.SystemColor[] systemColorObjects = new java.awt.SystemColor[]{ java.awt.SystemColor.desktop , java.awt.SystemColor.activeCaption , java.awt.SystemColor.activeCaptionText , java.awt.SystemColor.activeCaptionBorder , java.awt.SystemColor.inactiveCaption , java.awt.SystemColor.inactiveCaptionText , java.awt.SystemColor.inactiveCaptionBorder , java.awt.SystemColor.window , java.awt.SystemColor.windowBorder , java.awt.SystemColor.windowText , java.awt.SystemColor.menu , java.awt.SystemColor.menuText , java.awt.SystemColor.text , java.awt.SystemColor.textText , java.awt.SystemColor.textHighlight , java.awt.SystemColor.textHighlightText , java.awt.SystemColor.textInactiveText , java.awt.SystemColor.control , java.awt.SystemColor.controlText , java.awt.SystemColor.controlHighlight , java.awt.SystemColor.controlLtHighlight , java.awt.SystemColor.controlShadow , java.awt.SystemColor.controlDkShadow , java.awt.SystemColor.scrollbar , java.awt.SystemColor.info , java.awt.SystemColor.infoText };

    static {
        sun.awt.AWTAccessor.setSystemColorAccessor(java.awt.SystemColor::updateSystemColors);
        java.awt.SystemColor.updateSystemColors();
    }

    private static void updateSystemColors() {
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Toolkit.getDefaultToolkit().loadSystemColors(java.awt.SystemColor.systemColors);
        } 
        for (int i = 0 ; i < (java.awt.SystemColor.systemColors.length) ; i++) {
            java.awt.SystemColor.systemColorObjects[i].value = java.awt.SystemColor.systemColors[i];
        }
    }

    private SystemColor(byte index) {
        super(java.awt.SystemColor.systemColors[index]);
        java.awt.SystemColor.this.index = index;
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[i=") + (index)) + "]";
    }

    private java.lang.Object readResolve() {
        return java.awt.SystemColor.systemColorObjects[value];
    }

    private java.lang.Object writeReplace() throws java.io.ObjectStreamException {
        java.awt.SystemColor color = new java.awt.SystemColor(((byte)(index)));
        color.value = index;
        return color;
    }
}


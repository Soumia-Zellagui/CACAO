package java.awt;


public interface ActiveEvent {
    public void dispatch();
}


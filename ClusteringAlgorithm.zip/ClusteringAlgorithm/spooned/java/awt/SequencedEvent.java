package java.awt;


class SequencedEvent extends java.awt.AWTEvent implements java.awt.ActiveEvent {
    private static final long serialVersionUID = 547742659238625067L;

    private static final int ID = (java.awt.event.FocusEvent.FOCUS_LAST) + 1;

    private static final java.util.LinkedList<java.awt.SequencedEvent> list = new java.util.LinkedList<>();

    private final java.awt.AWTEvent nested;

    private sun.awt.AppContext appContext;

    private boolean disposed;

    static {
        sun.awt.AWTAccessor.setSequencedEventAccessor(new sun.awt.AWTAccessor.SequencedEventAccessor() {
            public java.awt.AWTEvent getNested(java.awt.AWTEvent sequencedEvent) {
                return ((java.awt.SequencedEvent)(sequencedEvent)).nested;
            }

            public boolean isSequencedEvent(java.awt.AWTEvent event) {
                return event instanceof java.awt.SequencedEvent;
            }
        });
    }

    public SequencedEvent(java.awt.AWTEvent nested) {
        super(nested.getSource(), java.awt.SequencedEvent.ID);
        this.nested = nested;
        sun.awt.SunToolkit.setSystemGenerated(nested);
        synchronized(java.awt.SequencedEvent.class) {
            java.awt.SequencedEvent.list.add(java.awt.SequencedEvent.this);
        }
    }

    public final void dispatch() {
        try {
            appContext = sun.awt.AppContext.getAppContext();
            if ((java.awt.SequencedEvent.getFirst()) != (java.awt.SequencedEvent.this)) {
                if (java.awt.EventQueue.isDispatchThread()) {
                    java.awt.EventDispatchThread edt = ((java.awt.EventDispatchThread)(java.lang.Thread.currentThread()));
                    edt.pumpEvents(java.awt.SentEvent.ID, new java.awt.Conditional() {
                        public boolean evaluate() {
                            return !(java.awt.SequencedEvent.this.isFirstOrDisposed());
                        }
                    });
                } else {
                    while (!(isFirstOrDisposed())) {
                        synchronized(java.awt.SequencedEvent.class) {
                            try {
                                java.awt.SequencedEvent.class.wait(1000);
                            } catch (java.lang.InterruptedException e) {
                                break;
                            }
                        }
                    }
                }
            } 
            if (!(disposed)) {
                java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setCurrentSequencedEvent(java.awt.SequencedEvent.this);
                java.awt.Toolkit.getEventQueue().dispatchEvent(nested);
            } 
        } finally {
            dispose();
        }
    }

    private static final boolean isOwnerAppContextDisposed(java.awt.SequencedEvent se) {
        if (se != null) {
            java.lang.Object target = se.nested.getSource();
            if (target instanceof java.awt.Component) {
                return ((java.awt.Component)(target)).appContext.isDisposed();
            } 
        } 
        return false;
    }

    public final boolean isFirstOrDisposed() {
        if (disposed) {
            return true;
        } 
        return ((java.awt.SequencedEvent.this) == (java.awt.SequencedEvent.getFirstWithContext())) || (disposed);
    }

    private static final synchronized java.awt.SequencedEvent getFirst() {
        return ((java.awt.SequencedEvent)(java.awt.SequencedEvent.list.getFirst()));
    }

    private static final java.awt.SequencedEvent getFirstWithContext() {
        java.awt.SequencedEvent first = java.awt.SequencedEvent.getFirst();
        while (java.awt.SequencedEvent.isOwnerAppContextDisposed(first)) {
            first.dispose();
            first = java.awt.SequencedEvent.getFirst();
        }
        return first;
    }

    final void dispose() {
        synchronized(java.awt.SequencedEvent.class) {
            if (disposed) {
                return ;
            } 
            if ((java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getCurrentSequencedEvent()) == (java.awt.SequencedEvent.this)) {
                java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().setCurrentSequencedEvent(null);
            } 
            disposed = true;
        }
        if ((appContext) != null) {
            sun.awt.SunToolkit.postEvent(appContext, new java.awt.SentEvent());
        } 
        java.awt.SequencedEvent next = null;
        synchronized(java.awt.SequencedEvent.class) {
            java.awt.SequencedEvent.class.notifyAll();
            if ((java.awt.SequencedEvent.list.getFirst()) == (java.awt.SequencedEvent.this)) {
                java.awt.SequencedEvent.list.removeFirst();
                if (!(java.awt.SequencedEvent.list.isEmpty())) {
                    next = ((java.awt.SequencedEvent)(java.awt.SequencedEvent.list.getFirst()));
                } 
            } else {
                java.awt.SequencedEvent.list.remove(java.awt.SequencedEvent.this);
            }
        }
        if ((next != null) && ((next.appContext) != null)) {
            sun.awt.SunToolkit.postEvent(next.appContext, new java.awt.SentEvent());
        } 
    }
}


package java.awt;


public final class RadialGradientPaint extends java.awt.MultipleGradientPaint {
    private final java.awt.geom.Point2D focus;

    private final java.awt.geom.Point2D center;

    private final float radius;

    public RadialGradientPaint(float cx ,float cy ,float radius ,float[] fractions ,java.awt.Color[] colors) {
        this(cx, cy, radius, cx, cy, fractions, colors, java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }

    public RadialGradientPaint(java.awt.geom.Point2D center ,float radius ,float[] fractions ,java.awt.Color[] colors) {
        this(center, radius, center, fractions, colors, java.awt.MultipleGradientPaint.CycleMethod.NO_CYCLE);
    }

    public RadialGradientPaint(float cx ,float cy ,float radius ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(cx, cy, radius, cx, cy, fractions, colors, cycleMethod);
    }

    public RadialGradientPaint(java.awt.geom.Point2D center ,float radius ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(center, radius, center, fractions, colors, cycleMethod);
    }

    public RadialGradientPaint(float cx ,float cy ,float radius ,float fx ,float fy ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(new java.awt.geom.Point2D.Float(cx , cy), radius, new java.awt.geom.Point2D.Float(fx , fy), fractions, colors, cycleMethod);
    }

    public RadialGradientPaint(java.awt.geom.Point2D center ,float radius ,java.awt.geom.Point2D focus ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(center, radius, focus, fractions, colors, cycleMethod, java.awt.MultipleGradientPaint.ColorSpaceType.SRGB, new java.awt.geom.AffineTransform());
    }

    @java.beans.ConstructorProperties(value = { "centerPoint" , "radius" , "focusPoint" , "fractions" , "colors" , "cycleMethod" , "colorSpace" , "transform" })
    public RadialGradientPaint(java.awt.geom.Point2D center ,float radius ,java.awt.geom.Point2D focus ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod ,java.awt.MultipleGradientPaint.ColorSpaceType colorSpace ,java.awt.geom.AffineTransform gradientTransform) {
        super(fractions, colors, cycleMethod, colorSpace, gradientTransform);
        if (center == null) {
            throw new java.lang.NullPointerException("Center point must be non-null");
        } 
        if (focus == null) {
            throw new java.lang.NullPointerException("Focus point must be non-null");
        } 
        if (radius <= 0) {
            throw new java.lang.IllegalArgumentException(("Radius must be greater " + "than zero"));
        } 
        this.center = new java.awt.geom.Point2D.Double(center.getX() , center.getY());
        this.focus = new java.awt.geom.Point2D.Double(focus.getX() , focus.getY());
        this.radius = radius;
    }

    public RadialGradientPaint(java.awt.geom.Rectangle2D gradientBounds ,float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
        this(new java.awt.geom.Point2D.Double(gradientBounds.getCenterX() , gradientBounds.getCenterY()), 1.0F, new java.awt.geom.Point2D.Double(gradientBounds.getCenterX() , gradientBounds.getCenterY()), fractions, colors, cycleMethod, java.awt.MultipleGradientPaint.ColorSpaceType.SRGB, java.awt.RadialGradientPaint.createGradientTransform(gradientBounds));
        if (gradientBounds.isEmpty()) {
            throw new java.lang.IllegalArgumentException(("Gradient bounds must be " + "non-empty"));
        } 
    }

    private static java.awt.geom.AffineTransform createGradientTransform(java.awt.geom.Rectangle2D r) {
        double cx = r.getCenterX();
        double cy = r.getCenterY();
        java.awt.geom.AffineTransform xform = java.awt.geom.AffineTransform.getTranslateInstance(cx, cy);
        xform.scale(((r.getWidth()) / 2), ((r.getHeight()) / 2));
        xform.translate((-cx), (-cy));
        return xform;
    }

    public java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds, java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform transform, java.awt.RenderingHints hints) {
        transform = new java.awt.geom.AffineTransform(transform);
        transform.concatenate(gradientTransform);
        return new java.awt.RadialGradientPaintContext(java.awt.RadialGradientPaint.this , cm , deviceBounds , userBounds , transform , hints , ((float)(center.getX())) , ((float)(center.getY())) , radius , ((float)(focus.getX())) , ((float)(focus.getY())) , fractions , colors , cycleMethod , colorSpace);
    }

    public java.awt.geom.Point2D getCenterPoint() {
        return new java.awt.geom.Point2D.Double(center.getX() , center.getY());
    }

    public java.awt.geom.Point2D getFocusPoint() {
        return new java.awt.geom.Point2D.Double(focus.getX() , focus.getY());
    }

    public float getRadius() {
        return radius;
    }
}


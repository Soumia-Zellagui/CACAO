package java.awt;


public interface PrintGraphics {
    public java.awt.PrintJob getPrintJob();
}


package java.awt;


public abstract class Graphics {
    protected Graphics() {
    }

    public abstract java.awt.Graphics create();

    public java.awt.Graphics create(int x, int y, int width, int height) {
        java.awt.Graphics g = create();
        if (g == null)
            return null;
        
        g.translate(x, y);
        g.clipRect(0, 0, width, height);
        return g;
    }

    public abstract void translate(int x, int y);

    public abstract java.awt.Color getColor();

    public abstract void setColor(java.awt.Color c);

    public abstract void setPaintMode();

    public abstract void setXORMode(java.awt.Color c1);

    public abstract java.awt.Font getFont();

    public abstract void setFont(java.awt.Font font);

    public java.awt.FontMetrics getFontMetrics() {
        return getFontMetrics(getFont());
    }

    public abstract java.awt.FontMetrics getFontMetrics(java.awt.Font f);

    public abstract java.awt.Rectangle getClipBounds();

    public abstract void clipRect(int x, int y, int width, int height);

    public abstract void setClip(int x, int y, int width, int height);

    public abstract java.awt.Shape getClip();

    public abstract void setClip(java.awt.Shape clip);

    public abstract void copyArea(int x, int y, int width, int height, int dx, int dy);

    public abstract void drawLine(int x1, int y1, int x2, int y2);

    public abstract void fillRect(int x, int y, int width, int height);

    public void drawRect(int x, int y, int width, int height) {
        if ((width < 0) || (height < 0)) {
            return ;
        } 
        if ((height == 0) || (width == 0)) {
            drawLine(x, y, (x + width), (y + height));
        } else {
            drawLine(x, y, ((x + width) - 1), y);
            drawLine((x + width), y, (x + width), ((y + height) - 1));
            drawLine((x + width), (y + height), (x + 1), (y + height));
            drawLine(x, (y + height), x, (y + 1));
        }
    }

    public abstract void clearRect(int x, int y, int width, int height);

    public abstract void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight);

    public abstract void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight);

    public void draw3DRect(int x, int y, int width, int height, boolean raised) {
        java.awt.Color c = getColor();
        java.awt.Color brighter = c.brighter();
        java.awt.Color darker = c.darker();
        setColor((raised ? brighter : darker));
        drawLine(x, y, x, (y + height));
        drawLine((x + 1), y, ((x + width) - 1), y);
        setColor((raised ? darker : brighter));
        drawLine((x + 1), (y + height), (x + width), (y + height));
        drawLine((x + width), y, (x + width), ((y + height) - 1));
        setColor(c);
    }

    public void fill3DRect(int x, int y, int width, int height, boolean raised) {
        java.awt.Color c = getColor();
        java.awt.Color brighter = c.brighter();
        java.awt.Color darker = c.darker();
        if (!raised) {
            setColor(darker);
        } 
        fillRect((x + 1), (y + 1), (width - 2), (height - 2));
        setColor((raised ? brighter : darker));
        drawLine(x, y, x, ((y + height) - 1));
        drawLine((x + 1), y, ((x + width) - 2), y);
        setColor((raised ? darker : brighter));
        drawLine((x + 1), ((y + height) - 1), ((x + width) - 1), ((y + height) - 1));
        drawLine(((x + width) - 1), y, ((x + width) - 1), ((y + height) - 2));
        setColor(c);
    }

    public abstract void drawOval(int x, int y, int width, int height);

    public abstract void fillOval(int x, int y, int width, int height);

    public abstract void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle);

    public abstract void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle);

    public abstract void drawPolyline(int[] xPoints, int[] yPoints, int nPoints);

    public abstract void drawPolygon(int[] xPoints, int[] yPoints, int nPoints);

    public void drawPolygon(java.awt.Polygon p) {
        drawPolygon(p.xpoints, p.ypoints, p.npoints);
    }

    public abstract void fillPolygon(int[] xPoints, int[] yPoints, int nPoints);

    public void fillPolygon(java.awt.Polygon p) {
        fillPolygon(p.xpoints, p.ypoints, p.npoints);
    }

    public abstract void drawString(java.lang.String str, int x, int y);

    public abstract void drawString(java.text.AttributedCharacterIterator iterator, int x, int y);

    public void drawChars(char[] data, int offset, int length, int x, int y) {
        drawString(new java.lang.String(data , offset , length), x, y);
    }

    public void drawBytes(byte[] data, int offset, int length, int x, int y) {
        drawString(new java.lang.String(data , 0 , offset , length), x, y);
    }

    public abstract boolean drawImage(java.awt.Image img, int x, int y, java.awt.image.ImageObserver observer);

    public abstract boolean drawImage(java.awt.Image img, int x, int y, int width, int height, java.awt.image.ImageObserver observer);

    public abstract boolean drawImage(java.awt.Image img, int x, int y, java.awt.Color bgcolor, java.awt.image.ImageObserver observer);

    public abstract boolean drawImage(java.awt.Image img, int x, int y, int width, int height, java.awt.Color bgcolor, java.awt.image.ImageObserver observer);

    public abstract boolean drawImage(java.awt.Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, java.awt.image.ImageObserver observer);

    public abstract boolean drawImage(java.awt.Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, java.awt.Color bgcolor, java.awt.image.ImageObserver observer);

    public abstract void dispose();

    public void finalize() {
        dispose();
    }

    public java.lang.String toString() {
        return (((((getClass().getName()) + "[font=") + (getFont())) + ",color=") + (getColor())) + "]";
    }

    @java.lang.Deprecated
    public java.awt.Rectangle getClipRect() {
        return getClipBounds();
    }

    public boolean hitClip(int x, int y, int width, int height) {
        java.awt.Rectangle clipRect = getClipBounds();
        if (clipRect == null) {
            return true;
        } 
        return clipRect.intersects(x, y, width, height);
    }

    public java.awt.Rectangle getClipBounds(java.awt.Rectangle r) {
        java.awt.Rectangle clipRect = getClipBounds();
        if (clipRect != null) {
            r.x = clipRect.x;
            r.y = clipRect.y;
            r.width = clipRect.width;
            r.height = clipRect.height;
        } else if (r == null) {
            throw new java.lang.NullPointerException("null rectangle parameter");
        } 
        return r;
    }
}


package java.awt;


public abstract class FocusTraversalPolicy {
    public abstract java.awt.Component getComponentAfter(java.awt.Container aContainer, java.awt.Component aComponent);

    public abstract java.awt.Component getComponentBefore(java.awt.Container aContainer, java.awt.Component aComponent);

    public abstract java.awt.Component getFirstComponent(java.awt.Container aContainer);

    public abstract java.awt.Component getLastComponent(java.awt.Container aContainer);

    public abstract java.awt.Component getDefaultComponent(java.awt.Container aContainer);

    public java.awt.Component getInitialComponent(java.awt.Window window) {
        if (window == null) {
            throw new java.lang.IllegalArgumentException("window cannot be equal to null.");
        } 
        java.awt.Component def = getDefaultComponent(window);
        if ((def == null) && (window.isFocusableWindow())) {
            def = window;
        } 
        return def;
    }
}


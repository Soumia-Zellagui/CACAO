package java.awt;


public class Choice extends java.awt.Component implements java.awt.ItemSelectable , javax.accessibility.Accessible {
    java.util.Vector<java.lang.String> pItems;

    int selectedIndex = -1;

    transient java.awt.event.ItemListener itemListener;

    private static final java.lang.String base = "choice";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -4075310674757313071L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Choice.initIDs();
        } 
    }

    public Choice() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        pItems = new java.util.Vector<>();
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Choice.class) {
            return (java.awt.Choice.base) + ((java.awt.Choice.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createChoice(java.awt.Choice.this);
            
            super.addNotify();
        }
    }

    public int getItemCount() {
        return countItems();
    }

    @java.lang.Deprecated
    public int countItems() {
        return pItems.size();
    }

    public java.lang.String getItem(int index) {
        return getItemImpl(index);
    }

    final java.lang.String getItemImpl(int index) {
        return pItems.elementAt(index);
    }

    public void add(java.lang.String item) {
        addItem(item);
    }

    public void addItem(java.lang.String item) {
        synchronized(java.awt.Choice.this) {
            insertNoInvalidate(item, pItems.size());
        }
        invalidateIfValid();
    }

    private void insertNoInvalidate(java.lang.String item, int index) {
        if (item == null) {
            throw new java.lang.NullPointerException("cannot add null item to Choice");
        } 
        pItems.insertElementAt(item, index);
        java.awt.peer.ChoicePeer peer = ((java.awt.peer.ChoicePeer)(java.awt.Choice.this.peer));
        if (peer != null) {
            peer.add(item, index);
        } 
        if (((selectedIndex) < 0) || ((selectedIndex) >= index)) {
            select(0);
        } 
    }

    public void insert(java.lang.String item, int index) {
        synchronized(java.awt.Choice.this) {
            if (index < 0) {
                throw new java.lang.IllegalArgumentException("index less than zero.");
            } 
            index = java.lang.Math.min(index, pItems.size());
            insertNoInvalidate(item, index);
        }
        invalidateIfValid();
    }

    public void remove(java.lang.String item) {
        synchronized(java.awt.Choice.this) {
            int index = pItems.indexOf(item);
            if (index < 0) {
                throw new java.lang.IllegalArgumentException((("item " + item) + " not found in choice"));
            } else {
                removeNoInvalidate(index);
            }
        }
        invalidateIfValid();
    }

    public void remove(int position) {
        synchronized(java.awt.Choice.this) {
            removeNoInvalidate(position);
        }
        invalidateIfValid();
    }

    private void removeNoInvalidate(int position) {
        pItems.removeElementAt(position);
        java.awt.peer.ChoicePeer peer = ((java.awt.peer.ChoicePeer)(java.awt.Choice.this.peer));
        if (peer != null) {
            peer.remove(position);
        } 
        if ((pItems.size()) == 0) {
            selectedIndex = -1;
        } else if ((selectedIndex) == position) {
            select(0);
        } else if ((selectedIndex) > position) {
            select(((selectedIndex) - 1));
        } 
    }

    public void removeAll() {
        synchronized(java.awt.Choice.this) {
            if ((peer) != null) {
                ((java.awt.peer.ChoicePeer)(peer)).removeAll();
            } 
            pItems.removeAllElements();
            selectedIndex = -1;
        }
        invalidateIfValid();
    }

    public synchronized java.lang.String getSelectedItem() {
        return (selectedIndex) >= 0 ? getItem(selectedIndex) : null;
    }

    public synchronized java.lang.Object[] getSelectedObjects() {
        if ((selectedIndex) >= 0) {
            java.lang.Object[] items = new java.lang.Object[1];
            items[0] = getItem(selectedIndex);
            return items;
        } 
        return null;
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    public synchronized void select(int pos) {
        if ((pos >= (pItems.size())) || (pos < 0)) {
            throw new java.lang.IllegalArgumentException(("illegal Choice item position: " + pos));
        } 
        if ((pItems.size()) > 0) {
            selectedIndex = pos;
            java.awt.peer.ChoicePeer peer = ((java.awt.peer.ChoicePeer)(java.awt.Choice.this.peer));
            if (peer != null) {
                peer.select(pos);
            } 
        } 
    }

    public synchronized void select(java.lang.String str) {
        int index = pItems.indexOf(str);
        if (index >= 0) {
            select(index);
        } 
    }

    public synchronized void addItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.add(itemListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.remove(itemListener, l);
    }

    public synchronized java.awt.event.ItemListener[] getItemListeners() {
        return getListeners(java.awt.event.ItemListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ItemListener.class)) {
            l = itemListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.ItemEvent.ITEM_STATE_CHANGED)) {
            if ((((eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) || ((itemListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ItemEvent) {
            processItemEvent(((java.awt.event.ItemEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processItemEvent(java.awt.event.ItemEvent e) {
        java.awt.event.ItemListener listener = itemListener;
        if (listener != null) {
            listener.itemStateChanged(e);
        } 
    }

    protected java.lang.String paramString() {
        return ((super.paramString()) + ",current=") + (getSelectedItem());
    }

    private int choiceSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.itemListenerK, itemListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.itemListenerK) == key)
                addItemListener(((java.awt.event.ItemListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Choice.AccessibleAWTChoice();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTChoice extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleAction {
        private static final long serialVersionUID = 7175603582428509322L;

        public AccessibleAWTChoice() {
            super();
        }

        public javax.accessibility.AccessibleAction getAccessibleAction() {
            return java.awt.Choice.AccessibleAWTChoice.this;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.COMBO_BOX;
        }

        public int getAccessibleActionCount() {
            return 0;
        }

        public java.lang.String getAccessibleActionDescription(int i) {
            return null;
        }

        public boolean doAccessibleAction(int i) {
            return false;
        }
    }
}


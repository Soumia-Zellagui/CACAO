package java.awt;


public class Label extends java.awt.Component implements javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Label.initIDs();
        } 
    }

    public static final int LEFT = 0;

    public static final int CENTER = 1;

    public static final int RIGHT = 2;

    java.lang.String text;

    int alignment = java.awt.Label.LEFT;

    private static final java.lang.String base = "label";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 3094126758329070636L;

    public Label() throws java.awt.HeadlessException {
        this("", java.awt.Label.LEFT);
    }

    public Label(java.lang.String text) throws java.awt.HeadlessException {
        this(text, java.awt.Label.LEFT);
    }

    public Label(java.lang.String text ,int alignment) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.Label.this.text = text;
        setAlignment(alignment);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Label.class) {
            return (java.awt.Label.base) + ((java.awt.Label.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createLabel(java.awt.Label.this);
            
            super.addNotify();
        }
    }

    public int getAlignment() {
        return alignment;
    }

    public synchronized void setAlignment(int alignment) {
        switch (alignment) {
            case java.awt.Label.LEFT :
            case java.awt.Label.CENTER :
            case java.awt.Label.RIGHT :
                java.awt.Label.this.alignment = alignment;
                java.awt.peer.LabelPeer peer = ((java.awt.peer.LabelPeer)(java.awt.Label.this.peer));
                if (peer != null) {
                    peer.setAlignment(alignment);
                } 
                return ;
        }
        throw new java.lang.IllegalArgumentException(("improper alignment: " + alignment));
    }

    public java.lang.String getText() {
        return text;
    }

    public void setText(java.lang.String text) {
        boolean testvalid = false;
        synchronized(java.awt.Label.this) {
            if ((text != (java.awt.Label.this.text)) && (((java.awt.Label.this.text) == null) || (!(java.awt.Label.this.text.equals(text))))) {
                java.awt.Label.this.text = text;
                java.awt.peer.LabelPeer peer = ((java.awt.peer.LabelPeer)(java.awt.Label.this.peer));
                if (peer != null) {
                    peer.setText(text);
                } 
                testvalid = true;
            } 
        }
        if (testvalid) {
            invalidateIfValid();
        } 
    }

    protected java.lang.String paramString() {
        java.lang.String align = "";
        switch (alignment) {
            case java.awt.Label.LEFT :
                align = "left";
                break;
            case java.awt.Label.CENTER :
                align = "center";
                break;
            case java.awt.Label.RIGHT :
                align = "right";
                break;
        }
        return ((((super.paramString()) + ",align=") + align) + ",text=") + (text);
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Label.AccessibleAWTLabel();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTLabel extends java.awt.Component.AccessibleAWTComponent {
        private static final long serialVersionUID = -3568967560160480438L;

        public AccessibleAWTLabel() {
            super();
        }

        public java.lang.String getAccessibleName() {
            if ((accessibleName) != null) {
                return accessibleName;
            } else {
                if ((getText()) == null) {
                    return super.getAccessibleName();
                } else {
                    return getText();
                }
            }
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.LABEL;
        }
    }
}


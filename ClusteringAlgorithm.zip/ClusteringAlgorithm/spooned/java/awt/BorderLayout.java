package java.awt;


public class BorderLayout implements java.awt.LayoutManager2 , java.io.Serializable {
    int hgap;

    int vgap;

    java.awt.Component north;

    java.awt.Component west;

    java.awt.Component east;

    java.awt.Component south;

    java.awt.Component center;

    java.awt.Component firstLine;

    java.awt.Component lastLine;

    java.awt.Component firstItem;

    java.awt.Component lastItem;

    public static final java.lang.String NORTH = "North";

    public static final java.lang.String SOUTH = "South";

    public static final java.lang.String EAST = "East";

    public static final java.lang.String WEST = "West";

    public static final java.lang.String CENTER = "Center";

    public static final java.lang.String BEFORE_FIRST_LINE = "First";

    public static final java.lang.String AFTER_LAST_LINE = "Last";

    public static final java.lang.String BEFORE_LINE_BEGINS = "Before";

    public static final java.lang.String AFTER_LINE_ENDS = "After";

    public static final java.lang.String PAGE_START = java.awt.BorderLayout.BEFORE_FIRST_LINE;

    public static final java.lang.String PAGE_END = java.awt.BorderLayout.AFTER_LAST_LINE;

    public static final java.lang.String LINE_START = java.awt.BorderLayout.BEFORE_LINE_BEGINS;

    public static final java.lang.String LINE_END = java.awt.BorderLayout.AFTER_LINE_ENDS;

    private static final long serialVersionUID = -8658291919501921765L;

    public BorderLayout() {
        this(0, 0);
    }

    public BorderLayout(int hgap ,int vgap) {
        java.awt.BorderLayout.this.hgap = hgap;
        java.awt.BorderLayout.this.vgap = vgap;
    }

    public int getHgap() {
        return hgap;
    }

    public void setHgap(int hgap) {
        java.awt.BorderLayout.this.hgap = hgap;
    }

    public int getVgap() {
        return vgap;
    }

    public void setVgap(int vgap) {
        java.awt.BorderLayout.this.vgap = vgap;
    }

    public void addLayoutComponent(java.awt.Component comp, java.lang.Object constraints) {
        synchronized(comp.getTreeLock()) {
            if ((constraints == null) || (constraints instanceof java.lang.String)) {
                addLayoutComponent(((java.lang.String)(constraints)), comp);
            } else {
                throw new java.lang.IllegalArgumentException("cannot add to layout: constraint must be a string (or null)");
            }
        }
    }

    @java.lang.Deprecated
    public void addLayoutComponent(java.lang.String name, java.awt.Component comp) {
        synchronized(comp.getTreeLock()) {
            if (name == null) {
                name = "Center";
            } 
            if ("Center".equals(name)) {
                center = comp;
            } else if ("North".equals(name)) {
                north = comp;
            } else if ("South".equals(name)) {
                south = comp;
            } else if ("East".equals(name)) {
                east = comp;
            } else if ("West".equals(name)) {
                west = comp;
            } else if (java.awt.BorderLayout.BEFORE_FIRST_LINE.equals(name)) {
                firstLine = comp;
            } else if (java.awt.BorderLayout.AFTER_LAST_LINE.equals(name)) {
                lastLine = comp;
            } else if (java.awt.BorderLayout.BEFORE_LINE_BEGINS.equals(name)) {
                firstItem = comp;
            } else if (java.awt.BorderLayout.AFTER_LINE_ENDS.equals(name)) {
                lastItem = comp;
            } else {
                throw new java.lang.IllegalArgumentException(("cannot add to layout: unknown constraint: " + name));
            }
        }
    }

    public void removeLayoutComponent(java.awt.Component comp) {
        synchronized(comp.getTreeLock()) {
            if (comp == (center)) {
                center = null;
            } else if (comp == (north)) {
                north = null;
            } else if (comp == (south)) {
                south = null;
            } else if (comp == (east)) {
                east = null;
            } else if (comp == (west)) {
                west = null;
            } 
            if (comp == (firstLine)) {
                firstLine = null;
            } else if (comp == (lastLine)) {
                lastLine = null;
            } else if (comp == (firstItem)) {
                firstItem = null;
            } else if (comp == (lastItem)) {
                lastItem = null;
            } 
        }
    }

    public java.awt.Component getLayoutComponent(java.lang.Object constraints) {
        if (java.awt.BorderLayout.CENTER.equals(constraints)) {
            return center;
        } else if (java.awt.BorderLayout.NORTH.equals(constraints)) {
            return north;
        } else if (java.awt.BorderLayout.SOUTH.equals(constraints)) {
            return south;
        } else if (java.awt.BorderLayout.WEST.equals(constraints)) {
            return west;
        } else if (java.awt.BorderLayout.EAST.equals(constraints)) {
            return east;
        } else if (java.awt.BorderLayout.PAGE_START.equals(constraints)) {
            return firstLine;
        } else if (java.awt.BorderLayout.PAGE_END.equals(constraints)) {
            return lastLine;
        } else if (java.awt.BorderLayout.LINE_START.equals(constraints)) {
            return firstItem;
        } else if (java.awt.BorderLayout.LINE_END.equals(constraints)) {
            return lastItem;
        } else {
            throw new java.lang.IllegalArgumentException(("cannot get component: unknown constraint: " + constraints));
        }
    }

    public java.awt.Component getLayoutComponent(java.awt.Container target, java.lang.Object constraints) {
        boolean ltr = target.getComponentOrientation().isLeftToRight();
        java.awt.Component result = null;
        if (java.awt.BorderLayout.NORTH.equals(constraints)) {
            result = (firstLine) != null ? firstLine : north;
        } else if (java.awt.BorderLayout.SOUTH.equals(constraints)) {
            result = (lastLine) != null ? lastLine : south;
        } else if (java.awt.BorderLayout.WEST.equals(constraints)) {
            result = ltr ? firstItem : lastItem;
            if (result == null) {
                result = west;
            } 
        } else if (java.awt.BorderLayout.EAST.equals(constraints)) {
            result = ltr ? lastItem : firstItem;
            if (result == null) {
                result = east;
            } 
        } else if (java.awt.BorderLayout.CENTER.equals(constraints)) {
            result = center;
        } else {
            throw new java.lang.IllegalArgumentException(("cannot get component: invalid constraint: " + constraints));
        }
        return result;
    }

    public java.lang.Object getConstraints(java.awt.Component comp) {
        if (comp == null) {
            return null;
        } 
        if (comp == (center)) {
            return java.awt.BorderLayout.CENTER;
        } else if (comp == (north)) {
            return java.awt.BorderLayout.NORTH;
        } else if (comp == (south)) {
            return java.awt.BorderLayout.SOUTH;
        } else if (comp == (west)) {
            return java.awt.BorderLayout.WEST;
        } else if (comp == (east)) {
            return java.awt.BorderLayout.EAST;
        } else if (comp == (firstLine)) {
            return java.awt.BorderLayout.PAGE_START;
        } else if (comp == (lastLine)) {
            return java.awt.BorderLayout.PAGE_END;
        } else if (comp == (firstItem)) {
            return java.awt.BorderLayout.LINE_START;
        } else if (comp == (lastItem)) {
            return java.awt.BorderLayout.LINE_END;
        } 
        return null;
    }

    public java.awt.Dimension minimumLayoutSize(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            java.awt.Dimension dim = new java.awt.Dimension(0 , 0);
            boolean ltr = target.getComponentOrientation().isLeftToRight();
            java.awt.Component c = null;
            if ((c = getChild(java.awt.BorderLayout.EAST, ltr)) != null) {
                java.awt.Dimension d = c.getMinimumSize();
                dim.width += (d.width) + (hgap);
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.WEST, ltr)) != null) {
                java.awt.Dimension d = c.getMinimumSize();
                dim.width += (d.width) + (hgap);
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.CENTER, ltr)) != null) {
                java.awt.Dimension d = c.getMinimumSize();
                dim.width += d.width;
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.NORTH, ltr)) != null) {
                java.awt.Dimension d = c.getMinimumSize();
                dim.width = java.lang.Math.max(d.width, dim.width);
                dim.height += (d.height) + (vgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.SOUTH, ltr)) != null) {
                java.awt.Dimension d = c.getMinimumSize();
                dim.width = java.lang.Math.max(d.width, dim.width);
                dim.height += (d.height) + (vgap);
            } 
            java.awt.Insets insets = target.getInsets();
            dim.width += (insets.left) + (insets.right);
            dim.height += (insets.top) + (insets.bottom);
            return dim;
        }
    }

    public java.awt.Dimension preferredLayoutSize(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            java.awt.Dimension dim = new java.awt.Dimension(0 , 0);
            boolean ltr = target.getComponentOrientation().isLeftToRight();
            java.awt.Component c = null;
            if ((c = getChild(java.awt.BorderLayout.EAST, ltr)) != null) {
                java.awt.Dimension d = c.getPreferredSize();
                dim.width += (d.width) + (hgap);
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.WEST, ltr)) != null) {
                java.awt.Dimension d = c.getPreferredSize();
                dim.width += (d.width) + (hgap);
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.CENTER, ltr)) != null) {
                java.awt.Dimension d = c.getPreferredSize();
                dim.width += d.width;
                dim.height = java.lang.Math.max(d.height, dim.height);
            } 
            if ((c = getChild(java.awt.BorderLayout.NORTH, ltr)) != null) {
                java.awt.Dimension d = c.getPreferredSize();
                dim.width = java.lang.Math.max(d.width, dim.width);
                dim.height += (d.height) + (vgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.SOUTH, ltr)) != null) {
                java.awt.Dimension d = c.getPreferredSize();
                dim.width = java.lang.Math.max(d.width, dim.width);
                dim.height += (d.height) + (vgap);
            } 
            java.awt.Insets insets = target.getInsets();
            dim.width += (insets.left) + (insets.right);
            dim.height += (insets.top) + (insets.bottom);
            return dim;
        }
    }

    public java.awt.Dimension maximumLayoutSize(java.awt.Container target) {
        return new java.awt.Dimension(java.lang.Integer.MAX_VALUE , java.lang.Integer.MAX_VALUE);
    }

    public float getLayoutAlignmentX(java.awt.Container parent) {
        return 0.5F;
    }

    public float getLayoutAlignmentY(java.awt.Container parent) {
        return 0.5F;
    }

    public void invalidateLayout(java.awt.Container target) {
    }

    public void layoutContainer(java.awt.Container target) {
        synchronized(target.getTreeLock()) {
            java.awt.Insets insets = target.getInsets();
            int top = insets.top;
            int bottom = (target.height) - (insets.bottom);
            int left = insets.left;
            int right = (target.width) - (insets.right);
            boolean ltr = target.getComponentOrientation().isLeftToRight();
            java.awt.Component c = null;
            if ((c = getChild(java.awt.BorderLayout.NORTH, ltr)) != null) {
                c.setSize((right - left), c.height);
                java.awt.Dimension d = c.getPreferredSize();
                c.setBounds(left, top, (right - left), d.height);
                top += (d.height) + (vgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.SOUTH, ltr)) != null) {
                c.setSize((right - left), c.height);
                java.awt.Dimension d = c.getPreferredSize();
                c.setBounds(left, (bottom - (d.height)), (right - left), d.height);
                bottom -= (d.height) + (vgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.EAST, ltr)) != null) {
                c.setSize(c.width, (bottom - top));
                java.awt.Dimension d = c.getPreferredSize();
                c.setBounds((right - (d.width)), top, d.width, (bottom - top));
                right -= (d.width) + (hgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.WEST, ltr)) != null) {
                c.setSize(c.width, (bottom - top));
                java.awt.Dimension d = c.getPreferredSize();
                c.setBounds(left, top, d.width, (bottom - top));
                left += (d.width) + (hgap);
            } 
            if ((c = getChild(java.awt.BorderLayout.CENTER, ltr)) != null) {
                c.setBounds(left, top, (right - left), (bottom - top));
            } 
        }
    }

    private java.awt.Component getChild(java.lang.String key, boolean ltr) {
        java.awt.Component result = null;
        if (key == (java.awt.BorderLayout.NORTH)) {
            result = (firstLine) != null ? firstLine : north;
        } else if (key == (java.awt.BorderLayout.SOUTH)) {
            result = (lastLine) != null ? lastLine : south;
        } else if (key == (java.awt.BorderLayout.WEST)) {
            result = ltr ? firstItem : lastItem;
            if (result == null) {
                result = west;
            } 
        } else if (key == (java.awt.BorderLayout.EAST)) {
            result = ltr ? lastItem : firstItem;
            if (result == null) {
                result = east;
            } 
        } else if (key == (java.awt.BorderLayout.CENTER)) {
            result = center;
        } 
        if ((result != null) && (!(result.visible))) {
            result = null;
        } 
        return result;
    }

    public java.lang.String toString() {
        return (((((getClass().getName()) + "[hgap=") + (hgap)) + ",vgap=") + (vgap)) + "]";
    }
}


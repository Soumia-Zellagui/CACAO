package java.awt;


abstract class ModalEventFilter implements java.awt.EventFilter {
    protected java.awt.Dialog modalDialog;

    protected boolean disabled;

    protected ModalEventFilter(java.awt.Dialog modalDialog) {
        java.awt.ModalEventFilter.this.modalDialog = modalDialog;
        disabled = false;
    }

    java.awt.Dialog getModalDialog() {
        return modalDialog;
    }

    public java.awt.EventFilter.FilterAction acceptEvent(java.awt.AWTEvent event) {
        if ((disabled) || (!(modalDialog.isVisible()))) {
            return java.awt.EventFilter.FilterAction.ACCEPT;
        } 
        int eventID = event.getID();
        if ((((eventID >= (java.awt.event.MouseEvent.MOUSE_FIRST)) && (eventID <= (java.awt.event.MouseEvent.MOUSE_LAST))) || ((eventID >= (java.awt.event.ActionEvent.ACTION_FIRST)) && (eventID <= (java.awt.event.ActionEvent.ACTION_LAST)))) || (eventID == (java.awt.event.WindowEvent.WINDOW_CLOSING))) {
            java.lang.Object o = event.getSource();
            if (o instanceof sun.awt.ModalExclude) {
            } else if (o instanceof java.awt.Component) {
                java.awt.Component c = ((java.awt.Component)(o));
                while ((c != null) && (!(c instanceof java.awt.Window))) {
                    c = c.getParent_NoClientCode();
                }
                if (c != null) {
                    return acceptWindow(((java.awt.Window)(c)));
                } 
            } 
        } 
        return java.awt.EventFilter.FilterAction.ACCEPT;
    }

    protected abstract java.awt.EventFilter.FilterAction acceptWindow(java.awt.Window w);

    void disable() {
        disabled = true;
    }

    int compareTo(java.awt.ModalEventFilter another) {
        java.awt.Dialog anotherDialog = another.getModalDialog();
        java.awt.Component c = modalDialog;
        while (c != null) {
            if (c == anotherDialog) {
                return 1;
            } 
            c = c.getParent_NoClientCode();
        }
        c = anotherDialog;
        while (c != null) {
            if (c == (modalDialog)) {
                return -1;
            } 
            c = c.getParent_NoClientCode();
        }
        java.awt.Dialog blocker = modalDialog.getModalBlocker();
        while (blocker != null) {
            if (blocker == anotherDialog) {
                return -1;
            } 
            blocker = blocker.getModalBlocker();
        }
        blocker = anotherDialog.getModalBlocker();
        while (blocker != null) {
            if (blocker == (modalDialog)) {
                return 1;
            } 
            blocker = blocker.getModalBlocker();
        }
        return modalDialog.getModalityType().compareTo(anotherDialog.getModalityType());
    }

    static java.awt.ModalEventFilter createFilterForDialog(java.awt.Dialog modalDialog) {
        switch (modalDialog.getModalityType()) {
            case DOCUMENT_MODAL :
                return new java.awt.ModalEventFilter.DocumentModalEventFilter(modalDialog);
            case APPLICATION_MODAL :
                return new java.awt.ModalEventFilter.ApplicationModalEventFilter(modalDialog);
            case TOOLKIT_MODAL :
                return new java.awt.ModalEventFilter.ToolkitModalEventFilter(modalDialog);
        }
        return null;
    }

    private static class ToolkitModalEventFilter extends java.awt.ModalEventFilter {
        private sun.awt.AppContext appContext;

        ToolkitModalEventFilter(java.awt.Dialog modalDialog) {
            super(modalDialog);
            appContext = modalDialog.appContext;
        }

        protected java.awt.EventFilter.FilterAction acceptWindow(java.awt.Window w) {
            if (w.isModalExcluded(java.awt.Dialog.ModalExclusionType.TOOLKIT_EXCLUDE)) {
                return java.awt.EventFilter.FilterAction.ACCEPT;
            } 
            if ((w.appContext) != (appContext)) {
                return java.awt.EventFilter.FilterAction.REJECT;
            } 
            while (w != null) {
                if (w == (modalDialog)) {
                    return java.awt.EventFilter.FilterAction.ACCEPT_IMMEDIATELY;
                } 
                w = w.getOwner();
            }
            return java.awt.EventFilter.FilterAction.REJECT;
        }
    }

    private static class ApplicationModalEventFilter extends java.awt.ModalEventFilter {
        private sun.awt.AppContext appContext;

        ApplicationModalEventFilter(java.awt.Dialog modalDialog) {
            super(modalDialog);
            appContext = modalDialog.appContext;
        }

        protected java.awt.EventFilter.FilterAction acceptWindow(java.awt.Window w) {
            if (w.isModalExcluded(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE)) {
                return java.awt.EventFilter.FilterAction.ACCEPT;
            } 
            if ((w.appContext) == (appContext)) {
                while (w != null) {
                    if (w == (modalDialog)) {
                        return java.awt.EventFilter.FilterAction.ACCEPT_IMMEDIATELY;
                    } 
                    w = w.getOwner();
                }
                return java.awt.EventFilter.FilterAction.REJECT;
            } 
            return java.awt.EventFilter.FilterAction.ACCEPT;
        }
    }

    private static class DocumentModalEventFilter extends java.awt.ModalEventFilter {
        private java.awt.Window documentRoot;

        DocumentModalEventFilter(java.awt.Dialog modalDialog) {
            super(modalDialog);
            documentRoot = modalDialog.getDocumentRoot();
        }

        protected java.awt.EventFilter.FilterAction acceptWindow(java.awt.Window w) {
            if (w.isModalExcluded(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE)) {
                java.awt.Window w1 = modalDialog.getOwner();
                while (w1 != null) {
                    if (w1 == w) {
                        return java.awt.EventFilter.FilterAction.REJECT;
                    } 
                    w1 = w1.getOwner();
                }
                return java.awt.EventFilter.FilterAction.ACCEPT;
            } 
            while (w != null) {
                if (w == (modalDialog)) {
                    return java.awt.EventFilter.FilterAction.ACCEPT_IMMEDIATELY;
                } 
                if (w == (documentRoot)) {
                    return java.awt.EventFilter.FilterAction.REJECT;
                } 
                w = w.getOwner();
            }
            return java.awt.EventFilter.FilterAction.ACCEPT;
        }
    }
}


package java.awt;


public class FileDialog extends java.awt.Dialog {
    public static final int LOAD = 0;

    public static final int SAVE = 1;

    int mode;

    java.lang.String dir;

    java.lang.String file;

    private java.io.File[] files;

    private boolean multipleMode = false;

    java.io.FilenameFilter filter;

    private static final java.lang.String base = "filedlg";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 5035145889651310422L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.FileDialog.initIDs();
        } 
    }

    static {
        sun.awt.AWTAccessor.setFileDialogAccessor(new sun.awt.AWTAccessor.FileDialogAccessor() {
            public void setFiles(java.awt.FileDialog fileDialog, java.io.File[] files) {
                fileDialog.setFiles(files);
            }

            public void setFile(java.awt.FileDialog fileDialog, java.lang.String file) {
                fileDialog.file = "".equals(file) ? null : file;
            }

            public void setDirectory(java.awt.FileDialog fileDialog, java.lang.String directory) {
                fileDialog.dir = "".equals(directory) ? null : directory;
            }

            public boolean isMultipleMode(java.awt.FileDialog fileDialog) {
                synchronized(fileDialog.getObjectLock()) {
                    return fileDialog.multipleMode;
                }
            }
        });
    }

    private static native void initIDs();

    public FileDialog(java.awt.Frame parent) {
        this(parent, "", java.awt.FileDialog.LOAD);
    }

    public FileDialog(java.awt.Frame parent ,java.lang.String title) {
        this(parent, title, java.awt.FileDialog.LOAD);
    }

    public FileDialog(java.awt.Frame parent ,java.lang.String title ,int mode) {
        super(parent, title, true);
        java.awt.FileDialog.this.setMode(mode);
        setLayout(null);
    }

    public FileDialog(java.awt.Dialog parent) {
        this(parent, "", java.awt.FileDialog.LOAD);
    }

    public FileDialog(java.awt.Dialog parent ,java.lang.String title) {
        this(parent, title, java.awt.FileDialog.LOAD);
    }

    public FileDialog(java.awt.Dialog parent ,java.lang.String title ,int mode) {
        super(parent, title, true);
        java.awt.FileDialog.this.setMode(mode);
        setLayout(null);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.FileDialog.class) {
            return (java.awt.FileDialog.base) + ((java.awt.FileDialog.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if (((parent) != null) && ((parent.getPeer()) == null)) {
                parent.addNotify();
            } 
            if ((peer) == null)
                peer = getToolkit().createFileDialog(java.awt.FileDialog.this);
            
            super.addNotify();
        }
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        switch (mode) {
            case java.awt.FileDialog.LOAD :
            case java.awt.FileDialog.SAVE :
                java.awt.FileDialog.this.mode = mode;
                break;
            default :
                throw new java.lang.IllegalArgumentException("illegal file dialog mode");
        }
    }

    public java.lang.String getDirectory() {
        return dir;
    }

    public void setDirectory(java.lang.String dir) {
        java.awt.FileDialog.this.dir = (dir != null) && (dir.equals("")) ? null : dir;
        java.awt.peer.FileDialogPeer peer = ((java.awt.peer.FileDialogPeer)(java.awt.FileDialog.this.peer));
        if (peer != null) {
            peer.setDirectory(java.awt.FileDialog.this.dir);
        } 
    }

    public java.lang.String getFile() {
        return file;
    }

    public java.io.File[] getFiles() {
        synchronized(getObjectLock()) {
            if ((files) != null) {
                return files.clone();
            } else {
                return new java.io.File[0];
            }
        }
    }

    private void setFiles(java.io.File[] files) {
        synchronized(getObjectLock()) {
            java.awt.FileDialog.this.files = files;
        }
    }

    public void setFile(java.lang.String file) {
        java.awt.FileDialog.this.file = (file != null) && (file.equals("")) ? null : file;
        java.awt.peer.FileDialogPeer peer = ((java.awt.peer.FileDialogPeer)(java.awt.FileDialog.this.peer));
        if (peer != null) {
            peer.setFile(java.awt.FileDialog.this.file);
        } 
    }

    public void setMultipleMode(boolean enable) {
        synchronized(getObjectLock()) {
            java.awt.FileDialog.this.multipleMode = enable;
        }
    }

    public boolean isMultipleMode() {
        synchronized(getObjectLock()) {
            return multipleMode;
        }
    }

    public java.io.FilenameFilter getFilenameFilter() {
        return filter;
    }

    public synchronized void setFilenameFilter(java.io.FilenameFilter filter) {
        java.awt.FileDialog.this.filter = filter;
        java.awt.peer.FileDialogPeer peer = ((java.awt.peer.FileDialogPeer)(java.awt.FileDialog.this.peer));
        if (peer != null) {
            peer.setFilenameFilter(filter);
        } 
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if (((dir) != null) && (dir.equals(""))) {
            dir = null;
        } 
        if (((file) != null) && (file.equals(""))) {
            file = null;
        } 
    }

    protected java.lang.String paramString() {
        java.lang.String str = super.paramString();
        str += ",dir= " + (dir);
        str += ",file= " + (file);
        return str + ((mode) == (java.awt.FileDialog.LOAD) ? ",load" : ",save");
    }

    boolean postsOldMouseEvents() {
        return false;
    }
}


package java.awt;


public class MenuBar extends java.awt.MenuComponent implements java.awt.MenuContainer , javax.accessibility.Accessible {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.MenuBar.initIDs();
        } 
        sun.awt.AWTAccessor.setMenuBarAccessor(new sun.awt.AWTAccessor.MenuBarAccessor() {
            public java.awt.Menu getHelpMenu(java.awt.MenuBar menuBar) {
                return menuBar.helpMenu;
            }

            public java.util.Vector<java.awt.Menu> getMenus(java.awt.MenuBar menuBar) {
                return menuBar.menus;
            }
        });
    }

    java.util.Vector<java.awt.Menu> menus = new java.util.Vector<>();

    java.awt.Menu helpMenu;

    private static final java.lang.String base = "menubar";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -4930327919388951260L;

    public MenuBar() throws java.awt.HeadlessException {
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.MenuBar.class) {
            return (java.awt.MenuBar.base) + ((java.awt.MenuBar.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = java.awt.Toolkit.getDefaultToolkit().createMenuBar(java.awt.MenuBar.this);
            
            int nmenus = getMenuCount();
            for (int i = 0 ; i < nmenus ; i++) {
                getMenu(i).addNotify();
            }
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            int nmenus = getMenuCount();
            for (int i = 0 ; i < nmenus ; i++) {
                getMenu(i).removeNotify();
            }
            super.removeNotify();
        }
    }

    public java.awt.Menu getHelpMenu() {
        return helpMenu;
    }

    public void setHelpMenu(final java.awt.Menu m) {
        synchronized(getTreeLock()) {
            if ((helpMenu) == m) {
                return ;
            } 
            if ((helpMenu) != null) {
                remove(helpMenu);
            } 
            helpMenu = m;
            if (m != null) {
                if ((m.parent) != (java.awt.MenuBar.this)) {
                    add(m);
                } 
                m.isHelpMenu = true;
                m.parent = java.awt.MenuBar.this;
                java.awt.peer.MenuBarPeer peer = ((java.awt.peer.MenuBarPeer)(java.awt.MenuBar.this.peer));
                if (peer != null) {
                    if ((m.peer) == null) {
                        m.addNotify();
                    } 
                    peer.addHelpMenu(m);
                } 
            } 
        }
    }

    public java.awt.Menu add(java.awt.Menu m) {
        synchronized(getTreeLock()) {
            if ((m.parent) != null) {
                m.parent.remove(m);
            } 
            menus.addElement(m);
            m.parent = java.awt.MenuBar.this;
            java.awt.peer.MenuBarPeer peer = ((java.awt.peer.MenuBarPeer)(java.awt.MenuBar.this.peer));
            if (peer != null) {
                if ((m.peer) == null) {
                    m.addNotify();
                } 
                peer.addMenu(m);
            } 
            return m;
        }
    }

    public void remove(final int index) {
        synchronized(getTreeLock()) {
            java.awt.Menu m = getMenu(index);
            menus.removeElementAt(index);
            java.awt.peer.MenuBarPeer peer = ((java.awt.peer.MenuBarPeer)(java.awt.MenuBar.this.peer));
            if (peer != null) {
                m.removeNotify();
                m.parent = null;
                peer.delMenu(index);
            } 
            if ((helpMenu) == m) {
                helpMenu = null;
                m.isHelpMenu = false;
            } 
        }
    }

    public void remove(java.awt.MenuComponent m) {
        synchronized(getTreeLock()) {
            int index = menus.indexOf(m);
            if (index >= 0) {
                remove(index);
            } 
        }
    }

    public int getMenuCount() {
        return countMenus();
    }

    @java.lang.Deprecated
    public int countMenus() {
        return getMenuCountImpl();
    }

    final int getMenuCountImpl() {
        return menus.size();
    }

    public java.awt.Menu getMenu(int i) {
        return getMenuImpl(i);
    }

    final java.awt.Menu getMenuImpl(int i) {
        return menus.elementAt(i);
    }

    public synchronized java.util.Enumeration<java.awt.MenuShortcut> shortcuts() {
        java.util.Vector<java.awt.MenuShortcut> shortcuts = new java.util.Vector<>();
        int nmenus = getMenuCount();
        for (int i = 0 ; i < nmenus ; i++) {
            java.util.Enumeration<java.awt.MenuShortcut> e = getMenu(i).shortcuts();
            while (e.hasMoreElements()) {
                shortcuts.addElement(e.nextElement());
            }
        }
        return shortcuts.elements();
    }

    public java.awt.MenuItem getShortcutMenuItem(java.awt.MenuShortcut s) {
        int nmenus = getMenuCount();
        for (int i = 0 ; i < nmenus ; i++) {
            java.awt.MenuItem mi = getMenu(i).getShortcutMenuItem(s);
            if (mi != null) {
                return mi;
            } 
        }
        return null;
    }

    boolean handleShortcut(java.awt.event.KeyEvent e) {
        int id = e.getID();
        if ((id != (java.awt.event.KeyEvent.KEY_PRESSED)) && (id != (java.awt.event.KeyEvent.KEY_RELEASED))) {
            return false;
        } 
        int accelKey = java.awt.Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
        if (((e.getModifiers()) & accelKey) == 0) {
            return false;
        } 
        int nmenus = getMenuCount();
        for (int i = 0 ; i < nmenus ; i++) {
            java.awt.Menu m = getMenu(i);
            if (m.handleShortcut(e)) {
                return true;
            } 
        }
        return false;
    }

    public void deleteShortcut(java.awt.MenuShortcut s) {
        int nmenus = getMenuCount();
        for (int i = 0 ; i < nmenus ; i++) {
            getMenu(i).deleteShortcut(s);
        }
    }

    private int menuBarSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultWriteObject();
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        for (int i = 0 ; i < (menus.size()) ; i++) {
            java.awt.Menu m = menus.elementAt(i);
            m.parent = java.awt.MenuBar.this;
        }
    }

    private static native void initIDs();

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.MenuBar.AccessibleAWTMenuBar();
        } 
        return accessibleContext;
    }

    int getAccessibleChildIndex(java.awt.MenuComponent child) {
        return menus.indexOf(child);
    }

    protected class AccessibleAWTMenuBar extends java.awt.MenuComponent.AccessibleAWTMenuComponent {
        private static final long serialVersionUID = -8577604491830083815L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.MENU_BAR;
        }
    }
}


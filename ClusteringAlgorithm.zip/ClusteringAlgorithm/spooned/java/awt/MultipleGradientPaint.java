package java.awt;


public abstract class MultipleGradientPaint implements java.awt.Paint {
    public static enum CycleMethod {
NO_CYCLE, REFLECT, REPEAT;    }

    public static enum ColorSpaceType {
SRGB, LINEAR_RGB;    }

    final int transparency;

    final float[] fractions;

    final java.awt.Color[] colors;

    final java.awt.geom.AffineTransform gradientTransform;

    final java.awt.MultipleGradientPaint.CycleMethod cycleMethod;

    final java.awt.MultipleGradientPaint.ColorSpaceType colorSpace;

    java.awt.image.ColorModel model;

    float[] normalizedIntervals;

    boolean isSimpleLookup;

    java.lang.ref.SoftReference<int[][]> gradients;

    java.lang.ref.SoftReference<int[]> gradient;

    int fastGradientArraySize;

    MultipleGradientPaint(float[] fractions ,java.awt.Color[] colors ,java.awt.MultipleGradientPaint.CycleMethod cycleMethod ,java.awt.MultipleGradientPaint.ColorSpaceType colorSpace ,java.awt.geom.AffineTransform gradientTransform) {
        if (fractions == null) {
            throw new java.lang.NullPointerException("Fractions array cannot be null");
        } 
        if (colors == null) {
            throw new java.lang.NullPointerException("Colors array cannot be null");
        } 
        if (cycleMethod == null) {
            throw new java.lang.NullPointerException("Cycle method cannot be null");
        } 
        if (colorSpace == null) {
            throw new java.lang.NullPointerException("Color space cannot be null");
        } 
        if (gradientTransform == null) {
            throw new java.lang.NullPointerException(("Gradient transform cannot be " + "null"));
        } 
        if ((fractions.length) != (colors.length)) {
            throw new java.lang.IllegalArgumentException(("Colors and fractions must " + "have equal size"));
        } 
        if ((colors.length) < 2) {
            throw new java.lang.IllegalArgumentException(("User must specify at least " + "2 colors"));
        } 
        float previousFraction = -1.0F;
        for (float currentFraction : fractions) {
            if ((currentFraction < 0.0F) || (currentFraction > 1.0F)) {
                throw new java.lang.IllegalArgumentException((("Fraction values must " + "be in the range 0 to 1: ") + currentFraction));
            } 
            if (currentFraction <= previousFraction) {
                throw new java.lang.IllegalArgumentException((("Keyframe fractions " + "must be increasing: ") + currentFraction));
            } 
            previousFraction = currentFraction;
        }
        boolean fixFirst = false;
        boolean fixLast = false;
        int len = fractions.length;
        int off = 0;
        if ((fractions[0]) != 0.0F) {
            fixFirst = true;
            len++;
            off++;
        } 
        if ((fractions[((fractions.length) - 1)]) != 1.0F) {
            fixLast = true;
            len++;
        } 
        this.fractions = new float[len];
        java.lang.System.arraycopy(fractions, 0, java.awt.MultipleGradientPaint.this.fractions, off, fractions.length);
        this.colors = new java.awt.Color[len];
        java.lang.System.arraycopy(colors, 0, java.awt.MultipleGradientPaint.this.colors, off, colors.length);
        if (fixFirst) {
            java.awt.MultipleGradientPaint.this.fractions[0] = 0.0F;
            java.awt.MultipleGradientPaint.this.colors[0] = colors[0];
        } 
        if (fixLast) {
            java.awt.MultipleGradientPaint.this.fractions[(len - 1)] = 1.0F;
            java.awt.MultipleGradientPaint.this.colors[(len - 1)] = colors[((colors.length) - 1)];
        } 
        this.colorSpace = colorSpace;
        this.cycleMethod = cycleMethod;
        this.gradientTransform = new java.awt.geom.AffineTransform(gradientTransform);
        boolean opaque = true;
        for (int i = 0 ; i < (colors.length) ; i++) {
            opaque = opaque && ((colors[i].getAlpha()) == 255);
        }
        this.transparency = opaque ? java.awt.Transparency.OPAQUE : java.awt.Transparency.TRANSLUCENT;
    }

    public final float[] getFractions() {
        return java.util.Arrays.copyOf(fractions, fractions.length);
    }

    public final java.awt.Color[] getColors() {
        return java.util.Arrays.copyOf(colors, colors.length);
    }

    public final java.awt.MultipleGradientPaint.CycleMethod getCycleMethod() {
        return cycleMethod;
    }

    public final java.awt.MultipleGradientPaint.ColorSpaceType getColorSpace() {
        return colorSpace;
    }

    public final java.awt.geom.AffineTransform getTransform() {
        return new java.awt.geom.AffineTransform(gradientTransform);
    }

    public final int getTransparency() {
        return transparency;
    }
}


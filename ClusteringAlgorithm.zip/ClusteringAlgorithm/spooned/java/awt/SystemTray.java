package java.awt;


public class SystemTray {
    private static java.awt.SystemTray systemTray;

    private int currentIconID = 0;

    private transient java.awt.peer.SystemTrayPeer peer;

    private static final java.awt.TrayIcon[] EMPTY_TRAY_ARRAY = new java.awt.TrayIcon[0];

    static {
        sun.awt.AWTAccessor.setSystemTrayAccessor(new sun.awt.AWTAccessor.SystemTrayAccessor() {
            public void firePropertyChange(java.awt.SystemTray tray, java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue) {
                tray.firePropertyChange(propertyName, oldValue, newValue);
            }
        });
    }

    private SystemTray() {
        addNotify();
    }

    public static java.awt.SystemTray getSystemTray() {
        java.awt.SystemTray.checkSystemTrayAllowed();
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        java.awt.SystemTray.initializeSystemTrayIfNeeded();
        if (!(java.awt.SystemTray.isSupported())) {
            throw new java.lang.UnsupportedOperationException("The system tray is not supported on the current platform.");
        } 
        return java.awt.SystemTray.systemTray;
    }

    public static boolean isSupported() {
        java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        if (toolkit instanceof sun.awt.SunToolkit) {
            java.awt.SystemTray.initializeSystemTrayIfNeeded();
            return ((sun.awt.SunToolkit)(toolkit)).isTraySupported();
        } else if (toolkit instanceof sun.awt.HeadlessToolkit) {
            return ((sun.awt.HeadlessToolkit)(toolkit)).isTraySupported();
        } else {
            return false;
        }
    }

    public void add(java.awt.TrayIcon trayIcon) throws java.awt.AWTException {
        if (trayIcon == null) {
            throw new java.lang.NullPointerException("adding null TrayIcon");
        } 
        java.awt.TrayIcon[] oldArray = null;
        java.awt.TrayIcon[] newArray = null;
        java.util.Vector<java.awt.TrayIcon> icons = null;
        synchronized(java.awt.SystemTray.this) {
            oldArray = java.awt.SystemTray.systemTray.getTrayIcons();
            icons = ((java.util.Vector<java.awt.TrayIcon>)(sun.awt.AppContext.getAppContext().get(java.awt.TrayIcon.class)));
            if (icons == null) {
                icons = new java.util.Vector<java.awt.TrayIcon>(3);
                sun.awt.AppContext.getAppContext().put(java.awt.TrayIcon.class, icons);
            } else if (icons.contains(trayIcon)) {
                throw new java.lang.IllegalArgumentException("adding TrayIcon that is already added");
            } 
            icons.add(trayIcon);
            newArray = java.awt.SystemTray.systemTray.getTrayIcons();
            trayIcon.setID((++(currentIconID)));
        }
        try {
            trayIcon.addNotify();
        } catch (java.awt.AWTException e) {
            icons.remove(trayIcon);
            throw e;
        }
        firePropertyChange("trayIcons", oldArray, newArray);
    }

    public void remove(java.awt.TrayIcon trayIcon) {
        if (trayIcon == null) {
            return ;
        } 
        java.awt.TrayIcon[] oldArray = null;
        java.awt.TrayIcon[] newArray = null;
        synchronized(java.awt.SystemTray.this) {
            oldArray = java.awt.SystemTray.systemTray.getTrayIcons();
            java.util.Vector<java.awt.TrayIcon> icons = ((java.util.Vector<java.awt.TrayIcon>)(sun.awt.AppContext.getAppContext().get(java.awt.TrayIcon.class)));
            if ((icons == null) || (!(icons.remove(trayIcon)))) {
                return ;
            } 
            trayIcon.removeNotify();
            newArray = java.awt.SystemTray.systemTray.getTrayIcons();
        }
        firePropertyChange("trayIcons", oldArray, newArray);
    }

    public java.awt.TrayIcon[] getTrayIcons() {
        java.util.Vector<java.awt.TrayIcon> icons = ((java.util.Vector<java.awt.TrayIcon>)(sun.awt.AppContext.getAppContext().get(java.awt.TrayIcon.class)));
        if (icons != null) {
            return ((java.awt.TrayIcon[])(icons.toArray(new java.awt.TrayIcon[icons.size()])));
        } 
        return java.awt.SystemTray.EMPTY_TRAY_ARRAY;
    }

    public java.awt.Dimension getTrayIconSize() {
        return peer.getTrayIconSize();
    }

    public synchronized void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        if (listener == null) {
            return ;
        } 
        getCurrentChangeSupport().addPropertyChangeListener(propertyName, listener);
    }

    public synchronized void removePropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        if (listener == null) {
            return ;
        } 
        getCurrentChangeSupport().removePropertyChangeListener(propertyName, listener);
    }

    public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String propertyName) {
        return getCurrentChangeSupport().getPropertyChangeListeners(propertyName);
    }

    private void firePropertyChange(java.lang.String propertyName, java.lang.Object oldValue, java.lang.Object newValue) {
        if (((oldValue != null) && (newValue != null)) && (oldValue.equals(newValue))) {
            return ;
        } 
        getCurrentChangeSupport().firePropertyChange(propertyName, oldValue, newValue);
    }

    private synchronized java.beans.PropertyChangeSupport getCurrentChangeSupport() {
        java.beans.PropertyChangeSupport changeSupport = ((java.beans.PropertyChangeSupport)(sun.awt.AppContext.getAppContext().get(java.awt.SystemTray.class)));
        if (changeSupport == null) {
            changeSupport = new java.beans.PropertyChangeSupport(java.awt.SystemTray.this);
            sun.awt.AppContext.getAppContext().put(java.awt.SystemTray.class, changeSupport);
        } 
        return changeSupport;
    }

    synchronized void addNotify() {
        if ((peer) == null) {
            java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
            if (toolkit instanceof sun.awt.SunToolkit) {
                peer = ((sun.awt.SunToolkit)(java.awt.Toolkit.getDefaultToolkit())).createSystemTray(java.awt.SystemTray.this);
            } else if (toolkit instanceof sun.awt.HeadlessToolkit) {
                peer = ((sun.awt.HeadlessToolkit)(java.awt.Toolkit.getDefaultToolkit())).createSystemTray(java.awt.SystemTray.this);
            } 
        } 
    }

    static void checkSystemTrayAllowed() {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.ACCESS_SYSTEM_TRAY_PERMISSION);
        } 
    }

    private static void initializeSystemTrayIfNeeded() {
        synchronized(java.awt.SystemTray.class) {
            if ((java.awt.SystemTray.systemTray) == null) {
                java.awt.SystemTray.systemTray = new java.awt.SystemTray();
            } 
        }
    }
}


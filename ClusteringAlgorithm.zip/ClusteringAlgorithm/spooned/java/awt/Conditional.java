package java.awt;


interface Conditional {
    boolean evaluate();
}


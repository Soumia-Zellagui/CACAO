package java.awt;


public class MouseInfo {
    private MouseInfo() {
    }

    public static java.awt.PointerInfo getPointerInfo() throws java.awt.HeadlessException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.WATCH_MOUSE_PERMISSION);
        } 
        java.awt.Point point = new java.awt.Point(0 , 0);
        int deviceNum = java.awt.Toolkit.getDefaultToolkit().getMouseInfoPeer().fillPointWithCoords(point);
        java.awt.GraphicsDevice[] gds = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
        java.awt.PointerInfo retval = null;
        if (java.awt.MouseInfo.areScreenDevicesIndependent(gds)) {
            retval = new java.awt.PointerInfo(gds[deviceNum] , point);
        } else {
            for (int i = 0 ; i < (gds.length) ; i++) {
                java.awt.GraphicsConfiguration gc = gds[i].getDefaultConfiguration();
                java.awt.Rectangle bounds = gc.getBounds();
                if (bounds.contains(point)) {
                    retval = new java.awt.PointerInfo(gds[i] , point);
                } 
            }
        }
        return retval;
    }

    private static boolean areScreenDevicesIndependent(java.awt.GraphicsDevice[] gds) {
        for (int i = 0 ; i < (gds.length) ; i++) {
            java.awt.Rectangle bounds = gds[i].getDefaultConfiguration().getBounds();
            if (((bounds.x) != 0) || ((bounds.y) != 0)) {
                return false;
            } 
        }
        return true;
    }

    public static int getNumberOfButtons() throws java.awt.HeadlessException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
        java.lang.Object prop = java.awt.Toolkit.getDefaultToolkit().getDesktopProperty("awt.mouse.numButtons");
        if (prop instanceof java.lang.Integer) {
            return ((java.lang.Integer)(prop)).intValue();
        } 
        assert false : "awt.mouse.numButtons is not an integer property";
        return 0;
    }
}


package java.awt;


public class TexturePaint implements java.awt.Paint {
    java.awt.image.BufferedImage bufImg;

    double tx;

    double ty;

    double sx;

    double sy;

    public TexturePaint(java.awt.image.BufferedImage txtr ,java.awt.geom.Rectangle2D anchor) {
        java.awt.TexturePaint.this.bufImg = txtr;
        java.awt.TexturePaint.this.tx = anchor.getX();
        java.awt.TexturePaint.this.ty = anchor.getY();
        java.awt.TexturePaint.this.sx = (anchor.getWidth()) / (bufImg.getWidth());
        java.awt.TexturePaint.this.sy = (anchor.getHeight()) / (bufImg.getHeight());
    }

    public java.awt.image.BufferedImage getImage() {
        return bufImg;
    }

    public java.awt.geom.Rectangle2D getAnchorRect() {
        return new java.awt.geom.Rectangle2D.Double(tx , ty , ((sx) * (bufImg.getWidth())) , ((sy) * (bufImg.getHeight())));
    }

    public java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds, java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform xform, java.awt.RenderingHints hints) {
        if (xform == null) {
            xform = new java.awt.geom.AffineTransform();
        } else {
            xform = ((java.awt.geom.AffineTransform)(xform.clone()));
        }
        xform.translate(tx, ty);
        xform.scale(sx, sy);
        return java.awt.TexturePaintContext.getContext(bufImg, xform, hints, deviceBounds);
    }

    public int getTransparency() {
        return bufImg.getColorModel().getTransparency();
    }
}


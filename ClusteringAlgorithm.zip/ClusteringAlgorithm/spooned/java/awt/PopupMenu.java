package java.awt;


public class PopupMenu extends java.awt.Menu {
    private static final java.lang.String base = "popup";

    static int nameCounter = 0;

    transient boolean isTrayIconPopup = false;

    static {
        sun.awt.AWTAccessor.setPopupMenuAccessor(new sun.awt.AWTAccessor.PopupMenuAccessor() {
            public boolean isTrayIconPopup(java.awt.PopupMenu popupMenu) {
                return popupMenu.isTrayIconPopup;
            }
        });
    }

    private static final long serialVersionUID = -4620452533522760060L;

    public PopupMenu() throws java.awt.HeadlessException {
        this("");
    }

    public PopupMenu(java.lang.String label) throws java.awt.HeadlessException {
        super(label);
    }

    public java.awt.MenuContainer getParent() {
        if (isTrayIconPopup) {
            return null;
        } 
        return super.getParent();
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.PopupMenu.class) {
            return (java.awt.PopupMenu.base) + ((java.awt.PopupMenu.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if (((parent) != null) && (!((parent) instanceof java.awt.Component))) {
                super.addNotify();
            } else {
                if ((peer) == null)
                    peer = java.awt.Toolkit.getDefaultToolkit().createPopupMenu(java.awt.PopupMenu.this);
                
                int nitems = getItemCount();
                for (int i = 0 ; i < nitems ; i++) {
                    java.awt.MenuItem mi = getItem(i);
                    mi.parent = java.awt.PopupMenu.this;
                    mi.addNotify();
                }
            }
        }
    }

    public void show(java.awt.Component origin, int x, int y) {
        java.awt.MenuContainer localParent = parent;
        if (localParent == null) {
            throw new java.lang.NullPointerException("parent is null");
        } 
        if (!(localParent instanceof java.awt.Component)) {
            throw new java.lang.IllegalArgumentException("PopupMenus with non-Component parents cannot be shown");
        } 
        java.awt.Component compParent = ((java.awt.Component)(localParent));
        if (compParent != origin) {
            if (compParent instanceof java.awt.Container) {
                if (!(((java.awt.Container)(compParent)).isAncestorOf(origin))) {
                    throw new java.lang.IllegalArgumentException("origin not in parent's hierarchy");
                } 
            } else {
                throw new java.lang.IllegalArgumentException("origin not in parent's hierarchy");
            }
        } 
        if (((compParent.getPeer()) == null) || (!(compParent.isShowing()))) {
            throw new java.lang.RuntimeException("parent not showing on screen");
        } 
        if ((peer) == null) {
            addNotify();
        } 
        synchronized(getTreeLock()) {
            if ((peer) != null) {
                ((java.awt.peer.PopupMenuPeer)(peer)).show(new java.awt.Event(origin , 0 , java.awt.Event.MOUSE_DOWN , x , y , 0 , 0));
            } 
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.PopupMenu.AccessibleAWTPopupMenu();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTPopupMenu extends java.awt.Menu.AccessibleAWTMenu {
        private static final long serialVersionUID = -4282044795947239955L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.POPUP_MENU;
        }
    }
}


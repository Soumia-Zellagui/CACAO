package java.awt;


public class Rectangle extends java.awt.geom.Rectangle2D implements java.awt.Shape , java.io.Serializable {
    public int x;

    public int y;

    public int width;

    public int height;

    private static final long serialVersionUID = -4345857070255674764L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Rectangle.initIDs();
        } 
    }

    public Rectangle() {
        this(0, 0, 0, 0);
    }

    public Rectangle(java.awt.Rectangle r) {
        this(r.x, r.y, r.width, r.height);
    }

    public Rectangle(int x ,int y ,int width ,int height) {
        java.awt.Rectangle.this.x = x;
        java.awt.Rectangle.this.y = y;
        java.awt.Rectangle.this.width = width;
        java.awt.Rectangle.this.height = height;
    }

    public Rectangle(int width ,int height) {
        this(0, 0, width, height);
    }

    public Rectangle(java.awt.Point p ,java.awt.Dimension d) {
        this(p.x, p.y, d.width, d.height);
    }

    public Rectangle(java.awt.Point p) {
        this(p.x, p.y, 0, 0);
    }

    public Rectangle(java.awt.Dimension d) {
        this(0, 0, d.width, d.height);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    @java.beans.Transient
    public java.awt.Rectangle getBounds() {
        return new java.awt.Rectangle(x , y , width , height);
    }

    public java.awt.geom.Rectangle2D getBounds2D() {
        return new java.awt.Rectangle(x , y , width , height);
    }

    public void setBounds(java.awt.Rectangle r) {
        setBounds(r.x, r.y, r.width, r.height);
    }

    public void setBounds(int x, int y, int width, int height) {
        reshape(x, y, width, height);
    }

    public void setRect(double x, double y, double width, double height) {
        int newx;
        int newy;
        int neww;
        int newh;
        if (x > (2.0 * (java.lang.Integer.MAX_VALUE))) {
            newx = java.lang.Integer.MAX_VALUE;
            neww = -1;
        } else {
            newx = java.awt.Rectangle.clip(x, false);
            if (width >= 0)
                width += x - newx;
            
            neww = java.awt.Rectangle.clip(width, (width >= 0));
        }
        if (y > (2.0 * (java.lang.Integer.MAX_VALUE))) {
            newy = java.lang.Integer.MAX_VALUE;
            newh = -1;
        } else {
            newy = java.awt.Rectangle.clip(y, false);
            if (height >= 0)
                height += y - newy;
            
            newh = java.awt.Rectangle.clip(height, (height >= 0));
        }
        reshape(newx, newy, neww, newh);
    }

    private static int clip(double v, boolean doceil) {
        if (v <= (java.lang.Integer.MIN_VALUE)) {
            return java.lang.Integer.MIN_VALUE;
        } 
        if (v >= (java.lang.Integer.MAX_VALUE)) {
            return java.lang.Integer.MAX_VALUE;
        } 
        return ((int)(doceil ? java.lang.Math.ceil(v) : java.lang.Math.floor(v)));
    }

    @java.lang.Deprecated
    public void reshape(int x, int y, int width, int height) {
        java.awt.Rectangle.this.x = x;
        java.awt.Rectangle.this.y = y;
        java.awt.Rectangle.this.width = width;
        java.awt.Rectangle.this.height = height;
    }

    public java.awt.Point getLocation() {
        return new java.awt.Point(x , y);
    }

    public void setLocation(java.awt.Point p) {
        setLocation(p.x, p.y);
    }

    public void setLocation(int x, int y) {
        move(x, y);
    }

    @java.lang.Deprecated
    public void move(int x, int y) {
        java.awt.Rectangle.this.x = x;
        java.awt.Rectangle.this.y = y;
    }

    public void translate(int dx, int dy) {
        int oldv = java.awt.Rectangle.this.x;
        int newv = oldv + dx;
        if (dx < 0) {
            if (newv > oldv) {
                if ((width) >= 0) {
                    width += newv - (java.lang.Integer.MIN_VALUE);
                } 
                newv = java.lang.Integer.MIN_VALUE;
            } 
        } else {
            if (newv < oldv) {
                if ((width) >= 0) {
                    width += newv - (java.lang.Integer.MAX_VALUE);
                    if ((width) < 0)
                        width = java.lang.Integer.MAX_VALUE;
                    
                } 
                newv = java.lang.Integer.MAX_VALUE;
            } 
        }
        java.awt.Rectangle.this.x = newv;
        oldv = java.awt.Rectangle.this.y;
        newv = oldv + dy;
        if (dy < 0) {
            if (newv > oldv) {
                if ((height) >= 0) {
                    height += newv - (java.lang.Integer.MIN_VALUE);
                } 
                newv = java.lang.Integer.MIN_VALUE;
            } 
        } else {
            if (newv < oldv) {
                if ((height) >= 0) {
                    height += newv - (java.lang.Integer.MAX_VALUE);
                    if ((height) < 0)
                        height = java.lang.Integer.MAX_VALUE;
                    
                } 
                newv = java.lang.Integer.MAX_VALUE;
            } 
        }
        java.awt.Rectangle.this.y = newv;
    }

    public java.awt.Dimension getSize() {
        return new java.awt.Dimension(width , height);
    }

    public void setSize(java.awt.Dimension d) {
        setSize(d.width, d.height);
    }

    public void setSize(int width, int height) {
        resize(width, height);
    }

    @java.lang.Deprecated
    public void resize(int width, int height) {
        java.awt.Rectangle.this.width = width;
        java.awt.Rectangle.this.height = height;
    }

    public boolean contains(java.awt.Point p) {
        return contains(p.x, p.y);
    }

    public boolean contains(int x, int y) {
        return inside(x, y);
    }

    public boolean contains(java.awt.Rectangle r) {
        return contains(r.x, r.y, r.width, r.height);
    }

    public boolean contains(int X, int Y, int W, int H) {
        int w = java.awt.Rectangle.this.width;
        int h = java.awt.Rectangle.this.height;
        if ((((w | h) | W) | H) < 0) {
            return false;
        } 
        int x = java.awt.Rectangle.this.x;
        int y = java.awt.Rectangle.this.y;
        if ((X < x) || (Y < y)) {
            return false;
        } 
        w += x;
        W += X;
        if (W <= X) {
            if ((w >= x) || (W > w))
                return false;
            
        } else {
            if ((w >= x) && (W > w))
                return false;
            
        }
        h += y;
        H += Y;
        if (H <= Y) {
            if ((h >= y) || (H > h))
                return false;
            
        } else {
            if ((h >= y) && (H > h))
                return false;
            
        }
        return true;
    }

    @java.lang.Deprecated
    public boolean inside(int X, int Y) {
        int w = java.awt.Rectangle.this.width;
        int h = java.awt.Rectangle.this.height;
        if ((w | h) < 0) {
            return false;
        } 
        int x = java.awt.Rectangle.this.x;
        int y = java.awt.Rectangle.this.y;
        if ((X < x) || (Y < y)) {
            return false;
        } 
        w += x;
        h += y;
        return ((w < x) || (w > X)) && ((h < y) || (h > Y));
    }

    public boolean intersects(java.awt.Rectangle r) {
        int tw = java.awt.Rectangle.this.width;
        int th = java.awt.Rectangle.this.height;
        int rw = r.width;
        int rh = r.height;
        if ((((rw <= 0) || (rh <= 0)) || (tw <= 0)) || (th <= 0)) {
            return false;
        } 
        int tx = java.awt.Rectangle.this.x;
        int ty = java.awt.Rectangle.this.y;
        int rx = r.x;
        int ry = r.y;
        rw += rx;
        rh += ry;
        tw += tx;
        th += ty;
        return ((((rw < rx) || (rw > tx)) && ((rh < ry) || (rh > ty))) && ((tw < tx) || (tw > rx))) && ((th < ty) || (th > ry));
    }

    public java.awt.Rectangle intersection(java.awt.Rectangle r) {
        int tx1 = java.awt.Rectangle.this.x;
        int ty1 = java.awt.Rectangle.this.y;
        int rx1 = r.x;
        int ry1 = r.y;
        long tx2 = tx1;
        tx2 += java.awt.Rectangle.this.width;
        long ty2 = ty1;
        ty2 += java.awt.Rectangle.this.height;
        long rx2 = rx1;
        rx2 += r.width;
        long ry2 = ry1;
        ry2 += r.height;
        if (tx1 < rx1)
            tx1 = rx1;
        
        if (ty1 < ry1)
            ty1 = ry1;
        
        if (tx2 > rx2)
            tx2 = rx2;
        
        if (ty2 > ry2)
            ty2 = ry2;
        
        tx2 -= tx1;
        ty2 -= ty1;
        if (tx2 < (java.lang.Integer.MIN_VALUE))
            tx2 = java.lang.Integer.MIN_VALUE;
        
        if (ty2 < (java.lang.Integer.MIN_VALUE))
            ty2 = java.lang.Integer.MIN_VALUE;
        
        return new java.awt.Rectangle(tx1 , ty1 , ((int)(tx2)) , ((int)(ty2)));
    }

    public java.awt.Rectangle union(java.awt.Rectangle r) {
        long tx2 = java.awt.Rectangle.this.width;
        long ty2 = java.awt.Rectangle.this.height;
        if ((tx2 | ty2) < 0) {
            return new java.awt.Rectangle(r);
        } 
        long rx2 = r.width;
        long ry2 = r.height;
        if ((rx2 | ry2) < 0) {
            return new java.awt.Rectangle(java.awt.Rectangle.this);
        } 
        int tx1 = java.awt.Rectangle.this.x;
        int ty1 = java.awt.Rectangle.this.y;
        tx2 += tx1;
        ty2 += ty1;
        int rx1 = r.x;
        int ry1 = r.y;
        rx2 += rx1;
        ry2 += ry1;
        if (tx1 > rx1)
            tx1 = rx1;
        
        if (ty1 > ry1)
            ty1 = ry1;
        
        if (tx2 < rx2)
            tx2 = rx2;
        
        if (ty2 < ry2)
            ty2 = ry2;
        
        tx2 -= tx1;
        ty2 -= ty1;
        if (tx2 > (java.lang.Integer.MAX_VALUE))
            tx2 = java.lang.Integer.MAX_VALUE;
        
        if (ty2 > (java.lang.Integer.MAX_VALUE))
            ty2 = java.lang.Integer.MAX_VALUE;
        
        return new java.awt.Rectangle(tx1 , ty1 , ((int)(tx2)) , ((int)(ty2)));
    }

    public void add(int newx, int newy) {
        if (((width) | (height)) < 0) {
            java.awt.Rectangle.this.x = newx;
            java.awt.Rectangle.this.y = newy;
            java.awt.Rectangle.this.width = java.awt.Rectangle.this.height = 0;
            return ;
        } 
        int x1 = java.awt.Rectangle.this.x;
        int y1 = java.awt.Rectangle.this.y;
        long x2 = java.awt.Rectangle.this.width;
        long y2 = java.awt.Rectangle.this.height;
        x2 += x1;
        y2 += y1;
        if (x1 > newx)
            x1 = newx;
        
        if (y1 > newy)
            y1 = newy;
        
        if (x2 < newx)
            x2 = newx;
        
        if (y2 < newy)
            y2 = newy;
        
        x2 -= x1;
        y2 -= y1;
        if (x2 > (java.lang.Integer.MAX_VALUE))
            x2 = java.lang.Integer.MAX_VALUE;
        
        if (y2 > (java.lang.Integer.MAX_VALUE))
            y2 = java.lang.Integer.MAX_VALUE;
        
        reshape(x1, y1, ((int)(x2)), ((int)(y2)));
    }

    public void add(java.awt.Point pt) {
        add(pt.x, pt.y);
    }

    public void add(java.awt.Rectangle r) {
        long tx2 = java.awt.Rectangle.this.width;
        long ty2 = java.awt.Rectangle.this.height;
        if ((tx2 | ty2) < 0) {
            reshape(r.x, r.y, r.width, r.height);
        } 
        long rx2 = r.width;
        long ry2 = r.height;
        if ((rx2 | ry2) < 0) {
            return ;
        } 
        int tx1 = java.awt.Rectangle.this.x;
        int ty1 = java.awt.Rectangle.this.y;
        tx2 += tx1;
        ty2 += ty1;
        int rx1 = r.x;
        int ry1 = r.y;
        rx2 += rx1;
        ry2 += ry1;
        if (tx1 > rx1)
            tx1 = rx1;
        
        if (ty1 > ry1)
            ty1 = ry1;
        
        if (tx2 < rx2)
            tx2 = rx2;
        
        if (ty2 < ry2)
            ty2 = ry2;
        
        tx2 -= tx1;
        ty2 -= ty1;
        if (tx2 > (java.lang.Integer.MAX_VALUE))
            tx2 = java.lang.Integer.MAX_VALUE;
        
        if (ty2 > (java.lang.Integer.MAX_VALUE))
            ty2 = java.lang.Integer.MAX_VALUE;
        
        reshape(tx1, ty1, ((int)(tx2)), ((int)(ty2)));
    }

    public void grow(int h, int v) {
        long x0 = java.awt.Rectangle.this.x;
        long y0 = java.awt.Rectangle.this.y;
        long x1 = java.awt.Rectangle.this.width;
        long y1 = java.awt.Rectangle.this.height;
        x1 += x0;
        y1 += y0;
        x0 -= h;
        y0 -= v;
        x1 += h;
        y1 += v;
        if (x1 < x0) {
            x1 -= x0;
            if (x1 < (java.lang.Integer.MIN_VALUE))
                x1 = java.lang.Integer.MIN_VALUE;
            
            if (x0 < (java.lang.Integer.MIN_VALUE))
                x0 = java.lang.Integer.MIN_VALUE;
            else if (x0 > (java.lang.Integer.MAX_VALUE))
                x0 = java.lang.Integer.MAX_VALUE;
            
        } else {
            if (x0 < (java.lang.Integer.MIN_VALUE))
                x0 = java.lang.Integer.MIN_VALUE;
            else if (x0 > (java.lang.Integer.MAX_VALUE))
                x0 = java.lang.Integer.MAX_VALUE;
            
            x1 -= x0;
            if (x1 < (java.lang.Integer.MIN_VALUE))
                x1 = java.lang.Integer.MIN_VALUE;
            else if (x1 > (java.lang.Integer.MAX_VALUE))
                x1 = java.lang.Integer.MAX_VALUE;
            
        }
        if (y1 < y0) {
            y1 -= y0;
            if (y1 < (java.lang.Integer.MIN_VALUE))
                y1 = java.lang.Integer.MIN_VALUE;
            
            if (y0 < (java.lang.Integer.MIN_VALUE))
                y0 = java.lang.Integer.MIN_VALUE;
            else if (y0 > (java.lang.Integer.MAX_VALUE))
                y0 = java.lang.Integer.MAX_VALUE;
            
        } else {
            if (y0 < (java.lang.Integer.MIN_VALUE))
                y0 = java.lang.Integer.MIN_VALUE;
            else if (y0 > (java.lang.Integer.MAX_VALUE))
                y0 = java.lang.Integer.MAX_VALUE;
            
            y1 -= y0;
            if (y1 < (java.lang.Integer.MIN_VALUE))
                y1 = java.lang.Integer.MIN_VALUE;
            else if (y1 > (java.lang.Integer.MAX_VALUE))
                y1 = java.lang.Integer.MAX_VALUE;
            
        }
        reshape(((int)(x0)), ((int)(y0)), ((int)(x1)), ((int)(y1)));
    }

    public boolean isEmpty() {
        return ((width) <= 0) || ((height) <= 0);
    }

    public int outcode(double x, double y) {
        int out = 0;
        if ((java.awt.Rectangle.this.width) <= 0) {
            out |= (java.awt.geom.Rectangle2D.OUT_LEFT) | (java.awt.geom.Rectangle2D.OUT_RIGHT);
        } else if (x < (java.awt.Rectangle.this.x)) {
            out |= java.awt.geom.Rectangle2D.OUT_LEFT;
        } else if (x > ((java.awt.Rectangle.this.x) + ((double)(java.awt.Rectangle.this.width)))) {
            out |= java.awt.geom.Rectangle2D.OUT_RIGHT;
        } 
        if ((java.awt.Rectangle.this.height) <= 0) {
            out |= (java.awt.geom.Rectangle2D.OUT_TOP) | (java.awt.geom.Rectangle2D.OUT_BOTTOM);
        } else if (y < (java.awt.Rectangle.this.y)) {
            out |= java.awt.geom.Rectangle2D.OUT_TOP;
        } else if (y > ((java.awt.Rectangle.this.y) + ((double)(java.awt.Rectangle.this.height)))) {
            out |= java.awt.geom.Rectangle2D.OUT_BOTTOM;
        } 
        return out;
    }

    public java.awt.geom.Rectangle2D createIntersection(java.awt.geom.Rectangle2D r) {
        if (r instanceof java.awt.Rectangle) {
            return intersection(((java.awt.Rectangle)(r)));
        } 
        java.awt.geom.Rectangle2D dest = new java.awt.geom.Rectangle2D.Double();
        java.awt.geom.Rectangle2D.intersect(java.awt.Rectangle.this, r, dest);
        return dest;
    }

    public java.awt.geom.Rectangle2D createUnion(java.awt.geom.Rectangle2D r) {
        if (r instanceof java.awt.Rectangle) {
            return union(((java.awt.Rectangle)(r)));
        } 
        java.awt.geom.Rectangle2D dest = new java.awt.geom.Rectangle2D.Double();
        java.awt.geom.Rectangle2D.union(java.awt.Rectangle.this, r, dest);
        return dest;
    }

    public boolean equals(java.lang.Object obj) {
        if (obj instanceof java.awt.Rectangle) {
            java.awt.Rectangle r = ((java.awt.Rectangle)(obj));
            return ((((x) == (r.x)) && ((y) == (r.y))) && ((width) == (r.width))) && ((height) == (r.height));
        } 
        return super.equals(obj);
    }

    public java.lang.String toString() {
        return (((((((((getClass().getName()) + "[x=") + (x)) + ",y=") + (y)) + ",width=") + (width)) + ",height=") + (height)) + "]";
    }
}


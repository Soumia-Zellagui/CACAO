package java.awt;


public class ContainerOrderFocusTraversalPolicy extends java.awt.FocusTraversalPolicy implements java.io.Serializable {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.ContainerOrderFocusTraversalPolicy");

    private final int FORWARD_TRAVERSAL = 0;

    private final int BACKWARD_TRAVERSAL = 1;

    private static final long serialVersionUID = 486933713763926351L;

    private boolean implicitDownCycleTraversal = true;

    private transient java.awt.Container cachedRoot;

    private transient java.util.List<java.awt.Component> cachedCycle;

    private java.util.List<java.awt.Component> getFocusTraversalCycle(java.awt.Container aContainer) {
        java.util.List<java.awt.Component> cycle = new java.util.ArrayList<java.awt.Component>();
        enumerateCycle(aContainer, cycle);
        return cycle;
    }

    private int getComponentIndex(java.util.List<java.awt.Component> cycle, java.awt.Component aComponent) {
        return cycle.indexOf(aComponent);
    }

    private void enumerateCycle(java.awt.Container container, java.util.List<java.awt.Component> cycle) {
        if (!((container.isVisible()) && (container.isDisplayable()))) {
            return ;
        } 
        cycle.add(container);
        java.awt.Component[] components = container.getComponents();
        for (int i = 0 ; i < (components.length) ; i++) {
            java.awt.Component comp = components[i];
            if (comp instanceof java.awt.Container) {
                java.awt.Container cont = ((java.awt.Container)(comp));
                if ((!(cont.isFocusCycleRoot())) && (!(cont.isFocusTraversalPolicyProvider()))) {
                    enumerateCycle(cont, cycle);
                    continue;
                } 
            } 
            cycle.add(comp);
        }
    }

    private java.awt.Container getTopmostProvider(java.awt.Container focusCycleRoot, java.awt.Component aComponent) {
        java.awt.Container aCont = aComponent.getParent();
        java.awt.Container ftp = null;
        while ((aCont != focusCycleRoot) && (aCont != null)) {
            if (aCont.isFocusTraversalPolicyProvider()) {
                ftp = aCont;
            } 
            aCont = aCont.getParent();
        }
        if (aCont == null) {
            return null;
        } 
        return ftp;
    }

    private java.awt.Component getComponentDownCycle(java.awt.Component comp, int traversalDirection) {
        java.awt.Component retComp = null;
        if (comp instanceof java.awt.Container) {
            java.awt.Container cont = ((java.awt.Container)(comp));
            if (cont.isFocusCycleRoot()) {
                if (getImplicitDownCycleTraversal()) {
                    retComp = cont.getFocusTraversalPolicy().getDefaultComponent(cont);
                    if ((retComp != null) && (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE))) {
                        java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Transfered focus down-cycle to " + retComp) + " in the focus cycle root ") + cont));
                    } 
                } else {
                    return null;
                }
            } else if (cont.isFocusTraversalPolicyProvider()) {
                retComp = traversalDirection == (FORWARD_TRAVERSAL) ? cont.getFocusTraversalPolicy().getDefaultComponent(cont) : cont.getFocusTraversalPolicy().getLastComponent(cont);
                if ((retComp != null) && (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE))) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Transfered focus to " + retComp) + " in the FTP provider ") + cont));
                } 
            } 
        } 
        return retComp;
    }

    public java.awt.Component getComponentAfter(java.awt.Container aContainer, java.awt.Component aComponent) {
        if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Searching in " + aContainer) + " for component after ") + aComponent));
        } 
        if ((aContainer == null) || (aComponent == null)) {
            throw new java.lang.IllegalArgumentException("aContainer and aComponent cannot be null");
        } 
        if ((!(aContainer.isFocusTraversalPolicyProvider())) && (!(aContainer.isFocusCycleRoot()))) {
            throw new java.lang.IllegalArgumentException("aContainer should be focus cycle root or focus traversal policy provider");
        } else if ((aContainer.isFocusCycleRoot()) && (!(aComponent.isFocusCycleRoot(aContainer)))) {
            throw new java.lang.IllegalArgumentException("aContainer is not a focus cycle root of aComponent");
        } 
        synchronized(aContainer.getTreeLock()) {
            if (!((aContainer.isVisible()) && (aContainer.isDisplayable()))) {
                return null;
            } 
            java.awt.Component comp = getComponentDownCycle(aComponent, FORWARD_TRAVERSAL);
            if (comp != null) {
                return comp;
            } 
            java.awt.Container provider = getTopmostProvider(aContainer, aComponent);
            if (provider != null) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Asking FTP " + provider) + " for component after ") + aComponent));
                } 
                java.awt.FocusTraversalPolicy policy = provider.getFocusTraversalPolicy();
                java.awt.Component afterComp = policy.getComponentAfter(provider, aComponent);
                if (afterComp != null) {
                    if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### FTP returned " + afterComp));
                    } 
                    return afterComp;
                } 
                aComponent = provider;
            } 
            java.util.List<java.awt.Component> cycle = getFocusTraversalCycle(aContainer);
            if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Cycle is " + cycle) + ", component is ") + aComponent));
            } 
            int index = getComponentIndex(cycle, aComponent);
            if (index < 0) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Didn't find component " + aComponent) + " in a cycle ") + aContainer));
                } 
                return getFirstComponent(aContainer);
            } 
            for (index++ ; index < (cycle.size()) ; index++) {
                comp = cycle.get(index);
                if (accept(comp)) {
                    return comp;
                } else if ((comp = getComponentDownCycle(comp, FORWARD_TRAVERSAL)) != null) {
                    return comp;
                } 
            }
            if (aContainer.isFocusCycleRoot()) {
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot = aContainer;
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle = cycle;
                comp = getFirstComponent(aContainer);
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot = null;
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle = null;
                return comp;
            } 
        }
        return null;
    }

    public java.awt.Component getComponentBefore(java.awt.Container aContainer, java.awt.Component aComponent) {
        if ((aContainer == null) || (aComponent == null)) {
            throw new java.lang.IllegalArgumentException("aContainer and aComponent cannot be null");
        } 
        if ((!(aContainer.isFocusTraversalPolicyProvider())) && (!(aContainer.isFocusCycleRoot()))) {
            throw new java.lang.IllegalArgumentException("aContainer should be focus cycle root or focus traversal policy provider");
        } else if ((aContainer.isFocusCycleRoot()) && (!(aComponent.isFocusCycleRoot(aContainer)))) {
            throw new java.lang.IllegalArgumentException("aContainer is not a focus cycle root of aComponent");
        } 
        synchronized(aContainer.getTreeLock()) {
            if (!((aContainer.isVisible()) && (aContainer.isDisplayable()))) {
                return null;
            } 
            java.awt.Container provider = getTopmostProvider(aContainer, aComponent);
            if (provider != null) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Asking FTP " + provider) + " for component after ") + aComponent));
                } 
                java.awt.FocusTraversalPolicy policy = provider.getFocusTraversalPolicy();
                java.awt.Component beforeComp = policy.getComponentBefore(provider, aComponent);
                if (beforeComp != null) {
                    if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### FTP returned " + beforeComp));
                    } 
                    return beforeComp;
                } 
                aComponent = provider;
                if (accept(aComponent)) {
                    return aComponent;
                } 
            } 
            java.util.List<java.awt.Component> cycle = getFocusTraversalCycle(aContainer);
            if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Cycle is " + cycle) + ", component is ") + aComponent));
            } 
            int index = getComponentIndex(cycle, aComponent);
            if (index < 0) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine(((("### Didn't find component " + aComponent) + " in a cycle ") + aContainer));
                } 
                return getLastComponent(aContainer);
            } 
            java.awt.Component comp = null;
            java.awt.Component tryComp = null;
            for (index-- ; index >= 0 ; index--) {
                comp = cycle.get(index);
                if ((comp != aContainer) && ((tryComp = getComponentDownCycle(comp, BACKWARD_TRAVERSAL)) != null)) {
                    return tryComp;
                } else if (accept(comp)) {
                    return comp;
                } 
            }
            if (aContainer.isFocusCycleRoot()) {
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot = aContainer;
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle = cycle;
                comp = getLastComponent(aContainer);
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot = null;
                java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle = null;
                return comp;
            } 
        }
        return null;
    }

    public java.awt.Component getFirstComponent(java.awt.Container aContainer) {
        java.util.List<java.awt.Component> cycle;
        if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### Getting first component in " + aContainer));
        } 
        if (aContainer == null) {
            throw new java.lang.IllegalArgumentException("aContainer cannot be null");
        } 
        synchronized(aContainer.getTreeLock()) {
            if (!((aContainer.isVisible()) && (aContainer.isDisplayable()))) {
                return null;
            } 
            if ((java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot) == aContainer) {
                cycle = java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle;
            } else {
                cycle = getFocusTraversalCycle(aContainer);
            }
            if ((cycle.size()) == 0) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine("### Cycle is empty");
                } 
                return null;
            } 
            if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### Cycle is " + cycle));
            } 
            for (java.awt.Component comp : cycle) {
                if (accept(comp)) {
                    return comp;
                } else if ((comp != aContainer) && ((comp = getComponentDownCycle(comp, FORWARD_TRAVERSAL)) != null)) {
                    return comp;
                } 
            }
        }
        return null;
    }

    public java.awt.Component getLastComponent(java.awt.Container aContainer) {
        java.util.List<java.awt.Component> cycle;
        if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### Getting last component in " + aContainer));
        } 
        if (aContainer == null) {
            throw new java.lang.IllegalArgumentException("aContainer cannot be null");
        } 
        synchronized(aContainer.getTreeLock()) {
            if (!((aContainer.isVisible()) && (aContainer.isDisplayable()))) {
                return null;
            } 
            if ((java.awt.ContainerOrderFocusTraversalPolicy.this.cachedRoot) == aContainer) {
                cycle = java.awt.ContainerOrderFocusTraversalPolicy.this.cachedCycle;
            } else {
                cycle = getFocusTraversalCycle(aContainer);
            }
            if ((cycle.size()) == 0) {
                if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                    java.awt.ContainerOrderFocusTraversalPolicy.log.fine("### Cycle is empty");
                } 
                return null;
            } 
            if (java.awt.ContainerOrderFocusTraversalPolicy.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                java.awt.ContainerOrderFocusTraversalPolicy.log.fine(("### Cycle is " + cycle));
            } 
            for (int i = (cycle.size()) - 1 ; i >= 0 ; i--) {
                java.awt.Component comp = cycle.get(i);
                if (accept(comp)) {
                    return comp;
                } else if ((comp instanceof java.awt.Container) && (comp != aContainer)) {
                    java.awt.Container cont = ((java.awt.Container)(comp));
                    if (cont.isFocusTraversalPolicyProvider()) {
                        java.awt.Component retComp = cont.getFocusTraversalPolicy().getLastComponent(cont);
                        if (retComp != null) {
                            return retComp;
                        } 
                    } 
                } 
            }
        }
        return null;
    }

    public java.awt.Component getDefaultComponent(java.awt.Container aContainer) {
        return getFirstComponent(aContainer);
    }

    public void setImplicitDownCycleTraversal(boolean implicitDownCycleTraversal) {
        java.awt.ContainerOrderFocusTraversalPolicy.this.implicitDownCycleTraversal = implicitDownCycleTraversal;
    }

    public boolean getImplicitDownCycleTraversal() {
        return implicitDownCycleTraversal;
    }

    protected boolean accept(java.awt.Component aComponent) {
        if (!(aComponent.canBeFocusOwner())) {
            return false;
        } 
        if (!(aComponent instanceof java.awt.Window)) {
            for (java.awt.Container enableTest = aComponent.getParent() ; enableTest != null ; enableTest = enableTest.getParent()) {
                if (!((enableTest.isEnabled()) || (enableTest.isLightweight()))) {
                    return false;
                } 
                if (enableTest instanceof java.awt.Window) {
                    break;
                } 
            }
        } 
        return true;
    }
}


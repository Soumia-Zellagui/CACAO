package java.awt;


public interface Transparency {
    @java.lang.annotation.Native
    public static final int OPAQUE = 1;

    @java.lang.annotation.Native
    public static final int BITMASK = 2;

    @java.lang.annotation.Native
    public static final int TRANSLUCENT = 3;

    public int getTransparency();
}


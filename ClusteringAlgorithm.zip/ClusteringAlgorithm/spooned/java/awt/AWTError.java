package java.awt;


public class AWTError extends java.lang.Error {
    private static final long serialVersionUID = -1819846354050686206L;

    public AWTError(java.lang.String msg) {
        super(msg);
    }
}


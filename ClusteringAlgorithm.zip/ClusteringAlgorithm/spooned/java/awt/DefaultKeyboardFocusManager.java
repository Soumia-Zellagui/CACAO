package java.awt;


public class DefaultKeyboardFocusManager extends java.awt.KeyboardFocusManager {
    private static final sun.util.logging.PlatformLogger focusLog = sun.util.logging.PlatformLogger.getLogger("java.awt.focus.DefaultKeyboardFocusManager");

    private static final java.lang.ref.WeakReference<java.awt.Window> NULL_WINDOW_WR = new java.lang.ref.WeakReference<java.awt.Window>(null);

    private static final java.lang.ref.WeakReference<java.awt.Component> NULL_COMPONENT_WR = new java.lang.ref.WeakReference<java.awt.Component>(null);

    private java.lang.ref.WeakReference<java.awt.Window> realOppositeWindowWR = java.awt.DefaultKeyboardFocusManager.NULL_WINDOW_WR;

    private java.lang.ref.WeakReference<java.awt.Component> realOppositeComponentWR = java.awt.DefaultKeyboardFocusManager.NULL_COMPONENT_WR;

    private int inSendMessage;

    private java.util.LinkedList<java.awt.event.KeyEvent> enqueuedKeyEvents = new java.util.LinkedList<java.awt.event.KeyEvent>();

    private java.util.LinkedList<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> typeAheadMarkers = new java.util.LinkedList<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker>();

    private boolean consumeNextKeyTyped;

    static {
        sun.awt.AWTAccessor.setDefaultKeyboardFocusManagerAccessor(new sun.awt.AWTAccessor.DefaultKeyboardFocusManagerAccessor() {
            public void consumeNextKeyTyped(java.awt.DefaultKeyboardFocusManager dkfm, java.awt.event.KeyEvent e) {
                dkfm.consumeNextKeyTyped(e);
            }
        });
    }

    private static class TypeAheadMarker {
        long after;

        java.awt.Component untilFocused;

        TypeAheadMarker(long after ,java.awt.Component untilFocused) {
            java.awt.DefaultKeyboardFocusManager.TypeAheadMarker.this.after = after;
            java.awt.DefaultKeyboardFocusManager.TypeAheadMarker.this.untilFocused = untilFocused;
        }

        public java.lang.String toString() {
            return ((">>> Marker after " + (after)) + " on ") + (untilFocused);
        }
    }

    private java.awt.Window getOwningFrameDialog(java.awt.Window window) {
        while ((window != null) && (!((window instanceof java.awt.Frame) || (window instanceof java.awt.Dialog)))) {
            window = ((java.awt.Window)(window.getParent()));
        }
        return window;
    }

    private void restoreFocus(java.awt.event.FocusEvent fe, java.awt.Window newFocusedWindow) {
        java.awt.Component realOppositeComponent = java.awt.DefaultKeyboardFocusManager.this.realOppositeComponentWR.get();
        java.awt.Component vetoedComponent = fe.getComponent();
        if ((newFocusedWindow != null) && (restoreFocus(newFocusedWindow, vetoedComponent, false))) {
        } else if ((realOppositeComponent != null) && (doRestoreFocus(realOppositeComponent, vetoedComponent, false))) {
        } else if (((fe.getOppositeComponent()) != null) && (doRestoreFocus(fe.getOppositeComponent(), vetoedComponent, false))) {
        } else {
            clearGlobalFocusOwnerPriv();
        }
    }

    private void restoreFocus(java.awt.event.WindowEvent we) {
        java.awt.Window realOppositeWindow = java.awt.DefaultKeyboardFocusManager.this.realOppositeWindowWR.get();
        if ((realOppositeWindow != null) && (restoreFocus(realOppositeWindow, null, false))) {
        } else if (((we.getOppositeWindow()) != null) && (restoreFocus(we.getOppositeWindow(), null, false))) {
        } else {
            clearGlobalFocusOwnerPriv();
        }
    }

    private boolean restoreFocus(java.awt.Window aWindow, java.awt.Component vetoedComponent, boolean clearOnFailure) {
        java.awt.Component toFocus = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(aWindow);
        if (((toFocus != null) && (toFocus != vetoedComponent)) && (doRestoreFocus(toFocus, vetoedComponent, false))) {
            return true;
        } else if (clearOnFailure) {
            clearGlobalFocusOwnerPriv();
            return true;
        } else {
            return false;
        }
    }

    private boolean restoreFocus(java.awt.Component toFocus, boolean clearOnFailure) {
        return doRestoreFocus(toFocus, null, clearOnFailure);
    }

    private boolean doRestoreFocus(java.awt.Component toFocus, java.awt.Component vetoedComponent, boolean clearOnFailure) {
        if ((((toFocus != vetoedComponent) && (toFocus.isShowing())) && (toFocus.canBeFocusOwner())) && (toFocus.requestFocus(false, sun.awt.CausedFocusEvent.Cause.ROLLBACK))) {
            return true;
        } else {
            java.awt.Component nextFocus = toFocus.getNextFocusCandidate();
            if (((nextFocus != null) && (nextFocus != vetoedComponent)) && (nextFocus.requestFocusInWindow(sun.awt.CausedFocusEvent.Cause.ROLLBACK))) {
                return true;
            } else if (clearOnFailure) {
                clearGlobalFocusOwnerPriv();
                return true;
            } else {
                return false;
            }
        }
    }

    private static class DefaultKeyboardFocusManagerSentEvent extends java.awt.SentEvent {
        private static final long serialVersionUID = -2924743257508701758L;

        public DefaultKeyboardFocusManagerSentEvent(java.awt.AWTEvent nested ,sun.awt.AppContext toNotify) {
            super(nested, toNotify);
        }

        public final void dispatch() {
            java.awt.KeyboardFocusManager manager = java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager();
            java.awt.DefaultKeyboardFocusManager defaultManager = manager instanceof java.awt.DefaultKeyboardFocusManager ? ((java.awt.DefaultKeyboardFocusManager)(manager)) : null;
            if (defaultManager != null) {
                synchronized(defaultManager) {
                    (defaultManager.inSendMessage)++;
                }
            } 
            super.dispatch();
            if (defaultManager != null) {
                synchronized(defaultManager) {
                    (defaultManager.inSendMessage)--;
                }
            } 
        }
    }

    static boolean sendMessage(java.awt.Component target, java.awt.AWTEvent e) {
        e.isPosted = true;
        sun.awt.AppContext myAppContext = sun.awt.AppContext.getAppContext();
        final sun.awt.AppContext targetAppContext = target.appContext;
        final java.awt.SentEvent se = new java.awt.DefaultKeyboardFocusManager.DefaultKeyboardFocusManagerSentEvent(e , myAppContext);
        if (myAppContext == targetAppContext) {
            se.dispatch();
        } else {
            if (targetAppContext.isDisposed()) {
                return false;
            } 
            sun.awt.SunToolkit.postEvent(targetAppContext, se);
            if (java.awt.EventQueue.isDispatchThread()) {
                java.awt.EventDispatchThread edt = ((java.awt.EventDispatchThread)(java.lang.Thread.currentThread()));
                edt.pumpEvents(java.awt.SentEvent.ID, new java.awt.Conditional() {
                    public boolean evaluate() {
                        return (!(se.dispatched)) && (!(targetAppContext.isDisposed()));
                    }
                });
            } else {
                synchronized(se) {
                    while ((!(se.dispatched)) && (!(targetAppContext.isDisposed()))) {
                        try {
                            se.wait(1000);
                        } catch (java.lang.InterruptedException ie) {
                            break;
                        }
                    }
                }
            }
        }
        return se.dispatched;
    }

    private boolean repostIfFollowsKeyEvents(java.awt.event.WindowEvent e) {
        if (!(e instanceof sun.awt.TimedWindowEvent)) {
            return false;
        } 
        sun.awt.TimedWindowEvent we = ((sun.awt.TimedWindowEvent)(e));
        long time = we.getWhen();
        synchronized(java.awt.DefaultKeyboardFocusManager.this) {
            java.awt.event.KeyEvent ke = enqueuedKeyEvents.isEmpty() ? null : enqueuedKeyEvents.getFirst();
            if ((ke != null) && (time >= (ke.getWhen()))) {
                java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = typeAheadMarkers.isEmpty() ? null : typeAheadMarkers.getFirst();
                if (marker != null) {
                    java.awt.Window toplevel = marker.untilFocused.getContainingWindow();
                    if ((toplevel != null) && (toplevel.isFocused())) {
                        sun.awt.SunToolkit.postEvent(sun.awt.AppContext.getAppContext(), new java.awt.SequencedEvent(e));
                        return true;
                    } 
                } 
            } 
        }
        return false;
    }

    public boolean dispatchEvent(java.awt.AWTEvent e) {
        if ((java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) && ((e instanceof java.awt.event.WindowEvent) || (e instanceof java.awt.event.FocusEvent))) {
            java.awt.DefaultKeyboardFocusManager.focusLog.fine(("" + e));
        } 
        switch (e.getID()) {
            case java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS :
                {
                    if (repostIfFollowsKeyEvents(((java.awt.event.WindowEvent)(e)))) {
                        break;
                    } 
                    java.awt.event.WindowEvent we = ((java.awt.event.WindowEvent)(e));
                    java.awt.Window oldFocusedWindow = getGlobalFocusedWindow();
                    java.awt.Window newFocusedWindow = we.getWindow();
                    if (newFocusedWindow == oldFocusedWindow) {
                        break;
                    } 
                    if (!(((newFocusedWindow.isFocusableWindow()) && (newFocusedWindow.isVisible())) && (newFocusedWindow.isDisplayable()))) {
                        restoreFocus(we);
                        break;
                    } 
                    if (oldFocusedWindow != null) {
                        boolean isEventDispatched = java.awt.DefaultKeyboardFocusManager.sendMessage(oldFocusedWindow, new java.awt.event.WindowEvent(oldFocusedWindow , java.awt.event.WindowEvent.WINDOW_LOST_FOCUS , newFocusedWindow));
                        if (!isEventDispatched) {
                            setGlobalFocusOwner(null);
                            setGlobalFocusedWindow(null);
                        } 
                    } 
                    java.awt.Window newActiveWindow = getOwningFrameDialog(newFocusedWindow);
                    java.awt.Window currentActiveWindow = getGlobalActiveWindow();
                    if (newActiveWindow != currentActiveWindow) {
                        java.awt.DefaultKeyboardFocusManager.sendMessage(newActiveWindow, new java.awt.event.WindowEvent(newActiveWindow , java.awt.event.WindowEvent.WINDOW_ACTIVATED , currentActiveWindow));
                        if (newActiveWindow != (getGlobalActiveWindow())) {
                            restoreFocus(we);
                            break;
                        } 
                    } 
                    setGlobalFocusedWindow(newFocusedWindow);
                    if (newFocusedWindow != (getGlobalFocusedWindow())) {
                        restoreFocus(we);
                        break;
                    } 
                    if ((inSendMessage) == 0) {
                        java.awt.Component toFocus = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(newFocusedWindow);
                        if ((toFocus == null) && (newFocusedWindow.isFocusableWindow())) {
                            toFocus = newFocusedWindow.getFocusTraversalPolicy().getInitialComponent(newFocusedWindow);
                        } 
                        java.awt.Component tempLost = null;
                        synchronized(java.awt.KeyboardFocusManager.class) {
                            tempLost = newFocusedWindow.setTemporaryLostComponent(null);
                        }
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                            java.awt.DefaultKeyboardFocusManager.focusLog.finer("tempLost {0}, toFocus {1}", tempLost, toFocus);
                        } 
                        if (tempLost != null) {
                            tempLost.requestFocusInWindow(sun.awt.CausedFocusEvent.Cause.ACTIVATION);
                        } 
                        if ((toFocus != null) && (toFocus != tempLost)) {
                            toFocus.requestFocusInWindow(sun.awt.CausedFocusEvent.Cause.ACTIVATION);
                        } 
                    } 
                    java.awt.Window realOppositeWindow = java.awt.DefaultKeyboardFocusManager.this.realOppositeWindowWR.get();
                    if (realOppositeWindow != (we.getOppositeWindow())) {
                        we = new java.awt.event.WindowEvent(newFocusedWindow , java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS , realOppositeWindow);
                    } 
                    return typeAheadAssertions(newFocusedWindow, we);
                }
            case java.awt.event.WindowEvent.WINDOW_ACTIVATED :
                {
                    java.awt.event.WindowEvent we = ((java.awt.event.WindowEvent)(e));
                    java.awt.Window oldActiveWindow = getGlobalActiveWindow();
                    java.awt.Window newActiveWindow = we.getWindow();
                    if (oldActiveWindow == newActiveWindow) {
                        break;
                    } 
                    if (oldActiveWindow != null) {
                        boolean isEventDispatched = java.awt.DefaultKeyboardFocusManager.sendMessage(oldActiveWindow, new java.awt.event.WindowEvent(oldActiveWindow , java.awt.event.WindowEvent.WINDOW_DEACTIVATED , newActiveWindow));
                        if (!isEventDispatched) {
                            setGlobalActiveWindow(null);
                        } 
                        if ((getGlobalActiveWindow()) != null) {
                            break;
                        } 
                    } 
                    setGlobalActiveWindow(newActiveWindow);
                    if (newActiveWindow != (getGlobalActiveWindow())) {
                        break;
                    } 
                    return typeAheadAssertions(newActiveWindow, we);
                }
            case java.awt.event.FocusEvent.FOCUS_GAINED :
                {
                    java.awt.event.FocusEvent fe = ((java.awt.event.FocusEvent)(e));
                    sun.awt.CausedFocusEvent.Cause cause = fe instanceof sun.awt.CausedFocusEvent ? ((sun.awt.CausedFocusEvent)(fe)).getCause() : sun.awt.CausedFocusEvent.Cause.UNKNOWN;
                    java.awt.Component oldFocusOwner = getGlobalFocusOwner();
                    java.awt.Component newFocusOwner = fe.getComponent();
                    if (oldFocusOwner == newFocusOwner) {
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                            java.awt.DefaultKeyboardFocusManager.focusLog.fine("Skipping {0} because focus owner is the same", e);
                        } 
                        dequeueKeyEvents((-1), newFocusOwner);
                        break;
                    } 
                    if (oldFocusOwner != null) {
                        boolean isEventDispatched = java.awt.DefaultKeyboardFocusManager.sendMessage(oldFocusOwner, new sun.awt.CausedFocusEvent(oldFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , fe.isTemporary() , newFocusOwner , cause));
                        if (!isEventDispatched) {
                            setGlobalFocusOwner(null);
                            if (!(fe.isTemporary())) {
                                setGlobalPermanentFocusOwner(null);
                            } 
                        } 
                    } 
                    final java.awt.Window newFocusedWindow = null;
                    final java.awt.Window currentFocusedWindow = getGlobalFocusedWindow();
                    if ((newFocusedWindow != null) && (newFocusedWindow != currentFocusedWindow)) {
                        java.awt.DefaultKeyboardFocusManager.sendMessage(newFocusedWindow, new java.awt.event.WindowEvent(newFocusedWindow , java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS , currentFocusedWindow));
                        if (newFocusedWindow != (getGlobalFocusedWindow())) {
                            dequeueKeyEvents((-1), newFocusOwner);
                            break;
                        } 
                    } 
                    if (!(((newFocusOwner.isFocusable()) && (newFocusOwner.isShowing())) && ((newFocusOwner.isEnabled()) || (cause.equals(sun.awt.CausedFocusEvent.Cause.UNKNOWN))))) {
                        dequeueKeyEvents((-1), newFocusOwner);
                        if (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled()) {
                            if (newFocusedWindow == null) {
                                restoreFocus(fe, currentFocusedWindow);
                            } else {
                                restoreFocus(fe, newFocusedWindow);
                            }
                            java.awt.KeyboardFocusManager.setMostRecentFocusOwner(newFocusedWindow, null);
                        } 
                        break;
                    } 
                    setGlobalFocusOwner(newFocusOwner);
                    if (newFocusOwner != (getGlobalFocusOwner())) {
                        dequeueKeyEvents((-1), newFocusOwner);
                        if (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled()) {
                            restoreFocus(fe, ((java.awt.Window)(newFocusedWindow)));
                        } 
                        break;
                    } 
                    if (!(fe.isTemporary())) {
                        setGlobalPermanentFocusOwner(newFocusOwner);
                        if (newFocusOwner != (getGlobalPermanentFocusOwner())) {
                            dequeueKeyEvents((-1), newFocusOwner);
                            if (java.awt.KeyboardFocusManager.isAutoFocusTransferEnabled()) {
                                restoreFocus(fe, ((java.awt.Window)(newFocusedWindow)));
                            } 
                            break;
                        } 
                    } 
                    setNativeFocusOwner(java.awt.KeyboardFocusManager.getHeavyweight(newFocusOwner));
                    java.awt.Component realOppositeComponent = java.awt.DefaultKeyboardFocusManager.this.realOppositeComponentWR.get();
                    if ((realOppositeComponent != null) && (realOppositeComponent != (fe.getOppositeComponent()))) {
                        fe = new sun.awt.CausedFocusEvent(newFocusOwner , java.awt.event.FocusEvent.FOCUS_GAINED , fe.isTemporary() , realOppositeComponent , cause);
                        ((java.awt.AWTEvent)(fe)).isPosted = true;
                    } 
                    return typeAheadAssertions(newFocusOwner, fe);
                }
            case java.awt.event.FocusEvent.FOCUS_LOST :
                {
                    java.awt.event.FocusEvent fe = ((java.awt.event.FocusEvent)(e));
                    java.awt.Component currentFocusOwner = getGlobalFocusOwner();
                    if (currentFocusOwner == null) {
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE))
                            java.awt.DefaultKeyboardFocusManager.focusLog.fine("Skipping {0} because focus owner is null", e);
                        
                        break;
                    } 
                    if (currentFocusOwner == (fe.getOppositeComponent())) {
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE))
                            java.awt.DefaultKeyboardFocusManager.focusLog.fine("Skipping {0} because current focus owner is equal to opposite", e);
                        
                        break;
                    } 
                    setGlobalFocusOwner(null);
                    if ((getGlobalFocusOwner()) != null) {
                        restoreFocus(currentFocusOwner, true);
                        break;
                    } 
                    if (!(fe.isTemporary())) {
                        setGlobalPermanentFocusOwner(null);
                        if ((getGlobalPermanentFocusOwner()) != null) {
                            restoreFocus(currentFocusOwner, true);
                            break;
                        } 
                    } else {
                        java.awt.Window owningWindow = currentFocusOwner.getContainingWindow();
                        if (owningWindow != null) {
                            owningWindow.setTemporaryLostComponent(currentFocusOwner);
                        } 
                    }
                    setNativeFocusOwner(null);
                    fe.setSource(currentFocusOwner);
                    realOppositeComponentWR = (fe.getOppositeComponent()) != null ? new java.lang.ref.WeakReference<java.awt.Component>(currentFocusOwner) : java.awt.DefaultKeyboardFocusManager.NULL_COMPONENT_WR;
                    return typeAheadAssertions(currentFocusOwner, fe);
                }
            case java.awt.event.WindowEvent.WINDOW_DEACTIVATED :
                {
                    java.awt.event.WindowEvent we = ((java.awt.event.WindowEvent)(e));
                    java.awt.Window currentActiveWindow = getGlobalActiveWindow();
                    if (currentActiveWindow == null) {
                        break;
                    } 
                    if (currentActiveWindow != (e.getSource())) {
                        break;
                    } 
                    setGlobalActiveWindow(null);
                    if ((getGlobalActiveWindow()) != null) {
                        break;
                    } 
                    we.setSource(currentActiveWindow);
                    return typeAheadAssertions(currentActiveWindow, we);
                }
            case java.awt.event.WindowEvent.WINDOW_LOST_FOCUS :
                {
                    if (repostIfFollowsKeyEvents(((java.awt.event.WindowEvent)(e)))) {
                        break;
                    } 
                    java.awt.event.WindowEvent we = ((java.awt.event.WindowEvent)(e));
                    java.awt.Window currentFocusedWindow = getGlobalFocusedWindow();
                    java.awt.Window losingFocusWindow = we.getWindow();
                    java.awt.Window activeWindow = getGlobalActiveWindow();
                    java.awt.Window oppositeWindow = we.getOppositeWindow();
                    if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE))
                        java.awt.DefaultKeyboardFocusManager.focusLog.fine("Active {0}, Current focused {1}, losing focus {2} opposite {3}", activeWindow, currentFocusedWindow, losingFocusWindow, oppositeWindow);
                    
                    if (currentFocusedWindow == null) {
                        break;
                    } 
                    if ((((inSendMessage) == 0) && (losingFocusWindow == activeWindow)) && (oppositeWindow == currentFocusedWindow)) {
                        break;
                    } 
                    java.awt.Component currentFocusOwner = getGlobalFocusOwner();
                    if (currentFocusOwner != null) {
                        java.awt.Component oppositeComp = null;
                        if (oppositeWindow != null) {
                            oppositeComp = oppositeWindow.getTemporaryLostComponent();
                            if (oppositeComp == null) {
                                oppositeComp = oppositeWindow.getMostRecentFocusOwner();
                            } 
                        } 
                        if (oppositeComp == null) {
                            oppositeComp = oppositeWindow;
                        } 
                        java.awt.DefaultKeyboardFocusManager.sendMessage(currentFocusOwner, new sun.awt.CausedFocusEvent(currentFocusOwner , java.awt.event.FocusEvent.FOCUS_LOST , true , oppositeComp , sun.awt.CausedFocusEvent.Cause.ACTIVATION));
                    } 
                    setGlobalFocusedWindow(null);
                    if ((getGlobalFocusedWindow()) != null) {
                        restoreFocus(currentFocusedWindow, null, true);
                        break;
                    } 
                    we.setSource(currentFocusedWindow);
                    realOppositeWindowWR = oppositeWindow != null ? new java.lang.ref.WeakReference<java.awt.Window>(currentFocusedWindow) : java.awt.DefaultKeyboardFocusManager.NULL_WINDOW_WR;
                    typeAheadAssertions(currentFocusedWindow, we);
                    if (oppositeWindow == null) {
                        java.awt.DefaultKeyboardFocusManager.sendMessage(activeWindow, new java.awt.event.WindowEvent(activeWindow , java.awt.event.WindowEvent.WINDOW_DEACTIVATED , null));
                        if ((getGlobalActiveWindow()) != null) {
                            restoreFocus(currentFocusedWindow, null, true);
                        } 
                    } 
                    break;
                }
            case java.awt.event.KeyEvent.KEY_TYPED :
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
                return typeAheadAssertions(null, e);
            default :
                return false;
        }
        return true;
    }

    public boolean dispatchKeyEvent(java.awt.event.KeyEvent e) {
        java.awt.Component focusOwner = ((java.awt.AWTEvent)(e)).isPosted ? getFocusOwner() : e.getComponent();
        if (((focusOwner != null) && (focusOwner.isShowing())) && (focusOwner.canBeFocusOwner())) {
            if (!(e.isConsumed())) {
                java.awt.Component comp = e.getComponent();
                if ((comp != null) && (comp.isEnabled())) {
                    redispatchEvent(comp, e);
                } 
            } 
        } 
        boolean stopPostProcessing = false;
        java.util.List<java.awt.KeyEventPostProcessor> processors = getKeyEventPostProcessors();
        if (processors != null) {
            for (java.util.Iterator<java.awt.KeyEventPostProcessor> iter = processors.iterator() ; (!stopPostProcessing) && (iter.hasNext()) ; ) {
                stopPostProcessing = iter.next().postProcessKeyEvent(e);
            }
        } 
        if (!stopPostProcessing) {
            postProcessKeyEvent(e);
        } 
        java.awt.Component source = e.getComponent();
        java.awt.peer.ComponentPeer peer = source.getPeer();
        if ((peer == null) || (peer instanceof java.awt.peer.LightweightPeer)) {
            java.awt.Container target = source.getNativeContainer();
            if (target != null) {
                peer = target.getPeer();
            } 
        } 
        if (peer != null) {
            peer.handleEvent(e);
        } 
        return true;
    }

    public boolean postProcessKeyEvent(java.awt.event.KeyEvent e) {
        if (!(e.isConsumed())) {
            java.awt.Component target = e.getComponent();
            java.awt.Container p = ((java.awt.Container)(target instanceof java.awt.Container ? target : target.getParent()));
            if (p != null) {
                p.postProcessKeyEvent(e);
            } 
        } 
        return true;
    }

    private void pumpApprovedKeyEvents() {
        java.awt.event.KeyEvent ke;
        do {
            ke = null;
            synchronized(java.awt.DefaultKeyboardFocusManager.this) {
                if ((enqueuedKeyEvents.size()) != 0) {
                    ke = enqueuedKeyEvents.getFirst();
                    if ((typeAheadMarkers.size()) != 0) {
                        java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = typeAheadMarkers.getFirst();
                        if ((ke.getWhen()) > (marker.after)) {
                            ke = null;
                        } 
                    } 
                    if (ke != null) {
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                            java.awt.DefaultKeyboardFocusManager.focusLog.finer("Pumping approved event {0}", ke);
                        } 
                        enqueuedKeyEvents.removeFirst();
                    } 
                } 
            }
            if (ke != null) {
                preDispatchKeyEvent(ke);
            } 
        } while (ke != null );
    }

    void dumpMarkers() {
        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.DefaultKeyboardFocusManager.focusLog.finest(">>> Markers dump, time: {0}", java.lang.System.currentTimeMillis());
            synchronized(java.awt.DefaultKeyboardFocusManager.this) {
                if ((typeAheadMarkers.size()) != 0) {
                    java.util.Iterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.iterator();
                    while (iter.hasNext()) {
                        java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = iter.next();
                        java.awt.DefaultKeyboardFocusManager.focusLog.finest("    {0}", marker);
                    }
                } 
            }
        } 
    }

    private boolean typeAheadAssertions(java.awt.Component target, java.awt.AWTEvent e) {
        pumpApprovedKeyEvents();
        switch (e.getID()) {
            case java.awt.event.KeyEvent.KEY_TYPED :
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
                {
                    java.awt.event.KeyEvent ke = ((java.awt.event.KeyEvent)(e));
                    synchronized(java.awt.DefaultKeyboardFocusManager.this) {
                        if ((e.isPosted) && ((typeAheadMarkers.size()) != 0)) {
                            java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = typeAheadMarkers.getFirst();
                            if ((ke.getWhen()) > (marker.after)) {
                                if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                                    java.awt.DefaultKeyboardFocusManager.focusLog.finer("Storing event {0} because of marker {1}", ke, marker);
                                } 
                                enqueuedKeyEvents.addLast(ke);
                                return true;
                            } 
                        } 
                    }
                    return preDispatchKeyEvent(ke);
                }
            case java.awt.event.FocusEvent.FOCUS_GAINED :
                if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                    java.awt.DefaultKeyboardFocusManager.focusLog.finest("Markers before FOCUS_GAINED on {0}", target);
                } 
                dumpMarkers();
                synchronized(java.awt.DefaultKeyboardFocusManager.this) {
                    boolean found = false;
                    if (hasMarker(target)) {
                        for (java.util.Iterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.iterator() ; iter.hasNext() ; ) {
                            if ((iter.next().untilFocused) == target) {
                                found = true;
                            } else if (found) {
                                break;
                            } 
                            iter.remove();
                        }
                    } else {
                        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                            java.awt.DefaultKeyboardFocusManager.focusLog.finer("Event without marker {0}", e);
                        } 
                    }
                }
                java.awt.DefaultKeyboardFocusManager.focusLog.finest("Markers after FOCUS_GAINED");
                dumpMarkers();
                redispatchEvent(target, e);
                pumpApprovedKeyEvents();
                return true;
            default :
                redispatchEvent(target, e);
                return true;
        }
    }

    private boolean hasMarker(java.awt.Component comp) {
        for (java.util.Iterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.iterator() ; iter.hasNext() ; ) {
            if ((iter.next().untilFocused) == comp) {
                return true;
            } 
        }
        return false;
    }

    void clearMarkers() {
        synchronized(java.awt.DefaultKeyboardFocusManager.this) {
            typeAheadMarkers.clear();
        }
    }

    private boolean preDispatchKeyEvent(java.awt.event.KeyEvent ke) {
        if (((java.awt.AWTEvent)(ke)).isPosted) {
            java.awt.Component focusOwner = getFocusOwner();
            ke.setSource((focusOwner != null ? focusOwner : getFocusedWindow()));
        } 
        if ((ke.getSource()) == null) {
            return true;
        } 
        java.awt.EventQueue.setCurrentEventAndMostRecentTime(ke);
        if (java.awt.KeyboardFocusManager.isProxyActive(ke)) {
            java.awt.Component source = ((java.awt.Component)(ke.getSource()));
            java.awt.Container target = source.getNativeContainer();
            if (target != null) {
                java.awt.peer.ComponentPeer peer = target.getPeer();
                if (peer != null) {
                    peer.handleEvent(ke);
                    ke.consume();
                } 
            } 
            return true;
        } 
        java.util.List<java.awt.KeyEventDispatcher> dispatchers = getKeyEventDispatchers();
        if (dispatchers != null) {
            for (java.util.Iterator<java.awt.KeyEventDispatcher> iter = dispatchers.iterator() ; iter.hasNext() ; ) {
                if (iter.next().dispatchKeyEvent(ke)) {
                    return true;
                } 
            }
        } 
        return dispatchKeyEvent(ke);
    }

    private void consumeNextKeyTyped(java.awt.event.KeyEvent e) {
        consumeNextKeyTyped = true;
    }

    private void consumeTraversalKey(java.awt.event.KeyEvent e) {
        e.consume();
        consumeNextKeyTyped = ((e.getID()) == (java.awt.event.KeyEvent.KEY_PRESSED)) && (!(e.isActionKey()));
    }

    private boolean consumeProcessedKeyEvent(java.awt.event.KeyEvent e) {
        if (((e.getID()) == (java.awt.event.KeyEvent.KEY_TYPED)) && (consumeNextKeyTyped)) {
            e.consume();
            consumeNextKeyTyped = false;
            return true;
        } 
        return false;
    }

    public void processKeyEvent(java.awt.Component focusedComponent, java.awt.event.KeyEvent e) {
        if (consumeProcessedKeyEvent(e)) {
            return ;
        } 
        if ((e.getID()) == (java.awt.event.KeyEvent.KEY_TYPED)) {
            return ;
        } 
        if ((focusedComponent.getFocusTraversalKeysEnabled()) && (!(e.isConsumed()))) {
            java.awt.AWTKeyStroke stroke = java.awt.AWTKeyStroke.getAWTKeyStrokeForEvent(e);
            java.awt.AWTKeyStroke oppStroke = java.awt.AWTKeyStroke.getAWTKeyStroke(stroke.getKeyCode(), stroke.getModifiers(), (!(stroke.isOnKeyRelease())));
            java.util.Set<java.awt.AWTKeyStroke> toTest;
            boolean contains;
            boolean containsOpp;
            toTest = focusedComponent.getFocusTraversalKeys(java.awt.KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS);
            contains = toTest.contains(stroke);
            containsOpp = toTest.contains(oppStroke);
            if (contains || containsOpp) {
                consumeTraversalKey(e);
                if (contains) {
                    focusNextComponent(focusedComponent);
                } 
                return ;
            } else if ((e.getID()) == (java.awt.event.KeyEvent.KEY_PRESSED)) {
                consumeNextKeyTyped = false;
            } 
            toTest = focusedComponent.getFocusTraversalKeys(java.awt.KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS);
            contains = toTest.contains(stroke);
            containsOpp = toTest.contains(oppStroke);
            if (contains || containsOpp) {
                consumeTraversalKey(e);
                if (contains) {
                    focusPreviousComponent(focusedComponent);
                } 
                return ;
            } 
            toTest = focusedComponent.getFocusTraversalKeys(java.awt.KeyboardFocusManager.UP_CYCLE_TRAVERSAL_KEYS);
            contains = toTest.contains(stroke);
            containsOpp = toTest.contains(oppStroke);
            if (contains || containsOpp) {
                consumeTraversalKey(e);
                if (contains) {
                    upFocusCycle(focusedComponent);
                } 
                return ;
            } 
            if (!((focusedComponent instanceof java.awt.Container) && (((java.awt.Container)(focusedComponent)).isFocusCycleRoot()))) {
                return ;
            } 
            toTest = focusedComponent.getFocusTraversalKeys(java.awt.KeyboardFocusManager.DOWN_CYCLE_TRAVERSAL_KEYS);
            contains = toTest.contains(stroke);
            containsOpp = toTest.contains(oppStroke);
            if (contains || containsOpp) {
                consumeTraversalKey(e);
                if (contains) {
                    downFocusCycle(((java.awt.Container)(focusedComponent)));
                } 
            } 
        } 
    }

    protected synchronized void enqueueKeyEvents(long after, java.awt.Component untilFocused) {
        if (untilFocused == null) {
            return ;
        } 
        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.DefaultKeyboardFocusManager.focusLog.finer("Enqueue at {0} for {1}", after, untilFocused);
        } 
        int insertionIndex = 0;
        int i = typeAheadMarkers.size();
        java.util.ListIterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.listIterator(i);
        for ( ; i > 0 ; i--) {
            java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = iter.previous();
            if ((marker.after) <= after) {
                insertionIndex = i;
                break;
            } 
        }
        typeAheadMarkers.add(insertionIndex, new java.awt.DefaultKeyboardFocusManager.TypeAheadMarker(after , untilFocused));
    }

    protected synchronized void dequeueKeyEvents(long after, java.awt.Component untilFocused) {
        if (untilFocused == null) {
            return ;
        } 
        if (java.awt.DefaultKeyboardFocusManager.focusLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            java.awt.DefaultKeyboardFocusManager.focusLog.finer("Dequeue at {0} for {1}", after, untilFocused);
        } 
        java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker;
        java.util.ListIterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.listIterator((after >= 0 ? typeAheadMarkers.size() : 0));
        if (after < 0) {
            while (iter.hasNext()) {
                marker = iter.next();
                if ((marker.untilFocused) == untilFocused) {
                    iter.remove();
                    return ;
                } 
            }
        } else {
            while (iter.hasPrevious()) {
                marker = iter.previous();
                if (((marker.untilFocused) == untilFocused) && ((marker.after) == after)) {
                    iter.remove();
                    return ;
                } 
            }
        }
    }

    protected synchronized void discardKeyEvents(java.awt.Component comp) {
        if (comp == null) {
            return ;
        } 
        long start = -1;
        for (java.util.Iterator<java.awt.DefaultKeyboardFocusManager.TypeAheadMarker> iter = typeAheadMarkers.iterator() ; iter.hasNext() ; ) {
            java.awt.DefaultKeyboardFocusManager.TypeAheadMarker marker = iter.next();
            java.awt.Component toTest = marker.untilFocused;
            boolean match = toTest == comp;
            while (((!match) && (toTest != null)) && (!(toTest instanceof java.awt.Window))) {
                toTest = toTest.getParent();
                match = toTest == comp;
            }
            if (match) {
                if (start < 0) {
                    start = marker.after;
                } 
                iter.remove();
            } else if (start >= 0) {
                purgeStampedEvents(start, marker.after);
                start = -1;
            } 
        }
        purgeStampedEvents(start, (-1));
    }

    private void purgeStampedEvents(long start, long end) {
        if (start < 0) {
            return ;
        } 
        for (java.util.Iterator<java.awt.event.KeyEvent> iter = enqueuedKeyEvents.iterator() ; iter.hasNext() ; ) {
            java.awt.event.KeyEvent ke = iter.next();
            long time = ke.getWhen();
            if ((start < time) && ((end < 0) || (time <= end))) {
                iter.remove();
            } 
            if ((end >= 0) && (time > end)) {
                break;
            } 
        }
    }

    public void focusPreviousComponent(java.awt.Component aComponent) {
        if (aComponent != null) {
            aComponent.transferFocusBackward();
        } 
    }

    public void focusNextComponent(java.awt.Component aComponent) {
        if (aComponent != null) {
            aComponent.transferFocus();
        } 
    }

    public void upFocusCycle(java.awt.Component aComponent) {
        if (aComponent != null) {
            aComponent.transferFocusUpCycle();
        } 
    }

    public void downFocusCycle(java.awt.Container aContainer) {
        if ((aContainer != null) && (aContainer.isFocusCycleRoot())) {
            aContainer.transferFocusDownCycle();
        } 
    }
}


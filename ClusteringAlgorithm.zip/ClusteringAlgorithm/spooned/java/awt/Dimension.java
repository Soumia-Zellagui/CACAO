package java.awt;


public class Dimension extends java.awt.geom.Dimension2D implements java.io.Serializable {
    public int width;

    public int height;

    private static final long serialVersionUID = 4723952579491349524L;

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Dimension.initIDs();
        } 
    }

    public Dimension() {
        this(0, 0);
    }

    public Dimension(java.awt.Dimension d) {
        this(d.width, d.height);
    }

    public Dimension(int width ,int height) {
        java.awt.Dimension.this.width = width;
        java.awt.Dimension.this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public void setSize(double width, double height) {
        java.awt.Dimension.this.width = ((int)(java.lang.Math.ceil(width)));
        java.awt.Dimension.this.height = ((int)(java.lang.Math.ceil(height)));
    }

    @java.beans.Transient
    public java.awt.Dimension getSize() {
        return new java.awt.Dimension(width , height);
    }

    public void setSize(java.awt.Dimension d) {
        setSize(d.width, d.height);
    }

    public void setSize(int width, int height) {
        java.awt.Dimension.this.width = width;
        java.awt.Dimension.this.height = height;
    }

    public boolean equals(java.lang.Object obj) {
        if (obj instanceof java.awt.Dimension) {
            java.awt.Dimension d = ((java.awt.Dimension)(obj));
            return ((width) == (d.width)) && ((height) == (d.height));
        } 
        return false;
    }

    public int hashCode() {
        int sum = (width) + (height);
        return ((sum * (sum + 1)) / 2) + (width);
    }

    public java.lang.String toString() {
        return (((((getClass().getName()) + "[width=") + (width)) + ",height=") + (height)) + "]";
    }
}


package java.awt;


public interface CompositeContext {
    public void dispose();

    public void compose(java.awt.image.Raster src, java.awt.image.Raster dstIn, java.awt.image.WritableRaster dstOut);
}


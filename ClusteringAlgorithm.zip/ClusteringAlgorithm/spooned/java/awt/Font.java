package java.awt;


public class Font implements java.io.Serializable {
    private static class FontAccessImpl extends sun.font.FontAccess {
        public sun.font.Font2D getFont2D(java.awt.Font font) {
            return font.getFont2D();
        }

        public void setFont2D(java.awt.Font font, sun.font.Font2DHandle handle) {
            font.font2DHandle = handle;
        }

        public void setCreatedFont(java.awt.Font font) {
            font.createdFont = true;
        }

        public boolean isCreatedFont(java.awt.Font font) {
            return font.createdFont;
        }
    }

    static {
        java.awt.Toolkit.loadLibraries();
        java.awt.Font.initIDs();
        sun.font.FontAccess.setFontAccess(new java.awt.Font.FontAccessImpl());
    }

    private java.util.Hashtable<java.lang.Object, java.lang.Object> fRequestedAttributes;

    public static final java.lang.String DIALOG = "Dialog";

    public static final java.lang.String DIALOG_INPUT = "DialogInput";

    public static final java.lang.String SANS_SERIF = "SansSerif";

    public static final java.lang.String SERIF = "Serif";

    public static final java.lang.String MONOSPACED = "Monospaced";

    public static final int PLAIN = 0;

    public static final int BOLD = 1;

    public static final int ITALIC = 2;

    public static final int ROMAN_BASELINE = 0;

    public static final int CENTER_BASELINE = 1;

    public static final int HANGING_BASELINE = 2;

    public static final int TRUETYPE_FONT = 0;

    public static final int TYPE1_FONT = 1;

    protected java.lang.String name;

    protected int style;

    protected int size;

    protected float pointSize;

    private transient java.awt.peer.FontPeer peer;

    private transient long pData;

    private transient sun.font.Font2DHandle font2DHandle;

    private transient sun.font.AttributeValues values;

    private transient boolean hasLayoutAttributes;

    private transient boolean createdFont = false;

    private transient boolean nonIdentityTx;

    private static final java.awt.geom.AffineTransform identityTx = new java.awt.geom.AffineTransform();

    private static final long serialVersionUID = -4206021311591459213L;

    @java.lang.Deprecated
    public java.awt.peer.FontPeer getPeer() {
        return getPeer_NoClientCode();
    }

    @java.lang.SuppressWarnings(value = "deprecation")
    final java.awt.peer.FontPeer getPeer_NoClientCode() {
        if ((peer) == null) {
            java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
            java.awt.Font.this.peer = tk.getFontPeer(name, style);
        } 
        return peer;
    }

    private sun.font.AttributeValues getAttributeValues() {
        if ((values) == null) {
            sun.font.AttributeValues valuesTmp = new sun.font.AttributeValues();
            valuesTmp.setFamily(name);
            valuesTmp.setSize(pointSize);
            if (((style) & (java.awt.Font.BOLD)) != 0) {
                valuesTmp.setWeight(2);
            } 
            if (((style) & (java.awt.Font.ITALIC)) != 0) {
                valuesTmp.setPosture(0.2F);
            } 
            valuesTmp.defineAll(java.awt.Font.PRIMARY_MASK);
            values = valuesTmp;
        } 
        return values;
    }

    private sun.font.Font2D getFont2D() {
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        if ((((fm.usingPerAppContextComposites()) && ((font2DHandle) != null)) && ((font2DHandle.font2D) instanceof sun.font.CompositeFont)) && (((sun.font.CompositeFont)(font2DHandle.font2D)).isStdComposite())) {
            return fm.findFont2D(name, style, sun.font.FontManager.LOGICAL_FALLBACK);
        } else if ((font2DHandle) == null) {
            font2DHandle = fm.findFont2D(name, style, sun.font.FontManager.LOGICAL_FALLBACK).handle;
        } 
        return font2DHandle.font2D;
    }

    public Font(java.lang.String name ,int style ,int size) {
        java.awt.Font.this.name = name != null ? name : "Default";
        java.awt.Font.this.style = (style & (~3)) == 0 ? style : 0;
        java.awt.Font.this.size = size;
        java.awt.Font.this.pointSize = size;
    }

    private Font(java.lang.String name ,int style ,float sizePts) {
        java.awt.Font.this.name = name != null ? name : "Default";
        java.awt.Font.this.style = (style & (~3)) == 0 ? style : 0;
        java.awt.Font.this.size = ((int)(sizePts + 0.5));
        java.awt.Font.this.pointSize = sizePts;
    }

    private Font(java.lang.String name ,int style ,float sizePts ,boolean created ,sun.font.Font2DHandle handle) {
        this(name, style, sizePts);
        java.awt.Font.this.createdFont = created;
        if (created) {
            if (((handle.font2D) instanceof sun.font.CompositeFont) && ((handle.font2D.getStyle()) != style)) {
                sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
                java.awt.Font.this.font2DHandle = fm.getNewComposite(null, style, handle);
            } else {
                java.awt.Font.this.font2DHandle = handle;
            }
        } 
    }

    private Font(java.io.File fontFile ,int fontFormat ,boolean isCopy ,sun.font.CreatedFontTracker tracker) throws java.awt.FontFormatException {
        java.awt.Font.this.createdFont = true;
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        java.awt.Font.this.font2DHandle = fm.createFont2D(fontFile, fontFormat, isCopy, tracker).handle;
        java.awt.Font.this.name = java.awt.Font.this.font2DHandle.font2D.getFontName(java.util.Locale.getDefault());
        java.awt.Font.this.style = java.awt.Font.PLAIN;
        java.awt.Font.this.size = 1;
        java.awt.Font.this.pointSize = 1.0F;
    }

    private Font(sun.font.AttributeValues values ,java.lang.String oldName ,int oldStyle ,boolean created ,sun.font.Font2DHandle handle) {
        java.awt.Font.this.createdFont = created;
        if (created) {
            java.awt.Font.this.font2DHandle = handle;
            java.lang.String newName = null;
            if (oldName != null) {
                newName = values.getFamily();
                if (oldName.equals(newName))
                    newName = null;
                
            } 
            int newStyle = 0;
            if (oldStyle == (-1)) {
                newStyle = -1;
            } else {
                if ((values.getWeight()) >= 2.0F)
                    newStyle = java.awt.Font.BOLD;
                
                if ((values.getPosture()) >= 0.2F)
                    newStyle |= java.awt.Font.ITALIC;
                
                if (oldStyle == newStyle)
                    newStyle = -1;
                
            }
            if ((handle.font2D) instanceof sun.font.CompositeFont) {
                if ((newStyle != (-1)) || (newName != null)) {
                    sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
                    java.awt.Font.this.font2DHandle = fm.getNewComposite(newName, newStyle, handle);
                } 
            } else if (newName != null) {
                java.awt.Font.this.createdFont = false;
                java.awt.Font.this.font2DHandle = null;
            } 
        } 
        initFromValues(values);
    }

    public Font(java.util.Map<? extends java.text.AttributedCharacterIterator.Attribute, ?> attributes) {
        initFromValues(sun.font.AttributeValues.fromMap(attributes, java.awt.Font.RECOGNIZED_MASK));
    }

    protected Font(java.awt.Font font) {
        if ((font.values) != null) {
            initFromValues(font.getAttributeValues().clone());
        } else {
            java.awt.Font.this.name = font.name;
            java.awt.Font.this.style = font.style;
            java.awt.Font.this.size = font.size;
            java.awt.Font.this.pointSize = font.pointSize;
        }
        java.awt.Font.this.font2DHandle = font.font2DHandle;
        java.awt.Font.this.createdFont = font.createdFont;
    }

    private static final int RECOGNIZED_MASK = (sun.font.AttributeValues.MASK_ALL) & (~(sun.font.AttributeValues.getMask(sun.font.EAttribute.EFONT)));

    private static final int PRIMARY_MASK = sun.font.AttributeValues.getMask(sun.font.EAttribute.EFAMILY, sun.font.EAttribute.EWEIGHT, sun.font.EAttribute.EWIDTH, sun.font.EAttribute.EPOSTURE, sun.font.EAttribute.ESIZE, sun.font.EAttribute.ETRANSFORM, sun.font.EAttribute.ESUPERSCRIPT, sun.font.EAttribute.ETRACKING);

    private static final int SECONDARY_MASK = (java.awt.Font.RECOGNIZED_MASK) & (~(java.awt.Font.PRIMARY_MASK));

    private static final int LAYOUT_MASK = sun.font.AttributeValues.getMask(sun.font.EAttribute.ECHAR_REPLACEMENT, sun.font.EAttribute.EFOREGROUND, sun.font.EAttribute.EBACKGROUND, sun.font.EAttribute.EUNDERLINE, sun.font.EAttribute.ESTRIKETHROUGH, sun.font.EAttribute.ERUN_DIRECTION, sun.font.EAttribute.EBIDI_EMBEDDING, sun.font.EAttribute.EJUSTIFICATION, sun.font.EAttribute.EINPUT_METHOD_HIGHLIGHT, sun.font.EAttribute.EINPUT_METHOD_UNDERLINE, sun.font.EAttribute.ESWAP_COLORS, sun.font.EAttribute.ENUMERIC_SHAPING, sun.font.EAttribute.EKERNING, sun.font.EAttribute.ELIGATURES, sun.font.EAttribute.ETRACKING, sun.font.EAttribute.ESUPERSCRIPT);

    private static final int EXTRA_MASK = sun.font.AttributeValues.getMask(sun.font.EAttribute.ETRANSFORM, sun.font.EAttribute.ESUPERSCRIPT, sun.font.EAttribute.EWIDTH);

    private void initFromValues(sun.font.AttributeValues values) {
        java.awt.Font.this.values = values;
        values.defineAll(java.awt.Font.PRIMARY_MASK);
        java.awt.Font.this.name = values.getFamily();
        java.awt.Font.this.pointSize = values.getSize();
        java.awt.Font.this.size = ((int)((values.getSize()) + 0.5));
        if ((values.getWeight()) >= 2.0F)
            java.awt.Font.this.style |= java.awt.Font.BOLD;
        
        if ((values.getPosture()) >= 0.2F)
            java.awt.Font.this.style |= java.awt.Font.ITALIC;
        
        java.awt.Font.this.nonIdentityTx = values.anyNonDefault(java.awt.Font.EXTRA_MASK);
        java.awt.Font.this.hasLayoutAttributes = values.anyNonDefault(java.awt.Font.LAYOUT_MASK);
    }

    public static java.awt.Font getFont(java.util.Map<? extends java.text.AttributedCharacterIterator.Attribute, ?> attributes) {
        if ((attributes instanceof sun.font.AttributeMap) && ((((sun.font.AttributeMap)(attributes)).getValues()) != null)) {
            sun.font.AttributeValues values = ((sun.font.AttributeMap)(attributes)).getValues();
            if (values.isNonDefault(sun.font.EAttribute.EFONT)) {
                java.awt.Font font = values.getFont();
                if (!(values.anyDefined(java.awt.Font.SECONDARY_MASK))) {
                    return font;
                } 
                values = font.getAttributeValues().clone();
                values.merge(attributes, java.awt.Font.SECONDARY_MASK);
                return new java.awt.Font(values , font.name , font.style , font.createdFont , font.font2DHandle);
            } 
            return new java.awt.Font(attributes);
        } 
        java.awt.Font font = ((java.awt.Font)(attributes.get(java.awt.font.TextAttribute.FONT)));
        if (font != null) {
            if ((attributes.size()) > 1) {
                sun.font.AttributeValues values = font.getAttributeValues().clone();
                values.merge(attributes, java.awt.Font.SECONDARY_MASK);
                return new java.awt.Font(values , font.name , font.style , font.createdFont , font.font2DHandle);
            } 
            return font;
        } 
        return new java.awt.Font(attributes);
    }

    private static boolean hasTempPermission() {
        if ((java.lang.System.getSecurityManager()) == null) {
            return true;
        } 
        java.io.File f = null;
        boolean hasPerm = false;
        try {
            f = java.nio.file.Files.createTempFile("+~JT", ".tmp").toFile();
            f.delete();
            f = null;
            hasPerm = true;
        } catch (java.lang.Throwable t) {
        }
        return hasPerm;
    }

    public static java.awt.Font createFont(int fontFormat, java.io.InputStream fontStream) throws java.awt.FontFormatException, java.io.IOException {
        if (java.awt.Font.hasTempPermission()) {
            return java.awt.Font.createFont0(fontFormat, fontStream, null);
        } 
        sun.font.CreatedFontTracker tracker = sun.font.CreatedFontTracker.getTracker();
        boolean acquired = false;
        try {
            acquired = tracker.acquirePermit();
            if (!acquired) {
                throw new java.io.IOException("Timed out waiting for resources.");
            } 
            return java.awt.Font.createFont0(fontFormat, fontStream, tracker);
        } catch (java.lang.InterruptedException e) {
            throw new java.io.IOException("Problem reading font data.");
        } finally {
            if (acquired) {
                tracker.releasePermit();
            } 
        }
    }

    private static java.awt.Font createFont0(int fontFormat, java.io.InputStream fontStream, sun.font.CreatedFontTracker tracker) throws java.awt.FontFormatException, java.io.IOException {
        if ((fontFormat != (java.awt.Font.TRUETYPE_FONT)) && (fontFormat != (java.awt.Font.TYPE1_FONT))) {
            throw new java.lang.IllegalArgumentException("font format not recognized");
        } 
        boolean copiedFontData = false;
        try {
            final java.io.File tFile = java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction<java.io.File>() {
                public java.io.File run() throws java.io.IOException {
                    return java.nio.file.Files.createTempFile("+~JF", ".tmp").toFile();
                }
            });
            if (tracker != null) {
                tracker.add(tFile);
            } 
            int totalSize = 0;
            try {
                final java.io.OutputStream outStream = java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction<java.io.OutputStream>() {
                    public java.io.OutputStream run() throws java.io.IOException {
                        return new java.io.FileOutputStream(tFile);
                    }
                });
                if (tracker != null) {
                    tracker.set(tFile, outStream);
                } 
                try {
                    byte[] buf = new byte[8192];
                    for ( ;  ; ) {
                        int bytesRead = fontStream.read(buf);
                        if (bytesRead < 0) {
                            break;
                        } 
                        if (tracker != null) {
                            if ((totalSize + bytesRead) > (sun.font.CreatedFontTracker.MAX_FILE_SIZE)) {
                                throw new java.io.IOException("File too big.");
                            } 
                            if ((totalSize + (tracker.getNumBytes())) > (sun.font.CreatedFontTracker.MAX_TOTAL_BYTES)) {
                                throw new java.io.IOException("Total files too big.");
                            } 
                            totalSize += bytesRead;
                            tracker.addBytes(bytesRead);
                        } 
                        outStream.write(buf, 0, bytesRead);
                    }
                } finally {
                    outStream.close();
                }
                copiedFontData = true;
                java.awt.Font font = new java.awt.Font(tFile , fontFormat , true , tracker);
                return font;
            } finally {
                if (tracker != null) {
                    tracker.remove(tFile);
                } 
                if (!copiedFontData) {
                    if (tracker != null) {
                        tracker.subBytes(totalSize);
                    } 
                    java.security.AccessController.doPrivileged(new java.security.PrivilegedExceptionAction<java.lang.Void>() {
                        public java.lang.Void run() {
                            tFile.delete();
                            return null;
                        }
                    });
                } 
            }
        } catch (java.lang.Throwable t) {
            if (t instanceof java.awt.FontFormatException) {
                throw ((java.awt.FontFormatException)(t));
            } 
            if (t instanceof java.io.IOException) {
                throw ((java.io.IOException)(t));
            } 
            java.lang.Throwable cause = t.getCause();
            if (cause instanceof java.awt.FontFormatException) {
                throw ((java.awt.FontFormatException)(cause));
            } 
            throw new java.io.IOException("Problem reading font data.");
        }
    }

    public static java.awt.Font createFont(int fontFormat, java.io.File fontFile) throws java.awt.FontFormatException, java.io.IOException {
        fontFile = new java.io.File(fontFile.getPath());
        if ((fontFormat != (java.awt.Font.TRUETYPE_FONT)) && (fontFormat != (java.awt.Font.TYPE1_FONT))) {
            throw new java.lang.IllegalArgumentException("font format not recognized");
        } 
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm != null) {
            java.io.FilePermission filePermission = new java.io.FilePermission(fontFile.getPath() , "read");
            sm.checkPermission(filePermission);
        } 
        if (!(fontFile.canRead())) {
            throw new java.io.IOException(("Can't read " + fontFile));
        } 
        return new java.awt.Font(fontFile , fontFormat , false , null);
    }

    public java.awt.geom.AffineTransform getTransform() {
        if (nonIdentityTx) {
            sun.font.AttributeValues values = getAttributeValues();
            java.awt.geom.AffineTransform at = values.isNonDefault(sun.font.EAttribute.ETRANSFORM) ? new java.awt.geom.AffineTransform(values.getTransform()) : new java.awt.geom.AffineTransform();
            if ((values.getSuperscript()) != 0) {
                int superscript = values.getSuperscript();
                double trans = 0;
                int n = 0;
                boolean up = superscript > 0;
                int sign = up ? -1 : 1;
                int ss = up ? superscript : -superscript;
                while ((ss & 7) > n) {
                    int newn = ss & 7;
                    trans += sign * ((java.awt.Font.ssinfo[newn]) - (java.awt.Font.ssinfo[n]));
                    ss >>= 3;
                    sign = -sign;
                    n = newn;
                }
                trans *= pointSize;
                double scale = java.lang.Math.pow((2.0 / 3.0), n);
                at.preConcatenate(java.awt.geom.AffineTransform.getTranslateInstance(0, trans));
                at.scale(scale, scale);
            } 
            if (values.isNonDefault(sun.font.EAttribute.EWIDTH)) {
                at.scale(values.getWidth(), 1.0F);
            } 
            return at;
        } 
        return new java.awt.geom.AffineTransform();
    }

    private static final float[] ssinfo = new float[]{ 0.0F , 0.375F , 0.625F , 0.7916667F , 0.9027778F , 0.9768519F , 1.0262346F , 1.0591564F };

    public java.lang.String getFamily() {
        return getFamily_NoClientCode();
    }

    final java.lang.String getFamily_NoClientCode() {
        return getFamily(java.util.Locale.getDefault());
    }

    public java.lang.String getFamily(java.util.Locale l) {
        if (l == null) {
            throw new java.lang.NullPointerException("null locale doesn't mean default");
        } 
        return getFont2D().getFamilyName(l);
    }

    public java.lang.String getPSName() {
        return getFont2D().getPostscriptName();
    }

    public java.lang.String getName() {
        return name;
    }

    public java.lang.String getFontName() {
        return getFontName(java.util.Locale.getDefault());
    }

    public java.lang.String getFontName(java.util.Locale l) {
        if (l == null) {
            throw new java.lang.NullPointerException("null locale doesn't mean default");
        } 
        return getFont2D().getFontName(l);
    }

    public int getStyle() {
        return style;
    }

    public int getSize() {
        return size;
    }

    public float getSize2D() {
        return pointSize;
    }

    public boolean isPlain() {
        return (style) == 0;
    }

    public boolean isBold() {
        return ((style) & (java.awt.Font.BOLD)) != 0;
    }

    public boolean isItalic() {
        return ((style) & (java.awt.Font.ITALIC)) != 0;
    }

    public boolean isTransformed() {
        return nonIdentityTx;
    }

    public boolean hasLayoutAttributes() {
        return hasLayoutAttributes;
    }

    public static java.awt.Font getFont(java.lang.String nm) {
        return java.awt.Font.getFont(nm, null);
    }

    public static java.awt.Font decode(java.lang.String str) {
        java.lang.String fontName = str;
        java.lang.String styleName = "";
        int fontSize = 12;
        int fontStyle = java.awt.Font.PLAIN;
        if (str == null) {
            return new java.awt.Font(java.awt.Font.DIALOG , fontStyle , fontSize);
        } 
        int lastHyphen = str.lastIndexOf('-');
        int lastSpace = str.lastIndexOf(' ');
        char sepChar = lastHyphen > lastSpace ? '-' : ' ';
        int sizeIndex = str.lastIndexOf(sepChar);
        int styleIndex = str.lastIndexOf(sepChar, (sizeIndex - 1));
        int strlen = str.length();
        if ((sizeIndex > 0) && ((sizeIndex + 1) < strlen)) {
            try {
                fontSize = java.lang.Integer.valueOf(str.substring((sizeIndex + 1))).intValue();
                if (fontSize <= 0) {
                    fontSize = 12;
                } 
            } catch (java.lang.NumberFormatException e) {
                styleIndex = sizeIndex;
                sizeIndex = strlen;
                if ((str.charAt((sizeIndex - 1))) == sepChar) {
                    sizeIndex--;
                } 
            }
        } 
        if ((styleIndex >= 0) && ((styleIndex + 1) < strlen)) {
            styleName = str.substring((styleIndex + 1), sizeIndex);
            styleName = styleName.toLowerCase(java.util.Locale.ENGLISH);
            if (styleName.equals("bolditalic")) {
                fontStyle = (java.awt.Font.BOLD) | (java.awt.Font.ITALIC);
            } else if (styleName.equals("italic")) {
                fontStyle = java.awt.Font.ITALIC;
            } else if (styleName.equals("bold")) {
                fontStyle = java.awt.Font.BOLD;
            } else if (styleName.equals("plain")) {
                fontStyle = java.awt.Font.PLAIN;
            } else {
                styleIndex = sizeIndex;
                if ((str.charAt((styleIndex - 1))) == sepChar) {
                    styleIndex--;
                } 
            }
            fontName = str.substring(0, styleIndex);
        } else {
            int fontEnd = strlen;
            if (styleIndex > 0) {
                fontEnd = styleIndex;
            } else if (sizeIndex > 0) {
                fontEnd = sizeIndex;
            } 
            if ((fontEnd > 0) && ((str.charAt((fontEnd - 1))) == sepChar)) {
                fontEnd--;
            } 
            fontName = str.substring(0, fontEnd);
        }
        return new java.awt.Font(fontName , fontStyle , fontSize);
    }

    public static java.awt.Font getFont(java.lang.String nm, java.awt.Font font) {
        java.lang.String str = null;
        try {
            str = java.lang.System.getProperty(nm);
        } catch (java.lang.SecurityException e) {
        }
        if (str == null) {
            return font;
        } 
        return java.awt.Font.decode(str);
    }

    transient int hash;

    public int hashCode() {
        if ((hash) == 0) {
            hash = ((name.hashCode()) ^ (style)) ^ (size);
            if (((nonIdentityTx) && ((values) != null)) && ((values.getTransform()) != null)) {
                hash ^= values.getTransform().hashCode();
            } 
        } 
        return hash;
    }

    public boolean equals(java.lang.Object obj) {
        if (obj == (java.awt.Font.this)) {
            return true;
        } 
        if (obj != null) {
            try {
                java.awt.Font font = ((java.awt.Font)(obj));
                if (((((((size) == (font.size)) && ((style) == (font.style))) && ((nonIdentityTx) == (font.nonIdentityTx))) && ((hasLayoutAttributes) == (font.hasLayoutAttributes))) && ((pointSize) == (font.pointSize))) && (name.equals(font.name))) {
                    if ((values) == null) {
                        if ((font.values) == null) {
                            return true;
                        } else {
                            return getAttributeValues().equals(font.values);
                        }
                    } else {
                        return values.equals(font.getAttributeValues());
                    }
                } 
            } catch (java.lang.ClassCastException e) {
            }
        } 
        return false;
    }

    public java.lang.String toString() {
        java.lang.String strStyle;
        if (isBold()) {
            strStyle = isItalic() ? "bolditalic" : "bold";
        } else {
            strStyle = isItalic() ? "italic" : "plain";
        }
        return (((((((((getClass().getName()) + "[family=") + (getFamily())) + ",name=") + (name)) + ",style=") + strStyle) + ",size=") + (size)) + "]";
    }

    private int fontSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        if ((values) != null) {
            synchronized(values) {
                fRequestedAttributes = values.toSerializableHashtable();
                s.defaultWriteObject();
                fRequestedAttributes = null;
            }
        } else {
            s.defaultWriteObject();
        }
    }

    private void readObject(java.io.ObjectInputStream s) throws java.io.IOException, java.lang.ClassNotFoundException {
        s.defaultReadObject();
        if ((pointSize) == 0) {
            pointSize = ((float)(size));
        } 
        if ((fRequestedAttributes) != null) {
            values = getAttributeValues();
            sun.font.AttributeValues extras = sun.font.AttributeValues.fromSerializableHashtable(fRequestedAttributes);
            if (!(sun.font.AttributeValues.is16Hashtable(fRequestedAttributes))) {
                extras.unsetDefault();
            } 
            values = getAttributeValues().merge(extras);
            java.awt.Font.this.nonIdentityTx = values.anyNonDefault(java.awt.Font.EXTRA_MASK);
            java.awt.Font.this.hasLayoutAttributes = values.anyNonDefault(java.awt.Font.LAYOUT_MASK);
            fRequestedAttributes = null;
        } 
    }

    public int getNumGlyphs() {
        return getFont2D().getNumGlyphs();
    }

    public int getMissingGlyphCode() {
        return getFont2D().getMissingGlyphCode();
    }

    public byte getBaselineFor(char c) {
        return getFont2D().getBaselineFor(c);
    }

    public java.util.Map<java.awt.font.TextAttribute, ?> getAttributes() {
        return new sun.font.AttributeMap(getAttributeValues());
    }

    public java.text.AttributedCharacterIterator.Attribute[] getAvailableAttributes() {
        java.text.AttributedCharacterIterator.Attribute[] attributes = new java.text.AttributedCharacterIterator.Attribute[]{ java.awt.font.TextAttribute.FAMILY , java.awt.font.TextAttribute.WEIGHT , java.awt.font.TextAttribute.WIDTH , java.awt.font.TextAttribute.POSTURE , java.awt.font.TextAttribute.SIZE , java.awt.font.TextAttribute.TRANSFORM , java.awt.font.TextAttribute.SUPERSCRIPT , java.awt.font.TextAttribute.CHAR_REPLACEMENT , java.awt.font.TextAttribute.FOREGROUND , java.awt.font.TextAttribute.BACKGROUND , java.awt.font.TextAttribute.UNDERLINE , java.awt.font.TextAttribute.STRIKETHROUGH , java.awt.font.TextAttribute.RUN_DIRECTION , java.awt.font.TextAttribute.BIDI_EMBEDDING , java.awt.font.TextAttribute.JUSTIFICATION , java.awt.font.TextAttribute.INPUT_METHOD_HIGHLIGHT , java.awt.font.TextAttribute.INPUT_METHOD_UNDERLINE , java.awt.font.TextAttribute.SWAP_COLORS , java.awt.font.TextAttribute.NUMERIC_SHAPING , java.awt.font.TextAttribute.KERNING , java.awt.font.TextAttribute.LIGATURES , java.awt.font.TextAttribute.TRACKING };
        return attributes;
    }

    public java.awt.Font deriveFont(int style, float size) {
        if ((values) == null) {
            return new java.awt.Font(name , style , size , createdFont , font2DHandle);
        } 
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        int oldStyle = (java.awt.Font.this.style) != style ? java.awt.Font.this.style : -1;
        java.awt.Font.applyStyle(style, newValues);
        newValues.setSize(size);
        return new java.awt.Font(newValues , null , oldStyle , createdFont , font2DHandle);
    }

    public java.awt.Font deriveFont(int style, java.awt.geom.AffineTransform trans) {
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        int oldStyle = (java.awt.Font.this.style) != style ? java.awt.Font.this.style : -1;
        java.awt.Font.applyStyle(style, newValues);
        java.awt.Font.applyTransform(trans, newValues);
        return new java.awt.Font(newValues , null , oldStyle , createdFont , font2DHandle);
    }

    public java.awt.Font deriveFont(float size) {
        if ((values) == null) {
            return new java.awt.Font(name , style , size , createdFont , font2DHandle);
        } 
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        newValues.setSize(size);
        return new java.awt.Font(newValues , null , (-1) , createdFont , font2DHandle);
    }

    public java.awt.Font deriveFont(java.awt.geom.AffineTransform trans) {
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        java.awt.Font.applyTransform(trans, newValues);
        return new java.awt.Font(newValues , null , (-1) , createdFont , font2DHandle);
    }

    public java.awt.Font deriveFont(int style) {
        if ((values) == null) {
            return new java.awt.Font(name , style , size , createdFont , font2DHandle);
        } 
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        int oldStyle = (java.awt.Font.this.style) != style ? java.awt.Font.this.style : -1;
        java.awt.Font.applyStyle(style, newValues);
        return new java.awt.Font(newValues , null , oldStyle , createdFont , font2DHandle);
    }

    public java.awt.Font deriveFont(java.util.Map<? extends java.text.AttributedCharacterIterator.Attribute, ?> attributes) {
        if (attributes == null) {
            return java.awt.Font.this;
        } 
        sun.font.AttributeValues newValues = getAttributeValues().clone();
        newValues.merge(attributes, java.awt.Font.RECOGNIZED_MASK);
        return new java.awt.Font(newValues , name , style , createdFont , font2DHandle);
    }

    public boolean canDisplay(char c) {
        return getFont2D().canDisplay(c);
    }

    public boolean canDisplay(int codePoint) {
        if (!(java.lang.Character.isValidCodePoint(codePoint))) {
            throw new java.lang.IllegalArgumentException(("invalid code point: " + (java.lang.Integer.toHexString(codePoint))));
        } 
        return getFont2D().canDisplay(codePoint);
    }

    public int canDisplayUpTo(java.lang.String str) {
        sun.font.Font2D font2d = getFont2D();
        int len = str.length();
        for (int i = 0 ; i < len ; i++) {
            char c = str.charAt(i);
            if (font2d.canDisplay(c)) {
                continue;
            } 
            if (!(java.lang.Character.isHighSurrogate(c))) {
                return i;
            } 
            if (!(font2d.canDisplay(str.codePointAt(i)))) {
                return i;
            } 
            i++;
        }
        return -1;
    }

    public int canDisplayUpTo(char[] text, int start, int limit) {
        sun.font.Font2D font2d = getFont2D();
        for (int i = start ; i < limit ; i++) {
            char c = text[i];
            if (font2d.canDisplay(c)) {
                continue;
            } 
            if (!(java.lang.Character.isHighSurrogate(c))) {
                return i;
            } 
            if (!(font2d.canDisplay(java.lang.Character.codePointAt(text, i, limit)))) {
                return i;
            } 
            i++;
        }
        return -1;
    }

    public int canDisplayUpTo(java.text.CharacterIterator iter, int start, int limit) {
        sun.font.Font2D font2d = getFont2D();
        char c = iter.setIndex(start);
        for (int i = start ; i < limit ; i++ , c = iter.next()) {
            if (font2d.canDisplay(c)) {
                continue;
            } 
            if (!(java.lang.Character.isHighSurrogate(c))) {
                return i;
            } 
            char c2 = iter.next();
            if (!(java.lang.Character.isLowSurrogate(c2))) {
                return i;
            } 
            if (!(font2d.canDisplay(java.lang.Character.toCodePoint(c, c2)))) {
                return i;
            } 
            i++;
        }
        return -1;
    }

    public float getItalicAngle() {
        return getItalicAngle(null);
    }

    private float getItalicAngle(java.awt.font.FontRenderContext frc) {
        java.lang.Object aa;
        java.lang.Object fm;
        if (frc == null) {
            aa = java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_OFF;
            fm = java.awt.RenderingHints.VALUE_FRACTIONALMETRICS_OFF;
        } else {
            aa = frc.getAntiAliasingHint();
            fm = frc.getFractionalMetricsHint();
        }
        return getFont2D().getItalicAngle(java.awt.Font.this, java.awt.Font.identityTx, aa, fm);
    }

    public boolean hasUniformLineMetrics() {
        return false;
    }

    private transient java.lang.ref.SoftReference<sun.font.FontLineMetrics> flmref;

    private sun.font.FontLineMetrics defaultLineMetrics(java.awt.font.FontRenderContext frc) {
        sun.font.FontLineMetrics flm = null;
        if ((((flmref) == null) || ((flm = flmref.get()) == null)) || (!(flm.frc.equals(frc)))) {
            float[] metrics = new float[8];
            getFont2D().getFontMetrics(java.awt.Font.this, java.awt.Font.identityTx, frc.getAntiAliasingHint(), frc.getFractionalMetricsHint(), metrics);
            float ascent = metrics[0];
            float descent = metrics[1];
            float leading = metrics[2];
            float ssOffset = 0;
            if (((values) != null) && ((values.getSuperscript()) != 0)) {
                ssOffset = ((float)(getTransform().getTranslateY()));
                ascent -= ssOffset;
                descent += ssOffset;
            } 
            float height = (ascent + descent) + leading;
            int baselineIndex = 0;
            float[] baselineOffsets = new float[]{ 0 , ((descent / 2.0F) - ascent) / 2.0F , -ascent };
            float strikethroughOffset = metrics[4];
            float strikethroughThickness = metrics[5];
            float underlineOffset = metrics[6];
            float underlineThickness = metrics[7];
            float italicAngle = getItalicAngle(frc);
            if (isTransformed()) {
                java.awt.geom.AffineTransform ctx = values.getCharTransform();
                if (ctx != null) {
                    java.awt.geom.Point2D.Float pt = new java.awt.geom.Point2D.Float();
                    pt.setLocation(0, strikethroughOffset);
                    ctx.deltaTransform(pt, pt);
                    strikethroughOffset = pt.y;
                    pt.setLocation(0, strikethroughThickness);
                    ctx.deltaTransform(pt, pt);
                    strikethroughThickness = pt.y;
                    pt.setLocation(0, underlineOffset);
                    ctx.deltaTransform(pt, pt);
                    underlineOffset = pt.y;
                    pt.setLocation(0, underlineThickness);
                    ctx.deltaTransform(pt, pt);
                    underlineThickness = pt.y;
                } 
            } 
            strikethroughOffset += ssOffset;
            underlineOffset += ssOffset;
            sun.font.CoreMetrics cm = new sun.font.CoreMetrics(ascent , descent , leading , height , baselineIndex , baselineOffsets , strikethroughOffset , strikethroughThickness , underlineOffset , underlineThickness , ssOffset , italicAngle);
            flm = new sun.font.FontLineMetrics(0 , cm , frc);
            flmref = new java.lang.ref.SoftReference<sun.font.FontLineMetrics>(flm);
        } 
        return ((sun.font.FontLineMetrics)(flm.clone()));
    }

    public java.awt.font.LineMetrics getLineMetrics(java.lang.String str, java.awt.font.FontRenderContext frc) {
        sun.font.FontLineMetrics flm = defaultLineMetrics(frc);
        flm.numchars = str.length();
        return flm;
    }

    public java.awt.font.LineMetrics getLineMetrics(java.lang.String str, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        sun.font.FontLineMetrics flm = defaultLineMetrics(frc);
        int numChars = limit - beginIndex;
        flm.numchars = numChars < 0 ? 0 : numChars;
        return flm;
    }

    public java.awt.font.LineMetrics getLineMetrics(char[] chars, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        sun.font.FontLineMetrics flm = defaultLineMetrics(frc);
        int numChars = limit - beginIndex;
        flm.numchars = numChars < 0 ? 0 : numChars;
        return flm;
    }

    public java.awt.font.LineMetrics getLineMetrics(java.text.CharacterIterator ci, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        sun.font.FontLineMetrics flm = defaultLineMetrics(frc);
        int numChars = limit - beginIndex;
        flm.numchars = numChars < 0 ? 0 : numChars;
        return flm;
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.lang.String str, java.awt.font.FontRenderContext frc) {
        char[] array = str.toCharArray();
        return getStringBounds(array, 0, array.length, frc);
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.lang.String str, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        java.lang.String substr = str.substring(beginIndex, limit);
        return getStringBounds(substr, frc);
    }

    public java.awt.geom.Rectangle2D getStringBounds(char[] chars, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        if (beginIndex < 0) {
            throw new java.lang.IndexOutOfBoundsException(("beginIndex: " + beginIndex));
        } 
        if (limit > (chars.length)) {
            throw new java.lang.IndexOutOfBoundsException(("limit: " + limit));
        } 
        if (beginIndex > limit) {
            throw new java.lang.IndexOutOfBoundsException(("range length: " + (limit - beginIndex)));
        } 
        boolean simple = ((values) == null) || ((((values.getKerning()) == 0) && ((values.getLigatures()) == 0)) && ((values.getBaselineTransform()) == null));
        if (simple) {
            simple = !(sun.font.FontUtilities.isComplexText(chars, beginIndex, limit));
        } 
        if (simple) {
            java.awt.font.GlyphVector gv = new sun.font.StandardGlyphVector(java.awt.Font.this , chars , beginIndex , (limit - beginIndex) , frc);
            return gv.getLogicalBounds();
        } else {
            java.lang.String str = new java.lang.String(chars , beginIndex , (limit - beginIndex));
            java.awt.font.TextLayout tl = new java.awt.font.TextLayout(str , java.awt.Font.this , frc);
            return new java.awt.geom.Rectangle2D.Float(0 , (-(tl.getAscent())) , tl.getAdvance() , (((tl.getAscent()) + (tl.getDescent())) + (tl.getLeading())));
        }
    }

    public java.awt.geom.Rectangle2D getStringBounds(java.text.CharacterIterator ci, int beginIndex, int limit, java.awt.font.FontRenderContext frc) {
        int start = ci.getBeginIndex();
        int end = ci.getEndIndex();
        if (beginIndex < start) {
            throw new java.lang.IndexOutOfBoundsException(("beginIndex: " + beginIndex));
        } 
        if (limit > end) {
            throw new java.lang.IndexOutOfBoundsException(("limit: " + limit));
        } 
        if (beginIndex > limit) {
            throw new java.lang.IndexOutOfBoundsException(("range length: " + (limit - beginIndex)));
        } 
        char[] arr = new char[limit - beginIndex];
        ci.setIndex(beginIndex);
        for (int idx = 0 ; idx < (arr.length) ; idx++) {
            arr[idx] = ci.current();
            ci.next();
        }
        return getStringBounds(arr, 0, arr.length, frc);
    }

    public java.awt.geom.Rectangle2D getMaxCharBounds(java.awt.font.FontRenderContext frc) {
        float[] metrics = new float[4];
        getFont2D().getFontMetrics(java.awt.Font.this, frc, metrics);
        return new java.awt.geom.Rectangle2D.Float(0 , (-(metrics[0])) , metrics[3] , (((metrics[0]) + (metrics[1])) + (metrics[2])));
    }

    public java.awt.font.GlyphVector createGlyphVector(java.awt.font.FontRenderContext frc, java.lang.String str) {
        return ((java.awt.font.GlyphVector)(new sun.font.StandardGlyphVector(java.awt.Font.this , str , frc)));
    }

    public java.awt.font.GlyphVector createGlyphVector(java.awt.font.FontRenderContext frc, char[] chars) {
        return ((java.awt.font.GlyphVector)(new sun.font.StandardGlyphVector(java.awt.Font.this , chars , frc)));
    }

    public java.awt.font.GlyphVector createGlyphVector(java.awt.font.FontRenderContext frc, java.text.CharacterIterator ci) {
        return ((java.awt.font.GlyphVector)(new sun.font.StandardGlyphVector(java.awt.Font.this , ci , frc)));
    }

    public java.awt.font.GlyphVector createGlyphVector(java.awt.font.FontRenderContext frc, int[] glyphCodes) {
        return ((java.awt.font.GlyphVector)(new sun.font.StandardGlyphVector(java.awt.Font.this , glyphCodes , frc)));
    }

    public java.awt.font.GlyphVector layoutGlyphVector(java.awt.font.FontRenderContext frc, char[] text, int start, int limit, int flags) {
        sun.font.GlyphLayout gl = sun.font.GlyphLayout.get(null);
        sun.font.StandardGlyphVector gv = gl.layout(java.awt.Font.this, frc, text, start, (limit - start), flags, null);
        sun.font.GlyphLayout.done(gl);
        return gv;
    }

    public static final int LAYOUT_LEFT_TO_RIGHT = 0;

    public static final int LAYOUT_RIGHT_TO_LEFT = 1;

    public static final int LAYOUT_NO_START_CONTEXT = 2;

    public static final int LAYOUT_NO_LIMIT_CONTEXT = 4;

    private static void applyTransform(java.awt.geom.AffineTransform trans, sun.font.AttributeValues values) {
        if (trans == null) {
            throw new java.lang.IllegalArgumentException("transform must not be null");
        } 
        values.setTransform(trans);
    }

    private static void applyStyle(int style, sun.font.AttributeValues values) {
        values.setWeight(((style & (java.awt.Font.BOLD)) != 0 ? 2.0F : 1.0F));
        values.setPosture(((style & (java.awt.Font.ITALIC)) != 0 ? 0.2F : 0.0F));
    }

    private static native void initIDs();
}


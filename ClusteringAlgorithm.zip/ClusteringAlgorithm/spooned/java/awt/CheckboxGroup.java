package java.awt;


public class CheckboxGroup implements java.io.Serializable {
    java.awt.Checkbox selectedCheckbox = null;

    private static final long serialVersionUID = 3729780091441768983L;

    public CheckboxGroup() {
    }

    public java.awt.Checkbox getSelectedCheckbox() {
        return getCurrent();
    }

    @java.lang.Deprecated
    public java.awt.Checkbox getCurrent() {
        return selectedCheckbox;
    }

    public void setSelectedCheckbox(java.awt.Checkbox box) {
        setCurrent(box);
    }

    @java.lang.Deprecated
    public synchronized void setCurrent(java.awt.Checkbox box) {
        if ((box != null) && ((box.group) != (java.awt.CheckboxGroup.this))) {
            return ;
        } 
        java.awt.Checkbox oldChoice = java.awt.CheckboxGroup.this.selectedCheckbox;
        java.awt.CheckboxGroup.this.selectedCheckbox = box;
        if (((oldChoice != null) && (oldChoice != box)) && ((oldChoice.group) == (java.awt.CheckboxGroup.this))) {
            oldChoice.setState(false);
        } 
        if (((box != null) && (oldChoice != box)) && (!(box.getState()))) {
            box.setStateInternal(true);
        } 
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[selectedCheckbox=") + (selectedCheckbox)) + "]";
    }
}


package java.awt;


@java.lang.FunctionalInterface
public interface KeyEventDispatcher {
    boolean dispatchKeyEvent(java.awt.event.KeyEvent e);
}


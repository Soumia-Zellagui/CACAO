package java.awt;


abstract class AttributeValue {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.AttributeValue");

    private final int value;

    private final java.lang.String[] names;

    protected AttributeValue(int value ,java.lang.String[] names) {
        if (java.awt.AttributeValue.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.AttributeValue.log.finest(((("value = " + value) + ", names = ") + names));
        } 
        if (java.awt.AttributeValue.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
            if (((value < 0) || (names == null)) || (value >= (names.length))) {
                java.awt.AttributeValue.log.finer("Assertion failed");
            } 
        } 
        this.value = value;
        this.names = names;
    }

    public int hashCode() {
        return value;
    }

    public java.lang.String toString() {
        return names[value];
    }
}


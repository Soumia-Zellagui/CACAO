package java.awt;


public interface Shape {
    public java.awt.Rectangle getBounds();

    public java.awt.geom.Rectangle2D getBounds2D();

    public boolean contains(double x, double y);

    public boolean contains(java.awt.geom.Point2D p);

    public boolean intersects(double x, double y, double w, double h);

    public boolean intersects(java.awt.geom.Rectangle2D r);

    public boolean contains(double x, double y, double w, double h);

    public boolean contains(java.awt.geom.Rectangle2D r);

    public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform at);

    public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform at, double flatness);
}


package java.awt;


class LightweightDispatcher implements java.awt.event.AWTEventListener , java.io.Serializable {
    private static final long serialVersionUID = 5184291520170872969L;

    private static final int LWD_MOUSE_DRAGGED_OVER = 1500;

    private static final sun.util.logging.PlatformLogger eventLog = sun.util.logging.PlatformLogger.getLogger("java.awt.event.LightweightDispatcher");

    private static final int BUTTONS_DOWN_MASK;

    static {
        int[] buttonsDownMask = sun.awt.AWTAccessor.getInputEventAccessor().getButtonDownMasks();
        int mask = 0;
        for (int buttonDownMask : buttonsDownMask) {
            mask |= buttonDownMask;
        }
        BUTTONS_DOWN_MASK = mask;
    }

    LightweightDispatcher(java.awt.Container nativeContainer) {
        java.awt.LightweightDispatcher.this.nativeContainer = nativeContainer;
        mouseEventTarget = new java.lang.ref.WeakReference<>(null);
        targetLastEntered = new java.lang.ref.WeakReference<>(null);
        targetLastEnteredDT = new java.lang.ref.WeakReference<>(null);
        eventMask = 0;
    }

    void dispose() {
        stopListeningForOtherDrags();
        mouseEventTarget.clear();
        targetLastEntered.clear();
        targetLastEnteredDT.clear();
    }

    void enableEvents(long events) {
        eventMask |= events;
    }

    boolean dispatchEvent(java.awt.AWTEvent e) {
        boolean ret = false;
        if (e instanceof sun.awt.dnd.SunDropTargetEvent) {
            sun.awt.dnd.SunDropTargetEvent sdde = ((sun.awt.dnd.SunDropTargetEvent)(e));
            ret = processDropTargetEvent(sdde);
        } else {
            if ((e instanceof java.awt.event.MouseEvent) && (((eventMask) & (java.awt.LightweightDispatcher.MOUSE_MASK)) != 0)) {
                java.awt.event.MouseEvent me = ((java.awt.event.MouseEvent)(e));
                ret = processMouseEvent(me);
            } 
            if ((e.getID()) == (java.awt.event.MouseEvent.MOUSE_MOVED)) {
                nativeContainer.updateCursorImmediately();
            } 
        }
        return ret;
    }

    private boolean isMouseGrab(java.awt.event.MouseEvent e) {
        int modifiers = e.getModifiersEx();
        if (((e.getID()) == (java.awt.event.MouseEvent.MOUSE_PRESSED)) || ((e.getID()) == (java.awt.event.MouseEvent.MOUSE_RELEASED))) {
            modifiers ^= java.awt.event.InputEvent.getMaskForButton(e.getButton());
        } 
        return (modifiers & (java.awt.LightweightDispatcher.BUTTONS_DOWN_MASK)) != 0;
    }

    private boolean processMouseEvent(java.awt.event.MouseEvent e) {
        int id = e.getID();
        java.awt.Component mouseOver = nativeContainer.getMouseEventTarget(e.getX(), e.getY(), java.awt.Container.INCLUDE_SELF);
        trackMouseEnterExit(mouseOver, e);
        java.awt.Component met = mouseEventTarget.get();
        if ((!(isMouseGrab(e))) && (id != (java.awt.event.MouseEvent.MOUSE_CLICKED))) {
            met = mouseOver != (nativeContainer) ? mouseOver : null;
            mouseEventTarget = new java.lang.ref.WeakReference<>(met);
        } 
        if (met != null) {
            switch (id) {
                case java.awt.event.MouseEvent.MOUSE_ENTERED :
                case java.awt.event.MouseEvent.MOUSE_EXITED :
                    break;
                case java.awt.event.MouseEvent.MOUSE_PRESSED :
                    retargetMouseEvent(met, id, e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_RELEASED :
                    retargetMouseEvent(met, id, e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_CLICKED :
                    if (mouseOver == met) {
                        retargetMouseEvent(mouseOver, id, e);
                    } 
                    break;
                case java.awt.event.MouseEvent.MOUSE_MOVED :
                    retargetMouseEvent(met, id, e);
                    break;
                case java.awt.event.MouseEvent.MOUSE_DRAGGED :
                    if (isMouseGrab(e)) {
                        retargetMouseEvent(met, id, e);
                    } 
                    break;
                case java.awt.event.MouseEvent.MOUSE_WHEEL :
                    if ((java.awt.LightweightDispatcher.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) && (mouseOver != null)) {
                        java.awt.LightweightDispatcher.eventLog.finest(((("retargeting mouse wheel to " + (mouseOver.getName())) + ", ") + (mouseOver.getClass())));
                    } 
                    retargetMouseEvent(mouseOver, id, e);
                    break;
            }
            if (id != (java.awt.event.MouseEvent.MOUSE_WHEEL)) {
                e.consume();
            } 
        } 
        return e.isConsumed();
    }

    private boolean processDropTargetEvent(sun.awt.dnd.SunDropTargetEvent e) {
        int id = e.getID();
        int x = e.getX();
        int y = e.getY();
        if (!(nativeContainer.contains(x, y))) {
            final java.awt.Dimension d = nativeContainer.getSize();
            if ((d.width) <= x) {
                x = (d.width) - 1;
            } else if (x < 0) {
                x = 0;
            } 
            if ((d.height) <= y) {
                y = (d.height) - 1;
            } else if (y < 0) {
                y = 0;
            } 
        } 
        java.awt.Component mouseOver = nativeContainer.getDropTargetEventTarget(x, y, java.awt.Container.INCLUDE_SELF);
        trackMouseEnterExit(mouseOver, e);
        if ((mouseOver != (nativeContainer)) && (mouseOver != null)) {
            switch (id) {
                case sun.awt.dnd.SunDropTargetEvent.MOUSE_ENTERED :
                case sun.awt.dnd.SunDropTargetEvent.MOUSE_EXITED :
                    break;
                default :
                    retargetMouseEvent(mouseOver, id, e);
                    e.consume();
                    break;
            }
        } 
        return e.isConsumed();
    }

    private void trackDropTargetEnterExit(java.awt.Component targetOver, java.awt.event.MouseEvent e) {
        int id = e.getID();
        if ((id == (java.awt.event.MouseEvent.MOUSE_ENTERED)) && (isMouseDTInNativeContainer)) {
            targetLastEnteredDT.clear();
        } else if (id == (java.awt.event.MouseEvent.MOUSE_ENTERED)) {
            isMouseDTInNativeContainer = true;
        } else if (id == (java.awt.event.MouseEvent.MOUSE_EXITED)) {
            isMouseDTInNativeContainer = false;
        } 
        java.awt.Component tle = retargetMouseEnterExit(targetOver, e, targetLastEnteredDT.get(), isMouseDTInNativeContainer);
        targetLastEnteredDT = new java.lang.ref.WeakReference<>(tle);
    }

    private void trackMouseEnterExit(java.awt.Component targetOver, java.awt.event.MouseEvent e) {
        if (e instanceof sun.awt.dnd.SunDropTargetEvent) {
            trackDropTargetEnterExit(targetOver, e);
            return ;
        } 
        int id = e.getID();
        if ((((id != (java.awt.event.MouseEvent.MOUSE_EXITED)) && (id != (java.awt.event.MouseEvent.MOUSE_DRAGGED))) && (id != (java.awt.LightweightDispatcher.LWD_MOUSE_DRAGGED_OVER))) && (!(isMouseInNativeContainer))) {
            isMouseInNativeContainer = true;
            startListeningForOtherDrags();
        } else if (id == (java.awt.event.MouseEvent.MOUSE_EXITED)) {
            isMouseInNativeContainer = false;
            stopListeningForOtherDrags();
        } 
        java.awt.Component tle = retargetMouseEnterExit(targetOver, e, targetLastEntered.get(), isMouseInNativeContainer);
        targetLastEntered = new java.lang.ref.WeakReference<>(tle);
    }

    private java.awt.Component retargetMouseEnterExit(java.awt.Component targetOver, java.awt.event.MouseEvent e, java.awt.Component lastEntered, boolean inNativeContainer) {
        int id = e.getID();
        java.awt.Component targetEnter = inNativeContainer ? targetOver : null;
        if (lastEntered != targetEnter) {
            if (lastEntered != null) {
                retargetMouseEvent(lastEntered, java.awt.event.MouseEvent.MOUSE_EXITED, e);
            } 
            if (id == (java.awt.event.MouseEvent.MOUSE_EXITED)) {
                e.consume();
            } 
            if (targetEnter != null) {
                retargetMouseEvent(targetEnter, java.awt.event.MouseEvent.MOUSE_ENTERED, e);
            } 
            if (id == (java.awt.event.MouseEvent.MOUSE_ENTERED)) {
                e.consume();
            } 
        } 
        return targetEnter;
    }

    private void startListeningForOtherDrags() {
        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Object>() {
            public java.lang.Object run() {
                nativeContainer.getToolkit().addAWTEventListener(java.awt.LightweightDispatcher.this, ((java.awt.AWTEvent.MOUSE_EVENT_MASK) | (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)));
                return null;
            }
        });
    }

    private void stopListeningForOtherDrags() {
        java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Object>() {
            public java.lang.Object run() {
                nativeContainer.getToolkit().removeAWTEventListener(java.awt.LightweightDispatcher.this);
                return null;
            }
        });
    }

    public void eventDispatched(java.awt.AWTEvent e) {
        boolean isForeignDrag = (((e instanceof java.awt.event.MouseEvent) && (!(e instanceof sun.awt.dnd.SunDropTargetEvent))) && ((e.id) == (java.awt.event.MouseEvent.MOUSE_DRAGGED))) && ((e.getSource()) != (nativeContainer));
        if (!isForeignDrag) {
            return ;
        } 
        java.awt.event.MouseEvent srcEvent = ((java.awt.event.MouseEvent)(e));
        java.awt.event.MouseEvent me;
        synchronized(nativeContainer.getTreeLock()) {
            java.awt.Component srcComponent = srcEvent.getComponent();
            if (!(srcComponent.isShowing())) {
                return ;
            } 
            java.awt.Component c = nativeContainer;
            while ((c != null) && (!(c instanceof java.awt.Window))) {
                c = c.getParent_NoClientCode();
            }
            if ((c == null) || (((java.awt.Window)(c)).isModalBlocked())) {
                return ;
            } 
            me = new java.awt.event.MouseEvent(nativeContainer , java.awt.LightweightDispatcher.LWD_MOUSE_DRAGGED_OVER , srcEvent.getWhen() , ((srcEvent.getModifiersEx()) | (srcEvent.getModifiers())) , srcEvent.getX() , srcEvent.getY() , srcEvent.getXOnScreen() , srcEvent.getYOnScreen() , srcEvent.getClickCount() , srcEvent.isPopupTrigger() , srcEvent.getButton());
            ((java.awt.AWTEvent)(srcEvent)).copyPrivateDataInto(me);
            final java.awt.Point ptSrcOrigin = srcComponent.getLocationOnScreen();
            if ((sun.awt.AppContext.getAppContext()) != (nativeContainer.appContext)) {
                final java.awt.event.MouseEvent mouseEvent = me;
                java.lang.Runnable r = new java.lang.Runnable() {
                    public void run() {
                        if (!(nativeContainer.isShowing())) {
                            return ;
                        } 
                        java.awt.Point ptDstOrigin = nativeContainer.getLocationOnScreen();
                        mouseEvent.translatePoint(((ptSrcOrigin.x) - (ptDstOrigin.x)), ((ptSrcOrigin.y) - (ptDstOrigin.y)));
                        java.awt.Component targetOver = nativeContainer.getMouseEventTarget(mouseEvent.getX(), mouseEvent.getY(), java.awt.Container.INCLUDE_SELF);
                        trackMouseEnterExit(targetOver, mouseEvent);
                    }
                };
                sun.awt.SunToolkit.executeOnEventHandlerThread(nativeContainer, r);
                return ;
            } else {
                if (!(nativeContainer.isShowing())) {
                    return ;
                } 
                java.awt.Point ptDstOrigin = nativeContainer.getLocationOnScreen();
                me.translatePoint(((ptSrcOrigin.x) - (ptDstOrigin.x)), ((ptSrcOrigin.y) - (ptDstOrigin.y)));
            }
        }
        java.awt.Component targetOver = nativeContainer.getMouseEventTarget(me.getX(), me.getY(), java.awt.Container.INCLUDE_SELF);
        trackMouseEnterExit(targetOver, me);
    }

    void retargetMouseEvent(java.awt.Component target, int id, java.awt.event.MouseEvent e) {
        if (target == null) {
            return ;
        } 
        int x = e.getX();
        int y = e.getY();
        java.awt.Component component;
        for (component = target ; (component != null) && (component != (nativeContainer)) ; component = component.getParent()) {
            x -= component.x;
            y -= component.y;
        }
        java.awt.event.MouseEvent retargeted;
        if (component != null) {
            if (e instanceof sun.awt.dnd.SunDropTargetEvent) {
                retargeted = new sun.awt.dnd.SunDropTargetEvent(target , id , x , y , ((sun.awt.dnd.SunDropTargetEvent)(e)).getDispatcher());
            } else if (id == (java.awt.event.MouseEvent.MOUSE_WHEEL)) {
                retargeted = new java.awt.event.MouseWheelEvent(target , id , e.getWhen() , ((e.getModifiersEx()) | (e.getModifiers())) , x , y , e.getXOnScreen() , e.getYOnScreen() , e.getClickCount() , e.isPopupTrigger() , ((java.awt.event.MouseWheelEvent)(e)).getScrollType() , ((java.awt.event.MouseWheelEvent)(e)).getScrollAmount() , ((java.awt.event.MouseWheelEvent)(e)).getWheelRotation() , ((java.awt.event.MouseWheelEvent)(e)).getPreciseWheelRotation());
            } else {
                retargeted = new java.awt.event.MouseEvent(target , id , e.getWhen() , ((e.getModifiersEx()) | (e.getModifiers())) , x , y , e.getXOnScreen() , e.getYOnScreen() , e.getClickCount() , e.isPopupTrigger() , e.getButton());
            }
            ((java.awt.AWTEvent)(e)).copyPrivateDataInto(retargeted);
            if (target == (nativeContainer)) {
                ((java.awt.Container)(target)).dispatchEventToSelf(retargeted);
            } else {
                assert (sun.awt.AppContext.getAppContext()) == (target.appContext);
                if ((nativeContainer.modalComp) != null) {
                    if (((java.awt.Container)(nativeContainer.modalComp)).isAncestorOf(target)) {
                        target.dispatchEvent(retargeted);
                    } else {
                        e.consume();
                    }
                } else {
                    target.dispatchEvent(retargeted);
                }
            }
            if ((id == (java.awt.event.MouseEvent.MOUSE_WHEEL)) && (retargeted.isConsumed())) {
                e.consume();
            } 
        } 
    }

    private java.awt.Container nativeContainer;

    private java.awt.Component focus;

    private transient java.lang.ref.WeakReference<java.awt.Component> mouseEventTarget;

    private transient java.lang.ref.WeakReference<java.awt.Component> targetLastEntered;

    private transient java.lang.ref.WeakReference<java.awt.Component> targetLastEnteredDT;

    private transient boolean isMouseInNativeContainer = false;

    private transient boolean isMouseDTInNativeContainer = false;

    private java.awt.Cursor nativeCursor;

    private long eventMask;

    private static final long PROXY_EVENT_MASK = ((((java.awt.AWTEvent.FOCUS_EVENT_MASK) | (java.awt.AWTEvent.KEY_EVENT_MASK)) | (java.awt.AWTEvent.MOUSE_EVENT_MASK)) | (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) | (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK);

    private static final long MOUSE_MASK = ((java.awt.AWTEvent.MOUSE_EVENT_MASK) | (java.awt.AWTEvent.MOUSE_MOTION_EVENT_MASK)) | (java.awt.AWTEvent.MOUSE_WHEEL_EVENT_MASK);
}


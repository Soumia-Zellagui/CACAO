package java.awt;


public class Desktop {
    public static enum Action {
OPEN, EDIT, PRINT, MAIL, BROWSE;    }

    private java.awt.peer.DesktopPeer peer;

    private Desktop() {
        peer = java.awt.Toolkit.getDefaultToolkit().createDesktopPeer(java.awt.Desktop.this);
    }

    public static synchronized java.awt.Desktop getDesktop() {
        if (java.awt.GraphicsEnvironment.isHeadless())
            throw new java.awt.HeadlessException();
        
        if (!(java.awt.Desktop.isDesktopSupported())) {
            throw new java.lang.UnsupportedOperationException(("Desktop API is not " + "supported on the current platform"));
        } 
        sun.awt.AppContext context = sun.awt.AppContext.getAppContext();
        java.awt.Desktop desktop = ((java.awt.Desktop)(context.get(java.awt.Desktop.class)));
        if (desktop == null) {
            desktop = new java.awt.Desktop();
            context.put(java.awt.Desktop.class, desktop);
        } 
        return desktop;
    }

    public static boolean isDesktopSupported() {
        java.awt.Toolkit defaultToolkit = java.awt.Toolkit.getDefaultToolkit();
        if (defaultToolkit instanceof sun.awt.SunToolkit) {
            return true;
        } 
        return false;
    }

    public boolean isSupported(java.awt.Desktop.Action action) {
        return peer.isSupported(action);
    }

    private static void checkFileValidation(java.io.File file) {
        if (file == null)
            throw new java.lang.NullPointerException("File must not be null");
        
        if (!(file.exists())) {
            throw new java.lang.IllegalArgumentException((("The file: " + (file.getPath())) + " doesn't exist."));
        } 
        file.canRead();
    }

    private void checkActionSupport(java.awt.Desktop.Action actionType) {
        if (!(isSupported(actionType))) {
            throw new java.lang.UnsupportedOperationException((("The " + (actionType.name())) + " action is not supported on the current platform!"));
        } 
    }

    private void checkAWTPermission() {
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm != null) {
            sm.checkPermission(new java.awt.AWTPermission("showWindowWithoutWarningBanner"));
        } 
    }

    public void open(java.io.File file) throws java.io.IOException {
        checkAWTPermission();
        checkExec();
        checkActionSupport(java.awt.Desktop.Action.OPEN);
        java.awt.Desktop.checkFileValidation(file);
        peer.open(file);
    }

    public void edit(java.io.File file) throws java.io.IOException {
        checkAWTPermission();
        checkExec();
        checkActionSupport(java.awt.Desktop.Action.EDIT);
        file.canWrite();
        java.awt.Desktop.checkFileValidation(file);
        peer.edit(file);
    }

    public void print(java.io.File file) throws java.io.IOException {
        checkExec();
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm != null) {
            sm.checkPrintJobAccess();
        } 
        checkActionSupport(java.awt.Desktop.Action.PRINT);
        java.awt.Desktop.checkFileValidation(file);
        peer.print(file);
    }

    public void browse(java.net.URI uri) throws java.io.IOException {
        java.lang.SecurityException securityException = null;
        try {
            checkAWTPermission();
            checkExec();
        } catch (java.lang.SecurityException e) {
            securityException = e;
        }
        checkActionSupport(java.awt.Desktop.Action.BROWSE);
        if (uri == null) {
            throw new java.lang.NullPointerException();
        } 
        if (securityException == null) {
            peer.browse(uri);
            return ;
        } 
        java.net.URL url = null;
        try {
            url = uri.toURL();
        } catch (java.net.MalformedURLException e) {
            throw new java.lang.IllegalArgumentException("Unable to convert URI to URL" , e);
        }
        sun.awt.DesktopBrowse db = sun.awt.DesktopBrowse.getInstance();
        if (db == null) {
            throw securityException;
        } 
        db.browse(url);
    }

    public void mail() throws java.io.IOException {
        checkAWTPermission();
        checkExec();
        checkActionSupport(java.awt.Desktop.Action.MAIL);
        java.net.URI mailtoURI = null;
        try {
            mailtoURI = new java.net.URI("mailto:?");
            peer.mail(mailtoURI);
        } catch (java.net.URISyntaxException e) {
        }
    }

    public void mail(java.net.URI mailtoURI) throws java.io.IOException {
        checkAWTPermission();
        checkExec();
        checkActionSupport(java.awt.Desktop.Action.MAIL);
        if (mailtoURI == null)
            throw new java.lang.NullPointerException();
        
        if (!("mailto".equalsIgnoreCase(mailtoURI.getScheme()))) {
            throw new java.lang.IllegalArgumentException("URI scheme is not \"mailto\"");
        } 
        peer.mail(mailtoURI);
    }

    private void checkExec() throws java.lang.SecurityException {
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm != null) {
            sm.checkPermission(new java.io.FilePermission("<<ALL FILES>>" , sun.security.util.SecurityConstants.FILE_EXECUTE_ACTION));
        } 
    }
}


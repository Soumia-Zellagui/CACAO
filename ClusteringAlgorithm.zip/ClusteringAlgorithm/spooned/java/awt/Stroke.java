package java.awt;


public interface Stroke {
    java.awt.Shape createStrokedShape(java.awt.Shape p);
}


package java.awt;


class ImageMediaEntry extends java.awt.MediaEntry implements java.awt.image.ImageObserver , java.io.Serializable {
    java.awt.Image image;

    int width;

    int height;

    private static final long serialVersionUID = 4739377000350280650L;

    ImageMediaEntry(java.awt.MediaTracker mt ,java.awt.Image img ,int c ,int w ,int h) {
        super(mt, c);
        image = img;
        width = w;
        height = h;
    }

    boolean matches(java.awt.Image img, int w, int h) {
        return (((image) == img) && ((width) == w)) && ((height) == h);
    }

    java.lang.Object getMedia() {
        return image;
    }

    synchronized int getStatus(boolean doLoad, boolean doVerify) {
        if (doVerify) {
            int flags = tracker.target.checkImage(image, width, height, null);
            int s = parseflags(flags);
            if (s == 0) {
                if (((status) & ((java.awt.MediaEntry.ERRORED) | (java.awt.MediaEntry.COMPLETE))) != 0) {
                    setStatus(java.awt.MediaEntry.ABORTED);
                } 
            } else if (s != (status)) {
                setStatus(s);
            } 
        } 
        return super.getStatus(doLoad, doVerify);
    }

    void startLoad() {
        if (tracker.target.prepareImage(image, width, height, java.awt.ImageMediaEntry.this)) {
            setStatus(java.awt.MediaEntry.COMPLETE);
        } 
    }

    int parseflags(int infoflags) {
        if ((infoflags & (java.awt.image.ImageObserver.ERROR)) != 0) {
            return java.awt.MediaEntry.ERRORED;
        } else if ((infoflags & (java.awt.image.ImageObserver.ABORT)) != 0) {
            return java.awt.MediaEntry.ABORTED;
        } else if ((infoflags & ((java.awt.image.ImageObserver.ALLBITS) | (java.awt.image.ImageObserver.FRAMEBITS))) != 0) {
            return java.awt.MediaEntry.COMPLETE;
        } 
        return 0;
    }

    public boolean imageUpdate(java.awt.Image img, int infoflags, int x, int y, int w, int h) {
        if (cancelled) {
            return false;
        } 
        int s = parseflags(infoflags);
        if ((s != 0) && (s != (status))) {
            setStatus(s);
        } 
        return ((status) & (java.awt.MediaEntry.LOADING)) != 0;
    }
}


package java.awt;


public class TextComponent extends java.awt.Component implements javax.accessibility.Accessible {
    java.lang.String text;

    boolean editable = true;

    int selectionStart;

    int selectionEnd;

    boolean backgroundSetByClientCode = false;

    protected transient java.awt.event.TextListener textListener;

    private static final long serialVersionUID = -2214773872412987419L;

    TextComponent(java.lang.String text) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.TextComponent.this.text = text != null ? text : "";
        setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));
    }

    private void enableInputMethodsIfNecessary() {
        if (checkForEnableIM) {
            checkForEnableIM = false;
            try {
                java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
                boolean shouldEnable = false;
                if (toolkit instanceof sun.awt.InputMethodSupport) {
                    shouldEnable = ((sun.awt.InputMethodSupport)(toolkit)).enableInputMethodsForTextComponent();
                } 
                enableInputMethods(shouldEnable);
            } catch (java.lang.Exception e) {
            }
        } 
    }

    public void enableInputMethods(boolean enable) {
        checkForEnableIM = false;
        super.enableInputMethods(enable);
    }

    boolean areInputMethodsEnabled() {
        if (checkForEnableIM) {
            enableInputMethodsIfNecessary();
        } 
        return ((eventMask) & (java.awt.AWTEvent.INPUT_METHODS_ENABLED_MASK)) != 0;
    }

    public java.awt.im.InputMethodRequests getInputMethodRequests() {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null)
            return peer.getInputMethodRequests();
        else
            return null;
        
    }

    public void addNotify() {
        super.addNotify();
        enableInputMethodsIfNecessary();
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
            if (peer != null) {
                text = peer.getText();
                selectionStart = peer.getSelectionStart();
                selectionEnd = peer.getSelectionEnd();
            } 
            super.removeNotify();
        }
    }

    public synchronized void setText(java.lang.String t) {
        boolean skipTextEvent = (((text) == null) || (text.isEmpty())) && ((t == null) || (t.isEmpty()));
        text = t != null ? t : "";
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if ((peer != null) && (!skipTextEvent)) {
            peer.setText(text);
        } 
    }

    public synchronized java.lang.String getText() {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            text = peer.getText();
        } 
        return text;
    }

    public synchronized java.lang.String getSelectedText() {
        return getText().substring(getSelectionStart(), getSelectionEnd());
    }

    public boolean isEditable() {
        return editable;
    }

    public synchronized void setEditable(boolean b) {
        if ((editable) == b) {
            return ;
        } 
        editable = b;
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            peer.setEditable(b);
        } 
    }

    public java.awt.Color getBackground() {
        if ((!(editable)) && (!(backgroundSetByClientCode))) {
            return java.awt.SystemColor.control;
        } 
        return super.getBackground();
    }

    public void setBackground(java.awt.Color c) {
        backgroundSetByClientCode = true;
        super.setBackground(c);
    }

    public synchronized int getSelectionStart() {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            selectionStart = peer.getSelectionStart();
        } 
        return selectionStart;
    }

    public synchronized void setSelectionStart(int selectionStart) {
        select(selectionStart, getSelectionEnd());
    }

    public synchronized int getSelectionEnd() {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            selectionEnd = peer.getSelectionEnd();
        } 
        return selectionEnd;
    }

    public synchronized void setSelectionEnd(int selectionEnd) {
        select(getSelectionStart(), selectionEnd);
    }

    public synchronized void select(int selectionStart, int selectionEnd) {
        java.lang.String text = getText();
        if (selectionStart < 0) {
            selectionStart = 0;
        } 
        if (selectionStart > (text.length())) {
            selectionStart = text.length();
        } 
        if (selectionEnd > (text.length())) {
            selectionEnd = text.length();
        } 
        if (selectionEnd < selectionStart) {
            selectionEnd = selectionStart;
        } 
        java.awt.TextComponent.this.selectionStart = selectionStart;
        java.awt.TextComponent.this.selectionEnd = selectionEnd;
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            peer.select(selectionStart, selectionEnd);
        } 
    }

    public synchronized void selectAll() {
        java.awt.TextComponent.this.selectionStart = 0;
        java.awt.TextComponent.this.selectionEnd = getText().length();
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            peer.select(selectionStart, selectionEnd);
        } 
    }

    public synchronized void setCaretPosition(int position) {
        if (position < 0) {
            throw new java.lang.IllegalArgumentException("position less than zero.");
        } 
        int maxposition = getText().length();
        if (position > maxposition) {
            position = maxposition;
        } 
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            peer.setCaretPosition(position);
        } else {
            select(position, position);
        }
    }

    public synchronized int getCaretPosition() {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        int position = 0;
        if (peer != null) {
            position = peer.getCaretPosition();
        } else {
            position = selectionStart;
        }
        int maxposition = getText().length();
        if (position > maxposition) {
            position = maxposition;
        } 
        return position;
    }

    public synchronized void addTextListener(java.awt.event.TextListener l) {
        if (l == null) {
            return ;
        } 
        textListener = java.awt.AWTEventMulticaster.add(textListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeTextListener(java.awt.event.TextListener l) {
        if (l == null) {
            return ;
        } 
        textListener = java.awt.AWTEventMulticaster.remove(textListener, l);
    }

    public synchronized java.awt.event.TextListener[] getTextListeners() {
        return getListeners(java.awt.event.TextListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.TextListener.class)) {
            l = textListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        if ((e.id) == (java.awt.event.TextEvent.TEXT_VALUE_CHANGED)) {
            if ((((eventMask) & (java.awt.AWTEvent.TEXT_EVENT_MASK)) != 0) || ((textListener) != null)) {
                return true;
            } 
            return false;
        } 
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.TextEvent) {
            processTextEvent(((java.awt.event.TextEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processTextEvent(java.awt.event.TextEvent e) {
        java.awt.event.TextListener listener = textListener;
        if (listener != null) {
            int id = e.getID();
            switch (id) {
                case java.awt.event.TextEvent.TEXT_VALUE_CHANGED :
                    listener.textValueChanged(e);
                    break;
            }
        } 
    }

    protected java.lang.String paramString() {
        java.lang.String str = ((super.paramString()) + ",text=") + (getText());
        if (editable) {
            str += ",editable";
        } 
        return (((str + ",selection=") + (getSelectionStart())) + "-") + (getSelectionEnd());
    }

    private boolean canAccessClipboard() {
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm == null)
            return true;
        
        try {
            sm.checkPermission(sun.security.util.SecurityConstants.AWT.ACCESS_CLIPBOARD_PERMISSION);
            return true;
        } catch (java.lang.SecurityException e) {
        }
        return false;
    }

    private int textComponentSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        java.awt.peer.TextComponentPeer peer = ((java.awt.peer.TextComponentPeer)(java.awt.TextComponent.this.peer));
        if (peer != null) {
            text = peer.getText();
            selectionStart = peer.getSelectionStart();
            selectionEnd = peer.getSelectionEnd();
        } 
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.textListenerK, textListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.awt.TextComponent.this.text = (text) != null ? text : "";
        select(selectionStart, selectionEnd);
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.textListenerK) == key) {
                addTextListener(((java.awt.event.TextListener)(s.readObject())));
            } else {
                s.readObject();
            }
        }
        enableInputMethodsIfNecessary();
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.TextComponent.AccessibleAWTTextComponent();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTTextComponent extends java.awt.Component.AccessibleAWTComponent implements java.awt.event.TextListener , javax.accessibility.AccessibleText {
        private static final long serialVersionUID = 3631432373506317811L;

        public AccessibleAWTTextComponent() {
            java.awt.TextComponent.this.addTextListener(java.awt.TextComponent.AccessibleAWTTextComponent.this);
        }

        public void textValueChanged(java.awt.event.TextEvent textEvent) {
            java.lang.Integer cpos = java.lang.Integer.valueOf(java.awt.TextComponent.this.getCaretPosition());
            firePropertyChange(javax.accessibility.AccessibleContext.ACCESSIBLE_TEXT_PROPERTY, null, cpos);
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if (java.awt.TextComponent.this.isEditable()) {
                states.add(javax.accessibility.AccessibleState.EDITABLE);
            } 
            return states;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.TEXT;
        }

        public javax.accessibility.AccessibleText getAccessibleText() {
            return java.awt.TextComponent.AccessibleAWTTextComponent.this;
        }

        public int getIndexAtPoint(java.awt.Point p) {
            return -1;
        }

        public java.awt.Rectangle getCharacterBounds(int i) {
            return null;
        }

        public int getCharCount() {
            return java.awt.TextComponent.this.getText().length();
        }

        public int getCaretPosition() {
            return java.awt.TextComponent.this.getCaretPosition();
        }

        public javax.swing.text.AttributeSet getCharacterAttribute(int i) {
            return null;
        }

        public int getSelectionStart() {
            return java.awt.TextComponent.this.getSelectionStart();
        }

        public int getSelectionEnd() {
            return java.awt.TextComponent.this.getSelectionEnd();
        }

        public java.lang.String getSelectedText() {
            java.lang.String selText = java.awt.TextComponent.this.getSelectedText();
            if ((selText == null) || (selText.equals(""))) {
                return null;
            } 
            return selText;
        }

        public java.lang.String getAtIndex(int part, int index) {
            if ((index < 0) || (index >= (java.awt.TextComponent.this.getText().length()))) {
                return null;
            } 
            switch (part) {
                case javax.accessibility.AccessibleText.CHARACTER :
                    return java.awt.TextComponent.this.getText().substring(index, (index + 1));
                case javax.accessibility.AccessibleText.WORD :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator words = java.text.BreakIterator.getWordInstance();
                        words.setText(s);
                        int end = words.following(index);
                        return s.substring(words.previous(), end);
                    }
                case javax.accessibility.AccessibleText.SENTENCE :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator sentence = java.text.BreakIterator.getSentenceInstance();
                        sentence.setText(s);
                        int end = sentence.following(index);
                        return s.substring(sentence.previous(), end);
                    }
                default :
                    return null;
            }
        }

        private static final boolean NEXT = true;

        private static final boolean PREVIOUS = false;

        private int findWordLimit(int index, java.text.BreakIterator words, boolean direction, java.lang.String s) {
            int last = direction == (java.awt.TextComponent.AccessibleAWTTextComponent.NEXT) ? words.following(index) : words.preceding(index);
            int current = direction == (java.awt.TextComponent.AccessibleAWTTextComponent.NEXT) ? words.next() : words.previous();
            while (current != (java.text.BreakIterator.DONE)) {
                for (int p = java.lang.Math.min(last, current) ; p < (java.lang.Math.max(last, current)) ; p++) {
                    if (java.lang.Character.isLetter(s.charAt(p))) {
                        return last;
                    } 
                }
                last = current;
                current = direction == (java.awt.TextComponent.AccessibleAWTTextComponent.NEXT) ? words.next() : words.previous();
            }
            return java.text.BreakIterator.DONE;
        }

        public java.lang.String getAfterIndex(int part, int index) {
            if ((index < 0) || (index >= (java.awt.TextComponent.this.getText().length()))) {
                return null;
            } 
            switch (part) {
                case javax.accessibility.AccessibleText.CHARACTER :
                    if ((index + 1) >= (java.awt.TextComponent.this.getText().length())) {
                        return null;
                    } 
                    return java.awt.TextComponent.this.getText().substring((index + 1), (index + 2));
                case javax.accessibility.AccessibleText.WORD :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator words = java.text.BreakIterator.getWordInstance();
                        words.setText(s);
                        int start = findWordLimit(index, words, java.awt.TextComponent.AccessibleAWTTextComponent.NEXT, s);
                        if ((start == (java.text.BreakIterator.DONE)) || (start >= (s.length()))) {
                            return null;
                        } 
                        int end = words.following(start);
                        if ((end == (java.text.BreakIterator.DONE)) || (end >= (s.length()))) {
                            return null;
                        } 
                        return s.substring(start, end);
                    }
                case javax.accessibility.AccessibleText.SENTENCE :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator sentence = java.text.BreakIterator.getSentenceInstance();
                        sentence.setText(s);
                        int start = sentence.following(index);
                        if ((start == (java.text.BreakIterator.DONE)) || (start >= (s.length()))) {
                            return null;
                        } 
                        int end = sentence.following(start);
                        if ((end == (java.text.BreakIterator.DONE)) || (end >= (s.length()))) {
                            return null;
                        } 
                        return s.substring(start, end);
                    }
                default :
                    return null;
            }
        }

        public java.lang.String getBeforeIndex(int part, int index) {
            if ((index < 0) || (index > ((java.awt.TextComponent.this.getText().length()) - 1))) {
                return null;
            } 
            switch (part) {
                case javax.accessibility.AccessibleText.CHARACTER :
                    if (index == 0) {
                        return null;
                    } 
                    return java.awt.TextComponent.this.getText().substring((index - 1), index);
                case javax.accessibility.AccessibleText.WORD :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator words = java.text.BreakIterator.getWordInstance();
                        words.setText(s);
                        int end = findWordLimit(index, words, java.awt.TextComponent.AccessibleAWTTextComponent.PREVIOUS, s);
                        if (end == (java.text.BreakIterator.DONE)) {
                            return null;
                        } 
                        int start = words.preceding(end);
                        if (start == (java.text.BreakIterator.DONE)) {
                            return null;
                        } 
                        return s.substring(start, end);
                    }
                case javax.accessibility.AccessibleText.SENTENCE :
                    {
                        java.lang.String s = java.awt.TextComponent.this.getText();
                        java.text.BreakIterator sentence = java.text.BreakIterator.getSentenceInstance();
                        sentence.setText(s);
                        int end = sentence.following(index);
                        end = sentence.previous();
                        int start = sentence.previous();
                        if (start == (java.text.BreakIterator.DONE)) {
                            return null;
                        } 
                        return s.substring(start, end);
                    }
                default :
                    return null;
            }
        }
    }

    private boolean checkForEnableIM = true;
}


package java.awt;


public class MenuShortcut implements java.io.Serializable {
    int key;

    boolean usesShift;

    private static final long serialVersionUID = 143448358473180225L;

    public MenuShortcut(int key) {
        this(key, false);
    }

    public MenuShortcut(int key ,boolean useShiftModifier) {
        java.awt.MenuShortcut.this.key = key;
        java.awt.MenuShortcut.this.usesShift = useShiftModifier;
    }

    public int getKey() {
        return key;
    }

    public boolean usesShiftModifier() {
        return usesShift;
    }

    public boolean equals(java.awt.MenuShortcut s) {
        return ((s != null) && ((s.getKey()) == (key))) && ((s.usesShiftModifier()) == (usesShift));
    }

    public boolean equals(java.lang.Object obj) {
        if (obj instanceof java.awt.MenuShortcut) {
            return equals(((java.awt.MenuShortcut)(obj)));
        } 
        return false;
    }

    public int hashCode() {
        return usesShift ? ~(key) : key;
    }

    public java.lang.String toString() {
        int modifiers = 0;
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            modifiers = java.awt.Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
        } 
        if (usesShiftModifier()) {
            modifiers |= java.awt.Event.SHIFT_MASK;
        } 
        return ((java.awt.event.KeyEvent.getKeyModifiersText(modifiers)) + "+") + (java.awt.event.KeyEvent.getKeyText(key));
    }

    protected java.lang.String paramString() {
        java.lang.String str = "key=" + (key);
        if (usesShiftModifier()) {
            str += ",usesShiftModifier";
        } 
        return str;
    }
}


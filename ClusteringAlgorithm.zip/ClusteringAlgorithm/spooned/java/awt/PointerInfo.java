package java.awt;


public class PointerInfo {
    private final java.awt.GraphicsDevice device;

    private final java.awt.Point location;

    PointerInfo(final java.awt.GraphicsDevice device ,final java.awt.Point location) {
        this.device = device;
        this.location = location;
    }

    public java.awt.GraphicsDevice getDevice() {
        return device;
    }

    public java.awt.Point getLocation() {
        return location;
    }
}


package java.awt;


public abstract class GraphicsConfiguration {
    private static java.awt.BufferCapabilities defaultBufferCaps;

    private static java.awt.ImageCapabilities defaultImageCaps;

    protected GraphicsConfiguration() {
    }

    public abstract java.awt.GraphicsDevice getDevice();

    public java.awt.image.BufferedImage createCompatibleImage(int width, int height) {
        java.awt.image.ColorModel model = getColorModel();
        java.awt.image.WritableRaster raster = model.createCompatibleWritableRaster(width, height);
        return new java.awt.image.BufferedImage(model , raster , model.isAlphaPremultiplied() , null);
    }

    public java.awt.image.BufferedImage createCompatibleImage(int width, int height, int transparency) {
        if ((getColorModel().getTransparency()) == transparency) {
            return createCompatibleImage(width, height);
        } 
        java.awt.image.ColorModel cm = getColorModel(transparency);
        if (cm == null) {
            throw new java.lang.IllegalArgumentException(("Unknown transparency: " + transparency));
        } 
        java.awt.image.WritableRaster wr = cm.createCompatibleWritableRaster(width, height);
        return new java.awt.image.BufferedImage(cm , wr , cm.isAlphaPremultiplied() , null);
    }

    public java.awt.image.VolatileImage createCompatibleVolatileImage(int width, int height) {
        java.awt.image.VolatileImage vi = null;
        try {
            vi = createCompatibleVolatileImage(width, height, null, java.awt.Transparency.OPAQUE);
        } catch (java.awt.AWTException e) {
            assert false;
        }
        return vi;
    }

    public java.awt.image.VolatileImage createCompatibleVolatileImage(int width, int height, int transparency) {
        java.awt.image.VolatileImage vi = null;
        try {
            vi = createCompatibleVolatileImage(width, height, null, transparency);
        } catch (java.awt.AWTException e) {
            assert false;
        }
        return vi;
    }

    public java.awt.image.VolatileImage createCompatibleVolatileImage(int width, int height, java.awt.ImageCapabilities caps) throws java.awt.AWTException {
        return createCompatibleVolatileImage(width, height, caps, java.awt.Transparency.OPAQUE);
    }

    public java.awt.image.VolatileImage createCompatibleVolatileImage(int width, int height, java.awt.ImageCapabilities caps, int transparency) throws java.awt.AWTException {
        java.awt.image.VolatileImage vi = new sun.awt.image.SunVolatileImage(java.awt.GraphicsConfiguration.this , width , height , transparency , caps);
        if (((caps != null) && (caps.isAccelerated())) && (!(vi.getCapabilities().isAccelerated()))) {
            throw new java.awt.AWTException(("Supplied image capabilities could not " + "be met by this graphics configuration."));
        } 
        return vi;
    }

    public abstract java.awt.image.ColorModel getColorModel();

    public abstract java.awt.image.ColorModel getColorModel(int transparency);

    public abstract java.awt.geom.AffineTransform getDefaultTransform();

    public abstract java.awt.geom.AffineTransform getNormalizingTransform();

    public abstract java.awt.Rectangle getBounds();

    private static class DefaultBufferCapabilities extends java.awt.BufferCapabilities {
        public DefaultBufferCapabilities(java.awt.ImageCapabilities imageCaps) {
            super(imageCaps, imageCaps, null);
        }
    }

    public java.awt.BufferCapabilities getBufferCapabilities() {
        if ((java.awt.GraphicsConfiguration.defaultBufferCaps) == null) {
            java.awt.GraphicsConfiguration.defaultBufferCaps = new java.awt.GraphicsConfiguration.DefaultBufferCapabilities(getImageCapabilities());
        } 
        return java.awt.GraphicsConfiguration.defaultBufferCaps;
    }

    public java.awt.ImageCapabilities getImageCapabilities() {
        if ((java.awt.GraphicsConfiguration.defaultImageCaps) == null) {
            java.awt.GraphicsConfiguration.defaultImageCaps = new java.awt.ImageCapabilities(false);
        } 
        return java.awt.GraphicsConfiguration.defaultImageCaps;
    }

    public boolean isTranslucencyCapable() {
        return false;
    }
}


package java.awt;


public final class SplashScreen {
    SplashScreen(long ptr) {
        splashPtr = ptr;
    }

    public static java.awt.SplashScreen getSplashScreen() {
        synchronized(java.awt.SplashScreen.class) {
            if (java.awt.GraphicsEnvironment.isHeadless()) {
                throw new java.awt.HeadlessException();
            } 
            if ((!(java.awt.SplashScreen.wasClosed)) && ((java.awt.SplashScreen.theInstance) == null)) {
                java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.Void>() {
                    public java.lang.Void run() {
                        java.lang.System.loadLibrary("splashscreen");
                        return null;
                    }
                });
                long ptr = java.awt.SplashScreen._getInstance();
                if ((ptr != 0) && (java.awt.SplashScreen._isVisible(ptr))) {
                    java.awt.SplashScreen.theInstance = new java.awt.SplashScreen(ptr);
                } 
            } 
            return java.awt.SplashScreen.theInstance;
        }
    }

    public void setImageURL(java.net.URL imageURL) throws java.io.IOException, java.lang.IllegalStateException, java.lang.NullPointerException {
        checkVisible();
        java.net.URLConnection connection = imageURL.openConnection();
        connection.connect();
        int length = connection.getContentLength();
        java.io.InputStream stream = connection.getInputStream();
        byte[] buf = new byte[length];
        int off = 0;
        while (true) {
            int available = stream.available();
            if (available <= 0) {
                available = 1;
            } 
            if ((off + available) > length) {
                length = off * 2;
                if ((off + available) > length) {
                    length = available + off;
                } 
                byte[] oldBuf = buf;
                buf = new byte[length];
                java.lang.System.arraycopy(oldBuf, 0, buf, 0, off);
            } 
            int result = stream.read(buf, off, available);
            if (result < 0) {
                break;
            } 
            off += result;
        }
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            if (!(java.awt.SplashScreen._setImageData(splashPtr, buf))) {
                throw new java.io.IOException("Bad image format or i/o error when loading image");
            } 
            java.awt.SplashScreen.this.imageURL = imageURL;
        }
    }

    private void checkVisible() {
        if (!(isVisible())) {
            throw new java.lang.IllegalStateException("no splash screen available");
        } 
    }

    public java.net.URL getImageURL() throws java.lang.IllegalStateException {
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            if ((imageURL) == null) {
                try {
                    java.lang.String fileName = java.awt.SplashScreen._getImageFileName(splashPtr);
                    java.lang.String jarName = java.awt.SplashScreen._getImageJarName(splashPtr);
                    if (fileName != null) {
                        if (jarName != null) {
                            imageURL = new java.net.URL(((("jar:" + (new java.io.File(jarName).toURL().toString())) + "!/") + fileName));
                        } else {
                            imageURL = new java.io.File(fileName).toURL();
                        }
                    } 
                } catch (java.net.MalformedURLException e) {
                    if (java.awt.SplashScreen.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.SplashScreen.log.fine("MalformedURLException caught in the getImageURL() method", e);
                    } 
                }
            } 
            return imageURL;
        }
    }

    public java.awt.Rectangle getBounds() throws java.lang.IllegalStateException {
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            float scale = java.awt.SplashScreen._getScaleFactor(splashPtr);
            java.awt.Rectangle bounds = java.awt.SplashScreen._getBounds(splashPtr);
            assert scale > 0;
            if ((scale > 0) && (scale != 1)) {
                bounds.setSize(((int)((bounds.getWidth()) / scale)), ((int)((bounds.getWidth()) / scale)));
            } 
            return bounds;
        }
    }

    public java.awt.Dimension getSize() throws java.lang.IllegalStateException {
        return getBounds().getSize();
    }

    public java.awt.Graphics2D createGraphics() throws java.lang.IllegalStateException {
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            if ((image) == null) {
                java.awt.Dimension dim = java.awt.SplashScreen._getBounds(splashPtr).getSize();
                image = new java.awt.image.BufferedImage(dim.width , dim.height , java.awt.image.BufferedImage.TYPE_INT_ARGB);
            } 
            float scale = java.awt.SplashScreen._getScaleFactor(splashPtr);
            java.awt.Graphics2D g = image.createGraphics();
            assert scale > 0;
            if (scale <= 0) {
                scale = 1;
            } 
            g.scale(scale, scale);
            return g;
        }
    }

    public void update() throws java.lang.IllegalStateException {
        java.awt.image.BufferedImage image;
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            image = java.awt.SplashScreen.this.image;
        }
        if (image == null) {
            throw new java.lang.IllegalStateException("no overlay image available");
        } 
        java.awt.image.DataBuffer buf = image.getRaster().getDataBuffer();
        if (!(buf instanceof java.awt.image.DataBufferInt)) {
            throw new java.lang.AssertionError(("Overlay image DataBuffer is of invalid type == " + (buf.getClass().getName())));
        } 
        int numBanks = buf.getNumBanks();
        if (numBanks != 1) {
            throw new java.lang.AssertionError((("Invalid number of banks ==" + numBanks) + " in overlay image DataBuffer"));
        } 
        if (!((image.getSampleModel()) instanceof java.awt.image.SinglePixelPackedSampleModel)) {
            throw new java.lang.AssertionError(("Overlay image has invalid sample model == " + (image.getSampleModel().getClass().getName())));
        } 
        java.awt.image.SinglePixelPackedSampleModel sm = ((java.awt.image.SinglePixelPackedSampleModel)(image.getSampleModel()));
        int scanlineStride = sm.getScanlineStride();
        java.awt.Rectangle rect = image.getRaster().getBounds();
        int[] data = sun.awt.image.SunWritableRaster.stealData(((java.awt.image.DataBufferInt)(buf)), 0);
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            java.awt.SplashScreen._update(splashPtr, data, rect.x, rect.y, rect.width, rect.height, scanlineStride);
        }
    }

    public void close() throws java.lang.IllegalStateException {
        synchronized(java.awt.SplashScreen.class) {
            checkVisible();
            java.awt.SplashScreen._close(splashPtr);
            image = null;
            java.awt.SplashScreen.markClosed();
        }
    }

    static void markClosed() {
        synchronized(java.awt.SplashScreen.class) {
            java.awt.SplashScreen.wasClosed = true;
            java.awt.SplashScreen.theInstance = null;
        }
    }

    public boolean isVisible() {
        synchronized(java.awt.SplashScreen.class) {
            return (!(java.awt.SplashScreen.wasClosed)) && (java.awt.SplashScreen._isVisible(splashPtr));
        }
    }

    private java.awt.image.BufferedImage image;

    private final long splashPtr;

    private static boolean wasClosed = false;

    private java.net.URL imageURL;

    private static java.awt.SplashScreen theInstance = null;

    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.SplashScreen");

    private static native void _update(long splashPtr, int[] data, int x, int y, int width, int height, int scanlineStride);

    private static native boolean _isVisible(long splashPtr);

    private static native java.awt.Rectangle _getBounds(long splashPtr);

    private static native long _getInstance();

    private static native void _close(long splashPtr);

    private static native java.lang.String _getImageFileName(long splashPtr);

    private static native java.lang.String _getImageJarName(long SplashPtr);

    private static native boolean _setImageData(long SplashPtr, byte[] data);

    private static native float _getScaleFactor(long SplashPtr);
}


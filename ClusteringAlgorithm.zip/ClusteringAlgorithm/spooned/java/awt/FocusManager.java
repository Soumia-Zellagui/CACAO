package java.awt;


class FocusManager implements java.io.Serializable {
    java.awt.Container focusRoot;

    java.awt.Component focusOwner;

    static final long serialVersionUID = 2491878825643557906L;
}


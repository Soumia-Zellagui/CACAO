package java.awt;


abstract class GraphicsCallback extends sun.awt.SunGraphicsCallback {
    static final class PaintCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PaintCallback instance = new java.awt.GraphicsCallback.PaintCallback();

        private PaintCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.paint(cg);
        }

        static java.awt.GraphicsCallback.PaintCallback getInstance() {
            return java.awt.GraphicsCallback.PaintCallback.instance;
        }
    }

    static final class PrintCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PrintCallback instance = new java.awt.GraphicsCallback.PrintCallback();

        private PrintCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.print(cg);
        }

        static java.awt.GraphicsCallback.PrintCallback getInstance() {
            return java.awt.GraphicsCallback.PrintCallback.instance;
        }
    }

    static final class PaintAllCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PaintAllCallback instance = new java.awt.GraphicsCallback.PaintAllCallback();

        private PaintAllCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.paintAll(cg);
        }

        static java.awt.GraphicsCallback.PaintAllCallback getInstance() {
            return java.awt.GraphicsCallback.PaintAllCallback.instance;
        }
    }

    static final class PrintAllCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PrintAllCallback instance = new java.awt.GraphicsCallback.PrintAllCallback();

        private PrintAllCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.printAll(cg);
        }

        static java.awt.GraphicsCallback.PrintAllCallback getInstance() {
            return java.awt.GraphicsCallback.PrintAllCallback.instance;
        }
    }

    static final class PeerPaintCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PeerPaintCallback instance = new java.awt.GraphicsCallback.PeerPaintCallback();

        private PeerPaintCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.validate();
            if ((comp.peer) instanceof java.awt.peer.LightweightPeer) {
                comp.lightweightPaint(cg);
            } else {
                comp.peer.paint(cg);
            }
        }

        static java.awt.GraphicsCallback.PeerPaintCallback getInstance() {
            return java.awt.GraphicsCallback.PeerPaintCallback.instance;
        }
    }

    static final class PeerPrintCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PeerPrintCallback instance = new java.awt.GraphicsCallback.PeerPrintCallback();

        private PeerPrintCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            comp.validate();
            if ((comp.peer) instanceof java.awt.peer.LightweightPeer) {
                comp.lightweightPrint(cg);
            } else {
                comp.peer.print(cg);
            }
        }

        static java.awt.GraphicsCallback.PeerPrintCallback getInstance() {
            return java.awt.GraphicsCallback.PeerPrintCallback.instance;
        }
    }

    static final class PaintHeavyweightComponentsCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PaintHeavyweightComponentsCallback instance = new java.awt.GraphicsCallback.PaintHeavyweightComponentsCallback();

        private PaintHeavyweightComponentsCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            if ((comp.peer) instanceof java.awt.peer.LightweightPeer) {
                comp.paintHeavyweightComponents(cg);
            } else {
                comp.paintAll(cg);
            }
        }

        static java.awt.GraphicsCallback.PaintHeavyweightComponentsCallback getInstance() {
            return java.awt.GraphicsCallback.PaintHeavyweightComponentsCallback.instance;
        }
    }

    static final class PrintHeavyweightComponentsCallback extends java.awt.GraphicsCallback {
        private static java.awt.GraphicsCallback.PrintHeavyweightComponentsCallback instance = new java.awt.GraphicsCallback.PrintHeavyweightComponentsCallback();

        private PrintHeavyweightComponentsCallback() {
        }

        public void run(java.awt.Component comp, java.awt.Graphics cg) {
            if ((comp.peer) instanceof java.awt.peer.LightweightPeer) {
                comp.printHeavyweightComponents(cg);
            } else {
                comp.printAll(cg);
            }
        }

        static java.awt.GraphicsCallback.PrintHeavyweightComponentsCallback getInstance() {
            return java.awt.GraphicsCallback.PrintHeavyweightComponentsCallback.instance;
        }
    }
}


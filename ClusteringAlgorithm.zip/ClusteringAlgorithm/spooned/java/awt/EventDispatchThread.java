package java.awt;


class EventDispatchThread extends java.lang.Thread {
    private static final sun.util.logging.PlatformLogger eventLog = sun.util.logging.PlatformLogger.getLogger("java.awt.event.EventDispatchThread");

    private java.awt.EventQueue theQueue;

    private volatile boolean doDispatch = true;

    private static final int ANY_EVENT = -1;

    private java.util.ArrayList<java.awt.EventFilter> eventFilters = new java.util.ArrayList<java.awt.EventFilter>();

    EventDispatchThread(java.lang.ThreadGroup group ,java.lang.String name ,java.awt.EventQueue queue) {
        super(group, name);
        setEventQueue(queue);
    }

    public void stopDispatching() {
        doDispatch = false;
    }

    public void run() {
        try {
            pumpEvents(new java.awt.Conditional() {
                public boolean evaluate() {
                    return true;
                }
            });
        } finally {
            getEventQueue().detachDispatchThread(java.awt.EventDispatchThread.this);
        }
    }

    void pumpEvents(java.awt.Conditional cond) {
        pumpEvents(java.awt.EventDispatchThread.ANY_EVENT, cond);
    }

    void pumpEventsForHierarchy(java.awt.Conditional cond, java.awt.Component modalComponent) {
        pumpEventsForHierarchy(java.awt.EventDispatchThread.ANY_EVENT, cond, modalComponent);
    }

    void pumpEvents(int id, java.awt.Conditional cond) {
        pumpEventsForHierarchy(id, cond, null);
    }

    void pumpEventsForHierarchy(int id, java.awt.Conditional cond, java.awt.Component modalComponent) {
        pumpEventsForFilter(id, cond, new java.awt.EventDispatchThread.HierarchyEventFilter(modalComponent));
    }

    void pumpEventsForFilter(java.awt.Conditional cond, java.awt.EventFilter filter) {
        pumpEventsForFilter(java.awt.EventDispatchThread.ANY_EVENT, cond, filter);
    }

    void pumpEventsForFilter(int id, java.awt.Conditional cond, java.awt.EventFilter filter) {
        addEventFilter(filter);
        doDispatch = true;
        while (((doDispatch) && (!(isInterrupted()))) && (cond.evaluate())) {
            pumpOneEventForFilters(id);
        }
        removeEventFilter(filter);
    }

    void addEventFilter(java.awt.EventFilter filter) {
        if (java.awt.EventDispatchThread.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.EventDispatchThread.eventLog.finest(("adding the event filter: " + filter));
        } 
        synchronized(eventFilters) {
            if (!(eventFilters.contains(filter))) {
                if (filter instanceof java.awt.ModalEventFilter) {
                    java.awt.ModalEventFilter newFilter = ((java.awt.ModalEventFilter)(filter));
                    int k = 0;
                    for (k = 0 ; k < (eventFilters.size()) ; k++) {
                        java.awt.EventFilter f = eventFilters.get(k);
                        if (f instanceof java.awt.ModalEventFilter) {
                            java.awt.ModalEventFilter cf = ((java.awt.ModalEventFilter)(f));
                            if ((cf.compareTo(newFilter)) > 0) {
                                break;
                            } 
                        } 
                    }
                    eventFilters.add(k, filter);
                } else {
                    eventFilters.add(filter);
                }
            } 
        }
    }

    void removeEventFilter(java.awt.EventFilter filter) {
        if (java.awt.EventDispatchThread.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
            java.awt.EventDispatchThread.eventLog.finest(("removing the event filter: " + filter));
        } 
        synchronized(eventFilters) {
            eventFilters.remove(filter);
        }
    }

    void pumpOneEventForFilters(int id) {
        java.awt.AWTEvent event = null;
        boolean eventOK = false;
        try {
            java.awt.EventQueue eq = null;
            sun.awt.EventQueueDelegate.Delegate delegate = null;
            do {
                eq = getEventQueue();
                delegate = sun.awt.EventQueueDelegate.getDelegate();
                if ((delegate != null) && (id == (java.awt.EventDispatchThread.ANY_EVENT))) {
                    event = delegate.getNextEvent(eq);
                } else {
                    event = id == (java.awt.EventDispatchThread.ANY_EVENT) ? eq.getNextEvent() : eq.getNextEvent(id);
                }
                eventOK = true;
                synchronized(eventFilters) {
                    for (int i = (eventFilters.size()) - 1 ; i >= 0 ; i--) {
                        java.awt.EventFilter f = eventFilters.get(i);
                        java.awt.EventFilter.FilterAction accept = f.acceptEvent(event);
                        if (accept == (java.awt.EventFilter.FilterAction.REJECT)) {
                            eventOK = false;
                            break;
                        } else if (accept == (java.awt.EventFilter.FilterAction.ACCEPT_IMMEDIATELY)) {
                            break;
                        } 
                    }
                }
                eventOK = eventOK && (sun.awt.dnd.SunDragSourceContextPeer.checkEvent(event));
                if (!eventOK) {
                    event.consume();
                } 
            } while (eventOK == false );
            if (java.awt.EventDispatchThread.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINEST)) {
                java.awt.EventDispatchThread.eventLog.finest(("Dispatching: " + event));
            } 
            java.lang.Object handle = null;
            if (delegate != null) {
                handle = delegate.beforeDispatch(event);
            } 
            eq.dispatchEvent(event);
            if (delegate != null) {
                delegate.afterDispatch(event, handle);
            } 
        } catch (java.lang.ThreadDeath death) {
            doDispatch = false;
            throw death;
        } catch (java.lang.InterruptedException interruptedException) {
            doDispatch = false;
        } catch (java.lang.Throwable e) {
            processException(e);
        }
    }

    private void processException(java.lang.Throwable e) {
        if (java.awt.EventDispatchThread.eventLog.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
            java.awt.EventDispatchThread.eventLog.fine(("Processing exception: " + e));
        } 
        getUncaughtExceptionHandler().uncaughtException(java.awt.EventDispatchThread.this, e);
    }

    public synchronized java.awt.EventQueue getEventQueue() {
        return theQueue;
    }

    public synchronized void setEventQueue(java.awt.EventQueue eq) {
        theQueue = eq;
    }

    private static class HierarchyEventFilter implements java.awt.EventFilter {
        private java.awt.Component modalComponent;

        public HierarchyEventFilter(java.awt.Component modalComponent) {
            java.awt.EventDispatchThread.HierarchyEventFilter.this.modalComponent = modalComponent;
        }

        public java.awt.EventFilter.FilterAction acceptEvent(java.awt.AWTEvent event) {
            if ((modalComponent) != null) {
                int eventID = event.getID();
                boolean mouseEvent = (eventID >= (java.awt.event.MouseEvent.MOUSE_FIRST)) && (eventID <= (java.awt.event.MouseEvent.MOUSE_LAST));
                boolean actionEvent = (eventID >= (java.awt.event.ActionEvent.ACTION_FIRST)) && (eventID <= (java.awt.event.ActionEvent.ACTION_LAST));
                boolean windowClosingEvent = eventID == (java.awt.event.WindowEvent.WINDOW_CLOSING);
                if (java.awt.Component.isInstanceOf(modalComponent, "javax.swing.JInternalFrame")) {
                    return windowClosingEvent ? java.awt.EventFilter.FilterAction.REJECT : java.awt.EventFilter.FilterAction.ACCEPT;
                } 
                if ((mouseEvent || actionEvent) || windowClosingEvent) {
                    java.lang.Object o = event.getSource();
                    if (o instanceof sun.awt.ModalExclude) {
                        return java.awt.EventFilter.FilterAction.ACCEPT;
                    } else if (o instanceof java.awt.Component) {
                        java.awt.Component c = ((java.awt.Component)(o));
                        boolean modalExcluded = false;
                        if ((modalComponent) instanceof java.awt.Container) {
                            while ((c != (modalComponent)) && (c != null)) {
                                c = c.getParent();
                            }
                        } 
                        if ((!modalExcluded) && (c != (modalComponent))) {
                            return java.awt.EventFilter.FilterAction.REJECT;
                        } 
                    } 
                } 
            } 
            return java.awt.EventFilter.FilterAction.ACCEPT;
        }
    }
}


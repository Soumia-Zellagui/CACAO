package java.awt;


public abstract class Image {
    private static java.awt.ImageCapabilities defaultImageCaps = new java.awt.ImageCapabilities(false);

    protected float accelerationPriority = 0.5F;

    public abstract int getWidth(java.awt.image.ImageObserver observer);

    public abstract int getHeight(java.awt.image.ImageObserver observer);

    public abstract java.awt.image.ImageProducer getSource();

    public abstract java.awt.Graphics getGraphics();

    public abstract java.lang.Object getProperty(java.lang.String name, java.awt.image.ImageObserver observer);

    public static final java.lang.Object UndefinedProperty = new java.lang.Object();

    public java.awt.Image getScaledInstance(int width, int height, int hints) {
        java.awt.image.ImageFilter filter;
        if ((hints & ((java.awt.Image.SCALE_SMOOTH) | (java.awt.Image.SCALE_AREA_AVERAGING))) != 0) {
            filter = new java.awt.image.AreaAveragingScaleFilter(width , height);
        } else {
            filter = new java.awt.image.ReplicateScaleFilter(width , height);
        }
        java.awt.image.ImageProducer prod;
        prod = new java.awt.image.FilteredImageSource(getSource() , filter);
        return java.awt.Toolkit.getDefaultToolkit().createImage(prod);
    }

    public static final int SCALE_DEFAULT = 1;

    public static final int SCALE_FAST = 2;

    public static final int SCALE_SMOOTH = 4;

    public static final int SCALE_REPLICATE = 8;

    public static final int SCALE_AREA_AVERAGING = 16;

    public void flush() {
        if ((surfaceManager) != null) {
            surfaceManager.flush();
        } 
    }

    public java.awt.ImageCapabilities getCapabilities(java.awt.GraphicsConfiguration gc) {
        if ((surfaceManager) != null) {
            return surfaceManager.getCapabilities(gc);
        } 
        return java.awt.Image.defaultImageCaps;
    }

    public void setAccelerationPriority(float priority) {
        if ((priority < 0) || (priority > 1)) {
            throw new java.lang.IllegalArgumentException(("Priority must be a value " + "between 0 and 1, inclusive"));
        } 
        accelerationPriority = priority;
        if ((surfaceManager) != null) {
            surfaceManager.setAccelerationPriority(accelerationPriority);
        } 
    }

    public float getAccelerationPriority() {
        return accelerationPriority;
    }

    sun.awt.image.SurfaceManager surfaceManager;

    static {
        sun.awt.image.SurfaceManager.setImageAccessor(new sun.awt.image.SurfaceManager.ImageAccessor() {
            public sun.awt.image.SurfaceManager getSurfaceManager(java.awt.Image img) {
                return img.surfaceManager;
            }

            public void setSurfaceManager(java.awt.Image img, sun.awt.image.SurfaceManager mgr) {
                img.surfaceManager = mgr;
            }
        });
    }
}


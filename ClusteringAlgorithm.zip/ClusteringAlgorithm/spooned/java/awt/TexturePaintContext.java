package java.awt;


abstract class TexturePaintContext implements java.awt.PaintContext {
    public static java.awt.image.ColorModel xrgbmodel = new java.awt.image.DirectColorModel(24 , 16711680 , 65280 , 255);

    public static java.awt.image.ColorModel argbmodel = java.awt.image.ColorModel.getRGBdefault();

    java.awt.image.ColorModel colorModel;

    int bWidth;

    int bHeight;

    int maxWidth;

    java.awt.image.WritableRaster outRas;

    double xOrg;

    double yOrg;

    double incXAcross;

    double incYAcross;

    double incXDown;

    double incYDown;

    int colincx;

    int colincy;

    int colincxerr;

    int colincyerr;

    int rowincx;

    int rowincy;

    int rowincxerr;

    int rowincyerr;

    public static java.awt.PaintContext getContext(java.awt.image.BufferedImage bufImg, java.awt.geom.AffineTransform xform, java.awt.RenderingHints hints, java.awt.Rectangle devBounds) {
        java.awt.image.WritableRaster raster = bufImg.getRaster();
        java.awt.image.ColorModel cm = bufImg.getColorModel();
        int maxw = devBounds.width;
        java.lang.Object val = hints.get(java.awt.RenderingHints.KEY_INTERPOLATION);
        boolean filter = val == null ? (hints.get(java.awt.RenderingHints.KEY_RENDERING)) == (java.awt.RenderingHints.VALUE_RENDER_QUALITY) : val != (java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        if ((raster instanceof sun.awt.image.IntegerInterleavedRaster) && ((!filter) || (java.awt.TexturePaintContext.isFilterableDCM(cm)))) {
            sun.awt.image.IntegerInterleavedRaster iir = ((sun.awt.image.IntegerInterleavedRaster)(raster));
            if (((iir.getNumDataElements()) == 1) && ((iir.getPixelStride()) == 1)) {
                return new java.awt.TexturePaintContext.Int(iir , cm , xform , maxw , filter);
            } 
        } else if (raster instanceof sun.awt.image.ByteInterleavedRaster) {
            sun.awt.image.ByteInterleavedRaster bir = ((sun.awt.image.ByteInterleavedRaster)(raster));
            if (((bir.getNumDataElements()) == 1) && ((bir.getPixelStride()) == 1)) {
                if (filter) {
                    if (java.awt.TexturePaintContext.isFilterableICM(cm)) {
                        return new java.awt.TexturePaintContext.ByteFilter(bir , cm , xform , maxw);
                    } 
                } else {
                    return new java.awt.TexturePaintContext.Byte(bir , cm , xform , maxw);
                }
            } 
        } 
        return new java.awt.TexturePaintContext.Any(raster , cm , xform , maxw , filter);
    }

    public static boolean isFilterableICM(java.awt.image.ColorModel cm) {
        if (cm instanceof java.awt.image.IndexColorModel) {
            java.awt.image.IndexColorModel icm = ((java.awt.image.IndexColorModel)(cm));
            if ((icm.getMapSize()) <= 256) {
                return true;
            } 
        } 
        return false;
    }

    public static boolean isFilterableDCM(java.awt.image.ColorModel cm) {
        if (cm instanceof java.awt.image.DirectColorModel) {
            java.awt.image.DirectColorModel dcm = ((java.awt.image.DirectColorModel)(cm));
            return (((java.awt.TexturePaintContext.isMaskOK(dcm.getAlphaMask(), true)) && (java.awt.TexturePaintContext.isMaskOK(dcm.getRedMask(), false))) && (java.awt.TexturePaintContext.isMaskOK(dcm.getGreenMask(), false))) && (java.awt.TexturePaintContext.isMaskOK(dcm.getBlueMask(), false));
        } 
        return false;
    }

    public static boolean isMaskOK(int mask, boolean canbezero) {
        if (canbezero && (mask == 0)) {
            return true;
        } 
        return (((mask == 255) || (mask == 65280)) || (mask == 16711680)) || (mask == -16777216);
    }

    public static java.awt.image.ColorModel getInternedColorModel(java.awt.image.ColorModel cm) {
        if (((java.awt.TexturePaintContext.xrgbmodel) == cm) || (java.awt.TexturePaintContext.xrgbmodel.equals(cm))) {
            return java.awt.TexturePaintContext.xrgbmodel;
        } 
        if (((java.awt.TexturePaintContext.argbmodel) == cm) || (java.awt.TexturePaintContext.argbmodel.equals(cm))) {
            return java.awt.TexturePaintContext.argbmodel;
        } 
        return cm;
    }

    TexturePaintContext(java.awt.image.ColorModel cm ,java.awt.geom.AffineTransform xform ,int bWidth ,int bHeight ,int maxw) {
        java.awt.TexturePaintContext.this.colorModel = java.awt.TexturePaintContext.getInternedColorModel(cm);
        java.awt.TexturePaintContext.this.bWidth = bWidth;
        java.awt.TexturePaintContext.this.bHeight = bHeight;
        java.awt.TexturePaintContext.this.maxWidth = maxw;
        try {
            xform = xform.createInverse();
        } catch (java.awt.geom.NoninvertibleTransformException e) {
            xform.setToScale(0, 0);
        }
        java.awt.TexturePaintContext.this.incXAcross = java.awt.TexturePaintContext.mod(xform.getScaleX(), bWidth);
        java.awt.TexturePaintContext.this.incYAcross = java.awt.TexturePaintContext.mod(xform.getShearY(), bHeight);
        java.awt.TexturePaintContext.this.incXDown = java.awt.TexturePaintContext.mod(xform.getShearX(), bWidth);
        java.awt.TexturePaintContext.this.incYDown = java.awt.TexturePaintContext.mod(xform.getScaleY(), bHeight);
        java.awt.TexturePaintContext.this.xOrg = xform.getTranslateX();
        java.awt.TexturePaintContext.this.yOrg = xform.getTranslateY();
        java.awt.TexturePaintContext.this.colincx = ((int)(incXAcross));
        java.awt.TexturePaintContext.this.colincy = ((int)(incYAcross));
        java.awt.TexturePaintContext.this.colincxerr = java.awt.TexturePaintContext.fractAsInt(incXAcross);
        java.awt.TexturePaintContext.this.colincyerr = java.awt.TexturePaintContext.fractAsInt(incYAcross);
        java.awt.TexturePaintContext.this.rowincx = ((int)(incXDown));
        java.awt.TexturePaintContext.this.rowincy = ((int)(incYDown));
        java.awt.TexturePaintContext.this.rowincxerr = java.awt.TexturePaintContext.fractAsInt(incXDown);
        java.awt.TexturePaintContext.this.rowincyerr = java.awt.TexturePaintContext.fractAsInt(incYDown);
    }

    static int fractAsInt(double d) {
        return ((int)((d % 1.0) * (java.lang.Integer.MAX_VALUE)));
    }

    static double mod(double num, double den) {
        num = num % den;
        if (num < 0) {
            num += den;
            if (num >= den) {
                num = 0;
            } 
        } 
        return num;
    }

    public void dispose() {
        java.awt.TexturePaintContext.dropRaster(colorModel, outRas);
    }

    public java.awt.image.ColorModel getColorModel() {
        return colorModel;
    }

    public java.awt.image.Raster getRaster(int x, int y, int w, int h) {
        if ((((outRas) == null) || ((outRas.getWidth()) < w)) || ((outRas.getHeight()) < h)) {
            outRas = makeRaster((h == 1 ? java.lang.Math.max(w, maxWidth) : w), h);
        } 
        double X = java.awt.TexturePaintContext.mod((((xOrg) + (x * (incXAcross))) + (y * (incXDown))), bWidth);
        double Y = java.awt.TexturePaintContext.mod((((yOrg) + (x * (incYAcross))) + (y * (incYDown))), bHeight);
        setRaster(((int)(X)), ((int)(Y)), java.awt.TexturePaintContext.fractAsInt(X), java.awt.TexturePaintContext.fractAsInt(Y), w, h, bWidth, bHeight, colincx, colincxerr, colincy, colincyerr, rowincx, rowincxerr, rowincy, rowincyerr);
        sun.awt.image.SunWritableRaster.markDirty(outRas);
        return outRas;
    }

    private static java.lang.ref.WeakReference<java.awt.image.Raster> xrgbRasRef;

    private static java.lang.ref.WeakReference<java.awt.image.Raster> argbRasRef;

    static synchronized java.awt.image.WritableRaster makeRaster(java.awt.image.ColorModel cm, java.awt.image.Raster srcRas, int w, int h) {
        if ((java.awt.TexturePaintContext.xrgbmodel) == cm) {
            if ((java.awt.TexturePaintContext.xrgbRasRef) != null) {
                java.awt.image.WritableRaster wr = ((java.awt.image.WritableRaster)(java.awt.TexturePaintContext.xrgbRasRef.get()));
                if (((wr != null) && ((wr.getWidth()) >= w)) && ((wr.getHeight()) >= h)) {
                    java.awt.TexturePaintContext.xrgbRasRef = null;
                    return wr;
                } 
            } 
            if ((w <= 32) && (h <= 32)) {
                w = h = 32;
            } 
        } else if ((java.awt.TexturePaintContext.argbmodel) == cm) {
            if ((java.awt.TexturePaintContext.argbRasRef) != null) {
                java.awt.image.WritableRaster wr = ((java.awt.image.WritableRaster)(java.awt.TexturePaintContext.argbRasRef.get()));
                if (((wr != null) && ((wr.getWidth()) >= w)) && ((wr.getHeight()) >= h)) {
                    java.awt.TexturePaintContext.argbRasRef = null;
                    return wr;
                } 
            } 
            if ((w <= 32) && (h <= 32)) {
                w = h = 32;
            } 
        } 
        if (srcRas != null) {
            return srcRas.createCompatibleWritableRaster(w, h);
        } else {
            return cm.createCompatibleWritableRaster(w, h);
        }
    }

    static synchronized void dropRaster(java.awt.image.ColorModel cm, java.awt.image.Raster outRas) {
        if (outRas == null) {
            return ;
        } 
        if ((java.awt.TexturePaintContext.xrgbmodel) == cm) {
            java.awt.TexturePaintContext.xrgbRasRef = new java.lang.ref.WeakReference<>(outRas);
        } else if ((java.awt.TexturePaintContext.argbmodel) == cm) {
            java.awt.TexturePaintContext.argbRasRef = new java.lang.ref.WeakReference<>(outRas);
        } 
    }

    private static java.lang.ref.WeakReference<java.awt.image.Raster> byteRasRef;

    static synchronized java.awt.image.WritableRaster makeByteRaster(java.awt.image.Raster srcRas, int w, int h) {
        if ((java.awt.TexturePaintContext.byteRasRef) != null) {
            java.awt.image.WritableRaster wr = ((java.awt.image.WritableRaster)(java.awt.TexturePaintContext.byteRasRef.get()));
            if (((wr != null) && ((wr.getWidth()) >= w)) && ((wr.getHeight()) >= h)) {
                java.awt.TexturePaintContext.byteRasRef = null;
                return wr;
            } 
        } 
        if ((w <= 32) && (h <= 32)) {
            w = h = 32;
        } 
        return srcRas.createCompatibleWritableRaster(w, h);
    }

    static synchronized void dropByteRaster(java.awt.image.Raster outRas) {
        if (outRas == null) {
            return ;
        } 
        java.awt.TexturePaintContext.byteRasRef = new java.lang.ref.WeakReference<>(outRas);
    }

    public abstract java.awt.image.WritableRaster makeRaster(int w, int h);

    public abstract void setRaster(int x, int y, int xerr, int yerr, int w, int h, int bWidth, int bHeight, int colincx, int colincxerr, int colincy, int colincyerr, int rowincx, int rowincxerr, int rowincy, int rowincyerr);

    public static int blend(int[] rgbs, int xmul, int ymul) {
        xmul = xmul >>> 19;
        ymul = ymul >>> 19;
        int accumA;
        int accumR;
        int accumG;
        int accumB;
        accumA = accumR = accumG = accumB = 0;
        for (int i = 0 ; i < 4 ; i++) {
            int rgb = rgbs[i];
            xmul = (1 << 12) - xmul;
            if ((i & 1) == 0) {
                ymul = (1 << 12) - ymul;
            } 
            int factor = xmul * ymul;
            if (factor != 0) {
                accumA += (rgb >>> 24) * factor;
                accumR += ((rgb >>> 16) & 255) * factor;
                accumG += ((rgb >>> 8) & 255) * factor;
                accumB += (rgb & 255) * factor;
            } 
        }
        return (((((accumA + (1 << 23)) >>> 24) << 24) | (((accumR + (1 << 23)) >>> 24) << 16)) | (((accumG + (1 << 23)) >>> 24) << 8)) | ((accumB + (1 << 23)) >>> 24);
    }

    static class Int extends java.awt.TexturePaintContext {
        sun.awt.image.IntegerInterleavedRaster srcRas;

        int[] inData;

        int inOff;

        int inSpan;

        int[] outData;

        int outOff;

        int outSpan;

        boolean filter;

        public Int(sun.awt.image.IntegerInterleavedRaster srcRas ,java.awt.image.ColorModel cm ,java.awt.geom.AffineTransform xform ,int maxw ,boolean filter) {
            super(cm, xform, srcRas.getWidth(), srcRas.getHeight(), maxw);
            java.awt.TexturePaintContext.Int.this.srcRas = srcRas;
            java.awt.TexturePaintContext.Int.this.inData = srcRas.getDataStorage();
            java.awt.TexturePaintContext.Int.this.inSpan = srcRas.getScanlineStride();
            java.awt.TexturePaintContext.Int.this.inOff = srcRas.getDataOffset(0);
            java.awt.TexturePaintContext.Int.this.filter = filter;
        }

        public java.awt.image.WritableRaster makeRaster(int w, int h) {
            java.awt.image.WritableRaster ras = java.awt.TexturePaintContext.makeRaster(colorModel, srcRas, w, h);
            sun.awt.image.IntegerInterleavedRaster iiRas = ((sun.awt.image.IntegerInterleavedRaster)(ras));
            outData = iiRas.getDataStorage();
            outSpan = iiRas.getScanlineStride();
            outOff = iiRas.getDataOffset(0);
            return ras;
        }

        public void setRaster(int x, int y, int xerr, int yerr, int w, int h, int bWidth, int bHeight, int colincx, int colincxerr, int colincy, int colincyerr, int rowincx, int rowincxerr, int rowincy, int rowincyerr) {
            int[] inData = java.awt.TexturePaintContext.Int.this.inData;
            int[] outData = java.awt.TexturePaintContext.Int.this.outData;
            int out = outOff;
            int inSpan = java.awt.TexturePaintContext.Int.this.inSpan;
            int inOff = java.awt.TexturePaintContext.Int.this.inOff;
            int outSpan = java.awt.TexturePaintContext.Int.this.outSpan;
            boolean filter = java.awt.TexturePaintContext.Int.this.filter;
            boolean normalx = ((((colincx == 1) && (colincxerr == 0)) && (colincy == 0)) && (colincyerr == 0)) && (!filter);
            int rowx = x;
            int rowy = y;
            int rowxerr = xerr;
            int rowyerr = yerr;
            if (normalx) {
                outSpan -= w;
            } 
            int[] rgbs = filter ? new int[4] : null;
            for (int j = 0 ; j < h ; j++) {
                if (normalx) {
                    int in = (inOff + (rowy * inSpan)) + bWidth;
                    x = bWidth - rowx;
                    out += w;
                    if (bWidth >= 32) {
                        int i = w;
                        while (i > 0) {
                            int copyw = i < x ? i : x;
                            java.lang.System.arraycopy(inData, (in - x), outData, (out - i), copyw);
                            i -= copyw;
                            if ((x -= copyw) == 0) {
                                x = bWidth;
                            } 
                        }
                    } else {
                        for (int i = w ; i > 0 ; i--) {
                            outData[(out - i)] = inData[(in - x)];
                            if ((--x) == 0) {
                                x = bWidth;
                            } 
                        }
                    }
                } else {
                    x = rowx;
                    y = rowy;
                    xerr = rowxerr;
                    yerr = rowyerr;
                    for (int i = 0 ; i < w ; i++) {
                        if (filter) {
                            int nextx;
                            int nexty;
                            if ((nextx = x + 1) >= bWidth) {
                                nextx = 0;
                            } 
                            if ((nexty = y + 1) >= bHeight) {
                                nexty = 0;
                            } 
                            rgbs[0] = inData[((inOff + (y * inSpan)) + x)];
                            rgbs[1] = inData[((inOff + (y * inSpan)) + nextx)];
                            rgbs[2] = inData[((inOff + (nexty * inSpan)) + x)];
                            rgbs[3] = inData[((inOff + (nexty * inSpan)) + nextx)];
                            outData[(out + i)] = java.awt.TexturePaintContext.blend(rgbs, xerr, yerr);
                        } else {
                            outData[(out + i)] = inData[((inOff + (y * inSpan)) + x)];
                        }
                        if ((xerr += colincxerr) < 0) {
                            xerr &= java.lang.Integer.MAX_VALUE;
                            x++;
                        } 
                        if ((x += colincx) >= bWidth) {
                            x -= bWidth;
                        } 
                        if ((yerr += colincyerr) < 0) {
                            yerr &= java.lang.Integer.MAX_VALUE;
                            y++;
                        } 
                        if ((y += colincy) >= bHeight) {
                            y -= bHeight;
                        } 
                    }
                }
                if ((rowxerr += rowincxerr) < 0) {
                    rowxerr &= java.lang.Integer.MAX_VALUE;
                    rowx++;
                } 
                if ((rowx += rowincx) >= bWidth) {
                    rowx -= bWidth;
                } 
                if ((rowyerr += rowincyerr) < 0) {
                    rowyerr &= java.lang.Integer.MAX_VALUE;
                    rowy++;
                } 
                if ((rowy += rowincy) >= bHeight) {
                    rowy -= bHeight;
                } 
                out += outSpan;
            }
        }
    }

    static class Byte extends java.awt.TexturePaintContext {
        sun.awt.image.ByteInterleavedRaster srcRas;

        byte[] inData;

        int inOff;

        int inSpan;

        byte[] outData;

        int outOff;

        int outSpan;

        public Byte(sun.awt.image.ByteInterleavedRaster srcRas ,java.awt.image.ColorModel cm ,java.awt.geom.AffineTransform xform ,int maxw) {
            super(cm, xform, srcRas.getWidth(), srcRas.getHeight(), maxw);
            java.awt.TexturePaintContext.Byte.this.srcRas = srcRas;
            java.awt.TexturePaintContext.Byte.this.inData = srcRas.getDataStorage();
            java.awt.TexturePaintContext.Byte.this.inSpan = srcRas.getScanlineStride();
            java.awt.TexturePaintContext.Byte.this.inOff = srcRas.getDataOffset(0);
        }

        public java.awt.image.WritableRaster makeRaster(int w, int h) {
            java.awt.image.WritableRaster ras = java.awt.TexturePaintContext.makeByteRaster(srcRas, w, h);
            sun.awt.image.ByteInterleavedRaster biRas = ((sun.awt.image.ByteInterleavedRaster)(ras));
            outData = biRas.getDataStorage();
            outSpan = biRas.getScanlineStride();
            outOff = biRas.getDataOffset(0);
            return ras;
        }

        public void dispose() {
            java.awt.TexturePaintContext.dropByteRaster(outRas);
        }

        public void setRaster(int x, int y, int xerr, int yerr, int w, int h, int bWidth, int bHeight, int colincx, int colincxerr, int colincy, int colincyerr, int rowincx, int rowincxerr, int rowincy, int rowincyerr) {
            byte[] inData = java.awt.TexturePaintContext.Byte.this.inData;
            byte[] outData = java.awt.TexturePaintContext.Byte.this.outData;
            int out = outOff;
            int inSpan = java.awt.TexturePaintContext.Byte.this.inSpan;
            int inOff = java.awt.TexturePaintContext.Byte.this.inOff;
            int outSpan = java.awt.TexturePaintContext.Byte.this.outSpan;
            boolean normalx = (((colincx == 1) && (colincxerr == 0)) && (colincy == 0)) && (colincyerr == 0);
            int rowx = x;
            int rowy = y;
            int rowxerr = xerr;
            int rowyerr = yerr;
            if (normalx) {
                outSpan -= w;
            } 
            for (int j = 0 ; j < h ; j++) {
                if (normalx) {
                    int in = (inOff + (rowy * inSpan)) + bWidth;
                    x = bWidth - rowx;
                    out += w;
                    if (bWidth >= 32) {
                        int i = w;
                        while (i > 0) {
                            int copyw = i < x ? i : x;
                            java.lang.System.arraycopy(inData, (in - x), outData, (out - i), copyw);
                            i -= copyw;
                            if ((x -= copyw) == 0) {
                                x = bWidth;
                            } 
                        }
                    } else {
                        for (int i = w ; i > 0 ; i--) {
                            outData[(out - i)] = inData[(in - x)];
                            if ((--x) == 0) {
                                x = bWidth;
                            } 
                        }
                    }
                } else {
                    x = rowx;
                    y = rowy;
                    xerr = rowxerr;
                    yerr = rowyerr;
                    for (int i = 0 ; i < w ; i++) {
                        outData[(out + i)] = inData[((inOff + (y * inSpan)) + x)];
                        if ((xerr += colincxerr) < 0) {
                            xerr &= java.lang.Integer.MAX_VALUE;
                            x++;
                        } 
                        if ((x += colincx) >= bWidth) {
                            x -= bWidth;
                        } 
                        if ((yerr += colincyerr) < 0) {
                            yerr &= java.lang.Integer.MAX_VALUE;
                            y++;
                        } 
                        if ((y += colincy) >= bHeight) {
                            y -= bHeight;
                        } 
                    }
                }
                if ((rowxerr += rowincxerr) < 0) {
                    rowxerr &= java.lang.Integer.MAX_VALUE;
                    rowx++;
                } 
                if ((rowx += rowincx) >= bWidth) {
                    rowx -= bWidth;
                } 
                if ((rowyerr += rowincyerr) < 0) {
                    rowyerr &= java.lang.Integer.MAX_VALUE;
                    rowy++;
                } 
                if ((rowy += rowincy) >= bHeight) {
                    rowy -= bHeight;
                } 
                out += outSpan;
            }
        }
    }

    static class ByteFilter extends java.awt.TexturePaintContext {
        sun.awt.image.ByteInterleavedRaster srcRas;

        int[] inPalette;

        byte[] inData;

        int inOff;

        int inSpan;

        int[] outData;

        int outOff;

        int outSpan;

        public ByteFilter(sun.awt.image.ByteInterleavedRaster srcRas ,java.awt.image.ColorModel cm ,java.awt.geom.AffineTransform xform ,int maxw) {
            super(((cm.getTransparency()) == (java.awt.Transparency.OPAQUE) ? java.awt.TexturePaintContext.xrgbmodel : java.awt.TexturePaintContext.argbmodel), xform, srcRas.getWidth(), srcRas.getHeight(), maxw);
            java.awt.TexturePaintContext.ByteFilter.this.inPalette = new int[256];
            ((java.awt.image.IndexColorModel)(cm)).getRGBs(java.awt.TexturePaintContext.ByteFilter.this.inPalette);
            java.awt.TexturePaintContext.ByteFilter.this.srcRas = srcRas;
            java.awt.TexturePaintContext.ByteFilter.this.inData = srcRas.getDataStorage();
            java.awt.TexturePaintContext.ByteFilter.this.inSpan = srcRas.getScanlineStride();
            java.awt.TexturePaintContext.ByteFilter.this.inOff = srcRas.getDataOffset(0);
        }

        public java.awt.image.WritableRaster makeRaster(int w, int h) {
            java.awt.image.WritableRaster ras = java.awt.TexturePaintContext.makeRaster(colorModel, null, w, h);
            sun.awt.image.IntegerInterleavedRaster iiRas = ((sun.awt.image.IntegerInterleavedRaster)(ras));
            outData = iiRas.getDataStorage();
            outSpan = iiRas.getScanlineStride();
            outOff = iiRas.getDataOffset(0);
            return ras;
        }

        public void setRaster(int x, int y, int xerr, int yerr, int w, int h, int bWidth, int bHeight, int colincx, int colincxerr, int colincy, int colincyerr, int rowincx, int rowincxerr, int rowincy, int rowincyerr) {
            byte[] inData = java.awt.TexturePaintContext.ByteFilter.this.inData;
            int[] outData = java.awt.TexturePaintContext.ByteFilter.this.outData;
            int out = outOff;
            int inSpan = java.awt.TexturePaintContext.ByteFilter.this.inSpan;
            int inOff = java.awt.TexturePaintContext.ByteFilter.this.inOff;
            int outSpan = java.awt.TexturePaintContext.ByteFilter.this.outSpan;
            int rowx = x;
            int rowy = y;
            int rowxerr = xerr;
            int rowyerr = yerr;
            int[] rgbs = new int[4];
            for (int j = 0 ; j < h ; j++) {
                x = rowx;
                y = rowy;
                xerr = rowxerr;
                yerr = rowyerr;
                for (int i = 0 ; i < w ; i++) {
                    int nextx;
                    int nexty;
                    if ((nextx = x + 1) >= bWidth) {
                        nextx = 0;
                    } 
                    if ((nexty = y + 1) >= bHeight) {
                        nexty = 0;
                    } 
                    rgbs[0] = inPalette[(255 & (inData[((inOff + x) + (inSpan * y))]))];
                    rgbs[1] = inPalette[(255 & (inData[((inOff + nextx) + (inSpan * y))]))];
                    rgbs[2] = inPalette[(255 & (inData[((inOff + x) + (inSpan * nexty))]))];
                    rgbs[3] = inPalette[(255 & (inData[((inOff + nextx) + (inSpan * nexty))]))];
                    outData[(out + i)] = java.awt.TexturePaintContext.blend(rgbs, xerr, yerr);
                    if ((xerr += colincxerr) < 0) {
                        xerr &= java.lang.Integer.MAX_VALUE;
                        x++;
                    } 
                    if ((x += colincx) >= bWidth) {
                        x -= bWidth;
                    } 
                    if ((yerr += colincyerr) < 0) {
                        yerr &= java.lang.Integer.MAX_VALUE;
                        y++;
                    } 
                    if ((y += colincy) >= bHeight) {
                        y -= bHeight;
                    } 
                }
                if ((rowxerr += rowincxerr) < 0) {
                    rowxerr &= java.lang.Integer.MAX_VALUE;
                    rowx++;
                } 
                if ((rowx += rowincx) >= bWidth) {
                    rowx -= bWidth;
                } 
                if ((rowyerr += rowincyerr) < 0) {
                    rowyerr &= java.lang.Integer.MAX_VALUE;
                    rowy++;
                } 
                if ((rowy += rowincy) >= bHeight) {
                    rowy -= bHeight;
                } 
                out += outSpan;
            }
        }
    }

    static class Any extends java.awt.TexturePaintContext {
        java.awt.image.WritableRaster srcRas;

        boolean filter;

        public Any(java.awt.image.WritableRaster srcRas ,java.awt.image.ColorModel cm ,java.awt.geom.AffineTransform xform ,int maxw ,boolean filter) {
            super(cm, xform, srcRas.getWidth(), srcRas.getHeight(), maxw);
            java.awt.TexturePaintContext.Any.this.srcRas = srcRas;
            java.awt.TexturePaintContext.Any.this.filter = filter;
        }

        public java.awt.image.WritableRaster makeRaster(int w, int h) {
            return java.awt.TexturePaintContext.makeRaster(colorModel, srcRas, w, h);
        }

        public void setRaster(int x, int y, int xerr, int yerr, int w, int h, int bWidth, int bHeight, int colincx, int colincxerr, int colincy, int colincyerr, int rowincx, int rowincxerr, int rowincy, int rowincyerr) {
            java.lang.Object data = null;
            int rowx = x;
            int rowy = y;
            int rowxerr = xerr;
            int rowyerr = yerr;
            java.awt.image.WritableRaster srcRas = java.awt.TexturePaintContext.Any.this.srcRas;
            java.awt.image.WritableRaster outRas = java.awt.TexturePaintContext.Any.this.outRas;
            int[] rgbs = filter ? new int[4] : null;
            for (int j = 0 ; j < h ; j++) {
                x = rowx;
                y = rowy;
                xerr = rowxerr;
                yerr = rowyerr;
                for (int i = 0 ; i < w ; i++) {
                    data = srcRas.getDataElements(x, y, data);
                    if (filter) {
                        int nextx;
                        int nexty;
                        if ((nextx = x + 1) >= bWidth) {
                            nextx = 0;
                        } 
                        if ((nexty = y + 1) >= bHeight) {
                            nexty = 0;
                        } 
                        rgbs[0] = colorModel.getRGB(data);
                        data = srcRas.getDataElements(nextx, y, data);
                        rgbs[1] = colorModel.getRGB(data);
                        data = srcRas.getDataElements(x, nexty, data);
                        rgbs[2] = colorModel.getRGB(data);
                        data = srcRas.getDataElements(nextx, nexty, data);
                        rgbs[3] = colorModel.getRGB(data);
                        int rgb = java.awt.TexturePaintContext.blend(rgbs, xerr, yerr);
                        data = colorModel.getDataElements(rgb, data);
                    } 
                    outRas.setDataElements(i, j, data);
                    if ((xerr += colincxerr) < 0) {
                        xerr &= java.lang.Integer.MAX_VALUE;
                        x++;
                    } 
                    if ((x += colincx) >= bWidth) {
                        x -= bWidth;
                    } 
                    if ((yerr += colincyerr) < 0) {
                        yerr &= java.lang.Integer.MAX_VALUE;
                        y++;
                    } 
                    if ((y += colincy) >= bHeight) {
                        y -= bHeight;
                    } 
                }
                if ((rowxerr += rowincxerr) < 0) {
                    rowxerr &= java.lang.Integer.MAX_VALUE;
                    rowx++;
                } 
                if ((rowx += rowincx) >= bWidth) {
                    rowx -= bWidth;
                } 
                if ((rowyerr += rowincyerr) < 0) {
                    rowyerr &= java.lang.Integer.MAX_VALUE;
                    rowy++;
                } 
                if ((rowy += rowincy) >= bHeight) {
                    rowy -= bHeight;
                } 
            }
        }
    }
}


package java.awt;


public class List extends java.awt.Component implements java.awt.ItemSelectable , javax.accessibility.Accessible {
    java.util.Vector<java.lang.String> items = new java.util.Vector<>();

    int rows = 0;

    boolean multipleMode = false;

    int[] selected = new int[0];

    int visibleIndex = -1;

    transient java.awt.event.ActionListener actionListener;

    transient java.awt.event.ItemListener itemListener;

    private static final java.lang.String base = "list";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -3304312411574666869L;

    public List() throws java.awt.HeadlessException {
        this(0, false);
    }

    public List(int rows) throws java.awt.HeadlessException {
        this(rows, false);
    }

    static final int DEFAULT_VISIBLE_ROWS = 4;

    public List(int rows ,boolean multipleMode) throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.List.this.rows = rows != 0 ? rows : java.awt.List.DEFAULT_VISIBLE_ROWS;
        java.awt.List.this.multipleMode = multipleMode;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.List.class) {
            return (java.awt.List.base) + ((java.awt.List.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createList(java.awt.List.this);
            
            super.addNotify();
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            if (peer != null) {
                selected = peer.getSelectedIndexes();
            } 
            super.removeNotify();
        }
    }

    public int getItemCount() {
        return countItems();
    }

    @java.lang.Deprecated
    public int countItems() {
        return items.size();
    }

    public java.lang.String getItem(int index) {
        return getItemImpl(index);
    }

    final java.lang.String getItemImpl(int index) {
        return items.elementAt(index);
    }

    public synchronized java.lang.String[] getItems() {
        java.lang.String[] itemCopies = new java.lang.String[items.size()];
        items.copyInto(itemCopies);
        return itemCopies;
    }

    public void add(java.lang.String item) {
        addItem(item);
    }

    @java.lang.Deprecated
    public void addItem(java.lang.String item) {
        addItem(item, (-1));
    }

    public void add(java.lang.String item, int index) {
        addItem(item, index);
    }

    @java.lang.Deprecated
    public synchronized void addItem(java.lang.String item, int index) {
        if ((index < (-1)) || (index >= (items.size()))) {
            index = -1;
        } 
        if (item == null) {
            item = "";
        } 
        if (index == (-1)) {
            items.addElement(item);
        } else {
            items.insertElementAt(item, index);
        }
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            peer.add(item, index);
        } 
    }

    public synchronized void replaceItem(java.lang.String newValue, int index) {
        remove(index);
        add(newValue, index);
    }

    public void removeAll() {
        clear();
    }

    @java.lang.Deprecated
    public synchronized void clear() {
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            peer.removeAll();
        } 
        items = new java.util.Vector<>();
        selected = new int[0];
    }

    public synchronized void remove(java.lang.String item) {
        int index = items.indexOf(item);
        if (index < 0) {
            throw new java.lang.IllegalArgumentException((("item " + item) + " not found in list"));
        } else {
            remove(index);
        }
    }

    public void remove(int position) {
        delItem(position);
    }

    @java.lang.Deprecated
    public void delItem(int position) {
        delItems(position, position);
    }

    public synchronized int getSelectedIndex() {
        int[] sel = getSelectedIndexes();
        return (sel.length) == 1 ? sel[0] : -1;
    }

    public synchronized int[] getSelectedIndexes() {
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            selected = peer.getSelectedIndexes();
        } 
        return selected.clone();
    }

    public synchronized java.lang.String getSelectedItem() {
        int index = getSelectedIndex();
        return index < 0 ? null : getItem(index);
    }

    public synchronized java.lang.String[] getSelectedItems() {
        int[] sel = getSelectedIndexes();
        java.lang.String[] str = new java.lang.String[sel.length];
        for (int i = 0 ; i < (sel.length) ; i++) {
            str[i] = getItem(sel[i]);
        }
        return str;
    }

    public java.lang.Object[] getSelectedObjects() {
        return getSelectedItems();
    }

    public void select(int index) {
        java.awt.peer.ListPeer peer;
        do {
            peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            if (peer != null) {
                peer.select(index);
                return ;
            } 
            synchronized(java.awt.List.this) {
                boolean alreadySelected = false;
                for (int i = 0 ; i < (selected.length) ; i++) {
                    if ((selected[i]) == index) {
                        alreadySelected = true;
                        break;
                    } 
                }
                if (!alreadySelected) {
                    if (!(multipleMode)) {
                        selected = new int[1];
                        selected[0] = index;
                    } else {
                        int[] newsel = new int[(selected.length) + 1];
                        java.lang.System.arraycopy(selected, 0, newsel, 0, selected.length);
                        newsel[selected.length] = index;
                        selected = newsel;
                    }
                } 
            }
        } while (peer != (java.awt.List.this.peer) );
    }

    public synchronized void deselect(int index) {
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            if ((isMultipleMode()) || ((getSelectedIndex()) == index)) {
                peer.deselect(index);
            } 
        } 
        for (int i = 0 ; i < (selected.length) ; i++) {
            if ((selected[i]) == index) {
                int[] newsel = new int[(selected.length) - 1];
                java.lang.System.arraycopy(selected, 0, newsel, 0, i);
                java.lang.System.arraycopy(selected, (i + 1), newsel, i, ((selected.length) - (i + 1)));
                selected = newsel;
                return ;
            } 
        }
    }

    public boolean isIndexSelected(int index) {
        return isSelected(index);
    }

    @java.lang.Deprecated
    public boolean isSelected(int index) {
        int[] sel = getSelectedIndexes();
        for (int i = 0 ; i < (sel.length) ; i++) {
            if ((sel[i]) == index) {
                return true;
            } 
        }
        return false;
    }

    public int getRows() {
        return rows;
    }

    public boolean isMultipleMode() {
        return allowsMultipleSelections();
    }

    @java.lang.Deprecated
    public boolean allowsMultipleSelections() {
        return multipleMode;
    }

    public void setMultipleMode(boolean b) {
        setMultipleSelections(b);
    }

    @java.lang.Deprecated
    public synchronized void setMultipleSelections(boolean b) {
        if (b != (multipleMode)) {
            multipleMode = b;
            java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            if (peer != null) {
                peer.setMultipleMode(b);
            } 
        } 
    }

    public int getVisibleIndex() {
        return visibleIndex;
    }

    public synchronized void makeVisible(int index) {
        visibleIndex = index;
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            peer.makeVisible(index);
        } 
    }

    public java.awt.Dimension getPreferredSize(int rows) {
        return preferredSize(rows);
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize(int rows) {
        synchronized(getTreeLock()) {
            java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            return peer != null ? peer.getPreferredSize(rows) : super.preferredSize();
        }
    }

    public java.awt.Dimension getPreferredSize() {
        return preferredSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension preferredSize() {
        synchronized(getTreeLock()) {
            return (rows) > 0 ? preferredSize(rows) : super.preferredSize();
        }
    }

    public java.awt.Dimension getMinimumSize(int rows) {
        return minimumSize(rows);
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize(int rows) {
        synchronized(getTreeLock()) {
            java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            return peer != null ? peer.getMinimumSize(rows) : super.minimumSize();
        }
    }

    public java.awt.Dimension getMinimumSize() {
        return minimumSize();
    }

    @java.lang.Deprecated
    public java.awt.Dimension minimumSize() {
        synchronized(getTreeLock()) {
            return (rows) > 0 ? minimumSize(rows) : super.minimumSize();
        }
    }

    public synchronized void addItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.add(itemListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeItemListener(java.awt.event.ItemListener l) {
        if (l == null) {
            return ;
        } 
        itemListener = java.awt.AWTEventMulticaster.remove(itemListener, l);
    }

    public synchronized java.awt.event.ItemListener[] getItemListeners() {
        return getListeners(java.awt.event.ItemListener.class);
    }

    public synchronized void addActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.add(actionListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeActionListener(java.awt.event.ActionListener l) {
        if (l == null) {
            return ;
        } 
        actionListener = java.awt.AWTEventMulticaster.remove(actionListener, l);
    }

    public synchronized java.awt.event.ActionListener[] getActionListeners() {
        return getListeners(java.awt.event.ActionListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.ActionListener.class)) {
            l = actionListener;
        } else if (listenerType == (java.awt.event.ItemListener.class)) {
            l = itemListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        switch (e.id) {
            case java.awt.event.ActionEvent.ACTION_PERFORMED :
                if ((((eventMask) & (java.awt.AWTEvent.ACTION_EVENT_MASK)) != 0) || ((actionListener) != null)) {
                    return true;
                } 
                return false;
            case java.awt.event.ItemEvent.ITEM_STATE_CHANGED :
                if ((((eventMask) & (java.awt.AWTEvent.ITEM_EVENT_MASK)) != 0) || ((itemListener) != null)) {
                    return true;
                } 
                return false;
            default :
                break;
        }
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ItemEvent) {
            processItemEvent(((java.awt.event.ItemEvent)(e)));
            return ;
        } else if (e instanceof java.awt.event.ActionEvent) {
            processActionEvent(((java.awt.event.ActionEvent)(e)));
            return ;
        } 
        super.processEvent(e);
    }

    protected void processItemEvent(java.awt.event.ItemEvent e) {
        java.awt.event.ItemListener listener = itemListener;
        if (listener != null) {
            listener.itemStateChanged(e);
        } 
    }

    protected void processActionEvent(java.awt.event.ActionEvent e) {
        java.awt.event.ActionListener listener = actionListener;
        if (listener != null) {
            listener.actionPerformed(e);
        } 
    }

    protected java.lang.String paramString() {
        return ((super.paramString()) + ",selected=") + (getSelectedItem());
    }

    @java.lang.Deprecated
    public synchronized void delItems(int start, int end) {
        for (int i = end ; i >= start ; i--) {
            items.removeElementAt(i);
        }
        java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
        if (peer != null) {
            peer.delItems(start, end);
        } 
    }

    private int listSerializedDataVersion = 1;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        synchronized(java.awt.List.this) {
            java.awt.peer.ListPeer peer = ((java.awt.peer.ListPeer)(java.awt.List.this.peer));
            if (peer != null) {
                selected = peer.getSelectedIndexes();
            } 
        }
        s.defaultWriteObject();
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.itemListenerK, itemListener);
        java.awt.AWTEventMulticaster.save(s, java.awt.Component.actionListenerK, actionListener);
        s.writeObject(null);
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        s.defaultReadObject();
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.itemListenerK) == key)
                addItemListener(((java.awt.event.ItemListener)(s.readObject())));
            else if ((java.awt.Component.actionListenerK) == key)
                addActionListener(((java.awt.event.ActionListener)(s.readObject())));
            else
                s.readObject();
            
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.List.AccessibleAWTList();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTList extends java.awt.Component.AccessibleAWTComponent implements java.awt.event.ActionListener , java.awt.event.ItemListener , javax.accessibility.AccessibleSelection {
        private static final long serialVersionUID = 7924617370136012829L;

        public AccessibleAWTList() {
            super();
            java.awt.List.this.addActionListener(java.awt.List.AccessibleAWTList.this);
            java.awt.List.this.addItemListener(java.awt.List.AccessibleAWTList.this);
        }

        public void actionPerformed(java.awt.event.ActionEvent event) {
        }

        public void itemStateChanged(java.awt.event.ItemEvent event) {
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if (java.awt.List.this.isMultipleMode()) {
                states.add(javax.accessibility.AccessibleState.MULTISELECTABLE);
            } 
            return states;
        }

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.LIST;
        }

        public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
            return null;
        }

        public int getAccessibleChildrenCount() {
            return java.awt.List.this.getItemCount();
        }

        public javax.accessibility.Accessible getAccessibleChild(int i) {
            synchronized(java.awt.List.this) {
                if (i >= (java.awt.List.this.getItemCount())) {
                    return null;
                } else {
                    return new java.awt.List.AccessibleAWTList.AccessibleAWTListChild(java.awt.List.this , i);
                }
            }
        }

        public javax.accessibility.AccessibleSelection getAccessibleSelection() {
            return java.awt.List.AccessibleAWTList.this;
        }

        public int getAccessibleSelectionCount() {
            return java.awt.List.this.getSelectedIndexes().length;
        }

        public javax.accessibility.Accessible getAccessibleSelection(int i) {
            synchronized(java.awt.List.this) {
                int len = getAccessibleSelectionCount();
                if ((i < 0) || (i >= len)) {
                    return null;
                } else {
                    return getAccessibleChild(java.awt.List.this.getSelectedIndexes()[i]);
                }
            }
        }

        public boolean isAccessibleChildSelected(int i) {
            return java.awt.List.this.isIndexSelected(i);
        }

        public void addAccessibleSelection(int i) {
            java.awt.List.this.select(i);
        }

        public void removeAccessibleSelection(int i) {
            java.awt.List.this.deselect(i);
        }

        public void clearAccessibleSelection() {
            synchronized(java.awt.List.this) {
                int[] selectedIndexes = java.awt.List.this.getSelectedIndexes();
                if (selectedIndexes == null)
                    return ;
                
                for (int i = (selectedIndexes.length) - 1 ; i >= 0 ; i--) {
                    java.awt.List.this.deselect(selectedIndexes[i]);
                }
            }
        }

        public void selectAllAccessibleSelection() {
            synchronized(java.awt.List.this) {
                for (int i = (java.awt.List.this.getItemCount()) - 1 ; i >= 0 ; i--) {
                    java.awt.List.this.select(i);
                }
            }
        }

        protected class AccessibleAWTListChild extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.Accessible {
            private static final long serialVersionUID = 4412022926028300317L;

            private java.awt.List parent;

            private int indexInParent;

            public AccessibleAWTListChild(java.awt.List parent ,int indexInParent) {
                java.awt.List.AccessibleAWTList.AccessibleAWTListChild.this.parent = parent;
                java.awt.List.AccessibleAWTList.AccessibleAWTListChild.this.setAccessibleParent(parent);
                java.awt.List.AccessibleAWTList.AccessibleAWTListChild.this.indexInParent = indexInParent;
            }

            public javax.accessibility.AccessibleContext getAccessibleContext() {
                return java.awt.List.AccessibleAWTList.AccessibleAWTListChild.this;
            }

            public javax.accessibility.AccessibleRole getAccessibleRole() {
                return javax.accessibility.AccessibleRole.LIST_ITEM;
            }

            public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
                javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
                if (parent.isIndexSelected(indexInParent)) {
                    states.add(javax.accessibility.AccessibleState.SELECTED);
                } 
                return states;
            }

            public java.util.Locale getLocale() {
                return parent.getLocale();
            }

            public int getAccessibleIndexInParent() {
                return indexInParent;
            }

            public int getAccessibleChildrenCount() {
                return 0;
            }

            public javax.accessibility.Accessible getAccessibleChild(int i) {
                return null;
            }

            public java.awt.Color getBackground() {
                return parent.getBackground();
            }

            public void setBackground(java.awt.Color c) {
                parent.setBackground(c);
            }

            public java.awt.Color getForeground() {
                return parent.getForeground();
            }

            public void setForeground(java.awt.Color c) {
                parent.setForeground(c);
            }

            public java.awt.Cursor getCursor() {
                return parent.getCursor();
            }

            public void setCursor(java.awt.Cursor cursor) {
                parent.setCursor(cursor);
            }

            public java.awt.Font getFont() {
                return parent.getFont();
            }

            public void setFont(java.awt.Font f) {
                parent.setFont(f);
            }

            public java.awt.FontMetrics getFontMetrics(java.awt.Font f) {
                return parent.getFontMetrics(f);
            }

            public boolean isEnabled() {
                return parent.isEnabled();
            }

            public void setEnabled(boolean b) {
                parent.setEnabled(b);
            }

            public boolean isVisible() {
                return false;
            }

            public void setVisible(boolean b) {
                parent.setVisible(b);
            }

            public boolean isShowing() {
                return false;
            }

            public boolean contains(java.awt.Point p) {
                return false;
            }

            public java.awt.Point getLocationOnScreen() {
                return null;
            }

            public java.awt.Point getLocation() {
                return null;
            }

            public void setLocation(java.awt.Point p) {
            }

            public java.awt.Rectangle getBounds() {
                return null;
            }

            public void setBounds(java.awt.Rectangle r) {
            }

            public java.awt.Dimension getSize() {
                return null;
            }

            public void setSize(java.awt.Dimension d) {
            }

            public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
                return null;
            }

            public boolean isFocusTraversable() {
                return false;
            }

            public void requestFocus() {
            }

            public void addFocusListener(java.awt.event.FocusListener l) {
            }

            public void removeFocusListener(java.awt.event.FocusListener l) {
            }
        }
    }
}


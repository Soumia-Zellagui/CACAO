package java.awt;


public class GradientPaint implements java.awt.Paint {
    java.awt.geom.Point2D.Float p1;

    java.awt.geom.Point2D.Float p2;

    java.awt.Color color1;

    java.awt.Color color2;

    boolean cyclic;

    public GradientPaint(float x1 ,float y1 ,java.awt.Color color1 ,float x2 ,float y2 ,java.awt.Color color2) {
        if ((color1 == null) || (color2 == null)) {
            throw new java.lang.NullPointerException("Colors cannot be null");
        } 
        p1 = new java.awt.geom.Point2D.Float(x1 , y1);
        p2 = new java.awt.geom.Point2D.Float(x2 , y2);
        java.awt.GradientPaint.this.color1 = color1;
        java.awt.GradientPaint.this.color2 = color2;
    }

    public GradientPaint(java.awt.geom.Point2D pt1 ,java.awt.Color color1 ,java.awt.geom.Point2D pt2 ,java.awt.Color color2) {
        if ((((color1 == null) || (color2 == null)) || (pt1 == null)) || (pt2 == null)) {
            throw new java.lang.NullPointerException("Colors and points should be non-null");
        } 
        p1 = new java.awt.geom.Point2D.Float(((float)(pt1.getX())) , ((float)(pt1.getY())));
        p2 = new java.awt.geom.Point2D.Float(((float)(pt2.getX())) , ((float)(pt2.getY())));
        java.awt.GradientPaint.this.color1 = color1;
        java.awt.GradientPaint.this.color2 = color2;
    }

    public GradientPaint(float x1 ,float y1 ,java.awt.Color color1 ,float x2 ,float y2 ,java.awt.Color color2 ,boolean cyclic) {
        this(x1, y1, color1, x2, y2, color2);
        java.awt.GradientPaint.this.cyclic = cyclic;
    }

    @java.beans.ConstructorProperties(value = { "point1" , "color1" , "point2" , "color2" , "cyclic" })
    public GradientPaint(java.awt.geom.Point2D pt1 ,java.awt.Color color1 ,java.awt.geom.Point2D pt2 ,java.awt.Color color2 ,boolean cyclic) {
        this(pt1, color1, pt2, color2);
        java.awt.GradientPaint.this.cyclic = cyclic;
    }

    public java.awt.geom.Point2D getPoint1() {
        return new java.awt.geom.Point2D.Float(p1.x , p1.y);
    }

    public java.awt.Color getColor1() {
        return color1;
    }

    public java.awt.geom.Point2D getPoint2() {
        return new java.awt.geom.Point2D.Float(p2.x , p2.y);
    }

    public java.awt.Color getColor2() {
        return color2;
    }

    public boolean isCyclic() {
        return cyclic;
    }

    public java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds, java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform xform, java.awt.RenderingHints hints) {
        return new java.awt.GradientPaintContext(cm , p1 , p2 , xform , color1 , color2 , cyclic);
    }

    public int getTransparency() {
        int a1 = color1.getAlpha();
        int a2 = color2.getAlpha();
        return (a1 & a2) == 255 ? java.awt.Transparency.OPAQUE : java.awt.Transparency.TRANSLUCENT;
    }
}


package java.awt;


class SentEvent extends java.awt.AWTEvent implements java.awt.ActiveEvent {
    private static final long serialVersionUID = -383615247028828931L;

    static final int ID = (java.awt.event.FocusEvent.FOCUS_LAST) + 2;

    boolean dispatched;

    private java.awt.AWTEvent nested;

    private sun.awt.AppContext toNotify;

    SentEvent() {
        this(null);
    }

    SentEvent(java.awt.AWTEvent nested) {
        this(nested, null);
    }

    SentEvent(java.awt.AWTEvent nested ,sun.awt.AppContext toNotify) {
        super((nested != null ? nested.getSource() : java.awt.Toolkit.getDefaultToolkit()), java.awt.SentEvent.ID);
        java.awt.SentEvent.this.nested = nested;
        java.awt.SentEvent.this.toNotify = toNotify;
    }

    public void dispatch() {
        try {
            if ((nested) != null) {
                java.awt.Toolkit.getEventQueue().dispatchEvent(nested);
            } 
        } finally {
            dispatched = true;
            if ((toNotify) != null) {
                sun.awt.SunToolkit.postEvent(toNotify, new java.awt.SentEvent());
            } 
            synchronized(java.awt.SentEvent.this) {
                notifyAll();
            }
        }
    }

    final void dispose() {
        dispatched = true;
        if ((toNotify) != null) {
            sun.awt.SunToolkit.postEvent(toNotify, new java.awt.SentEvent());
        } 
        synchronized(java.awt.SentEvent.this) {
            notifyAll();
        }
    }
}


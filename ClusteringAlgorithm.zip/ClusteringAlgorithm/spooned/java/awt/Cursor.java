package java.awt;


public class Cursor implements java.io.Serializable {
    public static final int DEFAULT_CURSOR = 0;

    public static final int CROSSHAIR_CURSOR = 1;

    public static final int TEXT_CURSOR = 2;

    public static final int WAIT_CURSOR = 3;

    public static final int SW_RESIZE_CURSOR = 4;

    public static final int SE_RESIZE_CURSOR = 5;

    public static final int NW_RESIZE_CURSOR = 6;

    public static final int NE_RESIZE_CURSOR = 7;

    public static final int N_RESIZE_CURSOR = 8;

    public static final int S_RESIZE_CURSOR = 9;

    public static final int W_RESIZE_CURSOR = 10;

    public static final int E_RESIZE_CURSOR = 11;

    public static final int HAND_CURSOR = 12;

    public static final int MOVE_CURSOR = 13;

    @java.lang.Deprecated
    protected static java.awt.Cursor[] predefined = new java.awt.Cursor[14];

    private static final java.awt.Cursor[] predefinedPrivate = new java.awt.Cursor[14];

    static final java.lang.String[][] cursorProperties = new java.lang.String[][]{ new java.lang.String[]{ "AWT.DefaultCursor" , "Default Cursor" } , new java.lang.String[]{ "AWT.CrosshairCursor" , "Crosshair Cursor" } , new java.lang.String[]{ "AWT.TextCursor" , "Text Cursor" } , new java.lang.String[]{ "AWT.WaitCursor" , "Wait Cursor" } , new java.lang.String[]{ "AWT.SWResizeCursor" , "Southwest Resize Cursor" } , new java.lang.String[]{ "AWT.SEResizeCursor" , "Southeast Resize Cursor" } , new java.lang.String[]{ "AWT.NWResizeCursor" , "Northwest Resize Cursor" } , new java.lang.String[]{ "AWT.NEResizeCursor" , "Northeast Resize Cursor" } , new java.lang.String[]{ "AWT.NResizeCursor" , "North Resize Cursor" } , new java.lang.String[]{ "AWT.SResizeCursor" , "South Resize Cursor" } , new java.lang.String[]{ "AWT.WResizeCursor" , "West Resize Cursor" } , new java.lang.String[]{ "AWT.EResizeCursor" , "East Resize Cursor" } , new java.lang.String[]{ "AWT.HandCursor" , "Hand Cursor" } , new java.lang.String[]{ "AWT.MoveCursor" , "Move Cursor" } };

    int type = java.awt.Cursor.DEFAULT_CURSOR;

    public static final int CUSTOM_CURSOR = -1;

    private static final java.util.Hashtable<java.lang.String, java.awt.Cursor> systemCustomCursors = new java.util.Hashtable<>(1);

    private static final java.lang.String systemCustomCursorDirPrefix = java.awt.Cursor.initCursorDir();

    private static java.lang.String initCursorDir() {
        java.lang.String jhome = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("java.home"));
        return ((((((jhome + (java.io.File.separator)) + "lib") + (java.io.File.separator)) + "images") + (java.io.File.separator)) + "cursors") + (java.io.File.separator);
    }

    private static final java.lang.String systemCustomCursorPropertiesFile = (java.awt.Cursor.systemCustomCursorDirPrefix) + "cursors.properties";

    private static java.util.Properties systemCustomCursorProperties = null;

    private static final java.lang.String CursorDotPrefix = "Cursor.";

    private static final java.lang.String DotFileSuffix = ".File";

    private static final java.lang.String DotHotspotSuffix = ".HotSpot";

    private static final java.lang.String DotNameSuffix = ".Name";

    private static final long serialVersionUID = 8028237497568985504L;

    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.Cursor");

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Cursor.initIDs();
        } 
        sun.awt.AWTAccessor.setCursorAccessor(new sun.awt.AWTAccessor.CursorAccessor() {
            public long getPData(java.awt.Cursor cursor) {
                return cursor.pData;
            }

            public void setPData(java.awt.Cursor cursor, long pData) {
                cursor.pData = pData;
            }

            public int getType(java.awt.Cursor cursor) {
                return cursor.type;
            }
        });
    }

    private static native void initIDs();

    private transient long pData;

    private transient java.lang.Object anchor = new java.lang.Object();

    static class CursorDisposer implements sun.java2d.DisposerRecord {
        volatile long pData;

        public CursorDisposer(long pData) {
            java.awt.Cursor.CursorDisposer.this.pData = pData;
        }

        public void dispose() {
            if ((pData) != 0) {
                java.awt.Cursor.finalizeImpl(pData);
            } 
        }
    }

    transient java.awt.Cursor.CursorDisposer disposer;

    private void setPData(long pData) {
        java.awt.Cursor.this.pData = pData;
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            return ;
        } 
        if ((disposer) == null) {
            disposer = new java.awt.Cursor.CursorDisposer(pData);
            if ((anchor) == null) {
                anchor = new java.lang.Object();
            } 
        } else {
            disposer.pData = pData;
        }
    }

    protected java.lang.String name;

    public static java.awt.Cursor getPredefinedCursor(int type) {
        if ((type < (java.awt.Cursor.DEFAULT_CURSOR)) || (type > (java.awt.Cursor.MOVE_CURSOR))) {
            throw new java.lang.IllegalArgumentException("illegal cursor type");
        } 
        java.awt.Cursor c = java.awt.Cursor.predefinedPrivate[type];
        if (c == null) {
            java.awt.Cursor.predefinedPrivate[type] = c = new java.awt.Cursor(type);
        } 
        if ((java.awt.Cursor.predefined[type]) == null) {
            java.awt.Cursor.predefined[type] = c;
        } 
        return c;
    }

    public static java.awt.Cursor getSystemCustomCursor(final java.lang.String name) throws java.awt.AWTException, java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.awt.Cursor cursor = java.awt.Cursor.systemCustomCursors.get(name);
        if (cursor == null) {
            synchronized(java.awt.Cursor.systemCustomCursors) {
                if ((java.awt.Cursor.systemCustomCursorProperties) == null)
                    java.awt.Cursor.loadSystemCustomCursorProperties();
                
            }
            java.lang.String prefix = (java.awt.Cursor.CursorDotPrefix) + name;
            java.lang.String key = prefix + (java.awt.Cursor.DotFileSuffix);
            if (!(java.awt.Cursor.systemCustomCursorProperties.containsKey(key))) {
                if (java.awt.Cursor.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                    java.awt.Cursor.log.finer((("Cursor.getSystemCustomCursor(" + name) + ") returned null"));
                } 
                return null;
            } 
            final java.lang.String fileName = java.awt.Cursor.systemCustomCursorProperties.getProperty(key);
            java.lang.String localized = java.awt.Cursor.systemCustomCursorProperties.getProperty((prefix + (java.awt.Cursor.DotNameSuffix)));
            if (localized == null)
                localized = name;
            
            java.lang.String hotspot = java.awt.Cursor.systemCustomCursorProperties.getProperty((prefix + (java.awt.Cursor.DotHotspotSuffix)));
            if (hotspot == null)
                throw new java.awt.AWTException(("no hotspot property defined for cursor: " + name));
            
            java.util.StringTokenizer st = new java.util.StringTokenizer(hotspot , ",");
            if ((st.countTokens()) != 2)
                throw new java.awt.AWTException(("failed to parse hotspot property for cursor: " + name));
            
            int x = 0;
            int y = 0;
            try {
                x = java.lang.Integer.parseInt(st.nextToken());
                y = java.lang.Integer.parseInt(st.nextToken());
            } catch (java.lang.NumberFormatException nfe) {
                throw new java.awt.AWTException(("failed to parse hotspot property for cursor: " + name));
            }
            try {
                final int fx = x;
                final int fy = y;
                final java.lang.String flocalized = localized;
                cursor = java.security.AccessController.<java.awt.Cursor>doPrivileged(new java.security.PrivilegedExceptionAction<java.awt.Cursor>() {
                    public java.awt.Cursor run() throws java.lang.Exception {
                        java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
                        java.awt.Image image = toolkit.getImage(((java.awt.Cursor.systemCustomCursorDirPrefix) + fileName));
                        return toolkit.createCustomCursor(image, new java.awt.Point(fx , fy), flocalized);
                    }
                });
            } catch (java.lang.Exception e) {
                throw new java.awt.AWTException(((((("Exception: " + (e.getClass())) + " ") + (e.getMessage())) + " occurred while creating cursor ") + name));
            }
            if (cursor == null) {
                if (java.awt.Cursor.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                    java.awt.Cursor.log.finer((("Cursor.getSystemCustomCursor(" + name) + ") returned null"));
                } 
            } else {
                java.awt.Cursor.systemCustomCursors.put(name, cursor);
            }
        } 
        return cursor;
    }

    public static java.awt.Cursor getDefaultCursor() {
        return java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR);
    }

    @java.beans.ConstructorProperties(value = { "type" })
    public Cursor(int type) {
        if ((type < (java.awt.Cursor.DEFAULT_CURSOR)) || (type > (java.awt.Cursor.MOVE_CURSOR))) {
            throw new java.lang.IllegalArgumentException("illegal cursor type");
        } 
        java.awt.Cursor.this.type = type;
        name = java.awt.Toolkit.getProperty(java.awt.Cursor.cursorProperties[type][0], java.awt.Cursor.cursorProperties[type][1]);
    }

    protected Cursor(java.lang.String name) {
        java.awt.Cursor.this.type = java.awt.Cursor.CUSTOM_CURSOR;
        java.awt.Cursor.this.name = name;
    }

    public int getType() {
        return type;
    }

    public java.lang.String getName() {
        return name;
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[") + (getName())) + "]";
    }

    private static void loadSystemCustomCursorProperties() throws java.awt.AWTException {
        synchronized(java.awt.Cursor.systemCustomCursors) {
            java.awt.Cursor.systemCustomCursorProperties = new java.util.Properties();
            try {
                java.security.AccessController.<java.lang.Object>doPrivileged(new java.security.PrivilegedExceptionAction<java.lang.Object>() {
                    public java.lang.Object run() throws java.lang.Exception {
                        java.io.FileInputStream fis = null;
                        try {
                            fis = new java.io.FileInputStream(java.awt.Cursor.systemCustomCursorPropertiesFile);
                            java.awt.Cursor.systemCustomCursorProperties.load(fis);
                        } finally {
                            if (fis != null)
                                fis.close();
                            
                        }
                        return null;
                    }
                });
            } catch (java.lang.Exception e) {
                java.awt.Cursor.systemCustomCursorProperties = null;
                throw new java.awt.AWTException(((((("Exception: " + (e.getClass())) + " ") + (e.getMessage())) + " occurred while loading: ") + (java.awt.Cursor.systemCustomCursorPropertiesFile)));
            }
        }
    }

    private static native void finalizeImpl(long pData);
}


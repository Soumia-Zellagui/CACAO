package java.awt;


interface EventFilter {
    static enum FilterAction {
ACCEPT, REJECT, ACCEPT_IMMEDIATELY;    }

    java.awt.EventFilter.FilterAction acceptEvent(java.awt.AWTEvent ev);
}


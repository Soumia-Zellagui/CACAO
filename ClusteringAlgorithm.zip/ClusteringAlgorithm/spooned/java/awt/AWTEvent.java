package java.awt;


public abstract class AWTEvent extends java.util.EventObject {
    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.AWTEvent");

    private byte[] bdata;

    protected int id;

    protected boolean consumed = false;

    private transient volatile java.security.AccessControlContext acc = java.security.AccessController.getContext();

    final java.security.AccessControlContext getAccessControlContext() {
        if ((acc) == null) {
            throw new java.lang.SecurityException("AWTEvent is missing AccessControlContext");
        } 
        return acc;
    }

    transient boolean focusManagerIsDispatching = false;

    transient boolean isPosted;

    private transient boolean isSystemGenerated;

    public static final long COMPONENT_EVENT_MASK = 1;

    public static final long CONTAINER_EVENT_MASK = 2;

    public static final long FOCUS_EVENT_MASK = 4;

    public static final long KEY_EVENT_MASK = 8;

    public static final long MOUSE_EVENT_MASK = 16;

    public static final long MOUSE_MOTION_EVENT_MASK = 32;

    public static final long WINDOW_EVENT_MASK = 64;

    public static final long ACTION_EVENT_MASK = 128;

    public static final long ADJUSTMENT_EVENT_MASK = 256;

    public static final long ITEM_EVENT_MASK = 512;

    public static final long TEXT_EVENT_MASK = 1024;

    public static final long INPUT_METHOD_EVENT_MASK = 2048;

    static final long INPUT_METHODS_ENABLED_MASK = 4096;

    public static final long PAINT_EVENT_MASK = 8192;

    public static final long INVOCATION_EVENT_MASK = 16384;

    public static final long HIERARCHY_EVENT_MASK = 32768;

    public static final long HIERARCHY_BOUNDS_EVENT_MASK = 65536;

    public static final long MOUSE_WHEEL_EVENT_MASK = 131072;

    public static final long WINDOW_STATE_EVENT_MASK = 262144;

    public static final long WINDOW_FOCUS_EVENT_MASK = 524288;

    public static final int RESERVED_ID_MAX = 1999;

    private static java.lang.reflect.Field inputEvent_CanAccessSystemClipboard_Field = null;

    private static final long serialVersionUID = -1825314779160409405L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.AWTEvent.initIDs();
        } 
        sun.awt.AWTAccessor.setAWTEventAccessor(new sun.awt.AWTAccessor.AWTEventAccessor() {
            public void setPosted(java.awt.AWTEvent ev) {
                ev.isPosted = true;
            }

            public void setSystemGenerated(java.awt.AWTEvent ev) {
                ev.isSystemGenerated = true;
            }

            public boolean isSystemGenerated(java.awt.AWTEvent ev) {
                return ev.isSystemGenerated;
            }

            public java.security.AccessControlContext getAccessControlContext(java.awt.AWTEvent ev) {
                return ev.getAccessControlContext();
            }

            public byte[] getBData(java.awt.AWTEvent ev) {
                return ev.bdata;
            }

            public void setBData(java.awt.AWTEvent ev, byte[] bdata) {
                ev.bdata = bdata;
            }
        });
    }

    private static synchronized java.lang.reflect.Field get_InputEvent_CanAccessSystemClipboard() {
        if ((java.awt.AWTEvent.inputEvent_CanAccessSystemClipboard_Field) == null) {
            java.awt.AWTEvent.inputEvent_CanAccessSystemClipboard_Field = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.lang.reflect.Field>() {
                public java.lang.reflect.Field run() {
                    java.lang.reflect.Field field = null;
                    try {
                        field = java.awt.event.InputEvent.class.getDeclaredField("canAccessSystemClipboard");
                        field.setAccessible(true);
                        return field;
                    } catch (java.lang.SecurityException e) {
                        if (java.awt.AWTEvent.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                            java.awt.AWTEvent.log.fine("AWTEvent.get_InputEvent_CanAccessSystemClipboard() got SecurityException ", e);
                        } 
                    } catch (java.lang.NoSuchFieldException e) {
                        if (java.awt.AWTEvent.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                            java.awt.AWTEvent.log.fine("AWTEvent.get_InputEvent_CanAccessSystemClipboard() got NoSuchFieldException ", e);
                        } 
                    }
                    return null;
                }
            });
        } 
        return java.awt.AWTEvent.inputEvent_CanAccessSystemClipboard_Field;
    }

    private static native void initIDs();

    public AWTEvent(java.awt.Event event) {
        this(event.target, event.id);
    }

    public AWTEvent(java.lang.Object source ,int id) {
        super(source);
        java.awt.AWTEvent.this.id = id;
        switch (id) {
            case java.awt.event.ActionEvent.ACTION_PERFORMED :
            case java.awt.event.ItemEvent.ITEM_STATE_CHANGED :
            case java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED :
            case java.awt.event.TextEvent.TEXT_VALUE_CHANGED :
                consumed = true;
                break;
            default :
        }
    }

    public void setSource(java.lang.Object newSource) {
        if ((source) == newSource) {
            return ;
        } 
        java.awt.Component comp = null;
        if (newSource instanceof java.awt.Component) {
            comp = ((java.awt.Component)(newSource));
            while (((comp != null) && ((comp.peer) != null)) && ((comp.peer) instanceof java.awt.peer.LightweightPeer)) {
                comp = comp.parent;
            }
        } 
        synchronized(java.awt.AWTEvent.this) {
            source = newSource;
            if (comp != null) {
                java.awt.peer.ComponentPeer peer = comp.peer;
                if (peer != null) {
                    nativeSetSource(peer);
                } 
            } 
        }
    }

    private native void nativeSetSource(java.awt.peer.ComponentPeer peer);

    public int getID() {
        return id;
    }

    public java.lang.String toString() {
        java.lang.String srcName = null;
        if ((source) instanceof java.awt.Component) {
            srcName = ((java.awt.Component)(source)).getName();
        } else if ((source) instanceof java.awt.MenuComponent) {
            srcName = ((java.awt.MenuComponent)(source)).getName();
        } 
        return ((((getClass().getName()) + "[") + (paramString())) + "] on ") + (srcName != null ? srcName : source);
    }

    public java.lang.String paramString() {
        return "";
    }

    protected void consume() {
        switch (id) {
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
            case java.awt.event.MouseEvent.MOUSE_PRESSED :
            case java.awt.event.MouseEvent.MOUSE_RELEASED :
            case java.awt.event.MouseEvent.MOUSE_MOVED :
            case java.awt.event.MouseEvent.MOUSE_DRAGGED :
            case java.awt.event.MouseEvent.MOUSE_ENTERED :
            case java.awt.event.MouseEvent.MOUSE_EXITED :
            case java.awt.event.MouseEvent.MOUSE_WHEEL :
            case java.awt.event.InputMethodEvent.INPUT_METHOD_TEXT_CHANGED :
            case java.awt.event.InputMethodEvent.CARET_POSITION_CHANGED :
                consumed = true;
                break;
            default :
        }
    }

    protected boolean isConsumed() {
        return consumed;
    }

    java.awt.Event convertToOld() {
        java.lang.Object src = getSource();
        int newid = id;
        switch (id) {
            case java.awt.event.KeyEvent.KEY_PRESSED :
            case java.awt.event.KeyEvent.KEY_RELEASED :
                java.awt.event.KeyEvent ke = ((java.awt.event.KeyEvent)(java.awt.AWTEvent.this));
                if (ke.isActionKey()) {
                    newid = (id) == (java.awt.event.KeyEvent.KEY_PRESSED) ? java.awt.Event.KEY_ACTION : java.awt.Event.KEY_ACTION_RELEASE;
                } 
                int keyCode = ke.getKeyCode();
                if (((keyCode == (java.awt.event.KeyEvent.VK_SHIFT)) || (keyCode == (java.awt.event.KeyEvent.VK_CONTROL))) || (keyCode == (java.awt.event.KeyEvent.VK_ALT))) {
                    return null;
                } 
                return new java.awt.Event(src , ke.getWhen() , newid , 0 , 0 , java.awt.Event.getOldEventKey(ke) , ((ke.getModifiers()) & (~(java.awt.event.InputEvent.BUTTON1_MASK))));
            case java.awt.event.MouseEvent.MOUSE_PRESSED :
            case java.awt.event.MouseEvent.MOUSE_RELEASED :
            case java.awt.event.MouseEvent.MOUSE_MOVED :
            case java.awt.event.MouseEvent.MOUSE_DRAGGED :
            case java.awt.event.MouseEvent.MOUSE_ENTERED :
            case java.awt.event.MouseEvent.MOUSE_EXITED :
                java.awt.event.MouseEvent me = ((java.awt.event.MouseEvent)(java.awt.AWTEvent.this));
                java.awt.Event olde = new java.awt.Event(src , me.getWhen() , newid , me.getX() , me.getY() , 0 , ((me.getModifiers()) & (~(java.awt.event.InputEvent.BUTTON1_MASK))));
                olde.clickCount = me.getClickCount();
                return olde;
            case java.awt.event.FocusEvent.FOCUS_GAINED :
                return new java.awt.Event(src , java.awt.Event.GOT_FOCUS , null);
            case java.awt.event.FocusEvent.FOCUS_LOST :
                return new java.awt.Event(src , java.awt.Event.LOST_FOCUS , null);
            case java.awt.event.WindowEvent.WINDOW_CLOSING :
            case java.awt.event.WindowEvent.WINDOW_ICONIFIED :
            case java.awt.event.WindowEvent.WINDOW_DEICONIFIED :
                return new java.awt.Event(src , newid , null);
            case java.awt.event.ComponentEvent.COMPONENT_MOVED :
                if ((src instanceof java.awt.Frame) || (src instanceof java.awt.Dialog)) {
                    java.awt.Point p = ((java.awt.Component)(src)).getLocation();
                    return new java.awt.Event(src , 0 , java.awt.Event.WINDOW_MOVED , p.x , p.y , 0 , 0);
                } 
                break;
            case java.awt.event.ActionEvent.ACTION_PERFORMED :
                java.awt.event.ActionEvent ae = ((java.awt.event.ActionEvent)(java.awt.AWTEvent.this));
                java.lang.String cmd;
                if (src instanceof java.awt.Button) {
                    cmd = ((java.awt.Button)(src)).getLabel();
                } else if (src instanceof java.awt.MenuItem) {
                    cmd = ((java.awt.MenuItem)(src)).getLabel();
                } else {
                    cmd = ae.getActionCommand();
                }
                return new java.awt.Event(src , 0 , newid , 0 , 0 , 0 , ae.getModifiers() , cmd);
            case java.awt.event.ItemEvent.ITEM_STATE_CHANGED :
                java.awt.event.ItemEvent ie = ((java.awt.event.ItemEvent)(java.awt.AWTEvent.this));
                java.lang.Object arg;
                if (src instanceof java.awt.List) {
                    newid = (ie.getStateChange()) == (java.awt.event.ItemEvent.SELECTED) ? java.awt.Event.LIST_SELECT : java.awt.Event.LIST_DESELECT;
                    arg = ie.getItem();
                } else {
                    newid = java.awt.Event.ACTION_EVENT;
                    if (src instanceof java.awt.Choice) {
                        arg = ie.getItem();
                    } else {
                        arg = java.lang.Boolean.valueOf(((ie.getStateChange()) == (java.awt.event.ItemEvent.SELECTED)));
                    }
                }
                return new java.awt.Event(src , newid , arg);
            case java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED :
                java.awt.event.AdjustmentEvent aje = ((java.awt.event.AdjustmentEvent)(java.awt.AWTEvent.this));
                switch (aje.getAdjustmentType()) {
                    case java.awt.event.AdjustmentEvent.UNIT_INCREMENT :
                        newid = java.awt.Event.SCROLL_LINE_DOWN;
                        break;
                    case java.awt.event.AdjustmentEvent.UNIT_DECREMENT :
                        newid = java.awt.Event.SCROLL_LINE_UP;
                        break;
                    case java.awt.event.AdjustmentEvent.BLOCK_INCREMENT :
                        newid = java.awt.Event.SCROLL_PAGE_DOWN;
                        break;
                    case java.awt.event.AdjustmentEvent.BLOCK_DECREMENT :
                        newid = java.awt.Event.SCROLL_PAGE_UP;
                        break;
                    case java.awt.event.AdjustmentEvent.TRACK :
                        if (aje.getValueIsAdjusting()) {
                            newid = java.awt.Event.SCROLL_ABSOLUTE;
                        } else {
                            newid = java.awt.Event.SCROLL_END;
                        }
                        break;
                    default :
                        return null;
                }
                return new java.awt.Event(src , newid , java.lang.Integer.valueOf(aje.getValue()));
            default :
        }
        return null;
    }

    void copyPrivateDataInto(java.awt.AWTEvent that) {
        that.bdata = java.awt.AWTEvent.this.bdata;
        if (((java.awt.AWTEvent.this) instanceof java.awt.event.InputEvent) && (that instanceof java.awt.event.InputEvent)) {
            java.lang.reflect.Field field = java.awt.AWTEvent.get_InputEvent_CanAccessSystemClipboard();
            if (field != null) {
                try {
                    boolean b = field.getBoolean(java.awt.AWTEvent.this);
                    field.setBoolean(that, b);
                } catch (java.lang.IllegalAccessException e) {
                    if (java.awt.AWTEvent.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.AWTEvent.log.fine("AWTEvent.copyPrivateDataInto() got IllegalAccessException ", e);
                    } 
                }
            } 
        } 
        that.isSystemGenerated = java.awt.AWTEvent.this.isSystemGenerated;
    }

    void dispatched() {
        if ((java.awt.AWTEvent.this) instanceof java.awt.event.InputEvent) {
            java.lang.reflect.Field field = java.awt.AWTEvent.get_InputEvent_CanAccessSystemClipboard();
            if (field != null) {
                try {
                    field.setBoolean(java.awt.AWTEvent.this, false);
                } catch (java.lang.IllegalAccessException e) {
                    if (java.awt.AWTEvent.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINE)) {
                        java.awt.AWTEvent.log.fine("AWTEvent.dispatched() got IllegalAccessException ", e);
                    } 
                }
            } 
        } 
    }
}


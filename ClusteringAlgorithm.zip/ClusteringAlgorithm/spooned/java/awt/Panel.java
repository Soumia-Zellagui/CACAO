package java.awt;


public class Panel extends java.awt.Container implements javax.accessibility.Accessible {
    private static final java.lang.String base = "panel";

    private static int nameCounter = 0;

    private static final long serialVersionUID = -2728009084054400034L;

    public Panel() {
        this(new java.awt.FlowLayout());
    }

    public Panel(java.awt.LayoutManager layout) {
        setLayout(layout);
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Panel.class) {
            return (java.awt.Panel.base) + ((java.awt.Panel.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if ((peer) == null)
                peer = getToolkit().createPanel(java.awt.Panel.this);
            
            super.addNotify();
        }
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Panel.AccessibleAWTPanel();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTPanel extends java.awt.Container.AccessibleAWTContainer {
        private static final long serialVersionUID = -6409552226660031050L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.PANEL;
        }
    }
}


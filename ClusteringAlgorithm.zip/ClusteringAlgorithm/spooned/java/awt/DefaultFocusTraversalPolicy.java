package java.awt;


public class DefaultFocusTraversalPolicy extends java.awt.ContainerOrderFocusTraversalPolicy {
    private static final long serialVersionUID = 8876966522510157497L;

    protected boolean accept(java.awt.Component aComponent) {
        if (!(((aComponent.isVisible()) && (aComponent.isDisplayable())) && (aComponent.isEnabled()))) {
            return false;
        } 
        if (!(aComponent instanceof java.awt.Window)) {
            for (java.awt.Container enableTest = aComponent.getParent() ; enableTest != null ; enableTest = enableTest.getParent()) {
                if (!((enableTest.isEnabled()) || (enableTest.isLightweight()))) {
                    return false;
                } 
                if (enableTest instanceof java.awt.Window) {
                    break;
                } 
            }
        } 
        boolean focusable = aComponent.isFocusable();
        if (aComponent.isFocusTraversableOverridden()) {
            return focusable;
        } 
        java.awt.peer.ComponentPeer peer = aComponent.getPeer();
        return (peer != null) && (peer.isFocusable());
    }
}


package java.awt;


public class Dialog extends java.awt.Window {
    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Dialog.initIDs();
        } 
    }

    boolean resizable = true;

    boolean undecorated = false;

    private transient boolean initialized = false;

    public static enum ModalityType {
MODELESS, DOCUMENT_MODAL, APPLICATION_MODAL, TOOLKIT_MODAL;    }

    public static final java.awt.Dialog.ModalityType DEFAULT_MODALITY_TYPE = java.awt.Dialog.ModalityType.APPLICATION_MODAL;

    boolean modal;

    java.awt.Dialog.ModalityType modalityType;

    public static enum ModalExclusionType {
NO_EXCLUDE, APPLICATION_EXCLUDE, TOOLKIT_EXCLUDE;    }

    static transient sun.awt.util.IdentityArrayList<java.awt.Dialog> modalDialogs = new sun.awt.util.IdentityArrayList<java.awt.Dialog>();

    transient sun.awt.util.IdentityArrayList<java.awt.Window> blockedWindows = new sun.awt.util.IdentityArrayList<java.awt.Window>();

    java.lang.String title;

    private transient java.awt.ModalEventFilter modalFilter;

    private transient volatile java.awt.SecondaryLoop secondaryLoop;

    transient volatile boolean isInHide = false;

    transient volatile boolean isInDispose = false;

    private static final java.lang.String base = "dialog";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 5920926903803293709L;

    public Dialog(java.awt.Frame owner) {
        this(owner, "", false);
    }

    public Dialog(java.awt.Frame owner ,boolean modal) {
        this(owner, "", modal);
    }

    public Dialog(java.awt.Frame owner ,java.lang.String title) {
        this(owner, title, false);
    }

    public Dialog(java.awt.Frame owner ,java.lang.String title ,boolean modal) {
        this(owner, title, (modal ? java.awt.Dialog.DEFAULT_MODALITY_TYPE : java.awt.Dialog.ModalityType.MODELESS));
    }

    public Dialog(java.awt.Frame owner ,java.lang.String title ,boolean modal ,java.awt.GraphicsConfiguration gc) {
        this(owner, title, (modal ? java.awt.Dialog.DEFAULT_MODALITY_TYPE : java.awt.Dialog.ModalityType.MODELESS), gc);
    }

    public Dialog(java.awt.Dialog owner) {
        this(owner, "", false);
    }

    public Dialog(java.awt.Dialog owner ,java.lang.String title) {
        this(owner, title, false);
    }

    public Dialog(java.awt.Dialog owner ,java.lang.String title ,boolean modal) {
        this(owner, title, (modal ? java.awt.Dialog.DEFAULT_MODALITY_TYPE : java.awt.Dialog.ModalityType.MODELESS));
    }

    public Dialog(java.awt.Dialog owner ,java.lang.String title ,boolean modal ,java.awt.GraphicsConfiguration gc) {
        this(owner, title, (modal ? java.awt.Dialog.DEFAULT_MODALITY_TYPE : java.awt.Dialog.ModalityType.MODELESS), gc);
    }

    public Dialog(java.awt.Window owner) {
        this(owner, "", java.awt.Dialog.ModalityType.MODELESS);
    }

    public Dialog(java.awt.Window owner ,java.lang.String title) {
        this(owner, title, java.awt.Dialog.ModalityType.MODELESS);
    }

    public Dialog(java.awt.Window owner ,java.awt.Dialog.ModalityType modalityType) {
        this(owner, "", modalityType);
    }

    public Dialog(java.awt.Window owner ,java.lang.String title ,java.awt.Dialog.ModalityType modalityType) {
        super(owner);
        if (((owner != null) && (!(owner instanceof java.awt.Frame))) && (!(owner instanceof java.awt.Dialog))) {
            throw new java.lang.IllegalArgumentException("Wrong parent window");
        } 
        java.awt.Dialog.this.title = title;
        setModalityType(modalityType);
        initialized = true;
    }

    public Dialog(java.awt.Window owner ,java.lang.String title ,java.awt.Dialog.ModalityType modalityType ,java.awt.GraphicsConfiguration gc) {
        super(owner, gc);
        if (((owner != null) && (!(owner instanceof java.awt.Frame))) && (!(owner instanceof java.awt.Dialog))) {
            throw new java.lang.IllegalArgumentException("wrong owner window");
        } 
        java.awt.Dialog.this.title = title;
        setModalityType(modalityType);
        initialized = true;
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Dialog.class) {
            return (java.awt.Dialog.base) + ((java.awt.Dialog.nameCounter)++);
        }
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            if (((parent) != null) && ((parent.getPeer()) == null)) {
                parent.addNotify();
            } 
            if ((peer) == null) {
                peer = getToolkit().createDialog(java.awt.Dialog.this);
            } 
            super.addNotify();
        }
    }

    public boolean isModal() {
        return isModal_NoClientCode();
    }

    final boolean isModal_NoClientCode() {
        return (modalityType) != (java.awt.Dialog.ModalityType.MODELESS);
    }

    public void setModal(boolean modal) {
        java.awt.Dialog.this.modal = modal;
        setModalityType((modal ? java.awt.Dialog.DEFAULT_MODALITY_TYPE : java.awt.Dialog.ModalityType.MODELESS));
    }

    public java.awt.Dialog.ModalityType getModalityType() {
        return modalityType;
    }

    public void setModalityType(java.awt.Dialog.ModalityType type) {
        if (type == null) {
            type = java.awt.Dialog.ModalityType.MODELESS;
        } 
        if (!(java.awt.Toolkit.getDefaultToolkit().isModalityTypeSupported(type))) {
            type = java.awt.Dialog.ModalityType.MODELESS;
        } 
        if ((modalityType) == type) {
            return ;
        } 
        checkModalityPermission(type);
        modalityType = type;
        modal = (modalityType) != (java.awt.Dialog.ModalityType.MODELESS);
    }

    public java.lang.String getTitle() {
        return title;
    }

    public void setTitle(java.lang.String title) {
        java.lang.String oldTitle = java.awt.Dialog.this.title;
        synchronized(java.awt.Dialog.this) {
            java.awt.Dialog.this.title = title;
            java.awt.peer.DialogPeer peer = ((java.awt.peer.DialogPeer)(java.awt.Dialog.this.peer));
            if (peer != null) {
                peer.setTitle(title);
            } 
        }
        firePropertyChange("title", oldTitle, title);
    }

    private boolean conditionalShow(java.awt.Component toFocus, java.util.concurrent.atomic.AtomicLong time) {
        boolean retval;
        closeSplashScreen();
        synchronized(getTreeLock()) {
            if ((peer) == null) {
                addNotify();
            } 
            validateUnconditionally();
            if (visible) {
                toFront();
                retval = false;
            } else {
                visible = retval = true;
                if (!(isModal())) {
                    java.awt.Dialog.checkShouldBeBlocked(java.awt.Dialog.this);
                } else {
                    java.awt.Dialog.modalDialogs.add(java.awt.Dialog.this);
                    modalShow();
                }
                if (((((toFocus != null) && (time != null)) && (isFocusable())) && (isEnabled())) && (!(isModalBlocked()))) {
                    time.set(java.awt.Toolkit.getEventQueue().getMostRecentKeyEventTime());
                    java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().enqueueKeyEvents(time.get(), toFocus);
                } 
                mixOnShowing();
                peer.setVisible(true);
                if (isModalBlocked()) {
                    modalBlocker.toFront();
                } 
                setLocationByPlatform(false);
                for (int i = 0 ; i < (ownedWindowList.size()) ; i++) {
                    java.awt.Window child = ownedWindowList.elementAt(i).get();
                    if ((child != null) && (child.showWithParent)) {
                        child.show();
                        child.showWithParent = false;
                    } 
                }
                java.awt.Window.updateChildFocusableWindowState(java.awt.Dialog.this);
                createHierarchyEvents(java.awt.event.HierarchyEvent.HIERARCHY_CHANGED, java.awt.Dialog.this, parent, java.awt.event.HierarchyEvent.SHOWING_CHANGED, java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.HIERARCHY_EVENT_MASK));
                if ((((componentListener) != null) || (((eventMask) & (java.awt.AWTEvent.COMPONENT_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.COMPONENT_EVENT_MASK))) {
                    java.awt.event.ComponentEvent e = new java.awt.event.ComponentEvent(java.awt.Dialog.this , java.awt.event.ComponentEvent.COMPONENT_SHOWN);
                    java.awt.Toolkit.getEventQueue().postEvent(e);
                } 
            }
        }
        if (retval && (((state) & (java.awt.Window.OPENED)) == 0)) {
            postWindowEvent(java.awt.event.WindowEvent.WINDOW_OPENED);
            state |= java.awt.Window.OPENED;
        } 
        return retval;
    }

    public void setVisible(boolean b) {
        super.setVisible(b);
    }

    @java.lang.Deprecated
    public void show() {
        if (!(initialized)) {
            throw new java.lang.IllegalStateException(("The dialog component " + "has not been initialized properly"));
        } 
        beforeFirstShow = false;
        if (!(isModal())) {
            conditionalShow(null, null);
        } else {
            sun.awt.AppContext showAppContext = sun.awt.AppContext.getAppContext();
            java.util.concurrent.atomic.AtomicLong time = new java.util.concurrent.atomic.AtomicLong();
            java.awt.Component predictedFocusOwner = null;
            try {
                predictedFocusOwner = getMostRecentFocusOwner();
                if (conditionalShow(predictedFocusOwner, time)) {
                    modalFilter = java.awt.ModalEventFilter.createFilterForDialog(java.awt.Dialog.this);
                    final java.awt.Conditional cond = new java.awt.Conditional() {
                        @java.lang.Override
                        public boolean evaluate() {
                            return (windowClosingException) == null;
                        }
                    };
                    if ((modalityType) == (java.awt.Dialog.ModalityType.TOOLKIT_MODAL)) {
                        java.util.Iterator<sun.awt.AppContext> it = sun.awt.AppContext.getAppContexts().iterator();
                        while (it.hasNext()) {
                            sun.awt.AppContext appContext = it.next();
                            if (appContext == showAppContext) {
                                continue;
                            } 
                            java.awt.EventQueue eventQueue = ((java.awt.EventQueue)(appContext.get(sun.awt.AppContext.EVENT_QUEUE_KEY)));
                            java.lang.Runnable createEDT = new java.lang.Runnable() {
                                public void run() {
                                }
                            };
                            eventQueue.postEvent(new java.awt.event.InvocationEvent(java.awt.Dialog.this , createEDT));
                            java.awt.EventDispatchThread edt = eventQueue.getDispatchThread();
                            edt.addEventFilter(modalFilter);
                        }
                    } 
                    modalityPushed();
                    try {
                        final java.awt.EventQueue eventQueue = java.security.AccessController.doPrivileged(new java.security.PrivilegedAction<java.awt.EventQueue>() {
                            public java.awt.EventQueue run() {
                                return java.awt.Toolkit.getDefaultToolkit().getSystemEventQueue();
                            }
                        });
                        secondaryLoop = eventQueue.createSecondaryLoop(cond, modalFilter, 0);
                        if (!(secondaryLoop.enter())) {
                            secondaryLoop = null;
                        } 
                    } finally {
                        modalityPopped();
                    }
                    if ((modalityType) == (java.awt.Dialog.ModalityType.TOOLKIT_MODAL)) {
                        java.util.Iterator<sun.awt.AppContext> it = sun.awt.AppContext.getAppContexts().iterator();
                        while (it.hasNext()) {
                            sun.awt.AppContext appContext = it.next();
                            if (appContext == showAppContext) {
                                continue;
                            } 
                            java.awt.EventQueue eventQueue = ((java.awt.EventQueue)(appContext.get(sun.awt.AppContext.EVENT_QUEUE_KEY)));
                            java.awt.EventDispatchThread edt = eventQueue.getDispatchThread();
                            edt.removeEventFilter(modalFilter);
                        }
                    } 
                    if ((windowClosingException) != null) {
                        windowClosingException.fillInStackTrace();
                        throw windowClosingException;
                    } 
                } 
            } finally {
                if (predictedFocusOwner != null) {
                    java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().dequeueKeyEvents(time.get(), predictedFocusOwner);
                } 
            }
        }
    }

    final void modalityPushed() {
        java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
        if (tk instanceof sun.awt.SunToolkit) {
            sun.awt.SunToolkit stk = ((sun.awt.SunToolkit)(tk));
        } 
    }

    final void modalityPopped() {
        java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
        if (tk instanceof sun.awt.SunToolkit) {
            sun.awt.SunToolkit stk = ((sun.awt.SunToolkit)(tk));
        } 
    }

    void interruptBlocking() {
        if (isModal()) {
            disposeImpl();
        } else if ((windowClosingException) != null) {
            windowClosingException.fillInStackTrace();
            windowClosingException.printStackTrace();
            windowClosingException = null;
        } 
    }

    private void hideAndDisposePreHandler() {
        isInHide = true;
        synchronized(getTreeLock()) {
            if ((secondaryLoop) != null) {
                modalHide();
                if ((modalFilter) != null) {
                    modalFilter.disable();
                } 
                java.awt.Dialog.modalDialogs.remove(java.awt.Dialog.this);
            } 
        }
    }

    private void hideAndDisposeHandler() {
        if ((secondaryLoop) != null) {
            secondaryLoop.exit();
            secondaryLoop = null;
        } 
        isInHide = false;
    }

    @java.lang.Deprecated
    public void hide() {
        hideAndDisposePreHandler();
        super.hide();
        if (!(isInDispose)) {
            hideAndDisposeHandler();
        } 
    }

    void doDispose() {
        isInDispose = true;
        super.doDispose();
        hideAndDisposeHandler();
        isInDispose = false;
    }

    public void toBack() {
        super.toBack();
        if (visible) {
            synchronized(getTreeLock()) {
                for (java.awt.Window w : blockedWindows) {
                    w.toBack_NoClientCode();
                }
            }
        } 
    }

    public boolean isResizable() {
        return resizable;
    }

    public void setResizable(boolean resizable) {
        boolean testvalid = false;
        synchronized(java.awt.Dialog.this) {
            java.awt.Dialog.this.resizable = resizable;
            java.awt.peer.DialogPeer peer = ((java.awt.peer.DialogPeer)(java.awt.Dialog.this.peer));
            if (peer != null) {
                peer.setResizable(resizable);
                testvalid = true;
            } 
        }
        if (testvalid) {
            invalidateIfValid();
        } 
    }

    public void setUndecorated(boolean undecorated) {
        synchronized(getTreeLock()) {
            if (isDisplayable()) {
                throw new java.awt.IllegalComponentStateException("The dialog is displayable.");
            } 
            if (!undecorated) {
                if ((getOpacity()) < 1.0F) {
                    throw new java.awt.IllegalComponentStateException("The dialog is not opaque");
                } 
                if ((getShape()) != null) {
                    throw new java.awt.IllegalComponentStateException("The dialog does not have a default shape");
                } 
                java.awt.Color bg = getBackground();
                if ((bg != null) && ((bg.getAlpha()) < 255)) {
                    throw new java.awt.IllegalComponentStateException("The dialog background color is not opaque");
                } 
            } 
            java.awt.Dialog.this.undecorated = undecorated;
        }
    }

    public boolean isUndecorated() {
        return undecorated;
    }

    @java.lang.Override
    public void setOpacity(float opacity) {
        synchronized(getTreeLock()) {
            if ((opacity < 1.0F) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The dialog is decorated");
            } 
            super.setOpacity(opacity);
        }
    }

    @java.lang.Override
    public void setShape(java.awt.Shape shape) {
        synchronized(getTreeLock()) {
            if ((shape != null) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The dialog is decorated");
            } 
            super.setShape(shape);
        }
    }

    @java.lang.Override
    public void setBackground(java.awt.Color bgColor) {
        synchronized(getTreeLock()) {
            if (((bgColor != null) && ((bgColor.getAlpha()) < 255)) && (!(isUndecorated()))) {
                throw new java.awt.IllegalComponentStateException("The dialog is decorated");
            } 
            super.setBackground(bgColor);
        }
    }

    protected java.lang.String paramString() {
        java.lang.String str = ((super.paramString()) + ",") + (modalityType);
        if ((title) != null) {
            str += ",title=" + (title);
        } 
        return str;
    }

    private static native void initIDs();

    void modalShow() {
        sun.awt.util.IdentityArrayList<java.awt.Dialog> blockers = new sun.awt.util.IdentityArrayList<java.awt.Dialog>();
        for (java.awt.Dialog d : java.awt.Dialog.modalDialogs) {
            if (d.shouldBlock(java.awt.Dialog.this)) {
                java.awt.Window w = d;
                while ((w != null) && (w != (java.awt.Dialog.this))) {
                    w = w.getOwner_NoClientCode();
                }
                if (((w == (java.awt.Dialog.this)) || (!(shouldBlock(d)))) || ((modalityType.compareTo(d.getModalityType())) < 0)) {
                    blockers.add(d);
                } 
            } 
        }
        for (int i = 0 ; i < (blockers.size()) ; i++) {
            java.awt.Dialog blocker = blockers.get(i);
            if (blocker.isModalBlocked()) {
                java.awt.Dialog blockerBlocker = blocker.getModalBlocker();
                if (!(blockers.contains(blockerBlocker))) {
                    blockers.add((i + 1), blockerBlocker);
                } 
            } 
        }
        if ((blockers.size()) > 0) {
            blockers.get(0).blockWindow(java.awt.Dialog.this);
        } 
        sun.awt.util.IdentityArrayList<java.awt.Window> blockersHierarchies = new sun.awt.util.IdentityArrayList<java.awt.Window>(blockers);
        int k = 0;
        while (k < (blockersHierarchies.size())) {
            java.awt.Window w = blockersHierarchies.get(k);
            java.awt.Window[] ownedWindows = w.getOwnedWindows_NoClientCode();
            for (java.awt.Window win : ownedWindows) {
                blockersHierarchies.add(win);
            }
            k++;
        }
        java.util.List<java.awt.Window> toBlock = new sun.awt.util.IdentityLinkedList<java.awt.Window>();
        sun.awt.util.IdentityArrayList<java.awt.Window> unblockedWindows = java.awt.Window.getAllUnblockedWindows();
        for (java.awt.Window w : unblockedWindows) {
            if ((shouldBlock(w)) && (!(blockersHierarchies.contains(w)))) {
                if ((w instanceof java.awt.Dialog) && (((java.awt.Dialog)(w)).isModal_NoClientCode())) {
                    java.awt.Dialog wd = ((java.awt.Dialog)(w));
                    if ((wd.shouldBlock(java.awt.Dialog.this)) && ((java.awt.Dialog.modalDialogs.indexOf(wd)) > (java.awt.Dialog.modalDialogs.indexOf(java.awt.Dialog.this)))) {
                        continue;
                    } 
                } 
                toBlock.add(w);
            } 
        }
        blockWindows(toBlock);
        if (!(isModalBlocked())) {
            updateChildrenBlocking();
        } 
    }

    void modalHide() {
        sun.awt.util.IdentityArrayList<java.awt.Window> save = new sun.awt.util.IdentityArrayList<java.awt.Window>();
        int blockedWindowsCount = blockedWindows.size();
        for (int i = 0 ; i < blockedWindowsCount ; i++) {
            java.awt.Window w = blockedWindows.get(0);
            save.add(w);
            unblockWindow(w);
        }
        for (int i = 0 ; i < blockedWindowsCount ; i++) {
            java.awt.Window w = save.get(i);
            if ((w instanceof java.awt.Dialog) && (((java.awt.Dialog)(w)).isModal_NoClientCode())) {
                java.awt.Dialog d = ((java.awt.Dialog)(w));
                d.modalShow();
            } else {
                java.awt.Dialog.checkShouldBeBlocked(w);
            }
        }
    }

    boolean shouldBlock(java.awt.Window w) {
        if (((((!(isVisible_NoClientCode())) || ((!(w.isVisible_NoClientCode())) && (!(w.isInShow)))) || (isInHide)) || (w == (java.awt.Dialog.this))) || (!(isModal_NoClientCode()))) {
            return false;
        } 
        if ((w instanceof java.awt.Dialog) && (((java.awt.Dialog)(w)).isInHide)) {
            return false;
        } 
        java.awt.Window blockerToCheck = java.awt.Dialog.this;
        while (blockerToCheck != null) {
            java.awt.Component c = w;
            while ((c != null) && (c != blockerToCheck)) {
                c = c.getParent_NoClientCode();
            }
            if (c == blockerToCheck) {
                return false;
            } 
            blockerToCheck = blockerToCheck.getModalBlocker();
        }
        switch (modalityType) {
            case MODELESS :
                return false;
            case DOCUMENT_MODAL :
                if (w.isModalExcluded(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE)) {
                    java.awt.Component c = java.awt.Dialog.this;
                    while ((c != null) && (c != w)) {
                        c = c.getParent_NoClientCode();
                    }
                    return c == w;
                } else {
                    return (getDocumentRoot()) == (w.getDocumentRoot());
                }
            case APPLICATION_MODAL :
                return (!(w.isModalExcluded(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE))) && ((appContext) == (w.appContext));
            case TOOLKIT_MODAL :
                return !(w.isModalExcluded(java.awt.Dialog.ModalExclusionType.TOOLKIT_EXCLUDE));
        }
        return false;
    }

    void blockWindow(java.awt.Window w) {
        if (!(w.isModalBlocked())) {
            w.setModalBlocked(java.awt.Dialog.this, true, true);
            blockedWindows.add(w);
        } 
    }

    void blockWindows(java.util.List<java.awt.Window> toBlock) {
        java.awt.peer.DialogPeer dpeer = ((java.awt.peer.DialogPeer)(peer));
        if (dpeer == null) {
            return ;
        } 
        java.util.Iterator<java.awt.Window> it = toBlock.iterator();
        while (it.hasNext()) {
            java.awt.Window w = it.next();
            if (!(w.isModalBlocked())) {
                w.setModalBlocked(java.awt.Dialog.this, true, false);
            } else {
                it.remove();
            }
        }
        dpeer.blockWindows(toBlock);
        blockedWindows.addAll(toBlock);
    }

    void unblockWindow(java.awt.Window w) {
        if ((w.isModalBlocked()) && (blockedWindows.contains(w))) {
            blockedWindows.remove(w);
            w.setModalBlocked(java.awt.Dialog.this, false, true);
        } 
    }

    static void checkShouldBeBlocked(java.awt.Window w) {
        synchronized(w.getTreeLock()) {
            for (int i = 0 ; i < (java.awt.Dialog.modalDialogs.size()) ; i++) {
                java.awt.Dialog modalDialog = java.awt.Dialog.modalDialogs.get(i);
                if (modalDialog.shouldBlock(w)) {
                    modalDialog.blockWindow(w);
                    break;
                } 
            }
        }
    }

    private void checkModalityPermission(java.awt.Dialog.ModalityType mt) {
        if (mt == (java.awt.Dialog.ModalityType.TOOLKIT_MODAL)) {
            java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
            if (sm != null) {
                sm.checkPermission(sun.security.util.SecurityConstants.AWT.TOOLKIT_MODALITY_PERMISSION);
            } 
        } 
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        java.io.ObjectInputStream.GetField fields = s.readFields();
        java.awt.Dialog.ModalityType localModalityType = ((java.awt.Dialog.ModalityType)(fields.get("modalityType", null)));
        try {
            checkModalityPermission(localModalityType);
        } catch (java.security.AccessControlException ace) {
            localModalityType = java.awt.Dialog.DEFAULT_MODALITY_TYPE;
        }
        if (localModalityType == null) {
            java.awt.Dialog.this.modal = fields.get("modal", false);
            setModal(modal);
        } else {
            java.awt.Dialog.this.modalityType = localModalityType;
        }
        java.awt.Dialog.this.resizable = fields.get("resizable", true);
        java.awt.Dialog.this.undecorated = fields.get("undecorated", false);
        java.awt.Dialog.this.title = ((java.lang.String)(fields.get("title", "")));
        blockedWindows = new sun.awt.util.IdentityArrayList<>();
        initialized = true;
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Dialog.AccessibleAWTDialog();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTDialog extends java.awt.Window.AccessibleAWTWindow {
        private static final long serialVersionUID = 4837230331833941201L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.DIALOG;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if ((getFocusOwner()) != null) {
                states.add(javax.accessibility.AccessibleState.ACTIVE);
            } 
            if (isModal()) {
                states.add(javax.accessibility.AccessibleState.MODAL);
            } 
            if (isResizable()) {
                states.add(javax.accessibility.AccessibleState.RESIZABLE);
            } 
            return states;
        }
    }
}


package java.awt;


public class ScrollPaneAdjustable implements java.awt.Adjustable , java.io.Serializable {
    private java.awt.ScrollPane sp;

    private int orientation;

    private int value;

    private int minimum;

    private int maximum;

    private int visibleAmount;

    private transient boolean isAdjusting;

    private int unitIncrement = 1;

    private int blockIncrement = 1;

    private java.awt.event.AdjustmentListener adjustmentListener;

    private static final java.lang.String SCROLLPANE_ONLY = "Can be set by scrollpane only";

    private static native void initIDs();

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.ScrollPaneAdjustable.initIDs();
        } 
        sun.awt.AWTAccessor.setScrollPaneAdjustableAccessor(new sun.awt.AWTAccessor.ScrollPaneAdjustableAccessor() {
            public void setTypedValue(final java.awt.ScrollPaneAdjustable adj, final int v, final int type) {
                adj.setTypedValue(v, type);
            }
        });
    }

    private static final long serialVersionUID = -3359745691033257079L;

    ScrollPaneAdjustable(java.awt.ScrollPane sp ,java.awt.event.AdjustmentListener l ,int orientation) {
        java.awt.ScrollPaneAdjustable.this.sp = sp;
        java.awt.ScrollPaneAdjustable.this.orientation = orientation;
        addAdjustmentListener(l);
    }

    void setSpan(int min, int max, int visible) {
        minimum = min;
        maximum = java.lang.Math.max(max, ((minimum) + 1));
        visibleAmount = java.lang.Math.min(visible, ((maximum) - (minimum)));
        visibleAmount = java.lang.Math.max(visibleAmount, 1);
        blockIncrement = java.lang.Math.max(((int)(visible * 0.9)), 1);
        setValue(value);
    }

    public int getOrientation() {
        return orientation;
    }

    public void setMinimum(int min) {
        throw new java.awt.AWTError(java.awt.ScrollPaneAdjustable.SCROLLPANE_ONLY);
    }

    public int getMinimum() {
        return 0;
    }

    public void setMaximum(int max) {
        throw new java.awt.AWTError(java.awt.ScrollPaneAdjustable.SCROLLPANE_ONLY);
    }

    public int getMaximum() {
        return maximum;
    }

    public synchronized void setUnitIncrement(int u) {
        if (u != (unitIncrement)) {
            unitIncrement = u;
            if ((sp.peer) != null) {
                java.awt.peer.ScrollPanePeer peer = ((java.awt.peer.ScrollPanePeer)(sp.peer));
                peer.setUnitIncrement(java.awt.ScrollPaneAdjustable.this, u);
            } 
        } 
    }

    public int getUnitIncrement() {
        return unitIncrement;
    }

    public synchronized void setBlockIncrement(int b) {
        blockIncrement = b;
    }

    public int getBlockIncrement() {
        return blockIncrement;
    }

    public void setVisibleAmount(int v) {
        throw new java.awt.AWTError(java.awt.ScrollPaneAdjustable.SCROLLPANE_ONLY);
    }

    public int getVisibleAmount() {
        return visibleAmount;
    }

    public void setValueIsAdjusting(boolean b) {
        if ((isAdjusting) != b) {
            isAdjusting = b;
            java.awt.event.AdjustmentEvent e = new java.awt.event.AdjustmentEvent(java.awt.ScrollPaneAdjustable.this , java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED , java.awt.event.AdjustmentEvent.TRACK , value , b);
            adjustmentListener.adjustmentValueChanged(e);
        } 
    }

    public boolean getValueIsAdjusting() {
        return isAdjusting;
    }

    public void setValue(int v) {
        setTypedValue(v, java.awt.event.AdjustmentEvent.TRACK);
    }

    private void setTypedValue(int v, int type) {
        v = java.lang.Math.max(v, minimum);
        v = java.lang.Math.min(v, ((maximum) - (visibleAmount)));
        if (v != (value)) {
            value = v;
            java.awt.event.AdjustmentEvent e = new java.awt.event.AdjustmentEvent(java.awt.ScrollPaneAdjustable.this , java.awt.event.AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED , type , value , isAdjusting);
            adjustmentListener.adjustmentValueChanged(e);
        } 
    }

    public int getValue() {
        return value;
    }

    public synchronized void addAdjustmentListener(java.awt.event.AdjustmentListener l) {
        if (l == null) {
            return ;
        } 
        adjustmentListener = java.awt.AWTEventMulticaster.add(adjustmentListener, l);
    }

    public synchronized void removeAdjustmentListener(java.awt.event.AdjustmentListener l) {
        if (l == null) {
            return ;
        } 
        adjustmentListener = java.awt.AWTEventMulticaster.remove(adjustmentListener, l);
    }

    public synchronized java.awt.event.AdjustmentListener[] getAdjustmentListeners() {
        return ((java.awt.event.AdjustmentListener[])(java.awt.AWTEventMulticaster.getListeners(adjustmentListener, java.awt.event.AdjustmentListener.class)));
    }

    public java.lang.String toString() {
        return (((getClass().getName()) + "[") + (paramString())) + "]";
    }

    public java.lang.String paramString() {
        return ((((((((((((((orientation) == (java.awt.Adjustable.VERTICAL) ? "vertical," : "horizontal,") + "[0..") + (maximum)) + "]") + ",val=") + (value)) + ",vis=") + (visibleAmount)) + ",unit=") + (unitIncrement)) + ",block=") + (blockIncrement)) + ",isAdjusting=") + (isAdjusting);
    }
}


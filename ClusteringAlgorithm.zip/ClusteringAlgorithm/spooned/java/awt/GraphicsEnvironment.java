package java.awt;


public abstract class GraphicsEnvironment {
    private static java.awt.GraphicsEnvironment localEnv;

    private static java.lang.Boolean headless;

    private static java.lang.Boolean defaultHeadless;

    protected GraphicsEnvironment() {
    }

    public static synchronized java.awt.GraphicsEnvironment getLocalGraphicsEnvironment() {
        if ((java.awt.GraphicsEnvironment.localEnv) == null) {
            java.awt.GraphicsEnvironment.localEnv = java.awt.GraphicsEnvironment.createGE();
        } 
        return java.awt.GraphicsEnvironment.localEnv;
    }

    private static java.awt.GraphicsEnvironment createGE() {
        java.awt.GraphicsEnvironment ge;
        java.lang.String nm = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("java.awt.graphicsenv" , null));
        try {
            java.lang.Class<java.awt.GraphicsEnvironment> geCls;
            try {
                geCls = ((java.lang.Class<java.awt.GraphicsEnvironment>)(java.lang.Class.forName(nm)));
            } catch (java.lang.ClassNotFoundException ex) {
                java.lang.ClassLoader cl = java.lang.ClassLoader.getSystemClassLoader();
                geCls = ((java.lang.Class<java.awt.GraphicsEnvironment>)(java.lang.Class.forName(nm, true, cl)));
            }
            ge = geCls.newInstance();
            if (java.awt.GraphicsEnvironment.isHeadless()) {
                ge = new sun.java2d.HeadlessGraphicsEnvironment(ge);
            } 
        } catch (java.lang.ClassNotFoundException e) {
            throw new java.lang.Error(("Could not find class: " + nm));
        } catch (java.lang.InstantiationException e) {
            throw new java.lang.Error(("Could not instantiate Graphics Environment: " + nm));
        } catch (java.lang.IllegalAccessException e) {
            throw new java.lang.Error(("Could not access Graphics Environment: " + nm));
        }
        return ge;
    }

    public static boolean isHeadless() {
        return java.awt.GraphicsEnvironment.getHeadlessProperty();
    }

    static java.lang.String getHeadlessMessage() {
        if ((java.awt.GraphicsEnvironment.headless) == null) {
            java.awt.GraphicsEnvironment.getHeadlessProperty();
        } 
        return (java.awt.GraphicsEnvironment.defaultHeadless) != (java.lang.Boolean.TRUE) ? null : "\nNo X11 DISPLAY variable was set, " + "but this program performed an operation which requires it.";
    }

    private static boolean getHeadlessProperty() {
        if ((java.awt.GraphicsEnvironment.headless) == null) {
            java.security.AccessController.doPrivileged(((java.security.PrivilegedAction<java.lang.Void>)(() -> {
                java.lang.String nm = java.lang.System.getProperty("java.awt.headless");
                if (nm == null) {
                    if ((java.lang.System.getProperty("javaplugin.version")) != null) {
                        java.awt.GraphicsEnvironment.headless = java.awt.GraphicsEnvironment.defaultHeadless = java.lang.Boolean.FALSE;
                    } else {
                        java.lang.String osName = java.lang.System.getProperty("os.name");
                        if ((osName.contains("OS X")) && ("sun.awt.HToolkit".equals(java.lang.System.getProperty("awt.toolkit")))) {
                            java.awt.GraphicsEnvironment.headless = java.awt.GraphicsEnvironment.defaultHeadless = java.lang.Boolean.TRUE;
                        } else {
                            final java.lang.String display = java.lang.System.getenv("DISPLAY");
                            java.awt.GraphicsEnvironment.headless = java.awt.GraphicsEnvironment.defaultHeadless = (((((("Linux".equals(osName)) || ("SunOS".equals(osName))) || ("FreeBSD".equals(osName))) || ("NetBSD".equals(osName))) || ("OpenBSD".equals(osName))) || ("AIX".equals(osName))) && ((display == null) || (display.trim().isEmpty()));
                        }
                    }
                } else {
                    java.awt.GraphicsEnvironment.headless = java.lang.Boolean.valueOf(nm);
                }
                return null;
            })));
        } 
        return java.awt.GraphicsEnvironment.headless;
    }

    static void checkHeadless() throws java.awt.HeadlessException {
        if (java.awt.GraphicsEnvironment.isHeadless()) {
            throw new java.awt.HeadlessException();
        } 
    }

    public boolean isHeadlessInstance() {
        return java.awt.GraphicsEnvironment.getHeadlessProperty();
    }

    public abstract java.awt.GraphicsDevice[] getScreenDevices() throws java.awt.HeadlessException;

    public abstract java.awt.GraphicsDevice getDefaultScreenDevice() throws java.awt.HeadlessException;

    public abstract java.awt.Graphics2D createGraphics(java.awt.image.BufferedImage img);

    public abstract java.awt.Font[] getAllFonts();

    public abstract java.lang.String[] getAvailableFontFamilyNames();

    public abstract java.lang.String[] getAvailableFontFamilyNames(java.util.Locale l);

    public boolean registerFont(java.awt.Font font) {
        if (font == null) {
            throw new java.lang.NullPointerException("font cannot be null.");
        } 
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        return fm.registerFont(font);
    }

    public void preferLocaleFonts() {
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        fm.preferLocaleFonts();
    }

    public void preferProportionalFonts() {
        sun.font.FontManager fm = sun.font.FontManagerFactory.getInstance();
        fm.preferProportionalFonts();
    }

    public java.awt.Point getCenterPoint() throws java.awt.HeadlessException {
        java.awt.Rectangle usableBounds = sun.java2d.SunGraphicsEnvironment.getUsableBounds(getDefaultScreenDevice());
        return new java.awt.Point((((usableBounds.width) / 2) + (usableBounds.x)) , (((usableBounds.height) / 2) + (usableBounds.y)));
    }

    public java.awt.Rectangle getMaximumWindowBounds() throws java.awt.HeadlessException {
        return sun.java2d.SunGraphicsEnvironment.getUsableBounds(getDefaultScreenDevice());
    }
}


package java.awt;


public interface MenuContainer {
    java.awt.Font getFont();

    void remove(java.awt.MenuComponent comp);

    @java.lang.Deprecated
    boolean postEvent(java.awt.Event evt);
}


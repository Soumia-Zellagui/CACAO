package java.awt;


public class Insets implements java.io.Serializable , java.lang.Cloneable {
    public int top;

    public int left;

    public int bottom;

    public int right;

    private static final long serialVersionUID = -2272572637695466749L;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Insets.initIDs();
        } 
    }

    public Insets(int top ,int left ,int bottom ,int right) {
        java.awt.Insets.this.top = top;
        java.awt.Insets.this.left = left;
        java.awt.Insets.this.bottom = bottom;
        java.awt.Insets.this.right = right;
    }

    public void set(int top, int left, int bottom, int right) {
        java.awt.Insets.this.top = top;
        java.awt.Insets.this.left = left;
        java.awt.Insets.this.bottom = bottom;
        java.awt.Insets.this.right = right;
    }

    public boolean equals(java.lang.Object obj) {
        if (obj instanceof java.awt.Insets) {
            java.awt.Insets insets = ((java.awt.Insets)(obj));
            return ((((top) == (insets.top)) && ((left) == (insets.left))) && ((bottom) == (insets.bottom))) && ((right) == (insets.right));
        } 
        return false;
    }

    public int hashCode() {
        int sum1 = (left) + (bottom);
        int sum2 = (right) + (top);
        int val1 = ((sum1 * (sum1 + 1)) / 2) + (left);
        int val2 = ((sum2 * (sum2 + 1)) / 2) + (top);
        int sum3 = val1 + val2;
        return ((sum3 * (sum3 + 1)) / 2) + val2;
    }

    public java.lang.String toString() {
        return (((((((((getClass().getName()) + "[top=") + (top)) + ",left=") + (left)) + ",bottom=") + (bottom)) + ",right=") + (right)) + "]";
    }

    public java.lang.Object clone() {
        try {
            return super.clone();
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError(e);
        }
    }

    private static native void initIDs();
}


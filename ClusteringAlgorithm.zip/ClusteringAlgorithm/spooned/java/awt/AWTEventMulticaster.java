package java.awt;


public class AWTEventMulticaster implements java.awt.event.ActionListener , java.awt.event.AdjustmentListener , java.awt.event.ComponentListener , java.awt.event.ContainerListener , java.awt.event.FocusListener , java.awt.event.HierarchyBoundsListener , java.awt.event.HierarchyListener , java.awt.event.InputMethodListener , java.awt.event.ItemListener , java.awt.event.KeyListener , java.awt.event.MouseListener , java.awt.event.MouseMotionListener , java.awt.event.MouseWheelListener , java.awt.event.TextListener , java.awt.event.WindowFocusListener , java.awt.event.WindowListener , java.awt.event.WindowStateListener {
    protected final java.util.EventListener a;

    protected final java.util.EventListener b;

    protected AWTEventMulticaster(java.util.EventListener a ,java.util.EventListener b) {
        this.a = a;
        this.b = b;
    }

    protected java.util.EventListener remove(java.util.EventListener oldl) {
        if (oldl == (a))
            return b;
        
        if (oldl == (b))
            return a;
        
        java.util.EventListener a2 = java.awt.AWTEventMulticaster.removeInternal(a, oldl);
        java.util.EventListener b2 = java.awt.AWTEventMulticaster.removeInternal(b, oldl);
        if ((a2 == (a)) && (b2 == (b))) {
            return java.awt.AWTEventMulticaster.this;
        } 
        return java.awt.AWTEventMulticaster.addInternal(a2, b2);
    }

    public void componentResized(java.awt.event.ComponentEvent e) {
        ((java.awt.event.ComponentListener)(a)).componentResized(e);
        ((java.awt.event.ComponentListener)(b)).componentResized(e);
    }

    public void componentMoved(java.awt.event.ComponentEvent e) {
        ((java.awt.event.ComponentListener)(a)).componentMoved(e);
        ((java.awt.event.ComponentListener)(b)).componentMoved(e);
    }

    public void componentShown(java.awt.event.ComponentEvent e) {
        ((java.awt.event.ComponentListener)(a)).componentShown(e);
        ((java.awt.event.ComponentListener)(b)).componentShown(e);
    }

    public void componentHidden(java.awt.event.ComponentEvent e) {
        ((java.awt.event.ComponentListener)(a)).componentHidden(e);
        ((java.awt.event.ComponentListener)(b)).componentHidden(e);
    }

    public void componentAdded(java.awt.event.ContainerEvent e) {
        ((java.awt.event.ContainerListener)(a)).componentAdded(e);
        ((java.awt.event.ContainerListener)(b)).componentAdded(e);
    }

    public void componentRemoved(java.awt.event.ContainerEvent e) {
        ((java.awt.event.ContainerListener)(a)).componentRemoved(e);
        ((java.awt.event.ContainerListener)(b)).componentRemoved(e);
    }

    public void focusGained(java.awt.event.FocusEvent e) {
        ((java.awt.event.FocusListener)(a)).focusGained(e);
        ((java.awt.event.FocusListener)(b)).focusGained(e);
    }

    public void focusLost(java.awt.event.FocusEvent e) {
        ((java.awt.event.FocusListener)(a)).focusLost(e);
        ((java.awt.event.FocusListener)(b)).focusLost(e);
    }

    public void keyTyped(java.awt.event.KeyEvent e) {
        ((java.awt.event.KeyListener)(a)).keyTyped(e);
        ((java.awt.event.KeyListener)(b)).keyTyped(e);
    }

    public void keyPressed(java.awt.event.KeyEvent e) {
        ((java.awt.event.KeyListener)(a)).keyPressed(e);
        ((java.awt.event.KeyListener)(b)).keyPressed(e);
    }

    public void keyReleased(java.awt.event.KeyEvent e) {
        ((java.awt.event.KeyListener)(a)).keyReleased(e);
        ((java.awt.event.KeyListener)(b)).keyReleased(e);
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseListener)(a)).mouseClicked(e);
        ((java.awt.event.MouseListener)(b)).mouseClicked(e);
    }

    public void mousePressed(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseListener)(a)).mousePressed(e);
        ((java.awt.event.MouseListener)(b)).mousePressed(e);
    }

    public void mouseReleased(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseListener)(a)).mouseReleased(e);
        ((java.awt.event.MouseListener)(b)).mouseReleased(e);
    }

    public void mouseEntered(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseListener)(a)).mouseEntered(e);
        ((java.awt.event.MouseListener)(b)).mouseEntered(e);
    }

    public void mouseExited(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseListener)(a)).mouseExited(e);
        ((java.awt.event.MouseListener)(b)).mouseExited(e);
    }

    public void mouseDragged(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseMotionListener)(a)).mouseDragged(e);
        ((java.awt.event.MouseMotionListener)(b)).mouseDragged(e);
    }

    public void mouseMoved(java.awt.event.MouseEvent e) {
        ((java.awt.event.MouseMotionListener)(a)).mouseMoved(e);
        ((java.awt.event.MouseMotionListener)(b)).mouseMoved(e);
    }

    public void windowOpened(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowOpened(e);
        ((java.awt.event.WindowListener)(b)).windowOpened(e);
    }

    public void windowClosing(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowClosing(e);
        ((java.awt.event.WindowListener)(b)).windowClosing(e);
    }

    public void windowClosed(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowClosed(e);
        ((java.awt.event.WindowListener)(b)).windowClosed(e);
    }

    public void windowIconified(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowIconified(e);
        ((java.awt.event.WindowListener)(b)).windowIconified(e);
    }

    public void windowDeiconified(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowDeiconified(e);
        ((java.awt.event.WindowListener)(b)).windowDeiconified(e);
    }

    public void windowActivated(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowActivated(e);
        ((java.awt.event.WindowListener)(b)).windowActivated(e);
    }

    public void windowDeactivated(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowListener)(a)).windowDeactivated(e);
        ((java.awt.event.WindowListener)(b)).windowDeactivated(e);
    }

    public void windowStateChanged(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowStateListener)(a)).windowStateChanged(e);
        ((java.awt.event.WindowStateListener)(b)).windowStateChanged(e);
    }

    public void windowGainedFocus(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowFocusListener)(a)).windowGainedFocus(e);
        ((java.awt.event.WindowFocusListener)(b)).windowGainedFocus(e);
    }

    public void windowLostFocus(java.awt.event.WindowEvent e) {
        ((java.awt.event.WindowFocusListener)(a)).windowLostFocus(e);
        ((java.awt.event.WindowFocusListener)(b)).windowLostFocus(e);
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
        ((java.awt.event.ActionListener)(a)).actionPerformed(e);
        ((java.awt.event.ActionListener)(b)).actionPerformed(e);
    }

    public void itemStateChanged(java.awt.event.ItemEvent e) {
        ((java.awt.event.ItemListener)(a)).itemStateChanged(e);
        ((java.awt.event.ItemListener)(b)).itemStateChanged(e);
    }

    public void adjustmentValueChanged(java.awt.event.AdjustmentEvent e) {
        ((java.awt.event.AdjustmentListener)(a)).adjustmentValueChanged(e);
        ((java.awt.event.AdjustmentListener)(b)).adjustmentValueChanged(e);
    }

    public void textValueChanged(java.awt.event.TextEvent e) {
        ((java.awt.event.TextListener)(a)).textValueChanged(e);
        ((java.awt.event.TextListener)(b)).textValueChanged(e);
    }

    public void inputMethodTextChanged(java.awt.event.InputMethodEvent e) {
        ((java.awt.event.InputMethodListener)(a)).inputMethodTextChanged(e);
        ((java.awt.event.InputMethodListener)(b)).inputMethodTextChanged(e);
    }

    public void caretPositionChanged(java.awt.event.InputMethodEvent e) {
        ((java.awt.event.InputMethodListener)(a)).caretPositionChanged(e);
        ((java.awt.event.InputMethodListener)(b)).caretPositionChanged(e);
    }

    public void hierarchyChanged(java.awt.event.HierarchyEvent e) {
        ((java.awt.event.HierarchyListener)(a)).hierarchyChanged(e);
        ((java.awt.event.HierarchyListener)(b)).hierarchyChanged(e);
    }

    public void ancestorMoved(java.awt.event.HierarchyEvent e) {
        ((java.awt.event.HierarchyBoundsListener)(a)).ancestorMoved(e);
        ((java.awt.event.HierarchyBoundsListener)(b)).ancestorMoved(e);
    }

    public void ancestorResized(java.awt.event.HierarchyEvent e) {
        ((java.awt.event.HierarchyBoundsListener)(a)).ancestorResized(e);
        ((java.awt.event.HierarchyBoundsListener)(b)).ancestorResized(e);
    }

    public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
        ((java.awt.event.MouseWheelListener)(a)).mouseWheelMoved(e);
        ((java.awt.event.MouseWheelListener)(b)).mouseWheelMoved(e);
    }

    public static java.awt.event.ComponentListener add(java.awt.event.ComponentListener a, java.awt.event.ComponentListener b) {
        return ((java.awt.event.ComponentListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.ContainerListener add(java.awt.event.ContainerListener a, java.awt.event.ContainerListener b) {
        return ((java.awt.event.ContainerListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.FocusListener add(java.awt.event.FocusListener a, java.awt.event.FocusListener b) {
        return ((java.awt.event.FocusListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.KeyListener add(java.awt.event.KeyListener a, java.awt.event.KeyListener b) {
        return ((java.awt.event.KeyListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.MouseListener add(java.awt.event.MouseListener a, java.awt.event.MouseListener b) {
        return ((java.awt.event.MouseListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.MouseMotionListener add(java.awt.event.MouseMotionListener a, java.awt.event.MouseMotionListener b) {
        return ((java.awt.event.MouseMotionListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.WindowListener add(java.awt.event.WindowListener a, java.awt.event.WindowListener b) {
        return ((java.awt.event.WindowListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.WindowStateListener add(java.awt.event.WindowStateListener a, java.awt.event.WindowStateListener b) {
        return ((java.awt.event.WindowStateListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.WindowFocusListener add(java.awt.event.WindowFocusListener a, java.awt.event.WindowFocusListener b) {
        return ((java.awt.event.WindowFocusListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.ActionListener add(java.awt.event.ActionListener a, java.awt.event.ActionListener b) {
        return ((java.awt.event.ActionListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.ItemListener add(java.awt.event.ItemListener a, java.awt.event.ItemListener b) {
        return ((java.awt.event.ItemListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.AdjustmentListener add(java.awt.event.AdjustmentListener a, java.awt.event.AdjustmentListener b) {
        return ((java.awt.event.AdjustmentListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.TextListener add(java.awt.event.TextListener a, java.awt.event.TextListener b) {
        return ((java.awt.event.TextListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.InputMethodListener add(java.awt.event.InputMethodListener a, java.awt.event.InputMethodListener b) {
        return ((java.awt.event.InputMethodListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.HierarchyListener add(java.awt.event.HierarchyListener a, java.awt.event.HierarchyListener b) {
        return ((java.awt.event.HierarchyListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.HierarchyBoundsListener add(java.awt.event.HierarchyBoundsListener a, java.awt.event.HierarchyBoundsListener b) {
        return ((java.awt.event.HierarchyBoundsListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.MouseWheelListener add(java.awt.event.MouseWheelListener a, java.awt.event.MouseWheelListener b) {
        return ((java.awt.event.MouseWheelListener)(java.awt.AWTEventMulticaster.addInternal(a, b)));
    }

    public static java.awt.event.ComponentListener remove(java.awt.event.ComponentListener l, java.awt.event.ComponentListener oldl) {
        return ((java.awt.event.ComponentListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.ContainerListener remove(java.awt.event.ContainerListener l, java.awt.event.ContainerListener oldl) {
        return ((java.awt.event.ContainerListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.FocusListener remove(java.awt.event.FocusListener l, java.awt.event.FocusListener oldl) {
        return ((java.awt.event.FocusListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.KeyListener remove(java.awt.event.KeyListener l, java.awt.event.KeyListener oldl) {
        return ((java.awt.event.KeyListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.MouseListener remove(java.awt.event.MouseListener l, java.awt.event.MouseListener oldl) {
        return ((java.awt.event.MouseListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.MouseMotionListener remove(java.awt.event.MouseMotionListener l, java.awt.event.MouseMotionListener oldl) {
        return ((java.awt.event.MouseMotionListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.WindowListener remove(java.awt.event.WindowListener l, java.awt.event.WindowListener oldl) {
        return ((java.awt.event.WindowListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.WindowStateListener remove(java.awt.event.WindowStateListener l, java.awt.event.WindowStateListener oldl) {
        return ((java.awt.event.WindowStateListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.WindowFocusListener remove(java.awt.event.WindowFocusListener l, java.awt.event.WindowFocusListener oldl) {
        return ((java.awt.event.WindowFocusListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.ActionListener remove(java.awt.event.ActionListener l, java.awt.event.ActionListener oldl) {
        return ((java.awt.event.ActionListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.ItemListener remove(java.awt.event.ItemListener l, java.awt.event.ItemListener oldl) {
        return ((java.awt.event.ItemListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.AdjustmentListener remove(java.awt.event.AdjustmentListener l, java.awt.event.AdjustmentListener oldl) {
        return ((java.awt.event.AdjustmentListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.TextListener remove(java.awt.event.TextListener l, java.awt.event.TextListener oldl) {
        return ((java.awt.event.TextListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.InputMethodListener remove(java.awt.event.InputMethodListener l, java.awt.event.InputMethodListener oldl) {
        return ((java.awt.event.InputMethodListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.HierarchyListener remove(java.awt.event.HierarchyListener l, java.awt.event.HierarchyListener oldl) {
        return ((java.awt.event.HierarchyListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.HierarchyBoundsListener remove(java.awt.event.HierarchyBoundsListener l, java.awt.event.HierarchyBoundsListener oldl) {
        return ((java.awt.event.HierarchyBoundsListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    public static java.awt.event.MouseWheelListener remove(java.awt.event.MouseWheelListener l, java.awt.event.MouseWheelListener oldl) {
        return ((java.awt.event.MouseWheelListener)(java.awt.AWTEventMulticaster.removeInternal(l, oldl)));
    }

    protected static java.util.EventListener addInternal(java.util.EventListener a, java.util.EventListener b) {
        if (a == null)
            return b;
        
        if (b == null)
            return a;
        
        return new java.awt.AWTEventMulticaster(a , b);
    }

    protected static java.util.EventListener removeInternal(java.util.EventListener l, java.util.EventListener oldl) {
        if ((l == oldl) || (l == null)) {
            return null;
        } else if (l instanceof java.awt.AWTEventMulticaster) {
            return ((java.awt.AWTEventMulticaster)(l)).remove(oldl);
        } else {
            return l;
        }
    }

    protected void saveInternal(java.io.ObjectOutputStream s, java.lang.String k) throws java.io.IOException {
        if ((a) instanceof java.awt.AWTEventMulticaster) {
            ((java.awt.AWTEventMulticaster)(a)).saveInternal(s, k);
        } else if ((a) instanceof java.io.Serializable) {
            s.writeObject(k);
            s.writeObject(a);
        } 
        if ((b) instanceof java.awt.AWTEventMulticaster) {
            ((java.awt.AWTEventMulticaster)(b)).saveInternal(s, k);
        } else if ((b) instanceof java.io.Serializable) {
            s.writeObject(k);
            s.writeObject(b);
        } 
    }

    protected static void save(java.io.ObjectOutputStream s, java.lang.String k, java.util.EventListener l) throws java.io.IOException {
        if (l == null) {
            return ;
        } else if (l instanceof java.awt.AWTEventMulticaster) {
            ((java.awt.AWTEventMulticaster)(l)).saveInternal(s, k);
        } else if (l instanceof java.io.Serializable) {
            s.writeObject(k);
            s.writeObject(l);
        } 
    }

    private static int getListenerCount(java.util.EventListener l, java.lang.Class<?> listenerType) {
        if (l instanceof java.awt.AWTEventMulticaster) {
            java.awt.AWTEventMulticaster mc = ((java.awt.AWTEventMulticaster)(l));
            return (java.awt.AWTEventMulticaster.getListenerCount(mc.a, listenerType)) + (java.awt.AWTEventMulticaster.getListenerCount(mc.b, listenerType));
        } else {
            return listenerType.isInstance(l) ? 1 : 0;
        }
    }

    private static int populateListenerArray(java.util.EventListener[] a, java.util.EventListener l, int index) {
        if (l instanceof java.awt.AWTEventMulticaster) {
            java.awt.AWTEventMulticaster mc = ((java.awt.AWTEventMulticaster)(l));
            int lhs = java.awt.AWTEventMulticaster.populateListenerArray(a, mc.a, index);
            return java.awt.AWTEventMulticaster.populateListenerArray(a, mc.b, lhs);
        } else if (a.getClass().getComponentType().isInstance(l)) {
            a[index] = l;
            return index + 1;
        } else {
            return index;
        }
    }

    @java.lang.SuppressWarnings(value = "unchecked")
    public static <T extends java.util.EventListener>T[] getListeners(java.util.EventListener l, java.lang.Class<T> listenerType) {
        if (listenerType == null) {
            throw new java.lang.NullPointerException("Listener type should not be null");
        } 
        int n = java.awt.AWTEventMulticaster.getListenerCount(l, listenerType);
        T[] result = ((T[])(java.lang.reflect.Array.newInstance(listenerType, n)));
        java.awt.AWTEventMulticaster.populateListenerArray(result, l, 0);
        return result;
    }
}


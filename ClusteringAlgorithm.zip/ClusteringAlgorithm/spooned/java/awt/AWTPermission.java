package java.awt;


public final class AWTPermission extends java.security.BasicPermission {
    private static final long serialVersionUID = 8890392402588814465L;

    public AWTPermission(java.lang.String name) {
        super(name);
    }

    public AWTPermission(java.lang.String name ,java.lang.String actions) {
        super(name, actions);
    }
}


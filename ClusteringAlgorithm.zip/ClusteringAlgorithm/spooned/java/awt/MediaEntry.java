package java.awt;


abstract class MediaEntry {
    java.awt.MediaTracker tracker;

    int ID;

    java.awt.MediaEntry next;

    int status;

    boolean cancelled;

    MediaEntry(java.awt.MediaTracker mt ,int id) {
        tracker = mt;
        ID = id;
    }

    abstract java.lang.Object getMedia();

    static java.awt.MediaEntry insert(java.awt.MediaEntry head, java.awt.MediaEntry me) {
        java.awt.MediaEntry cur = head;
        java.awt.MediaEntry prev = null;
        while (cur != null) {
            if ((cur.ID) > (me.ID)) {
                break;
            } 
            prev = cur;
            cur = cur.next;
        }
        me.next = cur;
        if (prev == null) {
            head = me;
        } else {
            prev.next = me;
        }
        return head;
    }

    int getID() {
        return ID;
    }

    abstract void startLoad();

    void cancel() {
        cancelled = true;
    }

    static final int LOADING = java.awt.MediaTracker.LOADING;

    static final int ABORTED = java.awt.MediaTracker.ABORTED;

    static final int ERRORED = java.awt.MediaTracker.ERRORED;

    static final int COMPLETE = java.awt.MediaTracker.COMPLETE;

    static final int LOADSTARTED = ((java.awt.MediaEntry.LOADING) | (java.awt.MediaEntry.ERRORED)) | (java.awt.MediaEntry.COMPLETE);

    static final int DONE = ((java.awt.MediaEntry.ABORTED) | (java.awt.MediaEntry.ERRORED)) | (java.awt.MediaEntry.COMPLETE);

    synchronized int getStatus(boolean doLoad, boolean doVerify) {
        if (doLoad && (((status) & (java.awt.MediaEntry.LOADSTARTED)) == 0)) {
            status = ((status) & (~(java.awt.MediaEntry.ABORTED))) | (java.awt.MediaEntry.LOADING);
            startLoad();
        } 
        return status;
    }

    void setStatus(int flag) {
        synchronized(java.awt.MediaEntry.this) {
            status = flag;
        }
        tracker.setDone();
    }
}


package java.awt;


public class Window extends java.awt.Container implements javax.accessibility.Accessible {
    public static enum Type {
NORMAL, UTILITY, POPUP;    }

    java.lang.String warningString;

    transient java.util.List<java.awt.Image> icons;

    private transient java.awt.Component temporaryLostComponent;

    static boolean systemSyncLWRequests = false;

    boolean syncLWRequests = false;

    transient boolean beforeFirstShow = true;

    private transient boolean disposing = false;

    transient java.awt.Window.WindowDisposerRecord disposerRecord = null;

    static final int OPENED = 1;

    int state;

    private boolean alwaysOnTop;

    private static final sun.awt.util.IdentityArrayList<java.awt.Window> allWindows = new sun.awt.util.IdentityArrayList<java.awt.Window>();

    transient java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>> ownedWindowList = new java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>>();

    private transient java.lang.ref.WeakReference<java.awt.Window> weakThis;

    transient boolean showWithParent;

    transient java.awt.Dialog modalBlocker;

    java.awt.Dialog.ModalExclusionType modalExclusionType;

    transient java.awt.event.WindowListener windowListener;

    transient java.awt.event.WindowStateListener windowStateListener;

    transient java.awt.event.WindowFocusListener windowFocusListener;

    transient java.awt.im.InputContext inputContext;

    private transient java.lang.Object inputContextLock = new java.lang.Object();

    private java.awt.FocusManager focusMgr;

    private boolean focusableWindowState = true;

    private volatile boolean autoRequestFocus = true;

    transient boolean isInShow = false;

    private float opacity = 1.0F;

    private java.awt.Shape shape = null;

    private static final java.lang.String base = "win";

    private static int nameCounter = 0;

    private static final long serialVersionUID = 4497834738069338734L;

    private static final sun.util.logging.PlatformLogger log = sun.util.logging.PlatformLogger.getLogger("java.awt.Window");

    private static final boolean locationByPlatformProp;

    transient boolean isTrayIconWindow = false;

    private transient volatile int securityWarningWidth = 0;

    private transient volatile int securityWarningHeight = 0;

    private transient double securityWarningPointX = 2.0;

    private transient double securityWarningPointY = 0.0;

    private transient float securityWarningAlignmentX = java.awt.Component.RIGHT_ALIGNMENT;

    private transient float securityWarningAlignmentY = java.awt.Component.TOP_ALIGNMENT;

    static {
        java.awt.Toolkit.loadLibraries();
        if (!(java.awt.GraphicsEnvironment.isHeadless())) {
            java.awt.Window.initIDs();
        } 
        java.lang.String s = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("java.awt.syncLWRequests"));
        systemSyncLWRequests = (s != null) && (s.equals("true"));
        s = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("java.awt.Window.locationByPlatform"));
        locationByPlatformProp = (s != null) && (s.equals("true"));
    }

    private static native void initIDs();

    Window(java.awt.GraphicsConfiguration gc) {
        init(gc);
    }

    transient java.lang.Object anchor = new java.lang.Object();

    static class WindowDisposerRecord implements sun.java2d.DisposerRecord {
        java.lang.ref.WeakReference<java.awt.Window> owner;

        final java.lang.ref.WeakReference<java.awt.Window> weakThis;

        final java.lang.ref.WeakReference<sun.awt.AppContext> context;

        WindowDisposerRecord(sun.awt.AppContext context ,java.awt.Window victim) {
            weakThis = victim.weakThis;
            this.context = new java.lang.ref.WeakReference<sun.awt.AppContext>(context);
        }

        public void updateOwner() {
            java.awt.Window victim = weakThis.get();
            owner = victim == null ? null : new java.lang.ref.WeakReference<java.awt.Window>(victim.getOwner());
        }

        public void dispose() {
            if ((owner) != null) {
                java.awt.Window parent = owner.get();
                if (parent != null) {
                    parent.removeOwnedWindow(weakThis);
                } 
            } 
            sun.awt.AppContext ac = context.get();
            if (null != ac) {
                java.awt.Window.removeFromWindowList(ac, weakThis);
            } 
        }
    }

    private java.awt.GraphicsConfiguration initGC(java.awt.GraphicsConfiguration gc) {
        java.awt.GraphicsEnvironment.checkHeadless();
        if (gc == null) {
            gc = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
        } 
        setGraphicsConfiguration(gc);
        return gc;
    }

    private void init(java.awt.GraphicsConfiguration gc) {
        java.awt.GraphicsEnvironment.checkHeadless();
        syncLWRequests = java.awt.Window.systemSyncLWRequests;
        weakThis = new java.lang.ref.WeakReference<java.awt.Window>(java.awt.Window.this);
        addToWindowList();
        setWarningString();
        java.awt.Window.this.cursor = java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR);
        java.awt.Window.this.visible = false;
        gc = initGC(gc);
        if ((gc.getDevice().getType()) != (java.awt.GraphicsDevice.TYPE_RASTER_SCREEN)) {
            throw new java.lang.IllegalArgumentException("not a screen device");
        } 
        setLayout(new java.awt.BorderLayout());
        java.awt.Rectangle screenBounds = gc.getBounds();
        java.awt.Insets screenInsets = getToolkit().getScreenInsets(gc);
        int x = ((getX()) + (screenBounds.x)) + (screenInsets.left);
        int y = ((getY()) + (screenBounds.y)) + (screenInsets.top);
        if ((x != (java.awt.Window.this.x)) || (y != (java.awt.Window.this.y))) {
            setLocation(x, y);
            setLocationByPlatform(java.awt.Window.locationByPlatformProp);
        } 
        modalExclusionType = java.awt.Dialog.ModalExclusionType.NO_EXCLUDE;
        disposerRecord = new java.awt.Window.WindowDisposerRecord(appContext , java.awt.Window.this);
        sun.java2d.Disposer.addRecord(anchor, disposerRecord);
        sun.awt.SunToolkit.checkAndSetPolicy(java.awt.Window.this);
    }

    Window() throws java.awt.HeadlessException {
        java.awt.GraphicsEnvironment.checkHeadless();
        init(((java.awt.GraphicsConfiguration)(null)));
    }

    public Window(java.awt.Frame owner) {
        this((owner == null ? ((java.awt.GraphicsConfiguration)(null)) : owner.getGraphicsConfiguration()));
        ownedInit(owner);
    }

    public Window(java.awt.Window owner) {
        this((owner == null ? ((java.awt.GraphicsConfiguration)(null)) : owner.getGraphicsConfiguration()));
        ownedInit(owner);
    }

    public Window(java.awt.Window owner ,java.awt.GraphicsConfiguration gc) {
        this(gc);
        ownedInit(owner);
    }

    private void ownedInit(java.awt.Window owner) {
        java.awt.Window.this.parent = owner;
        if (owner != null) {
            owner.addOwnedWindow(weakThis);
            if (owner.isAlwaysOnTop()) {
                try {
                    setAlwaysOnTop(true);
                } catch (java.lang.SecurityException ignore) {
                }
            } 
        } 
        disposerRecord.updateOwner();
    }

    java.lang.String constructComponentName() {
        synchronized(java.awt.Window.class) {
            return (java.awt.Window.base) + ((java.awt.Window.nameCounter)++);
        }
    }

    public java.util.List<java.awt.Image> getIconImages() {
        java.util.List<java.awt.Image> icons = java.awt.Window.this.icons;
        if ((icons == null) || ((icons.size()) == 0)) {
            return new java.util.ArrayList<java.awt.Image>();
        } 
        return new java.util.ArrayList<java.awt.Image>(icons);
    }

    public synchronized void setIconImages(java.util.List<? extends java.awt.Image> icons) {
        java.awt.Window.this.icons = icons == null ? new java.util.ArrayList<java.awt.Image>() : new java.util.ArrayList<java.awt.Image>(icons);
        java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
        if (peer != null) {
            peer.updateIconImages();
        } 
        firePropertyChange("iconImage", null, null);
    }

    public void setIconImage(java.awt.Image image) {
        java.util.ArrayList<java.awt.Image> imageList = new java.util.ArrayList<java.awt.Image>();
        if (image != null) {
            imageList.add(image);
        } 
        setIconImages(imageList);
    }

    public void addNotify() {
        synchronized(getTreeLock()) {
            java.awt.Container parent = java.awt.Window.this.parent;
            if ((parent != null) && ((parent.getPeer()) == null)) {
                parent.addNotify();
            } 
            if ((peer) == null) {
                peer = getToolkit().createWindow(java.awt.Window.this);
            } 
            synchronized(java.awt.Window.allWindows) {
                java.awt.Window.allWindows.add(java.awt.Window.this);
            }
            super.addNotify();
        }
    }

    public void removeNotify() {
        synchronized(getTreeLock()) {
            synchronized(java.awt.Window.allWindows) {
                java.awt.Window.allWindows.remove(java.awt.Window.this);
            }
            super.removeNotify();
        }
    }

    public void pack() {
        java.awt.Container parent = java.awt.Window.this.parent;
        if ((parent != null) && ((parent.getPeer()) == null)) {
            parent.addNotify();
        } 
        if ((peer) == null) {
            addNotify();
        } 
        java.awt.Dimension newSize = getPreferredSize();
        if ((peer) != null) {
            setClientSize(newSize.width, newSize.height);
        } 
        if (beforeFirstShow) {
            isPacked = true;
        } 
        validateUnconditionally();
    }

    public void setMinimumSize(java.awt.Dimension minimumSize) {
        synchronized(getTreeLock()) {
            super.setMinimumSize(minimumSize);
            java.awt.Dimension size = getSize();
            if (isMinimumSizeSet()) {
                if (((size.width) < (minimumSize.width)) || ((size.height) < (minimumSize.height))) {
                    int nw = java.lang.Math.max(width, minimumSize.width);
                    int nh = java.lang.Math.max(height, minimumSize.height);
                    setSize(nw, nh);
                } 
            } 
            if ((peer) != null) {
                ((java.awt.peer.WindowPeer)(peer)).updateMinimumSize();
            } 
        }
    }

    public void setSize(java.awt.Dimension d) {
        super.setSize(d);
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
    }

    @java.lang.Override
    public void setLocation(int x, int y) {
        super.setLocation(x, y);
    }

    @java.lang.Override
    public void setLocation(java.awt.Point p) {
        super.setLocation(p);
    }

    @java.lang.Deprecated
    public void reshape(int x, int y, int width, int height) {
        if (isMinimumSizeSet()) {
            java.awt.Dimension minSize = getMinimumSize();
            if (width < (minSize.width)) {
                width = minSize.width;
            } 
            if (height < (minSize.height)) {
                height = minSize.height;
            } 
        } 
        super.reshape(x, y, width, height);
    }

    void setClientSize(int w, int h) {
        synchronized(getTreeLock()) {
            setBoundsOp(java.awt.peer.ComponentPeer.SET_CLIENT_SIZE);
            setBounds(x, y, w, h);
        }
    }

    private static final java.util.concurrent.atomic.AtomicBoolean beforeFirstWindowShown = new java.util.concurrent.atomic.AtomicBoolean(true);

    final void closeSplashScreen() {
        if (isTrayIconWindow) {
            return ;
        } 
        if (java.awt.Window.beforeFirstWindowShown.getAndSet(false)) {
            sun.awt.SunToolkit.closeSplashScreen();
            java.awt.SplashScreen.markClosed();
        } 
    }

    public void setVisible(boolean b) {
        super.setVisible(b);
    }

    @java.lang.Deprecated
    public void show() {
        if ((peer) == null) {
            addNotify();
        } 
        validateUnconditionally();
        isInShow = true;
        if (visible) {
            toFront();
        } else {
            beforeFirstShow = false;
            closeSplashScreen();
            java.awt.Dialog.checkShouldBeBlocked(java.awt.Window.this);
            super.show();
            synchronized(getTreeLock()) {
                java.awt.Window.this.locationByPlatform = false;
            }
            for (int i = 0 ; i < (ownedWindowList.size()) ; i++) {
                java.awt.Window child = ownedWindowList.elementAt(i).get();
                if ((child != null) && (child.showWithParent)) {
                    child.show();
                    child.showWithParent = false;
                } 
            }
            if (!(isModalBlocked())) {
                updateChildrenBlocking();
            } else {
                modalBlocker.toFront_NoClientCode();
            }
            if (((java.awt.Window.this) instanceof java.awt.Frame) || ((java.awt.Window.this) instanceof java.awt.Dialog)) {
                java.awt.Window.updateChildFocusableWindowState(java.awt.Window.this);
            } 
        }
        isInShow = false;
        if (((state) & (java.awt.Window.OPENED)) == 0) {
            postWindowEvent(java.awt.event.WindowEvent.WINDOW_OPENED);
            state |= java.awt.Window.OPENED;
        } 
    }

    static void updateChildFocusableWindowState(java.awt.Window w) {
        if (((w.getPeer()) != null) && (w.isShowing())) {
            ((java.awt.peer.WindowPeer)(w.getPeer())).updateFocusableWindowState();
        } 
        for (int i = 0 ; i < (w.ownedWindowList.size()) ; i++) {
            java.awt.Window child = w.ownedWindowList.elementAt(i).get();
            if (child != null) {
                java.awt.Window.updateChildFocusableWindowState(child);
            } 
        }
    }

    synchronized void postWindowEvent(int id) {
        if ((((windowListener) != null) || (((eventMask) & (java.awt.AWTEvent.WINDOW_EVENT_MASK)) != 0)) || (java.awt.Toolkit.enabledOnToolkit(java.awt.AWTEvent.WINDOW_EVENT_MASK))) {
            java.awt.event.WindowEvent e = new java.awt.event.WindowEvent(java.awt.Window.this , id);
            java.awt.Toolkit.getEventQueue().postEvent(e);
        } 
    }

    @java.lang.Deprecated
    public void hide() {
        synchronized(ownedWindowList) {
            for (int i = 0 ; i < (ownedWindowList.size()) ; i++) {
                java.awt.Window child = ownedWindowList.elementAt(i).get();
                if ((child != null) && (child.visible)) {
                    child.hide();
                    child.showWithParent = true;
                } 
            }
        }
        if (isModalBlocked()) {
            modalBlocker.unblockWindow(java.awt.Window.this);
        } 
        super.hide();
        synchronized(getTreeLock()) {
            java.awt.Window.this.locationByPlatform = false;
        }
    }

    final void clearMostRecentFocusOwnerOnHide() {
    }

    public void dispose() {
        doDispose();
    }

    void disposeImpl() {
        dispose();
        if ((getPeer()) != null) {
            doDispose();
        } 
    }

    void doDispose() {
        class DisposeAction implements java.lang.Runnable {
            public void run() {
                disposing = true;
                try {
                    java.awt.GraphicsDevice gd = getGraphicsConfiguration().getDevice();
                    if ((gd.getFullScreenWindow()) == (java.awt.Window.this)) {
                        gd.setFullScreenWindow(null);
                    } 
                    java.lang.Object[] ownedWindowArray;
                    synchronized(ownedWindowList) {
                        ownedWindowArray = new java.lang.Object[ownedWindowList.size()];
                        ownedWindowList.copyInto(ownedWindowArray);
                    }
                    for (int i = 0 ; i < (ownedWindowArray.length) ; i++) {
                        java.awt.Window child = ((java.awt.Window)(((java.lang.ref.WeakReference)(ownedWindowArray[i])).get()));
                        if (child != null) {
                            child.disposeImpl();
                        } 
                    }
                    hide();
                    beforeFirstShow = true;
                    removeNotify();
                    synchronized(inputContextLock) {
                        if ((inputContext) != null) {
                            inputContext.dispose();
                            inputContext = null;
                        } 
                    }
                    clearCurrentFocusCycleRootOnHide();
                } finally {
                    disposing = false;
                }
            }
        }
        boolean fireWindowClosedEvent = isDisplayable();
        DisposeAction action = new DisposeAction();
        if (java.awt.EventQueue.isDispatchThread()) {
            action.run();
        } else {
            try {
                java.awt.EventQueue.invokeAndWait(java.awt.Window.this, action);
            } catch (java.lang.InterruptedException e) {
                java.lang.System.err.println("Disposal was interrupted:");
                e.printStackTrace();
            } catch (java.lang.reflect.InvocationTargetException e) {
                java.lang.System.err.println("Exception during disposal:");
                e.printStackTrace();
            }
        }
        if (fireWindowClosedEvent) {
            postWindowEvent(java.awt.event.WindowEvent.WINDOW_CLOSED);
        } 
    }

    void adjustListeningChildrenOnParent(long mask, int num) {
    }

    void adjustDecendantsOnParent(int num) {
    }

    public void toFront() {
        toFront_NoClientCode();
    }

    final void toFront_NoClientCode() {
        if (visible) {
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
            if (peer != null) {
                peer.toFront();
            } 
            if (isModalBlocked()) {
                modalBlocker.toFront_NoClientCode();
            } 
        } 
    }

    public void toBack() {
        toBack_NoClientCode();
    }

    final void toBack_NoClientCode() {
        if (isAlwaysOnTop()) {
            try {
                setAlwaysOnTop(false);
            } catch (java.lang.SecurityException e) {
            }
        } 
        if (visible) {
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
            if (peer != null) {
                peer.toBack();
            } 
        } 
    }

    public java.awt.Toolkit getToolkit() {
        return java.awt.Toolkit.getDefaultToolkit();
    }

    public final java.lang.String getWarningString() {
        return warningString;
    }

    private void setWarningString() {
        warningString = null;
        java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
        if (sm != null) {
            try {
                sm.checkPermission(sun.security.util.SecurityConstants.AWT.TOPLEVEL_WINDOW_PERMISSION);
            } catch (java.lang.SecurityException se) {
                warningString = java.security.AccessController.doPrivileged(new sun.security.action.GetPropertyAction("awt.appletWarning" , "Java Applet Window"));
            }
        } 
    }

    public java.util.Locale getLocale() {
        if ((java.awt.Window.this.locale) == null) {
            return java.util.Locale.getDefault();
        } 
        return java.awt.Window.this.locale;
    }

    public java.awt.im.InputContext getInputContext() {
        synchronized(inputContextLock) {
            if ((inputContext) == null) {
                inputContext = java.awt.im.InputContext.getInstance();
            } 
        }
        return inputContext;
    }

    public void setCursor(java.awt.Cursor cursor) {
        if (cursor == null) {
            cursor = java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR);
        } 
        super.setCursor(cursor);
    }

    public java.awt.Window getOwner() {
        return getOwner_NoClientCode();
    }

    final java.awt.Window getOwner_NoClientCode() {
        return ((java.awt.Window)(parent));
    }

    public java.awt.Window[] getOwnedWindows() {
        return getOwnedWindows_NoClientCode();
    }

    final java.awt.Window[] getOwnedWindows_NoClientCode() {
        java.awt.Window[] realCopy;
        synchronized(ownedWindowList) {
            int fullSize = ownedWindowList.size();
            int realSize = 0;
            java.awt.Window[] fullCopy = new java.awt.Window[fullSize];
            for (int i = 0 ; i < fullSize ; i++) {
                fullCopy[realSize] = ownedWindowList.elementAt(i).get();
                if ((fullCopy[realSize]) != null) {
                    realSize++;
                } 
            }
            if (fullSize != realSize) {
                realCopy = java.util.Arrays.copyOf(fullCopy, realSize);
            } else {
                realCopy = fullCopy;
            }
        }
        return realCopy;
    }

    boolean isModalBlocked() {
        return (modalBlocker) != null;
    }

    void setModalBlocked(java.awt.Dialog blocker, boolean blocked, boolean peerCall) {
        java.awt.Window.this.modalBlocker = blocked ? blocker : null;
        if (peerCall) {
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
            if (peer != null) {
                peer.setModalBlocked(blocker, blocked);
            } 
        } 
    }

    java.awt.Dialog getModalBlocker() {
        return modalBlocker;
    }

    static sun.awt.util.IdentityArrayList<java.awt.Window> getAllWindows() {
        synchronized(java.awt.Window.allWindows) {
            sun.awt.util.IdentityArrayList<java.awt.Window> v = new sun.awt.util.IdentityArrayList<java.awt.Window>();
            v.addAll(java.awt.Window.allWindows);
            return v;
        }
    }

    static sun.awt.util.IdentityArrayList<java.awt.Window> getAllUnblockedWindows() {
        synchronized(java.awt.Window.allWindows) {
            sun.awt.util.IdentityArrayList<java.awt.Window> unblocked = new sun.awt.util.IdentityArrayList<java.awt.Window>();
            for (int i = 0 ; i < (java.awt.Window.allWindows.size()) ; i++) {
                java.awt.Window w = java.awt.Window.allWindows.get(i);
                if (!(w.isModalBlocked())) {
                    unblocked.add(w);
                } 
            }
            return unblocked;
        }
    }

    private static java.awt.Window[] getWindows(sun.awt.AppContext appContext) {
        synchronized(java.awt.Window.class) {
            java.awt.Window[] realCopy;
            @java.lang.SuppressWarnings(value = "unchecked")
            java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>> windowList = ((java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>>)(appContext.get(java.awt.Window.class)));
            if (windowList != null) {
                int fullSize = windowList.size();
                int realSize = 0;
                java.awt.Window[] fullCopy = new java.awt.Window[fullSize];
                for (int i = 0 ; i < fullSize ; i++) {
                    java.awt.Window w = windowList.get(i).get();
                    if (w != null) {
                        fullCopy[(realSize++)] = w;
                    } 
                }
                if (fullSize != realSize) {
                    realCopy = java.util.Arrays.copyOf(fullCopy, realSize);
                } else {
                    realCopy = fullCopy;
                }
            } else {
                realCopy = new java.awt.Window[0];
            }
            return realCopy;
        }
    }

    public static java.awt.Window[] getWindows() {
        return java.awt.Window.getWindows(sun.awt.AppContext.getAppContext());
    }

    public static java.awt.Window[] getOwnerlessWindows() {
        java.awt.Window[] allWindows = java.awt.Window.getWindows();
        int ownerlessCount = 0;
        for (java.awt.Window w : allWindows) {
            if ((w.getOwner()) == null) {
                ownerlessCount++;
            } 
        }
        java.awt.Window[] ownerless = new java.awt.Window[ownerlessCount];
        int c = 0;
        for (java.awt.Window w : allWindows) {
            if ((w.getOwner()) == null) {
                ownerless[(c++)] = w;
            } 
        }
        return ownerless;
    }

    java.awt.Window getDocumentRoot() {
        synchronized(getTreeLock()) {
            java.awt.Window w = java.awt.Window.this;
            while ((w.getOwner()) != null) {
                w = w.getOwner();
            }
            return w;
        }
    }

    public void setModalExclusionType(java.awt.Dialog.ModalExclusionType exclusionType) {
        if (exclusionType == null) {
            exclusionType = java.awt.Dialog.ModalExclusionType.NO_EXCLUDE;
        } 
        if (!(java.awt.Toolkit.getDefaultToolkit().isModalExclusionTypeSupported(exclusionType))) {
            exclusionType = java.awt.Dialog.ModalExclusionType.NO_EXCLUDE;
        } 
        if ((modalExclusionType) == exclusionType) {
            return ;
        } 
        if (exclusionType == (java.awt.Dialog.ModalExclusionType.TOOLKIT_EXCLUDE)) {
            java.lang.SecurityManager sm = java.lang.System.getSecurityManager();
            if (sm != null) {
                sm.checkPermission(sun.security.util.SecurityConstants.AWT.TOOLKIT_MODALITY_PERMISSION);
            } 
        } 
        modalExclusionType = exclusionType;
    }

    public java.awt.Dialog.ModalExclusionType getModalExclusionType() {
        return modalExclusionType;
    }

    boolean isModalExcluded(java.awt.Dialog.ModalExclusionType exclusionType) {
        if (((modalExclusionType) != null) && ((modalExclusionType.compareTo(exclusionType)) >= 0)) {
            return true;
        } 
        java.awt.Window owner = getOwner_NoClientCode();
        return (owner != null) && (owner.isModalExcluded(exclusionType));
    }

    void updateChildrenBlocking() {
        java.util.Vector<java.awt.Window> childHierarchy = new java.util.Vector<java.awt.Window>();
        java.awt.Window[] ownedWindows = getOwnedWindows();
        for (int i = 0 ; i < (ownedWindows.length) ; i++) {
            childHierarchy.add(ownedWindows[i]);
        }
        int k = 0;
        while (k < (childHierarchy.size())) {
            java.awt.Window w = childHierarchy.get(k);
            if (w.isVisible()) {
                if (w.isModalBlocked()) {
                    java.awt.Dialog blocker = w.getModalBlocker();
                    blocker.unblockWindow(w);
                } 
                java.awt.Dialog.checkShouldBeBlocked(w);
                java.awt.Window[] wOwned = w.getOwnedWindows();
                for (int j = 0 ; j < (wOwned.length) ; j++) {
                    childHierarchy.add(wOwned[j]);
                }
            } 
            k++;
        }
    }

    public synchronized void addWindowListener(java.awt.event.WindowListener l) {
        if (l == null) {
            return ;
        } 
        newEventsOnly = true;
        windowListener = java.awt.AWTEventMulticaster.add(windowListener, l);
    }

    public synchronized void addWindowStateListener(java.awt.event.WindowStateListener l) {
        if (l == null) {
            return ;
        } 
        windowStateListener = java.awt.AWTEventMulticaster.add(windowStateListener, l);
        newEventsOnly = true;
    }

    public synchronized void addWindowFocusListener(java.awt.event.WindowFocusListener l) {
        if (l == null) {
            return ;
        } 
        windowFocusListener = java.awt.AWTEventMulticaster.add(windowFocusListener, l);
        newEventsOnly = true;
    }

    public synchronized void removeWindowListener(java.awt.event.WindowListener l) {
        if (l == null) {
            return ;
        } 
        windowListener = java.awt.AWTEventMulticaster.remove(windowListener, l);
    }

    public synchronized void removeWindowStateListener(java.awt.event.WindowStateListener l) {
        if (l == null) {
            return ;
        } 
        windowStateListener = java.awt.AWTEventMulticaster.remove(windowStateListener, l);
    }

    public synchronized void removeWindowFocusListener(java.awt.event.WindowFocusListener l) {
        if (l == null) {
            return ;
        } 
        windowFocusListener = java.awt.AWTEventMulticaster.remove(windowFocusListener, l);
    }

    public synchronized java.awt.event.WindowListener[] getWindowListeners() {
        return getListeners(java.awt.event.WindowListener.class);
    }

    public synchronized java.awt.event.WindowFocusListener[] getWindowFocusListeners() {
        return getListeners(java.awt.event.WindowFocusListener.class);
    }

    public synchronized java.awt.event.WindowStateListener[] getWindowStateListeners() {
        return getListeners(java.awt.event.WindowStateListener.class);
    }

    public <T extends java.util.EventListener>T[] getListeners(java.lang.Class<T> listenerType) {
        java.util.EventListener l = null;
        if (listenerType == (java.awt.event.WindowFocusListener.class)) {
            l = windowFocusListener;
        } else if (listenerType == (java.awt.event.WindowStateListener.class)) {
            l = windowStateListener;
        } else if (listenerType == (java.awt.event.WindowListener.class)) {
            l = windowListener;
        } else {
            return super.getListeners(listenerType);
        }
        return java.awt.AWTEventMulticaster.getListeners(l, listenerType);
    }

    boolean eventEnabled(java.awt.AWTEvent e) {
        switch (e.id) {
            case java.awt.event.WindowEvent.WINDOW_OPENED :
            case java.awt.event.WindowEvent.WINDOW_CLOSING :
            case java.awt.event.WindowEvent.WINDOW_CLOSED :
            case java.awt.event.WindowEvent.WINDOW_ICONIFIED :
            case java.awt.event.WindowEvent.WINDOW_DEICONIFIED :
            case java.awt.event.WindowEvent.WINDOW_ACTIVATED :
            case java.awt.event.WindowEvent.WINDOW_DEACTIVATED :
                if ((((eventMask) & (java.awt.AWTEvent.WINDOW_EVENT_MASK)) != 0) || ((windowListener) != null)) {
                    return true;
                } 
                return false;
            case java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS :
            case java.awt.event.WindowEvent.WINDOW_LOST_FOCUS :
                if ((((eventMask) & (java.awt.AWTEvent.WINDOW_FOCUS_EVENT_MASK)) != 0) || ((windowFocusListener) != null)) {
                    return true;
                } 
                return false;
            case java.awt.event.WindowEvent.WINDOW_STATE_CHANGED :
                if ((((eventMask) & (java.awt.AWTEvent.WINDOW_STATE_EVENT_MASK)) != 0) || ((windowStateListener) != null)) {
                    return true;
                } 
                return false;
            default :
                break;
        }
        return super.eventEnabled(e);
    }

    protected void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.WindowEvent) {
            switch (e.getID()) {
                case java.awt.event.WindowEvent.WINDOW_OPENED :
                case java.awt.event.WindowEvent.WINDOW_CLOSING :
                case java.awt.event.WindowEvent.WINDOW_CLOSED :
                case java.awt.event.WindowEvent.WINDOW_ICONIFIED :
                case java.awt.event.WindowEvent.WINDOW_DEICONIFIED :
                case java.awt.event.WindowEvent.WINDOW_ACTIVATED :
                case java.awt.event.WindowEvent.WINDOW_DEACTIVATED :
                    processWindowEvent(((java.awt.event.WindowEvent)(e)));
                    break;
                case java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS :
                case java.awt.event.WindowEvent.WINDOW_LOST_FOCUS :
                    processWindowFocusEvent(((java.awt.event.WindowEvent)(e)));
                    break;
                case java.awt.event.WindowEvent.WINDOW_STATE_CHANGED :
                    processWindowStateEvent(((java.awt.event.WindowEvent)(e)));
                    break;
            }
            return ;
        } 
        super.processEvent(e);
    }

    protected void processWindowEvent(java.awt.event.WindowEvent e) {
        java.awt.event.WindowListener listener = windowListener;
        if (listener != null) {
            switch (e.getID()) {
                case java.awt.event.WindowEvent.WINDOW_OPENED :
                    listener.windowOpened(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_CLOSING :
                    listener.windowClosing(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_CLOSED :
                    listener.windowClosed(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_ICONIFIED :
                    listener.windowIconified(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_DEICONIFIED :
                    listener.windowDeiconified(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_ACTIVATED :
                    listener.windowActivated(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_DEACTIVATED :
                    listener.windowDeactivated(e);
                    break;
                default :
                    break;
            }
        } 
    }

    protected void processWindowFocusEvent(java.awt.event.WindowEvent e) {
        java.awt.event.WindowFocusListener listener = windowFocusListener;
        if (listener != null) {
            switch (e.getID()) {
                case java.awt.event.WindowEvent.WINDOW_GAINED_FOCUS :
                    listener.windowGainedFocus(e);
                    break;
                case java.awt.event.WindowEvent.WINDOW_LOST_FOCUS :
                    listener.windowLostFocus(e);
                    break;
                default :
                    break;
            }
        } 
    }

    protected void processWindowStateEvent(java.awt.event.WindowEvent e) {
        java.awt.event.WindowStateListener listener = windowStateListener;
        if (listener != null) {
            switch (e.getID()) {
                case java.awt.event.WindowEvent.WINDOW_STATE_CHANGED :
                    listener.windowStateChanged(e);
                    break;
                default :
                    break;
            }
        } 
    }

    void preProcessKeyEvent(java.awt.event.KeyEvent e) {
        if (((((e.isActionKey()) && ((e.getKeyCode()) == (java.awt.event.KeyEvent.VK_F1))) && (e.isControlDown())) && (e.isShiftDown())) && ((e.getID()) == (java.awt.event.KeyEvent.KEY_PRESSED))) {
            list(java.lang.System.out, 0);
        } 
    }

    void postProcessKeyEvent(java.awt.event.KeyEvent e) {
    }

    public final void setAlwaysOnTop(boolean alwaysOnTop) throws java.lang.SecurityException {
        java.lang.SecurityManager security = java.lang.System.getSecurityManager();
        if (security != null) {
            security.checkPermission(sun.security.util.SecurityConstants.AWT.SET_WINDOW_ALWAYS_ON_TOP_PERMISSION);
        } 
        boolean oldAlwaysOnTop;
        synchronized(java.awt.Window.this) {
            oldAlwaysOnTop = java.awt.Window.this.alwaysOnTop;
            java.awt.Window.this.alwaysOnTop = alwaysOnTop;
        }
        if (oldAlwaysOnTop != alwaysOnTop) {
            if (isAlwaysOnTopSupported()) {
                java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
                synchronized(getTreeLock()) {
                    if (peer != null) {
                        peer.updateAlwaysOnTopState();
                    } 
                }
            } 
            firePropertyChange("alwaysOnTop", oldAlwaysOnTop, alwaysOnTop);
        } 
        setOwnedWindowsAlwaysOnTop(alwaysOnTop);
    }

    @java.lang.SuppressWarnings(value = { "rawtypes" , "unchecked" })
    private void setOwnedWindowsAlwaysOnTop(boolean alwaysOnTop) {
        java.lang.ref.WeakReference<java.awt.Window>[] ownedWindowArray;
        synchronized(ownedWindowList) {
            ownedWindowArray = new java.lang.ref.WeakReference[ownedWindowList.size()];
            ownedWindowList.copyInto(ownedWindowArray);
        }
        for (java.lang.ref.WeakReference<java.awt.Window> ref : ownedWindowArray) {
            java.awt.Window window = ref.get();
            if (window != null) {
                try {
                    window.setAlwaysOnTop(alwaysOnTop);
                } catch (java.lang.SecurityException ignore) {
                }
            } 
        }
    }

    public boolean isAlwaysOnTopSupported() {
        return java.awt.Toolkit.getDefaultToolkit().isAlwaysOnTopSupported();
    }

    public final boolean isAlwaysOnTop() {
        return alwaysOnTop;
    }

    public java.awt.Component getFocusOwner() {
        return isFocused() ? java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner() : null;
    }

    public java.awt.Component getMostRecentFocusOwner() {
        if (isFocused()) {
            return getFocusOwner();
        } else {
            java.awt.Component mostRecent = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(java.awt.Window.this);
            if (mostRecent != null) {
                return mostRecent;
            } else {
                return isFocusableWindow() ? getFocusTraversalPolicy().getInitialComponent(java.awt.Window.this) : null;
            }
        }
    }

    public boolean isActive() {
        return (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getActiveWindow()) == (java.awt.Window.this);
    }

    public boolean isFocused() {
        return (java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getGlobalFocusedWindow()) == (java.awt.Window.this);
    }

    @java.lang.SuppressWarnings(value = "unchecked")
    public java.util.Set<java.awt.AWTKeyStroke> getFocusTraversalKeys(int id) {
        if ((id < 0) || (id >= (java.awt.KeyboardFocusManager.TRAVERSAL_KEY_LENGTH))) {
            throw new java.lang.IllegalArgumentException("invalid focus traversal key identifier");
        } 
        @java.lang.SuppressWarnings(value = "rawtypes")
        java.util.Set keystrokes = (focusTraversalKeys) != null ? focusTraversalKeys[id] : null;
        if (keystrokes != null) {
            return keystrokes;
        } else {
            return java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().getDefaultFocusTraversalKeys(id);
        }
    }

    public final void setFocusCycleRoot(boolean focusCycleRoot) {
    }

    public final boolean isFocusCycleRoot() {
        return true;
    }

    public final java.awt.Container getFocusCycleRootAncestor() {
        return null;
    }

    public final boolean isFocusableWindow() {
        if (!(getFocusableWindowState())) {
            return false;
        } 
        if (((java.awt.Window.this) instanceof java.awt.Frame) || ((java.awt.Window.this) instanceof java.awt.Dialog)) {
            return true;
        } 
        if ((getFocusTraversalPolicy().getDefaultComponent(java.awt.Window.this)) == null) {
            return false;
        } 
        for (java.awt.Window owner = getOwner() ; owner != null ; owner = owner.getOwner()) {
            if ((owner instanceof java.awt.Frame) || (owner instanceof java.awt.Dialog)) {
                return owner.isShowing();
            } 
        }
        return false;
    }

    public boolean getFocusableWindowState() {
        return focusableWindowState;
    }

    public void setFocusableWindowState(boolean focusableWindowState) {
        boolean oldFocusableWindowState;
        synchronized(java.awt.Window.this) {
            oldFocusableWindowState = java.awt.Window.this.focusableWindowState;
            java.awt.Window.this.focusableWindowState = focusableWindowState;
        }
        java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(java.awt.Window.this.peer));
        if (peer != null) {
            peer.updateFocusableWindowState();
        } 
        firePropertyChange("focusableWindowState", oldFocusableWindowState, focusableWindowState);
        if ((oldFocusableWindowState && (!focusableWindowState)) && (isFocused())) {
            for (java.awt.Window owner = getOwner() ; owner != null ; owner = owner.getOwner()) {
                java.awt.Component toFocus = java.awt.KeyboardFocusManager.getMostRecentFocusOwner(owner);
                if ((toFocus != null) && (toFocus.requestFocus(false, sun.awt.CausedFocusEvent.Cause.ACTIVATION))) {
                    return ;
                } 
            }
            java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwnerPriv();
        } 
    }

    public void setAutoRequestFocus(boolean autoRequestFocus) {
        java.awt.Window.this.autoRequestFocus = autoRequestFocus;
    }

    public boolean isAutoRequestFocus() {
        return autoRequestFocus;
    }

    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
        super.addPropertyChangeListener(listener);
    }

    public void addPropertyChangeListener(java.lang.String propertyName, java.beans.PropertyChangeListener listener) {
        super.addPropertyChangeListener(propertyName, listener);
    }

    @java.lang.Override
    public boolean isValidateRoot() {
        return true;
    }

    void dispatchEventImpl(java.awt.AWTEvent e) {
        if ((e.getID()) == (java.awt.event.ComponentEvent.COMPONENT_RESIZED)) {
            invalidate();
            validate();
        } 
        super.dispatchEventImpl(e);
    }

    @java.lang.Deprecated
    public boolean postEvent(java.awt.Event e) {
        if (handleEvent(e)) {
            e.consume();
            return true;
        } 
        return false;
    }

    public boolean isShowing() {
        return visible;
    }

    boolean isDisposing() {
        return disposing;
    }

    @java.lang.Deprecated
    public void applyResourceBundle(java.util.ResourceBundle rb) {
        applyComponentOrientation(java.awt.ComponentOrientation.getOrientation(rb));
    }

    @java.lang.Deprecated
    public void applyResourceBundle(java.lang.String rbName) {
        applyResourceBundle(java.util.ResourceBundle.getBundle(rbName));
    }

    void addOwnedWindow(java.lang.ref.WeakReference<java.awt.Window> weakWindow) {
        if (weakWindow != null) {
            synchronized(ownedWindowList) {
                if (!(ownedWindowList.contains(weakWindow))) {
                    ownedWindowList.addElement(weakWindow);
                } 
            }
        } 
    }

    void removeOwnedWindow(java.lang.ref.WeakReference<java.awt.Window> weakWindow) {
        if (weakWindow != null) {
            ownedWindowList.removeElement(weakWindow);
        } 
    }

    void connectOwnedWindow(java.awt.Window child) {
        child.parent = java.awt.Window.this;
        addOwnedWindow(child.weakThis);
        child.disposerRecord.updateOwner();
    }

    private void addToWindowList() {
        synchronized(java.awt.Window.class) {
            @java.lang.SuppressWarnings(value = "unchecked")
            java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>> windowList = ((java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>>)(appContext.get(java.awt.Window.class)));
            if (windowList == null) {
                windowList = new java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>>();
                appContext.put(java.awt.Window.class, windowList);
            } 
            windowList.add(weakThis);
        }
    }

    private static void removeFromWindowList(sun.awt.AppContext context, java.lang.ref.WeakReference<java.awt.Window> weakThis) {
        synchronized(java.awt.Window.class) {
            @java.lang.SuppressWarnings(value = "unchecked")
            java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>> windowList = ((java.util.Vector<java.lang.ref.WeakReference<java.awt.Window>>)(context.get(java.awt.Window.class)));
            if (windowList != null) {
                windowList.remove(weakThis);
            } 
        }
    }

    private void removeFromWindowList() {
        java.awt.Window.removeFromWindowList(appContext, weakThis);
    }

    private java.awt.Window.Type type = java.awt.Window.Type.NORMAL;

    public void setType(java.awt.Window.Type type) {
        if (type == null) {
            throw new java.lang.IllegalArgumentException("type should not be null.");
        } 
        synchronized(getTreeLock()) {
            if (isDisplayable()) {
                throw new java.awt.IllegalComponentStateException("The window is displayable.");
            } 
            synchronized(getObjectLock()) {
                java.awt.Window.this.type = type;
            }
        }
    }

    public java.awt.Window.Type getType() {
        synchronized(getObjectLock()) {
            return type;
        }
    }

    private int windowSerializedDataVersion = 2;

    private void writeObject(java.io.ObjectOutputStream s) throws java.io.IOException {
        synchronized(java.awt.Window.this) {
            focusMgr = new java.awt.FocusManager();
            focusMgr.focusRoot = java.awt.Window.this;
            focusMgr.focusOwner = getMostRecentFocusOwner();
            s.defaultWriteObject();
            focusMgr = null;
            java.awt.AWTEventMulticaster.save(s, java.awt.Component.windowListenerK, windowListener);
            java.awt.AWTEventMulticaster.save(s, java.awt.Component.windowFocusListenerK, windowFocusListener);
            java.awt.AWTEventMulticaster.save(s, java.awt.Component.windowStateListenerK, windowStateListener);
        }
        s.writeObject(null);
        synchronized(ownedWindowList) {
            for (int i = 0 ; i < (ownedWindowList.size()) ; i++) {
                java.awt.Window child = ownedWindowList.elementAt(i).get();
                if (child != null) {
                    s.writeObject(java.awt.Component.ownedWindowK);
                    s.writeObject(child);
                } 
            }
        }
        s.writeObject(null);
        if ((icons) != null) {
            for (java.awt.Image i : icons) {
                if (i instanceof java.io.Serializable) {
                    s.writeObject(i);
                } 
            }
        } 
        s.writeObject(null);
    }

    private void initDeserializedWindow() {
        setWarningString();
        inputContextLock = new java.lang.Object();
        visible = false;
        weakThis = new java.lang.ref.WeakReference<>(java.awt.Window.this);
        anchor = new java.lang.Object();
        disposerRecord = new java.awt.Window.WindowDisposerRecord(appContext , java.awt.Window.this);
        sun.java2d.Disposer.addRecord(anchor, disposerRecord);
        addToWindowList();
        initGC(null);
        ownedWindowList = new java.util.Vector<>();
    }

    private void deserializeResources(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        if ((windowSerializedDataVersion) < 2) {
            if ((focusMgr) != null) {
                if ((focusMgr.focusOwner) != null) {
                    java.awt.KeyboardFocusManager.setMostRecentFocusOwner(java.awt.Window.this, focusMgr.focusOwner);
                } 
            } 
            focusableWindowState = true;
        } 
        java.lang.Object keyOrNull;
        while (null != (keyOrNull = s.readObject())) {
            java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
            if ((java.awt.Component.windowListenerK) == key) {
                addWindowListener(((java.awt.event.WindowListener)(s.readObject())));
            } else if ((java.awt.Component.windowFocusListenerK) == key) {
                addWindowFocusListener(((java.awt.event.WindowFocusListener)(s.readObject())));
            } else if ((java.awt.Component.windowStateListenerK) == key) {
                addWindowStateListener(((java.awt.event.WindowStateListener)(s.readObject())));
            } else
                s.readObject();
            
        }
        try {
            while (null != (keyOrNull = s.readObject())) {
                java.lang.String key = ((java.lang.String)(keyOrNull)).intern();
                if ((java.awt.Component.ownedWindowK) == key)
                    connectOwnedWindow(((java.awt.Window)(s.readObject())));
                else
                    s.readObject();
                
            }
            java.lang.Object obj = s.readObject();
            icons = new java.util.ArrayList<java.awt.Image>();
            while (obj != null) {
                if (obj instanceof java.awt.Image) {
                    icons.add(((java.awt.Image)(obj)));
                } 
                obj = s.readObject();
            }
        } catch (java.io.OptionalDataException e) {
        }
    }

    private void readObject(java.io.ObjectInputStream s) throws java.awt.HeadlessException, java.io.IOException, java.lang.ClassNotFoundException {
        java.awt.GraphicsEnvironment.checkHeadless();
        initDeserializedWindow();
        java.io.ObjectInputStream.GetField f = s.readFields();
        syncLWRequests = f.get("syncLWRequests", java.awt.Window.systemSyncLWRequests);
        state = f.get("state", 0);
        focusableWindowState = f.get("focusableWindowState", true);
        windowSerializedDataVersion = f.get("windowSerializedDataVersion", 1);
        locationByPlatform = f.get("locationByPlatform", java.awt.Window.locationByPlatformProp);
        focusMgr = ((java.awt.FocusManager)(f.get("focusMgr", null)));
        java.awt.Dialog.ModalExclusionType et = ((java.awt.Dialog.ModalExclusionType)(f.get("modalExclusionType", java.awt.Dialog.ModalExclusionType.NO_EXCLUDE)));
        setModalExclusionType(et);
        boolean aot = f.get("alwaysOnTop", false);
        if (aot) {
            setAlwaysOnTop(aot);
        } 
        shape = ((java.awt.Shape)(f.get("shape", null)));
        opacity = ((java.lang.Float)(f.get("opacity", 1.0F)));
        java.awt.Window.this.securityWarningWidth = 0;
        java.awt.Window.this.securityWarningHeight = 0;
        java.awt.Window.this.securityWarningPointX = 2.0;
        java.awt.Window.this.securityWarningPointY = 0.0;
        java.awt.Window.this.securityWarningAlignmentX = java.awt.Component.RIGHT_ALIGNMENT;
        java.awt.Window.this.securityWarningAlignmentY = java.awt.Component.TOP_ALIGNMENT;
        deserializeResources(s);
    }

    public javax.accessibility.AccessibleContext getAccessibleContext() {
        if ((accessibleContext) == null) {
            accessibleContext = new java.awt.Window.AccessibleAWTWindow();
        } 
        return accessibleContext;
    }

    protected class AccessibleAWTWindow extends java.awt.Container.AccessibleAWTContainer {
        private static final long serialVersionUID = 4215068635060671780L;

        public javax.accessibility.AccessibleRole getAccessibleRole() {
            return javax.accessibility.AccessibleRole.WINDOW;
        }

        public javax.accessibility.AccessibleStateSet getAccessibleStateSet() {
            javax.accessibility.AccessibleStateSet states = super.getAccessibleStateSet();
            if ((getFocusOwner()) != null) {
                states.add(javax.accessibility.AccessibleState.ACTIVE);
            } 
            return states;
        }
    }

    @java.lang.Override
    void setGraphicsConfiguration(java.awt.GraphicsConfiguration gc) {
        if (gc == null) {
            gc = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
        } 
        synchronized(getTreeLock()) {
            super.setGraphicsConfiguration(gc);
            if (java.awt.Window.log.isLoggable(sun.util.logging.PlatformLogger.Level.FINER)) {
                java.awt.Window.log.finer(((("+ Window.setGraphicsConfiguration(): new GC is \n+ " + (getGraphicsConfiguration_NoClientCode())) + "\n+ this is ") + (java.awt.Window.this)));
            } 
        }
    }

    public void setLocationRelativeTo(java.awt.Component c) {
        int dx = 0;
        int dy = 0;
        java.awt.GraphicsConfiguration gc = getGraphicsConfiguration_NoClientCode();
        java.awt.Rectangle gcBounds = gc.getBounds();
        java.awt.Dimension windowSize = getSize();
        java.awt.Window componentWindow = sun.awt.SunToolkit.getContainingWindow(c);
        if ((c == null) || (componentWindow == null)) {
            java.awt.GraphicsEnvironment ge = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment();
            gc = ge.getDefaultScreenDevice().getDefaultConfiguration();
            gcBounds = gc.getBounds();
            java.awt.Point centerPoint = ge.getCenterPoint();
            dx = (centerPoint.x) - ((windowSize.width) / 2);
            dy = (centerPoint.y) - ((windowSize.height) / 2);
        } else if (!(c.isShowing())) {
            gc = componentWindow.getGraphicsConfiguration();
            gcBounds = gc.getBounds();
            dx = (gcBounds.x) + (((gcBounds.width) - (windowSize.width)) / 2);
            dy = (gcBounds.y) + (((gcBounds.height) - (windowSize.height)) / 2);
        } else {
            gc = componentWindow.getGraphicsConfiguration();
            gcBounds = gc.getBounds();
            java.awt.Dimension compSize = c.getSize();
            java.awt.Point compLocation = c.getLocationOnScreen();
            dx = (compLocation.x) + (((compSize.width) - (windowSize.width)) / 2);
            dy = (compLocation.y) + (((compSize.height) - (windowSize.height)) / 2);
            if ((dy + (windowSize.height)) > ((gcBounds.y) + (gcBounds.height))) {
                dy = ((gcBounds.y) + (gcBounds.height)) - (windowSize.height);
                if ((((compLocation.x) - (gcBounds.x)) + ((compSize.width) / 2)) < ((gcBounds.width) / 2)) {
                    dx = (compLocation.x) + (compSize.width);
                } else {
                    dx = (compLocation.x) - (windowSize.width);
                }
            } 
        }
        if ((dy + (windowSize.height)) > ((gcBounds.y) + (gcBounds.height))) {
            dy = ((gcBounds.y) + (gcBounds.height)) - (windowSize.height);
        } 
        if (dy < (gcBounds.y)) {
            dy = gcBounds.y;
        } 
        if ((dx + (windowSize.width)) > ((gcBounds.x) + (gcBounds.width))) {
            dx = ((gcBounds.x) + (gcBounds.width)) - (windowSize.width);
        } 
        if (dx < (gcBounds.x)) {
            dx = gcBounds.x;
        } 
        setLocation(dx, dy);
    }

    void deliverMouseWheelToAncestor(java.awt.event.MouseWheelEvent e) {
    }

    boolean dispatchMouseWheelToAncestor(java.awt.event.MouseWheelEvent e) {
        return false;
    }

    public void createBufferStrategy(int numBuffers) {
        super.createBufferStrategy(numBuffers);
    }

    public void createBufferStrategy(int numBuffers, java.awt.BufferCapabilities caps) throws java.awt.AWTException {
        super.createBufferStrategy(numBuffers, caps);
    }

    public java.awt.image.BufferStrategy getBufferStrategy() {
        return super.getBufferStrategy();
    }

    java.awt.Component getTemporaryLostComponent() {
        return temporaryLostComponent;
    }

    java.awt.Component setTemporaryLostComponent(java.awt.Component component) {
        java.awt.Component previousComp = temporaryLostComponent;
        if ((component == null) || (component.canBeFocusOwner())) {
            temporaryLostComponent = component;
        } else {
            temporaryLostComponent = null;
        }
        return previousComp;
    }

    boolean canContainFocusOwner(java.awt.Component focusOwnerCandidate) {
        return (super.canContainFocusOwner(focusOwnerCandidate)) && (isFocusableWindow());
    }

    private boolean locationByPlatform = java.awt.Window.locationByPlatformProp;

    public void setLocationByPlatform(boolean locationByPlatform) {
        synchronized(getTreeLock()) {
            if (locationByPlatform && (isShowing())) {
                throw new java.awt.IllegalComponentStateException("The window is showing on screen.");
            } 
            java.awt.Window.this.locationByPlatform = locationByPlatform;
        }
    }

    public boolean isLocationByPlatform() {
        synchronized(getTreeLock()) {
            return locationByPlatform;
        }
    }

    public void setBounds(int x, int y, int width, int height) {
        synchronized(getTreeLock()) {
            if (((getBoundsOp()) == (java.awt.peer.ComponentPeer.SET_LOCATION)) || ((getBoundsOp()) == (java.awt.peer.ComponentPeer.SET_BOUNDS))) {
                locationByPlatform = false;
            } 
            super.setBounds(x, y, width, height);
        }
    }

    public void setBounds(java.awt.Rectangle r) {
        setBounds(r.x, r.y, r.width, r.height);
    }

    boolean isRecursivelyVisible() {
        return visible;
    }

    public float getOpacity() {
        synchronized(getTreeLock()) {
            return opacity;
        }
    }

    public void setOpacity(float opacity) {
        synchronized(getTreeLock()) {
            if ((opacity < 0.0F) || (opacity > 1.0F)) {
                throw new java.lang.IllegalArgumentException("The value of opacity should be in the range [0.0f .. 1.0f].");
            } 
            if (opacity < 1.0F) {
                java.awt.GraphicsConfiguration gc = getGraphicsConfiguration();
                java.awt.GraphicsDevice gd = gc.getDevice();
                if ((gc.getDevice().getFullScreenWindow()) == (java.awt.Window.this)) {
                    throw new java.awt.IllegalComponentStateException("Setting opacity for full-screen window is not supported.");
                } 
                if (!(gd.isWindowTranslucencySupported(java.awt.GraphicsDevice.WindowTranslucency.TRANSLUCENT))) {
                    throw new java.lang.UnsupportedOperationException("TRANSLUCENT translucency is not supported.");
                } 
            } 
            java.awt.Window.this.opacity = opacity;
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(getPeer()));
            if (peer != null) {
                peer.setOpacity(opacity);
            } 
        }
    }

    public java.awt.Shape getShape() {
        synchronized(getTreeLock()) {
            return (shape) == null ? null : new java.awt.geom.Path2D.Float(shape);
        }
    }

    public void setShape(java.awt.Shape shape) {
        synchronized(getTreeLock()) {
            if (shape != null) {
                java.awt.GraphicsConfiguration gc = getGraphicsConfiguration();
                java.awt.GraphicsDevice gd = gc.getDevice();
                if ((gc.getDevice().getFullScreenWindow()) == (java.awt.Window.this)) {
                    throw new java.awt.IllegalComponentStateException("Setting shape for full-screen window is not supported.");
                } 
                if (!(gd.isWindowTranslucencySupported(java.awt.GraphicsDevice.WindowTranslucency.PERPIXEL_TRANSPARENT))) {
                    throw new java.lang.UnsupportedOperationException("PERPIXEL_TRANSPARENT translucency is not supported.");
                } 
            } 
            java.awt.Window.this.shape = shape == null ? null : new java.awt.geom.Path2D.Float(shape);
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(getPeer()));
            if (peer != null) {
                peer.applyShape((shape == null ? null : sun.java2d.pipe.Region.getInstance(shape, null)));
            } 
        }
    }

    @java.lang.Override
    public java.awt.Color getBackground() {
        return super.getBackground();
    }

    @java.lang.Override
    public void setBackground(java.awt.Color bgColor) {
        java.awt.Color oldBg = getBackground();
        super.setBackground(bgColor);
        if ((oldBg != null) && (oldBg.equals(bgColor))) {
            return ;
        } 
        int oldAlpha = oldBg != null ? oldBg.getAlpha() : 255;
        int alpha = bgColor != null ? bgColor.getAlpha() : 255;
        if ((oldAlpha == 255) && (alpha < 255)) {
            java.awt.GraphicsConfiguration gc = getGraphicsConfiguration();
            java.awt.GraphicsDevice gd = gc.getDevice();
            if ((gc.getDevice().getFullScreenWindow()) == (java.awt.Window.this)) {
                throw new java.awt.IllegalComponentStateException("Making full-screen window non opaque is not supported.");
            } 
            if (!(gc.isTranslucencyCapable())) {
                java.awt.GraphicsConfiguration capableGC = gd.getTranslucencyCapableGC();
                if (capableGC == null) {
                    throw new java.lang.UnsupportedOperationException("PERPIXEL_TRANSLUCENT translucency is not supported");
                } 
                setGraphicsConfiguration(capableGC);
            } 
            java.awt.Window.setLayersOpaque(java.awt.Window.this, false);
        } else if ((oldAlpha < 255) && (alpha == 255)) {
            java.awt.Window.setLayersOpaque(java.awt.Window.this, true);
        } 
        java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(getPeer()));
        if (peer != null) {
            peer.setOpaque((alpha == 255));
        } 
    }

    @java.lang.Override
    public boolean isOpaque() {
        java.awt.Color bg = getBackground();
        return bg != null ? (bg.getAlpha()) == 255 : true;
    }

    private void updateWindow() {
        synchronized(getTreeLock()) {
            java.awt.peer.WindowPeer peer = ((java.awt.peer.WindowPeer)(getPeer()));
            if (peer != null) {
                peer.updateWindow();
            } 
        }
    }

    @java.lang.Override
    public void paint(java.awt.Graphics g) {
        if (!(isOpaque())) {
            java.awt.Graphics gg = g.create();
            try {
                if (gg instanceof java.awt.Graphics2D) {
                    gg.setColor(getBackground());
                    ((java.awt.Graphics2D)(gg)).setComposite(java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.SRC));
                    gg.fillRect(0, 0, getWidth(), getHeight());
                } 
            } finally {
                gg.dispose();
            }
        } 
        super.paint(g);
    }

    private static void setLayersOpaque(java.awt.Component component, boolean isOpaque) {
        if (sun.awt.SunToolkit.isInstanceOf(component, "javax.swing.RootPaneContainer")) {
            javax.swing.RootPaneContainer rpc = ((javax.swing.RootPaneContainer)(component));
            javax.swing.JRootPane root = rpc.getRootPane();
            javax.swing.JLayeredPane lp = root.getLayeredPane();
            java.awt.Container c = root.getContentPane();
            javax.swing.JComponent content = c instanceof javax.swing.JComponent ? ((javax.swing.JComponent)(c)) : null;
            lp.setOpaque(isOpaque);
            root.setOpaque(isOpaque);
            if (content != null) {
                content.setOpaque(isOpaque);
                int numChildren = content.getComponentCount();
                if (numChildren > 0) {
                    java.awt.Component child = content.getComponent(0);
                    if (child instanceof javax.swing.RootPaneContainer) {
                        java.awt.Window.setLayersOpaque(child, isOpaque);
                    } 
                } 
            } 
        } 
    }

    @java.lang.Override
    final java.awt.Container getContainer() {
        return null;
    }

    @java.lang.Override
    final void applyCompoundShape(sun.java2d.pipe.Region shape) {
    }

    @java.lang.Override
    final void applyCurrentShape() {
    }

    @java.lang.Override
    final void mixOnReshaping() {
    }

    @java.lang.Override
    final java.awt.Point getLocationOnWindow() {
        return new java.awt.Point(0 , 0);
    }

    private static double limit(double value, double min, double max) {
        value = java.lang.Math.max(value, min);
        value = java.lang.Math.min(value, max);
        return value;
    }

    private java.awt.geom.Point2D calculateSecurityWarningPosition(double x, double y, double w, double h) {
        double wx = (x + (w * (securityWarningAlignmentX))) + (securityWarningPointX);
        double wy = (y + (h * (securityWarningAlignmentY))) + (securityWarningPointY);
        wx = java.awt.Window.limit(wx, ((x - (securityWarningWidth)) - 2), ((x + w) + 2));
        wy = java.awt.Window.limit(wy, ((y - (securityWarningHeight)) - 2), ((y + h) + 2));
        java.awt.GraphicsConfiguration graphicsConfig = getGraphicsConfiguration_NoClientCode();
        java.awt.Rectangle screenBounds = graphicsConfig.getBounds();
        java.awt.Insets screenInsets = java.awt.Toolkit.getDefaultToolkit().getScreenInsets(graphicsConfig);
        wx = java.awt.Window.limit(wx, ((screenBounds.x) + (screenInsets.left)), ((((screenBounds.x) + (screenBounds.width)) - (screenInsets.right)) - (securityWarningWidth)));
        wy = java.awt.Window.limit(wy, ((screenBounds.y) + (screenInsets.top)), ((((screenBounds.y) + (screenBounds.height)) - (screenInsets.bottom)) - (securityWarningHeight)));
        return new java.awt.geom.Point2D.Double(wx , wy);
    }

    @java.lang.Override
    void updateZOrder() {
    }
}


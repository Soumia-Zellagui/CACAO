package java.awt;


public final class AlphaComposite implements java.awt.Composite {
    @java.lang.annotation.Native
    public static final int CLEAR = 1;

    @java.lang.annotation.Native
    public static final int SRC = 2;

    @java.lang.annotation.Native
    public static final int DST = 9;

    @java.lang.annotation.Native
    public static final int SRC_OVER = 3;

    @java.lang.annotation.Native
    public static final int DST_OVER = 4;

    @java.lang.annotation.Native
    public static final int SRC_IN = 5;

    @java.lang.annotation.Native
    public static final int DST_IN = 6;

    @java.lang.annotation.Native
    public static final int SRC_OUT = 7;

    @java.lang.annotation.Native
    public static final int DST_OUT = 8;

    @java.lang.annotation.Native
    public static final int SRC_ATOP = 10;

    @java.lang.annotation.Native
    public static final int DST_ATOP = 11;

    @java.lang.annotation.Native
    public static final int XOR = 12;

    public static final java.awt.AlphaComposite Clear = new java.awt.AlphaComposite(java.awt.AlphaComposite.CLEAR);

    public static final java.awt.AlphaComposite Src = new java.awt.AlphaComposite(java.awt.AlphaComposite.SRC);

    public static final java.awt.AlphaComposite Dst = new java.awt.AlphaComposite(java.awt.AlphaComposite.DST);

    public static final java.awt.AlphaComposite SrcOver = new java.awt.AlphaComposite(java.awt.AlphaComposite.SRC_OVER);

    public static final java.awt.AlphaComposite DstOver = new java.awt.AlphaComposite(java.awt.AlphaComposite.DST_OVER);

    public static final java.awt.AlphaComposite SrcIn = new java.awt.AlphaComposite(java.awt.AlphaComposite.SRC_IN);

    public static final java.awt.AlphaComposite DstIn = new java.awt.AlphaComposite(java.awt.AlphaComposite.DST_IN);

    public static final java.awt.AlphaComposite SrcOut = new java.awt.AlphaComposite(java.awt.AlphaComposite.SRC_OUT);

    public static final java.awt.AlphaComposite DstOut = new java.awt.AlphaComposite(java.awt.AlphaComposite.DST_OUT);

    public static final java.awt.AlphaComposite SrcAtop = new java.awt.AlphaComposite(java.awt.AlphaComposite.SRC_ATOP);

    public static final java.awt.AlphaComposite DstAtop = new java.awt.AlphaComposite(java.awt.AlphaComposite.DST_ATOP);

    public static final java.awt.AlphaComposite Xor = new java.awt.AlphaComposite(java.awt.AlphaComposite.XOR);

    @java.lang.annotation.Native
    private static final int MIN_RULE = java.awt.AlphaComposite.CLEAR;

    @java.lang.annotation.Native
    private static final int MAX_RULE = java.awt.AlphaComposite.XOR;

    float extraAlpha;

    int rule;

    private AlphaComposite(int rule) {
        this(rule, 1.0F);
    }

    private AlphaComposite(int rule ,float alpha) {
        if ((rule < (java.awt.AlphaComposite.MIN_RULE)) || (rule > (java.awt.AlphaComposite.MAX_RULE))) {
            throw new java.lang.IllegalArgumentException("unknown composite rule");
        } 
        if ((alpha >= 0.0F) && (alpha <= 1.0F)) {
            java.awt.AlphaComposite.this.rule = rule;
            java.awt.AlphaComposite.this.extraAlpha = alpha;
        } else {
            throw new java.lang.IllegalArgumentException("alpha value out of range");
        }
    }

    public static java.awt.AlphaComposite getInstance(int rule) {
        switch (rule) {
            case java.awt.AlphaComposite.CLEAR :
                return java.awt.AlphaComposite.Clear;
            case java.awt.AlphaComposite.SRC :
                return java.awt.AlphaComposite.Src;
            case java.awt.AlphaComposite.DST :
                return java.awt.AlphaComposite.Dst;
            case java.awt.AlphaComposite.SRC_OVER :
                return java.awt.AlphaComposite.SrcOver;
            case java.awt.AlphaComposite.DST_OVER :
                return java.awt.AlphaComposite.DstOver;
            case java.awt.AlphaComposite.SRC_IN :
                return java.awt.AlphaComposite.SrcIn;
            case java.awt.AlphaComposite.DST_IN :
                return java.awt.AlphaComposite.DstIn;
            case java.awt.AlphaComposite.SRC_OUT :
                return java.awt.AlphaComposite.SrcOut;
            case java.awt.AlphaComposite.DST_OUT :
                return java.awt.AlphaComposite.DstOut;
            case java.awt.AlphaComposite.SRC_ATOP :
                return java.awt.AlphaComposite.SrcAtop;
            case java.awt.AlphaComposite.DST_ATOP :
                return java.awt.AlphaComposite.DstAtop;
            case java.awt.AlphaComposite.XOR :
                return java.awt.AlphaComposite.Xor;
            default :
                throw new java.lang.IllegalArgumentException("unknown composite rule");
        }
    }

    public static java.awt.AlphaComposite getInstance(int rule, float alpha) {
        if (alpha == 1.0F) {
            return java.awt.AlphaComposite.getInstance(rule);
        } 
        return new java.awt.AlphaComposite(rule , alpha);
    }

    public java.awt.CompositeContext createContext(java.awt.image.ColorModel srcColorModel, java.awt.image.ColorModel dstColorModel, java.awt.RenderingHints hints) {
        return new sun.java2d.SunCompositeContext(java.awt.AlphaComposite.this , srcColorModel , dstColorModel);
    }

    public float getAlpha() {
        return extraAlpha;
    }

    public int getRule() {
        return rule;
    }

    public java.awt.AlphaComposite derive(int rule) {
        return (java.awt.AlphaComposite.this.rule) == rule ? java.awt.AlphaComposite.this : java.awt.AlphaComposite.getInstance(rule, java.awt.AlphaComposite.this.extraAlpha);
    }

    public java.awt.AlphaComposite derive(float alpha) {
        return (java.awt.AlphaComposite.this.extraAlpha) == alpha ? java.awt.AlphaComposite.this : java.awt.AlphaComposite.getInstance(java.awt.AlphaComposite.this.rule, alpha);
    }

    public int hashCode() {
        return ((java.lang.Float.floatToIntBits(extraAlpha)) * 31) + (rule);
    }

    public boolean equals(java.lang.Object obj) {
        if (!(obj instanceof java.awt.AlphaComposite)) {
            return false;
        } 
        java.awt.AlphaComposite ac = ((java.awt.AlphaComposite)(obj));
        if ((rule) != (ac.rule)) {
            return false;
        } 
        if ((extraAlpha) != (ac.extraAlpha)) {
            return false;
        } 
        return true;
    }
}


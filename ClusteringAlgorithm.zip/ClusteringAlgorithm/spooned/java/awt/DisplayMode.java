package java.awt;


public final class DisplayMode {
    private java.awt.Dimension size;

    private int bitDepth;

    private int refreshRate;

    public DisplayMode(int width ,int height ,int bitDepth ,int refreshRate) {
        java.awt.DisplayMode.this.size = new java.awt.Dimension(width , height);
        java.awt.DisplayMode.this.bitDepth = bitDepth;
        java.awt.DisplayMode.this.refreshRate = refreshRate;
    }

    public int getHeight() {
        return size.height;
    }

    public int getWidth() {
        return size.width;
    }

    @java.lang.annotation.Native
    public static final int BIT_DEPTH_MULTI = -1;

    public int getBitDepth() {
        return bitDepth;
    }

    @java.lang.annotation.Native
    public static final int REFRESH_RATE_UNKNOWN = 0;

    public int getRefreshRate() {
        return refreshRate;
    }

    public boolean equals(java.awt.DisplayMode dm) {
        if (dm == null) {
            return false;
        } 
        return ((((getHeight()) == (dm.getHeight())) && ((getWidth()) == (dm.getWidth()))) && ((getBitDepth()) == (dm.getBitDepth()))) && ((getRefreshRate()) == (dm.getRefreshRate()));
    }

    public boolean equals(java.lang.Object dm) {
        if (dm instanceof java.awt.DisplayMode) {
            return equals(((java.awt.DisplayMode)(dm)));
        } else {
            return false;
        }
    }

    public int hashCode() {
        return (((getWidth()) + (getHeight())) + ((getBitDepth()) * 7)) + ((getRefreshRate()) * 13);
    }
}


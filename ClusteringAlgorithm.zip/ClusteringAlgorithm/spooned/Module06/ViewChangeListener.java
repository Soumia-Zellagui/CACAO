package Module06;


public interface ViewChangeListener extends java.util.EventListener {
    public void viewSelectionChanged(Module03.DrawingView oldView, Module03.DrawingView newView);

    public void viewCreated(Module03.DrawingView view);

    public void viewDestroying(Module03.DrawingView view);
}


package Module06;


public class StandardDisposableResourceManager implements Module06.DisposableResourceManager {
    private java.util.WeakHashMap resources;

    private Module06.ResourceDisposabilityStrategy strategy;

    public StandardDisposableResourceManager(Module06.ResourceDisposabilityStrategy newStrategy) {
        resources = new java.util.WeakHashMap();
        setStrategy(newStrategy);
        getStrategy().setManager(Module06.StandardDisposableResourceManager.this);
    }

    public synchronized void registerResource(Module06.DisposableResourceHolder resource) {
        resources.put(resource, resource);
    }

    public synchronized void unregisterResource(Module06.DisposableResourceHolder resource) {
        resources.remove(resource);
    }

    public java.util.Iterator getResources() {
        return resources.values().iterator();
    }

    public synchronized boolean managesResource(Module06.DisposableResourceHolder resource) {
        return resources.containsValue(resource);
    }

    public Module06.ResourceDisposabilityStrategy getStrategy() {
        return strategy;
    }

    public void setStrategy(Module06.ResourceDisposabilityStrategy newStrategy) {
        strategy = newStrategy;
    }

    public void startDisposing() throws Module06.ResourceManagerNotSetException {
        getStrategy().startDisposing();
    }

    public void stopDisposing(long millis) {
        getStrategy().stopDisposing(millis);
    }
}


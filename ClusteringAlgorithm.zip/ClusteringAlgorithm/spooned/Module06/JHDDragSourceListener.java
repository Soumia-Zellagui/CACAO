package Module06;


public class JHDDragSourceListener implements java.awt.dnd.DragSourceListener {
    private Module06.Undoable sourceUndoable;

    private java.lang.Boolean autoscrollState;

    private Module01.DrawingEditor editor;

    public JHDDragSourceListener(Module01.DrawingEditor newEditor ,Module03.DrawingView newView) {
        Module06.JHDDragSourceListener.this.editor = newEditor;
    }

    protected Module01.DrawingEditor editor() {
        return editor;
    }

    public void dragDropEnd(java.awt.dnd.DragSourceDropEvent dsde) {
        Module03.DrawingView view = ((Module03.DrawingView)(dsde.getDragSourceContext().getComponent()));
        Module06.JHDDragSourceListener.log("DragSourceDropEvent-dragDropEnd");
        if ((dsde.getDropSuccess()) == true) {
            if ((dsde.getDropAction()) == (java.awt.dnd.DnDConstants.ACTION_MOVE)) {
                Module06.JHDDragSourceListener.log("DragSourceDropEvent-ACTION_MOVE");
                setSourceUndoActivity(createSourceUndoActivity(view));
                Module03.DNDFigures df = ((Module03.DNDFigures)(Module03.DNDHelper.processReceivedData(Module03.DNDFiguresTransferable.DNDFiguresFlavor, dsde.getDragSourceContext().getTransferable())));
                getSourceUndoActivity().setAffectedFigures(df.getFigures());
                Module03.DeleteFromDrawingVisitor deleteVisitor = new Module03.DeleteFromDrawingVisitor(view.drawing());
                Module03.FigureEnumeration fe = getSourceUndoActivity().getAffectedFigures();
                while (fe.hasNextFigure()) {
                    fe.nextFigure().visit(deleteVisitor);
                }
                view.clearSelection();
                view.checkDamage();
                editor().getUndoManager().pushUndo(getSourceUndoActivity());
                editor().getUndoManager().clearRedos();
                editor().figureSelectionChanged(view);
            } else if ((dsde.getDropAction()) == (java.awt.dnd.DnDConstants.ACTION_COPY)) {
                Module06.JHDDragSourceListener.log("DragSourceDropEvent-ACTION_COPY");
            } 
        } 
        if ((autoscrollState) != null) {
            java.awt.Component c = dsde.getDragSourceContext().getComponent();
            if (javax.swing.JComponent.class.isInstance(c)) {
                javax.swing.JComponent jc = ((javax.swing.JComponent)(c));
                jc.setAutoscrolls(autoscrollState.booleanValue());
                autoscrollState = null;
            } 
        } 
    }

    public void dragEnter(java.awt.dnd.DragSourceDragEvent dsde) {
        Module06.JHDDragSourceListener.log("DragSourceDragEvent-dragEnter");
        if ((autoscrollState) == null) {
            java.awt.Component c = dsde.getDragSourceContext().getComponent();
            if (javax.swing.JComponent.class.isInstance(c)) {
                javax.swing.JComponent jc = ((javax.swing.JComponent)(c));
                autoscrollState = new java.lang.Boolean(jc.getAutoscrolls());
                jc.setAutoscrolls(false);
            } 
        } 
    }

    public void dragExit(java.awt.dnd.DragSourceEvent dse) {
    }

    public void dragOver(java.awt.dnd.DragSourceDragEvent dsde) {
    }

    public void dropActionChanged(java.awt.dnd.DragSourceDragEvent dsde) {
        Module06.JHDDragSourceListener.log("DragSourceDragEvent-dropActionChanged");
    }

    protected Module06.Undoable createSourceUndoActivity(Module03.DrawingView drawingView) {
        Module06.JHDDragSourceListener.RemoveUndoActivity removeUndoActivity = new Module06.JHDDragSourceListener.RemoveUndoActivity(drawingView);
        return removeUndoActivity;
    }

    protected void setSourceUndoActivity(Module06.Undoable undoable) {
        sourceUndoable = undoable;
    }

    protected Module06.Undoable getSourceUndoActivity() {
        return sourceUndoable;
    }

    public static class RemoveUndoActivity extends Module06.UndoableAdapter {
        private boolean undone = false;

        public RemoveUndoActivity(Module03.DrawingView view) {
            super(view);
            Module06.JHDDragSourceListener.log(("RemoveUndoActivity created " + view));
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (isUndoable()) {
                if (getAffectedFigures().hasNextFigure()) {
                    Module06.JHDDragSourceListener.log("RemoveUndoActivity undo");
                    getDrawingView().clearSelection();
                    setAffectedFigures(getDrawingView().insertFigures(getAffectedFigures(), 0, 0, false));
                    undone = true;
                    return true;
                } 
            } 
            return false;
        }

        public boolean redo() {
            if (isRedoable()) {
                Module06.JHDDragSourceListener.log("RemoveUndoActivity redo");
                Module03.DeleteFromDrawingVisitor deleteVisitor = new Module03.DeleteFromDrawingVisitor(getDrawingView().drawing());
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    fe.nextFigure().visit(deleteVisitor);
                }
                getDrawingView().clearSelection();
                setAffectedFigures(deleteVisitor.getDeletedFigures());
                undone = false;
                return true;
            } 
            return false;
        }

        public void release() {
            if ((undone) == false) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    Module03.Figure f = fe.nextFigure();
                    getDrawingView().drawing().remove(f);
                    f.release();
                }
            } 
            setAffectedFigures(Module03.FigureEnumerator.getEmptyEnumeration());
        }
    }

    private static void log(java.lang.String message) {
    }
}


package Module06;


public interface ResourceDisposabilityStrategy {
    public void setManager(Module06.DisposableResourceManager manager);

    public Module06.DisposableResourceManager getManager();

    public void startDisposing() throws Module06.ResourceManagerNotSetException;

    public void stopDisposing(long millis);
}


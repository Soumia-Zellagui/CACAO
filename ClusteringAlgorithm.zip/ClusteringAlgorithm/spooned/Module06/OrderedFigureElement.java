package Module06;


public class OrderedFigureElement implements java.lang.Comparable {
    private Module03.Figure _theFigure;

    private int _nZ;

    public OrderedFigureElement(Module03.Figure aFigure ,int nZ) {
        _theFigure = aFigure;
        _nZ = nZ;
    }

    public Module03.Figure getFigure() {
        return _theFigure;
    }

    public int getZValue() {
        return _nZ;
    }

    public int compareTo(java.lang.Object o) {
        Module06.OrderedFigureElement ofe = ((Module06.OrderedFigureElement)(o));
        if ((_nZ) == (ofe.getZValue())) {
            return 0;
        } 
        if ((_nZ) > (ofe.getZValue())) {
            return 1;
        } 
        return -1;
    }
}


package Module06;


public class FigureAttributes extends java.lang.Object implements java.io.Serializable , java.lang.Cloneable {
    private java.util.Map fMap;

    private static final long serialVersionUID = -6886355144423666716L;

    private int figureAttributesSerializedDataVersion = 1;

    public FigureAttributes() {
        fMap = Module06.CollectionsFactory.current().createMap();
    }

    public java.lang.Object get(Module06.FigureAttributeConstant attributeConstant) {
        return fMap.get(attributeConstant);
    }

    public void set(Module06.FigureAttributeConstant attributeConstant, java.lang.Object value) {
        if (value != null) {
            fMap.put(attributeConstant, value);
        } else {
            fMap.remove(attributeConstant);
        }
    }

    public boolean hasDefined(Module06.FigureAttributeConstant attributeConstant) {
        return fMap.containsKey(attributeConstant);
    }

    public java.lang.Object clone() {
        try {
            Module06.FigureAttributes a = ((Module06.FigureAttributes)(super.clone()));
            a.fMap = Module06.CollectionsFactory.current().createMap(fMap);
            return a;
        } catch (java.lang.CloneNotSupportedException e) {
            throw new java.lang.InternalError();
        }
    }

    public void read(Module06.StorableInput dr) throws java.io.IOException {
        java.lang.String s = dr.readString();
        if (!(s.toLowerCase().equals("attributes"))) {
            throw new java.io.IOException("Attributes expected");
        } 
        fMap = Module06.CollectionsFactory.current().createMap();
        int size = dr.readInt();
        for (int i = 0 ; i < size ; i++) {
            java.lang.String key = dr.readString();
            java.lang.String valtype = dr.readString();
            java.lang.Object val = null;
            if (valtype.equals("Color")) {
                val = new java.awt.Color(dr.readInt() , dr.readInt() , dr.readInt());
            } else if (valtype.equals("Boolean")) {
                val = new java.lang.Boolean(dr.readString());
            } else if (valtype.equals("String")) {
                val = dr.readString();
            } else if (valtype.equals("Int")) {
                val = new java.lang.Integer(dr.readInt());
            } else if (valtype.equals("Storable")) {
                val = dr.readStorable();
            } else if (valtype.equals(Module03.Figure.POPUP_MENU)) {
                continue;
            } else if (valtype.equals("UNKNOWN")) {
                continue;
            } 
            Module06.FigureAttributeConstant attributeConstant = Module06.FigureAttributeConstant.getConstant(key);
            set(attributeConstant, val);
        }
    }

    public void write(Module06.StorableOutput dw) {
        dw.writeString("attributes");
        dw.writeInt(fMap.size());
        java.util.Iterator iter = fMap.keySet().iterator();
        while (iter.hasNext()) {
            Module06.FigureAttributeConstant fac = ((Module06.FigureAttributeConstant)(iter.next()));
            java.lang.String attributeName = fac.getName();
            java.lang.Object attributeValue = fMap.get(fac);
            dw.writeString(attributeName);
            if (attributeValue instanceof java.lang.String) {
                dw.writeString("String");
                dw.writeString(((java.lang.String)(attributeValue)));
            } else if (attributeValue instanceof java.awt.Color) {
                Module06.FigureAttributes.writeColor(dw, "Color", ((java.awt.Color)(attributeValue)));
            } else if (attributeValue instanceof java.lang.Boolean) {
                dw.writeString("Boolean");
                if (((java.lang.Boolean)(attributeValue)).booleanValue()) {
                    dw.writeString("TRUE");
                } else {
                    dw.writeString("FALSE");
                }
            } else if (attributeValue instanceof java.lang.Integer) {
                dw.writeString("Int");
                dw.writeInt(((java.lang.Integer)(attributeValue)).intValue());
            } else if (attributeValue instanceof Module03.Storable) {
                dw.writeString("Storable");
                dw.writeStorable(((Module03.Storable)(attributeValue)));
            } else if (attributeValue instanceof javax.swing.JPopupMenu) {
                dw.writeString(Module03.Figure.POPUP_MENU);
            } else {
                java.lang.System.err.println(("Unknown attribute: " + attributeValue));
                dw.writeString("UNKNOWN");
            }
        }
    }

    public static void writeColor(Module06.StorableOutput dw, java.lang.String colorName, java.awt.Color color) {
        if (color != null) {
            dw.writeString(colorName);
            dw.writeInt(color.getRed());
            dw.writeInt(color.getGreen());
            dw.writeInt(color.getBlue());
        } 
    }

    public static java.awt.Color readColor(Module06.StorableInput dr) throws java.io.IOException {
        return new java.awt.Color(dr.readInt() , dr.readInt() , dr.readInt());
    }
}


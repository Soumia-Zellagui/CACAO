package Module06;


public class CustomToolBar extends javax.swing.JToolBar {
    private java.util.List standardTools;

    private java.util.List editTools;

    private java.util.List currentTools;

    private boolean needsUpdate;

    public CustomToolBar() {
        super();
        standardTools = Module06.CollectionsFactory.current().createList();
        editTools = Module06.CollectionsFactory.current().createList();
        currentTools = standardTools;
        needsUpdate = false;
    }

    public void switchToolBar() {
        if ((currentTools) == (standardTools)) {
            switchToEditTools();
        } else {
            switchToStandardTools();
        }
    }

    public void switchToEditTools() {
        if ((currentTools) != (editTools)) {
            currentTools = editTools;
            needsUpdate = true;
        } 
    }

    public void switchToStandardTools() {
        if ((currentTools) != (standardTools)) {
            currentTools = standardTools;
            needsUpdate = true;
        } 
    }

    public void activateTools() {
        if (!(needsUpdate)) {
            return ;
        } else {
            removeAll();
            javax.swing.JComponent currentTool = null;
            java.util.Iterator iter = currentTools.iterator();
            while (iter.hasNext()) {
                currentTool = ((javax.swing.JComponent)(iter.next()));
                super.add(currentTool);
            }
            validate();
            needsUpdate = false;
        }
    }

    public java.awt.Component add(java.awt.Component newTool) {
        if ((currentTools) == (editTools)) {
            editTools.add(newTool);
        } else {
            standardTools.add(newTool);
        }
        needsUpdate = true;
        return super.add(newTool);
    }
}


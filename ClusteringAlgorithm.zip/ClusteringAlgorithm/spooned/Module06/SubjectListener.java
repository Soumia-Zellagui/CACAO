package Module06;


class SubjectListener implements javax.swing.event.ChangeListener {
    private final Module06.MiniMapView miniMapView;

    SubjectListener(Module06.MiniMapView miniMapView) {
        this.miniMapView = miniMapView;
    }

    public void stateChanged(javax.swing.event.ChangeEvent e) {
        Module06.SubjectListener.this.miniMapView.repaint();
    }
}


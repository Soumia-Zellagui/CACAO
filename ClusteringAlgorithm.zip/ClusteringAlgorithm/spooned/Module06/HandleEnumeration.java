package Module06;


public interface HandleEnumeration {
    public Module05.Handle nextHandle();

    public boolean hasNextHandle();

    public java.util.List toList();

    public void reset();
}


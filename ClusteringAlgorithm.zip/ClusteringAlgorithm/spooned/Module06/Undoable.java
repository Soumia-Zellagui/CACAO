package Module06;


public interface Undoable {
    public boolean undo();

    public boolean redo();

    public boolean isUndoable();

    public void setUndoable(boolean newIsUndoable);

    public boolean isRedoable();

    public void setRedoable(boolean newIsRedoable);

    public void release();

    public Module03.DrawingView getDrawingView();

    public void setAffectedFigures(Module03.FigureEnumeration newAffectedFigures);

    public Module03.FigureEnumeration getAffectedFigures();

    public int getAffectedFiguresCount();
}


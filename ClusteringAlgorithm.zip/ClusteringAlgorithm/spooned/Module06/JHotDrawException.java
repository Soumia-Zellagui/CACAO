package Module06;


public class JHotDrawException extends java.lang.Exception {
    private java.lang.Exception myNestedException;

    public JHotDrawException(java.lang.String msg) {
        super(msg);
    }

    public JHotDrawException(java.lang.Exception nestedException) {
        this(nestedException.getLocalizedMessage());
        setNestedException(nestedException);
        nestedException.fillInStackTrace();
    }

    protected void setNestedException(java.lang.Exception newNestedException) {
        myNestedException = newNestedException;
    }

    public java.lang.Exception getNestedException() {
        return myNestedException;
    }
}


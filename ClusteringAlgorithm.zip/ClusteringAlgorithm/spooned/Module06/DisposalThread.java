package Module06;


class DisposalThread extends java.lang.Thread {
    private Module06.ETSLADisposalStrategy strategy;

    private long periodicity = 60000;

    boolean interruptDisposalPending = false;

    DisposalThread(Module06.ETSLADisposalStrategy newStrategy ,long newPeriodicity) {
        strategy = newStrategy;
        periodicity = newPeriodicity;
    }

    public void run() {
        interruptDisposalPending = false;
        while (!(interruptDisposalPending)) {
            try {
                java.lang.Thread.sleep(periodicity);
            } catch (java.lang.Exception ex) {
                break;
            }
            strategy.dispose();
        }
        interruptDisposalPending = false;
    }

    public long getPeriodicity() {
        return periodicity;
    }

    public void setPeriodicity(long newPeriodicity) {
        periodicity = newPeriodicity;
    }

    public void interruptDisposal() {
        interruptDisposalPending = true;
    }
}


package Module06;


public abstract class DisposableResourceManagerFactory {
    public static long DEFAULT_DISPOSAL_PERIODICITY = 60000;

    protected static Module06.DisposableResourceManager currentManager = null;

    protected static Module06.ResourceDisposabilityStrategy currentStrategy = null;

    protected static Module06.DisposableResourceHolder holderPrototype = null;

    public static Module06.DisposableResourceManager getManager() {
        return Module06.DisposableResourceManagerFactory.currentManager;
    }

    public static void setStrategy(Module06.ResourceDisposabilityStrategy strategy) {
        Module06.DisposableResourceManagerFactory.currentStrategy = strategy;
    }

    protected static void initManager() {
        if ((Module06.DisposableResourceManagerFactory.currentManager) == null) {
            if ((Module06.DisposableResourceManagerFactory.holderPrototype) == null) {
                Module06.DisposableResourceManagerFactory.holderPrototype = new Module06.StandardDisposableResourceHolder();
            } 
            if ((Module06.DisposableResourceManagerFactory.currentStrategy) == null) {
                Module06.DisposableResourceManagerFactory.currentStrategy = new Module06.ETSLADisposalStrategy(Module06.DisposableResourceManagerFactory.DEFAULT_DISPOSAL_PERIODICITY);
            } 
            if ((Module06.DisposableResourceManagerFactory.currentManager) == null) {
                Module06.DisposableResourceManagerFactory.currentManager = new Module06.StandardDisposableResourceManager(Module06.DisposableResourceManagerFactory.currentStrategy);
            } 
            try {
                Module06.DisposableResourceManagerFactory.currentManager.startDisposing();
            } catch (Module06.ResourceManagerNotSetException ex) {
            }
        } 
    }
}


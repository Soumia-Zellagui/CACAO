package Module06;


public class HandleAndEnumerator implements Module06.HandleEnumeration {
    private Module06.HandleEnumeration myHE1;

    private Module06.HandleEnumeration myHE2;

    public HandleAndEnumerator(Module06.HandleEnumeration newHE1 ,Module06.HandleEnumeration newHE2) {
        myHE1 = newHE1;
        myHE2 = newHE2;
    }

    public Module05.Handle nextHandle() {
        if (myHE1.hasNextHandle()) {
            return myHE1.nextHandle();
        } else if (myHE2.hasNextHandle()) {
            return myHE2.nextHandle();
        } else {
            return null;
        }
    }

    public boolean hasNextHandle() {
        return (myHE1.hasNextHandle()) || (myHE2.hasNextHandle());
    }

    public java.util.List toList() {
        java.util.List joinedList = myHE1.toList();
        joinedList.addAll(myHE2.toList());
        return joinedList;
    }

    public void reset() {
        myHE1.reset();
        myHE2.reset();
    }
}


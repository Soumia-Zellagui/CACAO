package Module06;


public class UndoableAdapter implements Module06.Undoable {
    private java.util.List myAffectedFigures;

    private boolean myIsUndoable;

    private boolean myIsRedoable;

    private Module03.DrawingView myDrawingView;

    public UndoableAdapter(Module03.DrawingView newDrawingView) {
        setDrawingView(newDrawingView);
    }

    public boolean undo() {
        return isUndoable();
    }

    public boolean redo() {
        return isRedoable();
    }

    public boolean isUndoable() {
        return myIsUndoable;
    }

    public void setUndoable(boolean newIsUndoable) {
        myIsUndoable = newIsUndoable;
    }

    public boolean isRedoable() {
        return myIsRedoable;
    }

    public void setRedoable(boolean newIsRedoable) {
        myIsRedoable = newIsRedoable;
    }

    public void setAffectedFigures(Module03.FigureEnumeration newAffectedFigures) {
        if (newAffectedFigures == null) {
            throw new java.lang.IllegalArgumentException();
        } 
        rememberFigures(newAffectedFigures);
    }

    public Module03.FigureEnumeration getAffectedFigures() {
        if ((myAffectedFigures) == null) {
            Module03.FigureEnumerator fe = new Module03.FigureEnumerator(java.util.Collections.EMPTY_LIST);
            return fe;
        } else {
            Module03.FigureEnumerator f = new Module03.FigureEnumerator(Module06.CollectionsFactory.current().createList(myAffectedFigures));
            return f;
        }
    }

    public Module03.FigureEnumeration getAffectedFiguresReversed() {
        Module03.ReverseFigureEnumerator rfe = new Module03.ReverseFigureEnumerator(Module06.CollectionsFactory.current().createList(myAffectedFigures));
        return rfe;
    }

    public int getAffectedFiguresCount() {
        return myAffectedFigures.size();
    }

    protected void rememberFigures(Module03.FigureEnumeration toBeRemembered) {
        myAffectedFigures = Module06.CollectionsFactory.current().createList();
        while (toBeRemembered.hasNextFigure()) {
            myAffectedFigures.add(toBeRemembered.nextFigure());
        }
    }

    public void release() {
        Module03.FigureEnumeration fe = getAffectedFigures();
        while (fe.hasNextFigure()) {
            fe.nextFigure().release();
        }
        setAffectedFigures(Module03.FigureEnumerator.getEmptyEnumeration());
    }

    protected void duplicateAffectedFigures() {
        setAffectedFigures(Module03.StandardFigureSelection.duplicateFigures(getAffectedFigures(), getAffectedFiguresCount()));
    }

    public Module03.DrawingView getDrawingView() {
        return myDrawingView;
    }

    protected void setDrawingView(Module03.DrawingView newDrawingView) {
        myDrawingView = newDrawingView;
    }
}


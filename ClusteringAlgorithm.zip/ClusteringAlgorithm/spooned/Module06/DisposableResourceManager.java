package Module06;


public interface DisposableResourceManager {
    public void registerResource(Module06.DisposableResourceHolder resource);

    public void unregisterResource(Module06.DisposableResourceHolder resource);

    public java.util.Iterator getResources();

    public boolean managesResource(Module06.DisposableResourceHolder resource);

    public void startDisposing() throws Module06.ResourceManagerNotSetException;

    public void stopDisposing(long millis);
}


package Module06;


public class DrawingChangeEvent extends java.util.EventObject {
    private java.awt.Rectangle myRectangle;

    public DrawingChangeEvent(Module03.Drawing newSource ,java.awt.Rectangle newRect) {
        super(newSource);
        myRectangle = newRect;
    }

    public Module03.Drawing getDrawing() {
        return ((Module03.Drawing)(getSource()));
    }

    public java.awt.Rectangle getInvalidatedRectangle() {
        return myRectangle;
    }
}


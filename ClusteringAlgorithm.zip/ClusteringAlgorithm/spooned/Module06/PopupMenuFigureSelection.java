package Module06;


public interface PopupMenuFigureSelection {
    public void setSelectedFigure(Module03.Figure newSelectedFigure);

    public Module03.Figure getSelectedFigure();
}


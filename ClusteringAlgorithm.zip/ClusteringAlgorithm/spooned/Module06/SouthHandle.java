package Module06;


class SouthHandle extends Module06.ResizeHandle {
    SouthHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.south());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(r.x , r.y), new java.awt.Point(((r.x) + (r.width)) , java.lang.Math.max(r.y, y)));
    }
}


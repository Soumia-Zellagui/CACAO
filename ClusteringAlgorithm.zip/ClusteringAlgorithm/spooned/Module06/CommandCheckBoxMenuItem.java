package Module06;


public class CommandCheckBoxMenuItem extends javax.swing.JCheckBoxMenuItem implements Module06.CommandHolder {
    Module01.Command fCommand;

    public CommandCheckBoxMenuItem(Module01.Command command) {
        super(command.name());
        setCommand(command);
    }

    public CommandCheckBoxMenuItem(Module01.Command command ,javax.swing.Icon icon) {
        super(command.name(), icon);
        setCommand(command);
    }

    public CommandCheckBoxMenuItem(Module01.Command command ,boolean b) {
        super(command.name(), b);
        setCommand(command);
    }

    public CommandCheckBoxMenuItem(Module01.Command command ,javax.swing.Icon icon ,boolean b) {
        super(command.name(), icon, b);
        setCommand(command);
    }

    public Module01.Command getCommand() {
        return fCommand;
    }

    public void setCommand(Module01.Command newCommand) {
        fCommand = newCommand;
    }
}


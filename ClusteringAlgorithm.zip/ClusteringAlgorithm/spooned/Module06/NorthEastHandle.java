package Module06;


class NorthEastHandle extends Module06.ResizeHandle {
    NorthEastHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.northEast());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(r.x , java.lang.Math.min(((r.y) + (r.height)), y)), new java.awt.Point(java.lang.Math.max(r.x, x) , ((r.y) + (r.height))));
    }
}


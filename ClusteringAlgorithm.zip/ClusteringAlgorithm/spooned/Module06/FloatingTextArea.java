package Module06;


public class FloatingTextArea {
    protected javax.swing.JScrollPane fEditScrollContainer;

    protected javax.swing.JEditorPane fEditWidget;

    protected java.awt.Container fContainer;

    public FloatingTextArea() {
        fEditWidget = new javax.swing.JEditorPane();
        fEditScrollContainer = new javax.swing.JScrollPane(fEditWidget , javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS , javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        fEditScrollContainer.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
        fEditScrollContainer.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.black));
    }

    public void createOverlay(java.awt.Container container) {
        createOverlay(container, null);
    }

    public void createOverlay(java.awt.Container container, java.awt.Font font) {
        container.add(fEditScrollContainer, 0);
        if (font != null) {
            fEditWidget.setFont(font);
        } 
        fContainer = container;
    }

    public void setBounds(java.awt.Rectangle r, java.lang.String text) {
        fEditWidget.setText(text);
        fEditScrollContainer.setBounds(r.x, r.y, r.width, r.height);
        fEditScrollContainer.setVisible(true);
        fEditWidget.setCaretPosition(0);
        fEditWidget.requestFocus();
    }

    public java.lang.String getText() {
        return fEditWidget.getText();
    }

    public java.awt.Dimension getPreferredSize(int cols) {
        return new java.awt.Dimension(fEditWidget.getWidth() , fEditWidget.getHeight());
    }

    public void endOverlay() {
        fContainer.requestFocus();
        if ((fEditScrollContainer) != null) {
            fEditScrollContainer.setVisible(false);
            fContainer.remove(fEditScrollContainer);
            java.awt.Rectangle bounds = fEditScrollContainer.getBounds();
            fContainer.repaint(bounds.x, bounds.y, bounds.width, bounds.height);
        } 
    }
}


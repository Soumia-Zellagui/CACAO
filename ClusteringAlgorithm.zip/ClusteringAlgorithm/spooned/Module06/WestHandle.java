package Module06;


class WestHandle extends Module06.ResizeHandle {
    WestHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.west());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(java.lang.Math.min(((r.x) + (r.width)), x) , r.y), new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height))));
    }
}


package Module06;


public class Helper {
    public static Module03.DrawingView getDrawingView(java.awt.Container container) {
        Module03.DrawingView oldDrawingView = null;
        java.awt.Component[] components = container.getComponents();
        for (int i = 0 ; i < (components.length) ; i++) {
            if ((components[i]) instanceof Module03.DrawingView) {
                return ((Module03.DrawingView)(components[i]));
            } else if ((components[i]) instanceof java.awt.Container) {
                oldDrawingView = Module06.Helper.getDrawingView(((java.awt.Container)(components[i])));
                if (oldDrawingView != null) {
                    return oldDrawingView;
                } 
            } 
        }
        return null;
    }

    public static Module03.DrawingView getDrawingView(java.awt.Component component) {
        if (java.awt.Container.class.isInstance(component)) {
            return Module06.Helper.getDrawingView(((java.awt.Container)(component)));
        } else if (Module03.DrawingView.class.isInstance(component)) {
            return ((Module03.DrawingView)(component));
        } else {
            return null;
        }
    }
}


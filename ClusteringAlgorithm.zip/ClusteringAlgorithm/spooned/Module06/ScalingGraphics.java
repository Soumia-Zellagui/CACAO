package Module06;


public class ScalingGraphics extends java.awt.Graphics {
    private double scale = 1.0;

    private java.awt.Graphics real;

    private java.awt.Font userFont;

    private java.awt.Rectangle userClip;

    public ScalingGraphics(java.awt.Graphics realGraphics) {
        real = realGraphics;
    }

    public void setScale(double newScale) {
        scale = newScale;
    }

    public double getScale() {
        return scale;
    }

    private static java.awt.Font scaledFont(java.awt.Font f, double scale) {
        int size = f.getSize();
        int scaledSize = ((int)(size * scale));
        return new java.awt.Font(f.getFamily() , f.getStyle() , scaledSize);
    }

    private static java.awt.Shape scaledShape(java.awt.Shape s, double scale) {
        if (s instanceof java.awt.Rectangle) {
            java.awt.Rectangle r = ((java.awt.Rectangle)(s));
            return new java.awt.Rectangle(((int)((r.x) * scale)) , ((int)((r.y) * scale)) , ((int)((r.width) * scale)) , ((int)((r.height) * scale)));
        } else {
            throw new java.lang.RuntimeException(("Cannot scale shape: " + (s.getClass().getName())));
        }
    }

    public java.awt.Graphics create() {
        java.awt.Graphics realCopy = real.create();
        Module06.ScalingGraphics result = new Module06.ScalingGraphics(realCopy);
        result.setScale(getScale());
        return result;
    }

    public void translate(int x, int y) {
        real.translate(((int)(x * (scale))), ((int)(y * (scale))));
    }

    public java.awt.Color getColor() {
        return real.getColor();
    }

    public void setColor(java.awt.Color c) {
        real.setColor(c);
    }

    public void setPaintMode() {
        real.setPaintMode();
    }

    public void setXORMode(java.awt.Color c1) {
        real.setXORMode(c1);
    }

    public java.awt.Font getFont() {
        if ((userFont) == null)
            userFont = real.getFont();
        
        return userFont;
    }

    public void setFont(java.awt.Font font) {
        userFont = font;
        real.setFont(Module06.ScalingGraphics.scaledFont(font, scale));
    }

    public java.awt.FontMetrics getFontMetrics() {
        Module06.ScalingGraphics.ScalingFontMetrics scalingFontMetrics = new Module06.ScalingGraphics.ScalingFontMetrics(userFont , real.getFontMetrics());
        return scalingFontMetrics;
    }

    public java.awt.FontMetrics getFontMetrics(java.awt.Font f) {
        Module06.ScalingGraphics.ScalingFontMetrics scalingFontMetrics = new Module06.ScalingGraphics.ScalingFontMetrics(f , real.getFontMetrics(Module06.ScalingGraphics.scaledFont(f, scale)));
        return scalingFontMetrics;
    }

    public java.awt.Rectangle getClipBounds() {
        return userClip;
    }

    public void clipRect(int x, int y, int width, int height) {
        if ((userClip) == null)
            userClip = new java.awt.Rectangle(x , y , width , height);
        else
            userClip = userClip.intersection(new java.awt.Rectangle(x , y , width , height));
        
        real.clipRect(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public void setClip(int x, int y, int width, int height) {
        userClip = new java.awt.Rectangle(x , y , width , height);
        real.setClip(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public java.awt.Shape getClip() {
        return userClip;
    }

    public void setClip(java.awt.Shape clip) {
        userClip = ((java.awt.Rectangle)(clip));
        if (clip != null)
            real.setClip(Module06.ScalingGraphics.scaledShape(clip, scale));
        else
            real.setClip(null);
        
    }

    public void copyArea(int x, int y, int width, int height, int dx, int dy) {
        real.copyArea(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), ((int)(dx * (scale))), ((int)(dy * (scale))));
    }

    public void drawLine(int x1, int y1, int x2, int y2) {
        real.drawLine(((int)(x1 * (scale))), ((int)(y1 * (scale))), ((int)(x2 * (scale))), ((int)(y2 * (scale))));
    }

    public void fillRect(int x, int y, int width, int height) {
        real.fillRect(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public void clearRect(int x, int y, int width, int height) {
        real.clearRect(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        real.drawRoundRect(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), ((int)(arcWidth * (scale))), ((int)(arcHeight * (scale))));
    }

    public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        real.fillRoundRect(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), ((int)(arcWidth * (scale))), ((int)(arcHeight * (scale))));
    }

    public void drawOval(int x, int y, int width, int height) {
        real.drawOval(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public void fillOval(int x, int y, int width, int height) {
        real.fillOval(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))));
    }

    public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        real.drawArc(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), startAngle, arcAngle);
    }

    public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        real.fillArc(((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), startAngle, arcAngle);
    }

    public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {
        int[] realXPoints = new int[nPoints];
        int[] realYPoints = new int[nPoints];
        for (int i = 0 ; i < nPoints ; i++) {
            realXPoints[i] = ((int)((xPoints[i]) * (scale)));
            realYPoints[i] = ((int)((yPoints[i]) * (scale)));
        }
        real.drawPolyline(realXPoints, realYPoints, nPoints);
    }

    public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {
        int[] realXPoints = new int[nPoints];
        int[] realYPoints = new int[nPoints];
        for (int i = 0 ; i < nPoints ; i++) {
            realXPoints[i] = ((int)((xPoints[i]) * (scale)));
            realYPoints[i] = ((int)((yPoints[i]) * (scale)));
        }
        real.drawPolygon(realXPoints, realYPoints, nPoints);
    }

    public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {
        int[] realXPoints = new int[nPoints];
        int[] realYPoints = new int[nPoints];
        for (int i = 0 ; i < nPoints ; i++) {
            realXPoints[i] = ((int)((xPoints[i]) * (scale)));
            realYPoints[i] = ((int)((yPoints[i]) * (scale)));
        }
        real.fillPolygon(realXPoints, realYPoints, nPoints);
    }

    public void drawString(java.lang.String str, int x, int y) {
        real.drawString(str, ((int)(x * (scale))), ((int)(y * (scale))));
    }

    public void drawString(java.text.AttributedCharacterIterator iterator, int x, int y) {
        real.drawString(iterator, ((int)(x * (scale))), ((int)(y * (scale))));
    }

    public boolean drawImage(java.awt.Image img, int x, int y, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), x, y, observer);
        else
            return real.drawImage(img, ((int)(x * (scale))), ((int)(y * (scale))), ((int)((img.getWidth(observer)) * (scale))), ((int)((img.getHeight(observer)) * (scale))), observer);
        
    }

    public boolean drawImage(java.awt.Image img, int x, int y, int width, int height, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), x, y, width, height, observer);
        else
            return real.drawImage(img, ((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), observer);
        
    }

    public boolean drawImage(java.awt.Image img, int x, int y, java.awt.Color bgcolor, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), x, y, bgcolor, observer);
        else
            return real.drawImage(img, ((int)(x * (scale))), ((int)(y * (scale))), ((int)((img.getWidth(observer)) * (scale))), ((int)((img.getHeight(observer)) * (scale))), bgcolor, observer);
        
    }

    public boolean drawImage(java.awt.Image img, int x, int y, int width, int height, java.awt.Color bgcolor, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), x, y, width, height, bgcolor, observer);
        else
            return real.drawImage(img, ((int)(x * (scale))), ((int)(y * (scale))), ((int)(width * (scale))), ((int)(height * (scale))), bgcolor, observer);
        
    }

    public boolean drawImage(java.awt.Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, observer);
        else
            return real.drawImage(img, ((int)(dx1 * (scale))), ((int)(dy1 * (scale))), ((int)(dx2 * (scale))), ((int)(dy2 * (scale))), ((int)(sx1 * (scale))), ((int)(sy1 * (scale))), ((int)(sx2 * (scale))), ((int)(sy2 * (scale))), observer);
        
    }

    public boolean drawImage(java.awt.Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, java.awt.Color bgcolor, java.awt.image.ImageObserver observer) {
        if (img instanceof Module06.DoubleBufferImage)
            return real.drawImage(((Module06.DoubleBufferImage)(img)).getRealImage(), dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, bgcolor, observer);
        else
            return real.drawImage(img, ((int)(dx1 * (scale))), ((int)(dy1 * (scale))), ((int)(dx2 * (scale))), ((int)(dy2 * (scale))), ((int)(sx1 * (scale))), ((int)(sy1 * (scale))), ((int)(sx2 * (scale))), ((int)(sy2 * (scale))), bgcolor, observer);
        
    }

    public void dispose() {
        real.dispose();
    }

    private class ScalingFontMetrics extends java.awt.FontMetrics {
        private java.awt.FontMetrics real;

        private java.awt.Font userFont;

        public ScalingFontMetrics(java.awt.Font newUserFont ,java.awt.FontMetrics newReal) {
            super(null);
            userFont = newUserFont;
            real = newReal;
        }

        public java.awt.Font getFont() {
            return userFont;
        }

        public int getAscent() {
            return ((int)((real.getAscent()) / (Module06.ScalingGraphics.this.getScale())));
        }

        public int getLeading() {
            return ((int)((real.getLeading()) / (Module06.ScalingGraphics.this.getScale())));
        }

        public int getMaxAdvance() {
            return ((int)((real.getMaxAdvance()) / (Module06.ScalingGraphics.this.getScale())));
        }

        public int charWidth(char ch) {
            return ((int)((real.charWidth(ch)) / (Module06.ScalingGraphics.this.getScale())));
        }

        public int charsWidth(char[] data, int off, int len) {
            return ((int)((real.charsWidth(data, off, len)) / (Module06.ScalingGraphics.this.getScale())));
        }
    }
}


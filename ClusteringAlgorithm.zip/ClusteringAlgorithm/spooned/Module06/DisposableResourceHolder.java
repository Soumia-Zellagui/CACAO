package Module06;


public interface DisposableResourceHolder {
    public java.lang.Object getResource() throws java.lang.NullPointerException;

    public java.lang.Object clone();

    public void setResource(java.lang.Object resource);

    public void setDisposableDelay(long millis);

    public long getDisposableDelay();

    public void resetDelay();

    public long getLastTimeAccessed();

    public void dispose();

    public boolean isAvailable();

    public void lock();

    public void unlock();

    public boolean isLocked();
}


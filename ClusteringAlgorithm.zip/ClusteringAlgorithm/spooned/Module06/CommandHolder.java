package Module06;


public interface CommandHolder {
    public Module01.Command getCommand();

    public void setCommand(Module01.Command newCommand);
}


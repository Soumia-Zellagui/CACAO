package Module06;


public class VersionManagement {
    public static java.lang.String JHOTDRAW_COMPONENT = "org.jhotdraw/";

    public static java.lang.String JHOTDRAW_JAR = "jhotdraw.jar";

    public static java.lang.Package[] packages = new java.lang.Package[]{ java.lang.Package.getPackage("org.jhotdraw.applet") , java.lang.Package.getPackage("org.jhotdraw.application") , java.lang.Package.getPackage("org.jhotdraw.contrib") , java.lang.Package.getPackage("org.jhotdraw.figures") , java.lang.Package.getPackage("org.jhotdraw.framework") , java.lang.Package.getPackage("org.jhotdraw.standard") , java.lang.Package.getPackage("org.jhotdraw.util") };

    public static java.lang.String getJHotDrawVersion() {
        java.lang.Package pack = Module06.VersionManagement.packages[4];
        return pack.getSpecificationVersion();
    }

    public static java.lang.String getPackageVersion(final java.lang.Package lookupPackage) {
        if (lookupPackage == null) {
            return null;
        } 
        java.lang.String specVersion = lookupPackage.getSpecificationVersion();
        if (specVersion != null) {
            return specVersion;
        } else {
            java.lang.String normalizedPackageName = Module06.VersionManagement.normalizePackageName(lookupPackage.getName());
            java.lang.String nextPackageName = Module06.VersionManagement.getNextPackage(normalizedPackageName);
            return Module06.VersionManagement.getPackageVersion(java.lang.Package.getPackage(nextPackageName));
        }
    }

    public static boolean isCompatibleVersion(java.lang.String compareVersionString) {
        java.lang.Package pack = Module06.VersionManagement.packages[4];
        if (compareVersionString == null) {
            return (pack.getSpecificationVersion()) == null;
        } else {
            return pack.isCompatibleWith(compareVersionString);
        }
    }

    public static java.lang.String readVersionFromFile(java.lang.String applicationName, java.lang.String versionFileName) {
        try {
            java.io.FileInputStream fileInput = new java.io.FileInputStream(versionFileName);
            java.util.jar.Manifest manifest = new java.util.jar.Manifest();
            manifest.read(fileInput);
            java.util.Map entries = manifest.getEntries();
            java.util.Iterator entryIterator = entries.entrySet().iterator();
            while (entryIterator.hasNext()) {
                java.util.Map.Entry currentEntry = ((java.util.Map.Entry)(entryIterator.next()));
                java.lang.String packageName = currentEntry.getKey().toString();
                packageName = Module06.VersionManagement.normalizePackageName(packageName);
                java.util.jar.Attributes attributes = ((java.util.jar.Attributes)(currentEntry.getValue()));
                java.lang.String packageSpecVersion = attributes.getValue(java.util.jar.Attributes.Name.SPECIFICATION_VERSION);
                packageSpecVersion = Module06.VersionManagement.extractVersionInfo(packageSpecVersion);
                return packageSpecVersion;
            }
        } catch (java.io.IOException exception) {
            exception.printStackTrace();
        }
        return null;
    }

    protected static java.lang.String getNextPackage(java.lang.String searchPackage) {
        if (searchPackage == null) {
            return null;
        } 
        int foundNextPackage = searchPackage.lastIndexOf('.');
        if (foundNextPackage > 0) {
            return searchPackage.substring(0, foundNextPackage);
        } else {
            return null;
        }
    }

    public static java.lang.String normalizePackageName(java.lang.String toBeNormalized) {
        java.lang.String replaced = toBeNormalized.replace('/', '.');
        replaced = replaced.replace(java.io.File.pathSeparatorChar, '.');
        if (replaced.endsWith(".")) {
            int lastSeparator = replaced.lastIndexOf('.');
            return replaced.substring(0, lastSeparator);
        } else {
            return replaced;
        }
    }

    public static java.lang.String extractVersionInfo(java.lang.String versionString) {
        if (versionString == null) {
            return null;
        } 
        if ((versionString.length()) == 0) {
            return "";
        } 
        int startIndex = versionString.indexOf("\"");
        if (startIndex < 0) {
            startIndex = 0;
        } else {
            startIndex++;
        }
        int endIndex = versionString.lastIndexOf("\"");
        if (endIndex < 0) {
            endIndex = versionString.length();
        } 
        return versionString.substring(startIndex, endIndex);
    }
}


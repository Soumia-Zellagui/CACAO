package Module06;


public abstract class CollectionsFactory {
    private static java.lang.String JAVA_UTIL_LIST = "java.util.List";

    private static java.lang.String COLLECTIONS_FACTORY_PACKAGE = "org.jhotdraw.util.collections.jdk";

    private static final Module06.CollectionsFactory factory = Module06.CollectionsFactory.determineCollectionsFactory();

    public abstract java.util.List createList();

    public abstract java.util.List createList(java.util.Collection initList);

    public abstract java.util.List createList(int initSize);

    public abstract java.util.Map createMap();

    public abstract java.util.Map createMap(java.util.Map initMap);

    public abstract java.util.Set createSet();

    public abstract java.util.Set createSet(java.util.Set initSet);

    public static Module06.CollectionsFactory current() {
        return Module06.CollectionsFactory.factory;
    }

    protected static Module06.CollectionsFactory determineCollectionsFactory() {
        java.lang.String jdkVersion = null;
        if (Module06.CollectionsFactory.isJDK12()) {
            jdkVersion = "12";
        } else {
            jdkVersion = "11";
        }
        return Module06.CollectionsFactory.createCollectionsFactory(jdkVersion);
    }

    protected static boolean isJDK12() {
        try {
            java.lang.Class.forName(Module06.CollectionsFactory.JAVA_UTIL_LIST);
            return true;
        } catch (java.lang.ClassNotFoundException e) {
        }
        return false;
    }

    protected static Module06.CollectionsFactory createCollectionsFactory(java.lang.String jdkVersion) {
        try {
            java.lang.Class factoryClass = java.lang.Class.forName(((((Module06.CollectionsFactory.COLLECTIONS_FACTORY_PACKAGE) + jdkVersion) + ".CollectionsFactoryJDK") + jdkVersion));
            return ((Module06.CollectionsFactory)(factoryClass.newInstance()));
        } catch (java.lang.ClassNotFoundException e) {
            throw new Module06.JHotDrawRuntimeException(e);
        } catch (java.lang.InstantiationException e) {
            throw new Module06.JHotDrawRuntimeException(e);
        } catch (java.lang.IllegalAccessException e) {
            throw new Module06.JHotDrawRuntimeException(e);
        }
    }
}


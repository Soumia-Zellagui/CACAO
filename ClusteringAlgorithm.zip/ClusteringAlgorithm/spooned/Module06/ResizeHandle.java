package Module06;


class ResizeHandle extends Module05.LocatorHandle {
    ResizeHandle(Module03.Figure owner ,Module03.Locator loc) {
        super(owner, loc);
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        setUndoActivity(createUndoActivity(view));
        getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(owner()));
        ((Module06.ResizeHandle.UndoActivity)(getUndoActivity())).setOldDisplayBox(owner().displayBox());
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle oldDisplayBox = ((Module06.ResizeHandle.UndoActivity)(getUndoActivity())).getOldDisplayBox();
        if (owner().displayBox().equals(oldDisplayBox)) {
            setUndoActivity(null);
        } 
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView view) {
        return new Module06.ResizeHandle.UndoActivity(view);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Rectangle myOldDisplayBox;

        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            return resetDisplayBox();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            return resetDisplayBox();
        }

        private boolean resetDisplayBox() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.Figure currentFigure = fe.nextFigure();
            java.awt.Rectangle figureDisplayBox = currentFigure.displayBox();
            currentFigure.displayBox(getOldDisplayBox());
            setOldDisplayBox(figureDisplayBox);
            return true;
        }

        protected void setOldDisplayBox(java.awt.Rectangle newOldDisplayBox) {
            myOldDisplayBox = newOldDisplayBox;
        }

        public java.awt.Rectangle getOldDisplayBox() {
            return myOldDisplayBox;
        }
    }
}


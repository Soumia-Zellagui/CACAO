package Module06;


public abstract class PaletteButton extends javax.swing.JButton implements java.awt.event.MouseListener , java.awt.event.MouseMotionListener {
    protected static final int NORMAL = 1;

    protected static final int PRESSED = 2;

    protected static final int SELECTED = 3;

    private int fState;

    private int fOldState;

    private Module01.PaletteListener fListener;

    public PaletteButton(Module01.PaletteListener listener) {
        fListener = listener;
        fState = fOldState = Module06.PaletteButton.NORMAL;
        addMouseListener(Module06.PaletteButton.this);
        addMouseMotionListener(Module06.PaletteButton.this);
    }

    public java.lang.Object value() {
        return null;
    }

    public java.lang.String name() {
        return "";
    }

    public void reset() {
        if (isEnabled()) {
            fState = Module06.PaletteButton.NORMAL;
            setSelected(false);
            repaint();
        } 
    }

    public void select() {
        if (isEnabled()) {
            fState = Module06.PaletteButton.SELECTED;
            setSelected(true);
            repaint();
        } 
    }

    public void mousePressed(java.awt.event.MouseEvent e) {
        if (isEnabled()) {
            fOldState = fState;
            fState = Module06.PaletteButton.PRESSED;
            repaint();
        } 
    }

    public void mouseDragged(java.awt.event.MouseEvent e) {
        if (isEnabled()) {
            if (contains(e.getX(), e.getY())) {
                fState = Module06.PaletteButton.PRESSED;
            } else {
                fState = fOldState;
            }
            repaint();
        } 
    }

    public void mouseReleased(java.awt.event.MouseEvent e) {
        if (isEnabled()) {
            fState = fOldState;
            repaint();
            if (contains(e.getX(), e.getY())) {
                fListener.paletteUserSelected(Module06.PaletteButton.this);
            } 
        } 
    }

    public void mouseMoved(java.awt.event.MouseEvent e) {
        fListener.paletteUserOver(Module06.PaletteButton.this, true);
    }

    public void mouseExited(java.awt.event.MouseEvent e) {
        if ((fState) == (Module06.PaletteButton.PRESSED)) {
            mouseDragged(e);
        } 
        fListener.paletteUserOver(Module06.PaletteButton.this, false);
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
    }

    public void mouseEntered(java.awt.event.MouseEvent e) {
    }
}


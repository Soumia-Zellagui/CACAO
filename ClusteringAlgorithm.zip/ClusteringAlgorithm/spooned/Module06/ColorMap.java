package Module06;


public class ColorMap {
    static Module06.ColorEntry[] fMap = new Module06.ColorEntry[]{ new Module06.ColorEntry("Black" , java.awt.Color.black) , new Module06.ColorEntry("Blue" , java.awt.Color.blue) , new Module06.ColorEntry("Green" , java.awt.Color.green) , new Module06.ColorEntry("Red" , java.awt.Color.red) , new Module06.ColorEntry("Pink" , java.awt.Color.pink) , new Module06.ColorEntry("Magenta" , java.awt.Color.magenta) , new Module06.ColorEntry("Orange" , java.awt.Color.orange) , new Module06.ColorEntry("Yellow" , java.awt.Color.yellow) , new Module06.ColorEntry("New Tan" , new java.awt.Color(15452062)) , new Module06.ColorEntry("Aquamarine" , new java.awt.Color(7396243)) , new Module06.ColorEntry("Sea Green" , new java.awt.Color(2330216)) , new Module06.ColorEntry("Dark Gray" , java.awt.Color.darkGray) , new Module06.ColorEntry("Light Gray" , java.awt.Color.lightGray) , new Module06.ColorEntry("White" , java.awt.Color.white) , new Module06.ColorEntry("None" , new java.awt.Color(16762782)) };

    public static int size() {
        return Module06.ColorMap.fMap.length;
    }

    public static java.awt.Color color(int index) {
        if ((index < (Module06.ColorMap.size())) && (index >= 0)) {
            return Module06.ColorMap.fMap[index].fColor;
        } 
        throw new java.lang.ArrayIndexOutOfBoundsException(("Color index: " + index));
    }

    public static java.awt.Color color(java.lang.String name) {
        for (int i = 0 ; i < (Module06.ColorMap.fMap.length) ; i++) {
            if (Module06.ColorMap.fMap[i].fName.equals(name)) {
                return Module06.ColorMap.fMap[i].fColor;
            } 
        }
        return java.awt.Color.black;
    }

    public static java.lang.String name(int index) {
        if ((index < (Module06.ColorMap.size())) && (index >= 0)) {
            return Module06.ColorMap.fMap[index].fName;
        } 
        throw new java.lang.ArrayIndexOutOfBoundsException(("Color index: " + index));
    }

    public static int colorIndex(java.awt.Color color) {
        for (int i = 0 ; i < (Module06.ColorMap.fMap.length) ; i++) {
            if (Module06.ColorMap.fMap[i].fColor.equals(color)) {
                return i;
            } 
        }
        return 0;
    }

    public static boolean isTransparent(java.awt.Color color) {
        return color.equals(Module06.ColorMap.color("None"));
    }
}


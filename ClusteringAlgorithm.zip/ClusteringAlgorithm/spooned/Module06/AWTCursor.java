package Module06;


public class AWTCursor extends java.awt.Cursor implements Module06.Cursor {
    public AWTCursor(int type) {
        super(type);
    }

    public AWTCursor(java.lang.String newName) {
        super(newName);
    }
}


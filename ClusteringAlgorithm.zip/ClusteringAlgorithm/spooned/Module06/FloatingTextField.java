package Module06;


public class FloatingTextField {
    private javax.swing.JTextField fEditWidget;

    private java.awt.Container fContainer;

    public FloatingTextField() {
        fEditWidget = new javax.swing.JTextField(20);
    }

    public void createOverlay(java.awt.Container container) {
        createOverlay(container, null);
    }

    public void createOverlay(java.awt.Container container, java.awt.Font font) {
        container.add(fEditWidget, 0);
        if (font != null) {
            fEditWidget.setFont(font);
        } 
        fContainer = container;
    }

    public void addActionListener(java.awt.event.ActionListener listener) {
        fEditWidget.addActionListener(listener);
    }

    public void removeActionListener(java.awt.event.ActionListener listener) {
        fEditWidget.removeActionListener(listener);
    }

    public void setBounds(java.awt.Rectangle r, java.lang.String text) {
        fEditWidget.setText(text);
        fEditWidget.setLocation(r.x, r.y);
        fEditWidget.setSize(r.width, r.height);
        fEditWidget.setVisible(true);
        fEditWidget.selectAll();
        fEditWidget.requestFocus();
    }

    public java.lang.String getText() {
        return fEditWidget.getText();
    }

    public java.awt.Dimension getPreferredSize(int cols) {
        fEditWidget.setColumns(cols);
        return fEditWidget.getPreferredSize();
    }

    public void endOverlay() {
        fContainer.requestFocus();
        if ((fEditWidget) != null) {
            fEditWidget.setVisible(false);
            fContainer.remove(fEditWidget);
            java.awt.Rectangle bounds = fEditWidget.getBounds();
            fContainer.repaint(bounds.x, bounds.y, bounds.width, bounds.height);
        } 
    }
}


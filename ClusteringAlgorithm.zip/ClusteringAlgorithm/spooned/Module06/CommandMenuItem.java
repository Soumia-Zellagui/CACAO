package Module06;


public class CommandMenuItem extends javax.swing.JMenuItem implements Module06.CommandHolder , java.awt.event.ActionListener {
    private Module01.Command fCommand;

    public CommandMenuItem(Module01.Command command) {
        super(command.name());
        setCommand(command);
        addActionListener(Module06.CommandMenuItem.this);
    }

    public CommandMenuItem(Module01.Command command ,javax.swing.Icon icon) {
        super(command.name(), icon);
        setCommand(command);
        addActionListener(Module06.CommandMenuItem.this);
    }

    public CommandMenuItem(Module01.Command command ,int mnemonic) {
        super(command.name(), mnemonic);
        setCommand(command);
    }

    public Module01.Command getCommand() {
        return fCommand;
    }

    public void setCommand(Module01.Command newCommand) {
        fCommand = newCommand;
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
        getCommand().execute();
    }
}


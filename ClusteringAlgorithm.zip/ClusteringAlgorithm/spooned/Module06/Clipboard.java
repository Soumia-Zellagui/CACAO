package Module06;


public class Clipboard {
    static Module06.Clipboard fgClipboard = new Module06.Clipboard();

    public static Module06.Clipboard getClipboard() {
        return Module06.Clipboard.fgClipboard;
    }

    private java.lang.Object fContents;

    private Clipboard() {
    }

    public void setContents(java.lang.Object contents) {
        fContents = contents;
    }

    public java.lang.Object getContents() {
        return fContents;
    }
}


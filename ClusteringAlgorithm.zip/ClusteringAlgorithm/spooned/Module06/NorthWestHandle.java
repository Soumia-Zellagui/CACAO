package Module06;


class NorthWestHandle extends Module06.ResizeHandle {
    NorthWestHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.northWest());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(java.lang.Math.min(((r.x) + (r.width)), x) , java.lang.Math.min(((r.y) + (r.height)), y)), new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height))));
    }
}


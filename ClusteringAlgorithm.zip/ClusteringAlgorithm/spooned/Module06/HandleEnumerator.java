package Module06;


public class HandleEnumerator implements Module06.HandleEnumeration {
    private java.util.Iterator myIterator;

    private java.util.Collection myInitialCollection;

    private static Module06.HandleEnumerator singletonEmptyEnumerator = new Module06.HandleEnumerator(Module06.CollectionsFactory.current().createList());

    public HandleEnumerator(java.util.Collection c) {
        myInitialCollection = c;
        reset();
    }

    public boolean hasNextHandle() {
        return myIterator.hasNext();
    }

    public Module05.Handle nextHandle() {
        return ((Module05.Handle)(myIterator.next()));
    }

    public java.util.List toList() {
        java.util.List handles = Module06.CollectionsFactory.current().createList();
        while (hasNextHandle()) {
            handles.add(nextHandle());
        }
        myIterator = handles.iterator();
        return handles;
    }

    public void reset() {
        myIterator = myInitialCollection.iterator();
    }

    public static Module06.HandleEnumeration getEmptyEnumeration() {
        return Module06.HandleEnumerator.singletonEmptyEnumerator;
    }
}


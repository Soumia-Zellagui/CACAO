package Module06;


public class StandardDisposableResourceHolder implements Module06.DisposableResourceHolder , java.io.Serializable {
    private java.lang.Object resource = null;

    private long disposeDelay = 60000;

    private long lastTimeAccessed = 0;

    private boolean isLocked = false;

    public StandardDisposableResourceHolder() {
    }

    public StandardDisposableResourceHolder(java.lang.Object newResource) {
        resource = newResource;
        resetDelay();
    }

    public java.lang.Object clone() {
        Module06.StandardDisposableResourceHolder clone = new Module06.StandardDisposableResourceHolder();
        clone.setDisposableDelay(Module06.StandardDisposableResourceHolder.this.getDisposableDelay());
        return clone;
    }

    public java.lang.Object getResource() throws java.lang.NullPointerException {
        if ((resource) != null) {
            resetDelay();
            return resource;
        } 
        throw new java.lang.NullPointerException();
    }

    public void setResource(java.lang.Object newResource) {
        resource = newResource;
        resetDelay();
    }

    public void setDisposableDelay(long millis) {
        disposeDelay = millis;
    }

    public long getDisposableDelay() {
        return disposeDelay;
    }

    public void dispose() {
        resource = null;
    }

    public boolean isAvailable() {
        return (resource) != null;
    }

    public void lock() {
        isLocked = true;
    }

    public void unlock() {
        resetDelay();
        isLocked = false;
    }

    public boolean isLocked() {
        return isLocked;
    }

    public long getLastTimeAccessed() {
        return lastTimeAccessed;
    }

    public void resetDelay() {
        lastTimeAccessed = java.lang.System.currentTimeMillis();
    }
}


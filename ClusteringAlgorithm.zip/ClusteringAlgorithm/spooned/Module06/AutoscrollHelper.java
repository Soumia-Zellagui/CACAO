package Module06;


public abstract class AutoscrollHelper {
    private int autoscrollMargin = 20;

    private java.awt.Insets autoscrollInsets = new java.awt.Insets(0 , 0 , 0 , 0);

    public AutoscrollHelper(int margin) {
        autoscrollMargin = margin;
    }

    public void setAutoscrollMargin(int margin) {
        autoscrollMargin = margin;
    }

    public int getAutoscrollMargin() {
        return autoscrollMargin;
    }

    public abstract java.awt.Dimension getSize();

    public abstract java.awt.Rectangle getVisibleRect();

    public abstract void scrollRectToVisible(java.awt.Rectangle aRect);

    public void autoscroll(java.awt.Point location) {
        int top = 0;
        int left = 0;
        int bottom = 0;
        int right = 0;
        java.awt.Dimension size = getSize();
        java.awt.Rectangle rect = getVisibleRect();
        int bottomEdge = (rect.y) + (rect.height);
        int rightEdge = (rect.x) + (rect.width);
        if ((((location.y) - (rect.y)) <= (autoscrollMargin)) && ((rect.y) > 0))
            top = autoscrollMargin;
        
        if ((((location.x) - (rect.x)) <= (autoscrollMargin)) && ((rect.x) > 0))
            left = autoscrollMargin;
        
        if (((bottomEdge - (location.y)) <= (autoscrollMargin)) && (bottomEdge < (size.height)))
            bottom = autoscrollMargin;
        
        if (((rightEdge - (location.x)) <= (autoscrollMargin)) && (rightEdge < (size.width)))
            right = autoscrollMargin;
        
        rect.x += right - left;
        rect.y += bottom - top;
        scrollRectToVisible(rect);
    }

    public java.awt.Insets getAutoscrollInsets() {
        java.awt.Dimension size = getSize();
        java.awt.Rectangle rect = getVisibleRect();
        autoscrollInsets.top = (rect.y) + (autoscrollMargin);
        autoscrollInsets.left = (rect.x) + (autoscrollMargin);
        autoscrollInsets.bottom = ((size.height) - ((rect.y) + (rect.height))) + (autoscrollMargin);
        autoscrollInsets.right = ((size.width) - ((rect.x) + (rect.width))) + (autoscrollMargin);
        return autoscrollInsets;
    }
}


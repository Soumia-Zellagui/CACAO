package Module06;


public class Geom {
    private Geom() {
    }

    public static boolean lineContainsPoint(int x1, int y1, int x2, int y2, int px, int py) {
        java.awt.Rectangle r = new java.awt.Rectangle(new java.awt.Point(x1 , y1));
        r.add(x2, y2);
        r.grow(2, 2);
        if (!(r.contains(px, py))) {
            return false;
        } 
        double a;
        double b;
        double x;
        double y;
        if (x1 == x2) {
            return (java.lang.Math.abs((px - x1))) < 3;
        } 
        if (y1 == y2) {
            return (java.lang.Math.abs((py - y1))) < 3;
        } 
        a = (y1 - y2) / (x1 - x2);
        b = y1 - (a * x1);
        x = (py - b) / a;
        y = (a * px) + b;
        return (java.lang.Math.min(java.lang.Math.abs((x - px)), java.lang.Math.abs((y - py)))) < 4;
    }

    public static final int NORTH = 1;

    public static final int SOUTH = 2;

    public static final int WEST = 3;

    public static final int EAST = 4;

    public static int direction(int x1, int y1, int x2, int y2) {
        int direction = 0;
        int vx = x2 - x1;
        int vy = y2 - y1;
        if ((vy < vx) && (vx > (-vy))) {
            direction = Module06.Geom.EAST;
        } else if ((vy > vx) && (vy > (-vx))) {
            direction = Module06.Geom.NORTH;
        } else if ((vx < vy) && (vx < (-vy))) {
            direction = Module06.Geom.WEST;
        } else {
            direction = Module06.Geom.SOUTH;
        }
        return direction;
    }

    public static java.awt.Point south(java.awt.Rectangle r) {
        return new java.awt.Point(((r.x) + ((r.width) / 2)) , ((r.y) + (r.height)));
    }

    public static java.awt.Point center(java.awt.Rectangle r) {
        return new java.awt.Point(((r.x) + ((r.width) / 2)) , ((r.y) + ((r.height) / 2)));
    }

    public static java.awt.Point west(java.awt.Rectangle r) {
        return new java.awt.Point(r.x , ((r.y) + ((r.height) / 2)));
    }

    public static java.awt.Point east(java.awt.Rectangle r) {
        return new java.awt.Point(((r.x) + (r.width)) , ((r.y) + ((r.height) / 2)));
    }

    public static java.awt.Point north(java.awt.Rectangle r) {
        return new java.awt.Point(((r.x) + ((r.width) / 2)) , r.y);
    }

    public static java.awt.Point corner(java.awt.Rectangle r) {
        return new java.awt.Point(((int)(r.getMaxX())) , ((int)(r.getMaxY())));
    }

    public static java.awt.Point topLeftCorner(java.awt.Rectangle r) {
        return r.getLocation();
    }

    public static java.awt.Point topRightCorner(java.awt.Rectangle r) {
        return new java.awt.Point(((int)(r.getMaxX())) , ((int)(r.getMinY())));
    }

    public static java.awt.Point bottomLeftCorner(java.awt.Rectangle r) {
        return new java.awt.Point(((int)(r.getMinX())) , ((int)(r.getMaxY())));
    }

    public static java.awt.Point bottomRightCorner(java.awt.Rectangle r) {
        return Module06.Geom.corner(r);
    }

    public static int range(int min, int max, int value) {
        if (value < min) {
            value = min;
        } 
        if (value > max) {
            value = max;
        } 
        return value;
    }

    public static long length2(int x1, int y1, int x2, int y2) {
        return ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1));
    }

    public static long length(int x1, int y1, int x2, int y2) {
        return ((long)(java.lang.Math.sqrt(Module06.Geom.length2(x1, y1, x2, y2))));
    }

    public static double pointToAngle(java.awt.Rectangle r, java.awt.Point p) {
        int px = (p.x) - ((r.x) + ((r.width) / 2));
        int py = (p.y) - ((r.y) + ((r.height) / 2));
        return java.lang.Math.atan2((py * (r.width)), (px * (r.height)));
    }

    public static java.awt.Point angleToPoint(java.awt.Rectangle r, double angle) {
        double si = java.lang.Math.sin(angle);
        double co = java.lang.Math.cos(angle);
        double e = 1.0E-4;
        int x = 0;
        int y = 0;
        if ((java.lang.Math.abs(si)) > e) {
            x = ((int)(((1.0 + (co / (java.lang.Math.abs(si)))) / 2.0) * (r.width)));
            x = Module06.Geom.range(0, r.width, x);
        } else if (co >= 0.0) {
            x = r.width;
        } 
        if ((java.lang.Math.abs(co)) > e) {
            y = ((int)(((1.0 + (si / (java.lang.Math.abs(co)))) / 2.0) * (r.height)));
            y = Module06.Geom.range(0, r.height, y);
        } else if (si >= 0.0) {
            y = r.height;
        } 
        return new java.awt.Point(((r.x) + x) , ((r.y) + y));
    }

    public static java.awt.Point polarToPoint(double angle, double fx, double fy) {
        double si = java.lang.Math.sin(angle);
        double co = java.lang.Math.cos(angle);
        return new java.awt.Point(((int)((fx * co) + 0.5)) , ((int)((fy * si) + 0.5)));
    }

    public static java.awt.Point ovalAngleToPoint(java.awt.Rectangle r, double angle) {
        java.awt.Point center = Module06.Geom.center(r);
        java.awt.Point p = Module06.Geom.polarToPoint(angle, ((r.width) / 2), ((r.height) / 2));
        return new java.awt.Point(((center.x) + (p.x)) , ((center.y) + (p.y)));
    }

    public static java.awt.Point intersect(int xa, int ya, int xb, int yb, int xc, int yc, int xd, int yd) {
        double denom = ((xb - xa) * (yd - yc)) - ((yb - ya) * (xd - xc));
        double rnum = ((ya - yc) * (xd - xc)) - ((xa - xc) * (yd - yc));
        if (denom == 0.0) {
            if (rnum == 0.0) {
                if (((xa < xb) && ((xb < xc) || (xb < xd))) || ((xa > xb) && ((xb > xc) || (xb > xd)))) {
                    return new java.awt.Point(xb , yb);
                } else {
                    return new java.awt.Point(xa , ya);
                }
            } else {
                return null;
            }
        } 
        double r = rnum / denom;
        double snum = ((ya - yc) * (xb - xa)) - ((xa - xc) * (yb - ya));
        double s = snum / denom;
        if ((((0.0 <= r) && (r <= 1.0)) && (0.0 <= s)) && (s <= 1.0)) {
            int px = ((int)(xa + ((xb - xa) * r)));
            int py = ((int)(ya + ((yb - ya) * r)));
            return new java.awt.Point(px , py);
        } else {
            return null;
        }
    }

    public static double distanceFromLine(int xa, int ya, int xb, int yb, int xc, int yc) {
        int xdiff = xb - xa;
        int ydiff = yb - ya;
        long l2 = (xdiff * xdiff) + (ydiff * ydiff);
        if (l2 == 0) {
            return Module06.Geom.length(xa, ya, xc, yc);
        } 
        double rnum = ((ya - yc) * (ya - yb)) - ((xa - xc) * (xb - xa));
        double r = rnum / l2;
        if ((r < 0.0) || (r > 1.0)) {
            return java.lang.Double.MAX_VALUE;
        } 
        double xi = xa + (r * xdiff);
        double yi = ya + (r * ydiff);
        double xd = xc - xi;
        double yd = yc - yi;
        return java.lang.Math.sqrt(((xd * xd) + (yd * yd)));
    }

    public static double distanceFromLine2D(int xa, int ya, int xb, int yb, int xc, int yc) {
        java.awt.geom.Line2D.Double line = new java.awt.geom.Line2D.Double(xa , xb , ya , yb);
        return line.ptSegDist(xc, yc);
    }
}


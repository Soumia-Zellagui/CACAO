package Module06;


public class CommandButton extends javax.swing.JButton implements java.awt.event.ActionListener {
    private Module01.Command fCommand;

    public CommandButton(Module01.Command command) {
        super(command.name());
        fCommand = command;
        addActionListener(Module06.CommandButton.this);
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
        fCommand.execute();
        if (!(getText().equals(fCommand.name()))) {
            setText(fCommand.name());
        } 
    }
}


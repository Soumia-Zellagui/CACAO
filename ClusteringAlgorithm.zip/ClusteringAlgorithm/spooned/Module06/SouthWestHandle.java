package Module06;


class SouthWestHandle extends Module06.ResizeHandle {
    SouthWestHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.southWest());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(java.lang.Math.min(((r.x) + (r.width)), x) , r.y), new java.awt.Point(((r.x) + (r.width)) , java.lang.Math.max(r.y, y)));
    }
}


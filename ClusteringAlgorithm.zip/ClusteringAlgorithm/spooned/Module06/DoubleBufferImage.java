package Module06;


public class DoubleBufferImage extends java.awt.Image {
    private java.awt.Image real;

    private double scale;

    public DoubleBufferImage(java.awt.Image newReal ,double newScale) {
        real = newReal;
        scale = newScale;
    }

    public java.awt.Image getRealImage() {
        return real;
    }

    public void flush() {
        real.flush();
    }

    public java.awt.Graphics getGraphics() {
        Module06.ScalingGraphics result = new Module06.ScalingGraphics(real.getGraphics());
        result.setScale(scale);
        return result;
    }

    public int getHeight(java.awt.image.ImageObserver observer) {
        return real.getHeight(observer);
    }

    public java.lang.Object getProperty(java.lang.String name, java.awt.image.ImageObserver observer) {
        return real.getProperty(name, observer);
    }

    public java.awt.Image getScaledInstance(int width, int height, int hints) {
        return real.getScaledInstance(width, height, hints);
    }

    public java.awt.image.ImageProducer getSource() {
        return real.getSource();
    }

    public int getWidth(java.awt.image.ImageObserver observer) {
        return real.getWidth(observer);
    }
}


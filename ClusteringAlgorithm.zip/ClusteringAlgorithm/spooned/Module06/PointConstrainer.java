package Module06;


public interface PointConstrainer {
    public java.awt.Point constrainPoint(java.awt.Point p);

    public int getStepX();

    public int getStepY();
}


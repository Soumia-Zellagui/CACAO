package Module06;


public class CommandChoice extends javax.swing.JComboBox implements java.awt.event.ItemListener {
    private java.util.List fCommands;

    public CommandChoice() {
        super();
        fCommands = Module06.CollectionsFactory.current().createList(10);
        addItemListener(Module06.CommandChoice.this);
    }

    public synchronized void addItem(Module01.Command command) {
        addItem(command.name());
        fCommands.add(command);
    }

    public void itemStateChanged(java.awt.event.ItemEvent e) {
        if (((getSelectedIndex()) >= 0) && ((getSelectedIndex()) < (fCommands.size()))) {
            Module01.Command command = ((Module01.Command)(fCommands.get(getSelectedIndex())));
            if (command.isExecutable()) {
                command.execute();
            } 
        } 
    }
}


package Module06;


public class FigureAttributeConstant implements java.io.Serializable , java.lang.Cloneable {
    public static final java.lang.String FRAME_COLOR_STR = "FrameColor";

    public static final Module06.FigureAttributeConstant FRAME_COLOR = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.FRAME_COLOR_STR , 1);

    public static final java.lang.String FILL_COLOR_STR = "FillColor";

    public static final Module06.FigureAttributeConstant FILL_COLOR = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.FILL_COLOR_STR , 2);

    public static final java.lang.String TEXT_COLOR_STR = "TextColor";

    public static final Module06.FigureAttributeConstant TEXT_COLOR = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.TEXT_COLOR_STR , 3);

    public static final java.lang.String ARROW_MODE_STR = "ArrowMode";

    public static final Module06.FigureAttributeConstant ARROW_MODE = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.ARROW_MODE_STR , 4);

    public static final java.lang.String FONT_NAME_STR = "FontName";

    public static final Module06.FigureAttributeConstant FONT_NAME = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.FONT_NAME_STR , 5);

    public static final java.lang.String FONT_SIZE_STR = "FontSize";

    public static final Module06.FigureAttributeConstant FONT_SIZE = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.FONT_SIZE_STR , 6);

    public static final java.lang.String FONT_STYLE_STR = "FontStyle";

    public static final Module06.FigureAttributeConstant FONT_STYLE = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.FONT_STYLE_STR , 7);

    public static final java.lang.String URL_STR = "URL";

    public static final Module06.FigureAttributeConstant URL = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.URL_STR , 8);

    public static final java.lang.String LOCATION_STR = "Location";

    public static final Module06.FigureAttributeConstant LOCATION = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.LOCATION_STR , 9);

    public static final java.lang.String XALIGNMENT_STR = "XAlignment";

    public static final Module06.FigureAttributeConstant XALIGNMENT = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.XALIGNMENT_STR , 10);

    public static final java.lang.String YALIGNMENT_STR = "YAlignment";

    public static final Module06.FigureAttributeConstant YALIGNMENT = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.YALIGNMENT_STR , 11);

    public static final java.lang.String TOP_MARGIN_STR = "TopMargin";

    public static final Module06.FigureAttributeConstant TOP_MARGIN = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.TOP_MARGIN_STR , 12);

    public static final java.lang.String RIGHT_MARGIN_STR = "RightMargin";

    public static final Module06.FigureAttributeConstant RIGHT_MARGIN = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.RIGHT_MARGIN_STR , 13);

    public static final java.lang.String BOTTOM_MARGIN_STR = "BottomMargin";

    public static final Module06.FigureAttributeConstant BOTTOM_MARGIN = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.BOTTOM_MARGIN_STR , 14);

    public static final java.lang.String LEFT_MARGIN_STR = "LeftMargin";

    public static final Module06.FigureAttributeConstant LEFT_MARGIN = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.LEFT_MARGIN_STR , 15);

    public static final java.lang.String POPUP_MENU_STR = "PopupMenu";

    public static final Module06.FigureAttributeConstant POPUP_MENU = new Module06.FigureAttributeConstant(Module06.FigureAttributeConstant.POPUP_MENU_STR , 16);

    private static Module06.FigureAttributeConstant[] attributeConstants;

    private int myID;

    private java.lang.String myName;

    private FigureAttributeConstant(java.lang.String newName ,int newID) {
        setName(newName);
        setID(newID);
        Module06.FigureAttributeConstant.addConstant(Module06.FigureAttributeConstant.this);
    }

    public FigureAttributeConstant(java.lang.String newName) {
        this(newName, ((Module06.FigureAttributeConstant.attributeConstants.length) + 1));
    }

    private void setName(java.lang.String newName) {
        myName = newName;
    }

    public java.lang.String getName() {
        return myName;
    }

    private void setID(int newID) {
        myID = newID;
    }

    public int getID() {
        return myID;
    }

    public boolean equals(java.lang.Object compareObject) {
        if (compareObject == null) {
            return false;
        } 
        if (!(compareObject instanceof Module06.FigureAttributeConstant)) {
            return false;
        } 
        Module06.FigureAttributeConstant compareAttribute = ((Module06.FigureAttributeConstant)(compareObject));
        if ((compareAttribute.getID()) != (getID())) {
            return false;
        } 
        if (((compareAttribute.getName()) == null) && ((getName()) == null)) {
            return true;
        } 
        if (((compareAttribute.getName()) != null) && ((getName()) != null)) {
            return getName().equals(compareAttribute.getName());
        } 
        return false;
    }

    public int hashCode() {
        return getID();
    }

    private static void addConstant(Module06.FigureAttributeConstant newConstant) {
        int idPos = (newConstant.getID()) - 1;
        if ((idPos < (Module06.FigureAttributeConstant.attributeConstants.length)) && ((Module06.FigureAttributeConstant.attributeConstants[idPos]) != null)) {
            throw new Module06.JHotDrawRuntimeException(("No unique FigureAttribute ID: " + (newConstant.getID())));
        } 
        if (idPos >= (Module06.FigureAttributeConstant.attributeConstants.length)) {
            Module06.FigureAttributeConstant[] tempStrs = new Module06.FigureAttributeConstant[idPos + 1];
            java.lang.System.arraycopy(Module06.FigureAttributeConstant.attributeConstants, 0, tempStrs, 0, Module06.FigureAttributeConstant.attributeConstants.length);
            Module06.FigureAttributeConstant.attributeConstants = tempStrs;
        } 
        Module06.FigureAttributeConstant.attributeConstants[idPos] = newConstant;
    }

    public static Module06.FigureAttributeConstant getConstant(java.lang.String constantName) {
        for (int i = 0 ; i < (Module06.FigureAttributeConstant.attributeConstants.length) ; i++) {
            Module06.FigureAttributeConstant currentAttr = Module06.FigureAttributeConstant.getConstant(i);
            if (((currentAttr != null) && ((currentAttr.getName()) != null)) && (currentAttr.getName().equals(constantName))) {
                return currentAttr;
            } 
        }
        return new Module06.FigureAttributeConstant(constantName);
    }

    public static Module06.FigureAttributeConstant getConstant(int constantId) {
        return Module06.FigureAttributeConstant.attributeConstants[constantId];
    }

    {
        if ((Module06.FigureAttributeConstant.attributeConstants) == null) {
            attributeConstants = new Module06.FigureAttributeConstant[64];
        } 
    }
}


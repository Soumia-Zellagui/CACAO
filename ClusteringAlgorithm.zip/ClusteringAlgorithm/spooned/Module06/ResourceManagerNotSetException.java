package Module06;


public class ResourceManagerNotSetException extends java.lang.Exception {
    public ResourceManagerNotSetException() {
    }
}


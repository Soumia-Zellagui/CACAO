package Module06;


public class MiniMapZoomableView extends Module06.MiniMapView {
    public MiniMapZoomableView(Module03.DrawingView newMappedDrawingView ,javax.swing.JScrollPane subject) {
        super(newMappedDrawingView, subject);
    }

    public java.awt.geom.AffineTransform getInverseSubjectTransform() {
        double subjectsScale = ((Module03.ZoomDrawingView)(getMappedComponent())).getScale();
        java.awt.geom.AffineTransform at = null;
        try {
            at = java.awt.geom.AffineTransform.getScaleInstance(subjectsScale, subjectsScale).createInverse();
        } catch (java.awt.geom.NoninvertibleTransformException nte) {
        }
        return at;
    }
}


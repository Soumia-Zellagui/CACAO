package Module06;


public class Animator extends java.lang.Thread {
    private Module03.DrawingView fView;

    private Module03.Animatable fAnimatable;

    private volatile boolean fIsRunning;

    private static final int DELAY = 1000 / 16;

    public Animator(Module03.Animatable animatable ,Module03.DrawingView view) {
        super("Animator");
        fView = view;
        fAnimatable = animatable;
    }

    public void start() {
        super.start();
        fIsRunning = true;
    }

    public void end() {
        fIsRunning = false;
    }

    public void run() {
        while (fIsRunning) {
            long tm = java.lang.System.currentTimeMillis();
            fView.freezeView();
            fAnimatable.animationStep();
            fView.checkDamage();
            fView.unfreezeView();
            try {
                tm += Module06.Animator.DELAY;
                java.lang.Thread.sleep(java.lang.Math.max(0, (tm - (java.lang.System.currentTimeMillis()))));
            } catch (java.lang.InterruptedException e) {
                break;
            }
        }
    }
}


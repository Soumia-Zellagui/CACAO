package Module06;


public class MiniMapView extends javax.swing.JComponent {
    private javax.swing.JScrollPane m_subject;

    private Module03.DrawingView myMappedDrawingView;

    private Module06.SubjectListener m_subjectListener;

    private Module03.DrawingChangeListener myDrawingChangeListener;

    private java.awt.Color m_viewBoxColor = java.awt.Color.red;

    public MiniMapView(Module03.DrawingView newMappedDrawingView ,javax.swing.JScrollPane subject) {
        m_subjectListener = new Module06.SubjectListener(Module06.MiniMapView.this);
        setSubject(subject);
        setMappedDrawingView(newMappedDrawingView);
        myDrawingChangeListener = new Module03.MappedDrawingChangeListener(Module06.MiniMapView.this);
        getMappedDrawingView().drawing().addDrawingChangeListener(myDrawingChangeListener);
        Module06.MiniMapView.MouseListener ml = new Module06.MiniMapView.MouseListener();
        addMouseListener(ml);
        addMouseMotionListener(ml);
    }

    protected void setMappedDrawingView(Module03.DrawingView newMappedDrawingView) {
        myMappedDrawingView = newMappedDrawingView;
    }

    public Module03.DrawingView getMappedDrawingView() {
        return myMappedDrawingView;
    }

    protected void setSubject(javax.swing.JScrollPane subject) {
        if ((m_subject) != null) {
            m_subject.getViewport().removeChangeListener(m_subjectListener);
        } 
        m_subject = subject;
        if ((m_subject) != null) {
            m_subject.getViewport().addChangeListener(m_subjectListener);
        } 
        repaint();
    }

    public javax.swing.JScrollPane getSubject() {
        return m_subject;
    }

    public java.awt.Color getViewBowColor() {
        return m_viewBoxColor;
    }

    public void setViewBoxColor(java.awt.Color c) {
        m_viewBoxColor = c;
        repaint();
    }

    protected java.awt.Component getMappedComponent() {
        return ((java.awt.Component)(getMappedDrawingView()));
    }

    public void paint(java.awt.Graphics g) {
        java.awt.Graphics2D g2d = ((java.awt.Graphics2D)(g));
        java.awt.Component mappedComponent = getMappedComponent();
        java.awt.geom.AffineTransform at = getViewToMiniMapTransform(mappedComponent);
        g2d.transform(at);
        getMappedDrawingView().drawAll(g2d);
        drawViewRectangle(g2d, getViewRectangle());
    }

    protected void drawViewRectangle(java.awt.Graphics2D g2d, java.awt.Rectangle viewPortRectangle) {
        java.awt.geom.AffineTransform at = new java.awt.geom.AffineTransform();
        at.setToIdentity();
        g2d.setTransform(at);
        g2d.setColor(m_viewBoxColor);
        g2d.draw(viewPortRectangle);
    }

    protected java.awt.geom.AffineTransform getViewToMiniMapTransform(java.awt.Component mappedComponent) {
        double scaleX = ((double)(getWidth())) / ((double)(mappedComponent.getWidth()));
        double scaleY = ((double)(getHeight())) / ((double)(mappedComponent.getHeight()));
        java.awt.geom.AffineTransform at = getInverseSubjectTransform();
        at.concatenate(java.awt.geom.AffineTransform.getScaleInstance(scaleX, scaleY));
        return at;
    }

    protected java.awt.geom.AffineTransform getInverseSubjectTransform() {
        java.awt.geom.AffineTransform at = new java.awt.geom.AffineTransform();
        at.setToIdentity();
        return at;
    }

    protected java.awt.Rectangle getViewRectangle() {
        java.awt.Rectangle visiblePortion = m_subject.getViewportBorderBounds();
        java.awt.Point upperLeftViewPos = m_subject.getViewport().getViewPosition();
        double[] srcRecCorners = new double[4];
        double[] dstRecCorners = new double[4];
        srcRecCorners[0] = (upperLeftViewPos.x) + (visiblePortion.getX());
        srcRecCorners[1] = (upperLeftViewPos.y) + (visiblePortion.getY());
        srcRecCorners[2] = ((upperLeftViewPos.x) + (visiblePortion.getX())) + (visiblePortion.getWidth());
        srcRecCorners[3] = ((upperLeftViewPos.y) + (visiblePortion.getY())) + (visiblePortion.getHeight());
        getViewToMiniMapTransform(getMappedComponent()).transform(srcRecCorners, 0, dstRecCorners, 0, ((srcRecCorners.length) / 2));
        return new java.awt.Rectangle(((int)(dstRecCorners[0])) , ((int)(dstRecCorners[1])) , ((int)((dstRecCorners[2]) - (dstRecCorners[0]))) , ((int)((dstRecCorners[3]) - (dstRecCorners[1]))));
    }

    protected void scrollSubjectTo(int upperLeftX, int upperLeftY) {
        java.awt.geom.AffineTransform at = null;
        try {
            at = getViewToMiniMapTransform(getMappedComponent()).createInverse();
        } catch (java.awt.geom.NoninvertibleTransformException nite) {
            nite.printStackTrace();
            return ;
        }
        double[] srcPoints = new double[2];
        double[] destPoints = new double[2];
        srcPoints[0] = upperLeftX;
        srcPoints[1] = upperLeftY;
        at.transform(srcPoints, 0, destPoints, 0, 1);
        if ((destPoints[0]) < 0) {
            destPoints[0] = 0;
        } 
        if ((destPoints[1]) < 0) {
            destPoints[1] = 0;
        } 
        m_subject.getViewport().setViewPosition(new java.awt.Point(((int)(destPoints[0])) , ((int)(destPoints[1]))));
    }

    protected int[] getUpperLeftPointsFromCenter(int centerX, int centerY) {
        int[] upperLeft = new int[2];
        java.awt.Rectangle oldRectangle = getViewRectangle();
        upperLeft[0] = centerX - ((oldRectangle.width) / 2);
        upperLeft[1] = centerY - ((oldRectangle.height) / 2);
        if (((upperLeft[0]) + (oldRectangle.width)) > ((getX()) + (getWidth()))) {
            upperLeft[0] = ((getX()) + (getWidth())) - (oldRectangle.width);
        } 
        if (((upperLeft[1]) + (oldRectangle.height)) > ((getY()) + (getHeight()))) {
            upperLeft[1] = ((getY()) + (getHeight())) - (oldRectangle.height);
        } 
        return upperLeft;
    }

    public class MouseListener extends java.awt.event.MouseAdapter implements java.awt.event.MouseMotionListener {
        public void mousePressed(java.awt.event.MouseEvent e) {
            int[] rectangleUpperLeft = getUpperLeftPointsFromCenter(e.getX(), e.getY());
            scrollSubjectTo(rectangleUpperLeft[0], rectangleUpperLeft[1]);
        }

        public void mouseDragged(java.awt.event.MouseEvent e) {
            int[] rectangleUpperLeft = getUpperLeftPointsFromCenter(e.getX(), e.getY());
            scrollSubjectTo(rectangleUpperLeft[0], rectangleUpperLeft[1]);
        }

        public void mouseMoved(java.awt.event.MouseEvent e) {
        }
    }
}


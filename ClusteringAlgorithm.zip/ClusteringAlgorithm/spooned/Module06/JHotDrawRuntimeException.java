package Module06;


public class JHotDrawRuntimeException extends java.lang.RuntimeException {
    private java.lang.Exception myNestedException;

    public JHotDrawRuntimeException(java.lang.String msg) {
        super(msg);
    }

    public JHotDrawRuntimeException(java.lang.Exception nestedException) {
        this(nestedException.getLocalizedMessage());
        setNestedException(nestedException);
        nestedException.fillInStackTrace();
    }

    protected void setNestedException(java.lang.Exception newNestedException) {
        myNestedException = newNestedException;
    }

    public java.lang.Exception getNestedException() {
        return myNestedException;
    }
}


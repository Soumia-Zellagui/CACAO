package Module06;


class NorthHandle extends Module06.ResizeHandle {
    NorthHandle(Module03.Figure owner) {
        super(owner, Module03.RelativeLocator.north());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Rectangle r = owner().displayBox();
        owner().displayBox(new java.awt.Point(r.x , java.lang.Math.min(((r.y) + (r.height)), y)), new java.awt.Point(((r.x) + (r.width)) , ((r.y) + (r.height))));
    }
}


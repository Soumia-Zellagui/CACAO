package Module06;


public class BoxHandleKit {
    public static void addCornerHandles(Module03.Figure f, java.util.List handles) {
        handles.add(Module06.BoxHandleKit.southEast(f));
        handles.add(Module06.BoxHandleKit.southWest(f));
        handles.add(Module06.BoxHandleKit.northEast(f));
        handles.add(Module06.BoxHandleKit.northWest(f));
    }

    public static void addHandles(Module03.Figure f, java.util.List handles) {
        Module06.BoxHandleKit.addCornerHandles(f, handles);
        handles.add(Module06.BoxHandleKit.south(f));
        handles.add(Module06.BoxHandleKit.north(f));
        handles.add(Module06.BoxHandleKit.east(f));
        handles.add(Module06.BoxHandleKit.west(f));
    }

    public static Module05.Handle south(Module03.Figure owner) {
        return new Module06.SouthHandle(owner);
    }

    public static Module05.Handle southEast(Module03.Figure owner) {
        return new Module06.SouthEastHandle(owner);
    }

    public static Module05.Handle southWest(Module03.Figure owner) {
        return new Module06.SouthWestHandle(owner);
    }

    public static Module05.Handle north(Module03.Figure owner) {
        return new Module06.NorthHandle(owner);
    }

    public static Module05.Handle northEast(Module03.Figure owner) {
        return new Module06.NorthEastHandle(owner);
    }

    public static Module05.Handle northWest(Module03.Figure owner) {
        return new Module06.NorthWestHandle(owner);
    }

    public static Module05.Handle east(Module03.Figure owner) {
        return new Module06.EastHandle(owner);
    }

    public static Module05.Handle west(Module03.Figure owner) {
        return new Module06.WestHandle(owner);
    }
}


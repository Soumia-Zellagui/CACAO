package Module06;


public class GridConstrainer implements Module06.PointConstrainer , java.io.Serializable {
    private int fGridX;

    private int fGridY;

    public GridConstrainer(int x ,int y) {
        fGridX = java.lang.Math.max(1, x);
        fGridY = java.lang.Math.max(1, y);
    }

    public java.awt.Point constrainPoint(java.awt.Point p) {
        p.x = (((p.x) + ((fGridX) / 2)) / (fGridX)) * (fGridX);
        p.y = (((p.y) + ((fGridY) / 2)) / (fGridY)) * (fGridY);
        return p;
    }

    public int getStepX() {
        return fGridX;
    }

    public int getStepY() {
        return fGridY;
    }
}


package Module06;


public class ETSLADisposalStrategy implements Module06.ResourceDisposabilityStrategy {
    private Module06.DisposableResourceManager manager;

    private long gcPeriodicity = 60000;

    private Module06.DisposalThread disposalThread = null;

    private boolean disposingActive = false;

    public ETSLADisposalStrategy() {
    }

    public ETSLADisposalStrategy(long periodicity) {
        this(null, periodicity);
    }

    public ETSLADisposalStrategy(Module06.DisposableResourceManager newManager ,long newPeriodicity) {
        setManager(newManager);
        setPeriodicity(newPeriodicity);
        initDisposalThread();
    }

    public synchronized void setManager(Module06.DisposableResourceManager newManager) {
        if ((getManager()) == null) {
            stopDisposing(java.lang.Long.MAX_VALUE);
        } 
        manager = newManager;
    }

    public Module06.DisposableResourceManager getManager() {
        return manager;
    }

    public void startDisposing() throws Module06.ResourceManagerNotSetException {
        if ((getManager()) == null) {
            Module06.ResourceManagerNotSetException resourceManagerNotSetException = new Module06.ResourceManagerNotSetException();
            throw resourceManagerNotSetException;
        } 
        if (disposingActive) {
            return ;
        } 
        disposingActive = true;
        disposalThread.start();
    }

    public void stopDisposing(long millis) {
        if (!(disposingActive)) {
            return ;
        } 
        try {
            disposalThread.interruptDisposalPending = true;
            disposalThread.join(millis);
        } catch (java.lang.InterruptedException ex) {
        } finally {
            disposingActive = false;
        }
    }

    protected void initDisposalThread() {
        if ((disposalThread) != null) {
            return ;
        } 
        disposalThread = new Module06.DisposalThread(Module06.ETSLADisposalStrategy.this , getPeriodicity());
    }

    protected synchronized void dispose() {
        synchronized(getManager()) {
            long currentTime = java.lang.System.currentTimeMillis();
            java.util.Iterator resourceIter = getManager().getResources();
            Module06.DisposableResourceHolder resource;
            while (resourceIter.hasNext()) {
                resource = ((Module06.DisposableResourceHolder)(resourceIter.next()));
                synchronized(resource) {
                    if ((!(resource.isLocked())) && (((resource.getLastTimeAccessed()) + (resource.getDisposableDelay())) < currentTime)) {
                        resource.dispose();
                    } 
                }
            }
        }
    }

    public long getPeriodicity() {
        return gcPeriodicity;
    }

    public void setPeriodicity(long newPeriodicity) {
        gcPeriodicity = newPeriodicity;
        if ((disposalThread) != null) {
            disposalThread.setPeriodicity(newPeriodicity);
        } 
    }
}


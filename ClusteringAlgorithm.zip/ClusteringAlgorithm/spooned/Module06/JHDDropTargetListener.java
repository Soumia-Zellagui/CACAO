package Module06;


public class JHDDropTargetListener implements java.awt.dnd.DropTargetListener {
    private int fLastX = 0;

    private int fLastY = 0;

    private Module06.Undoable targetUndoable;

    private Module03.DrawingView dv;

    private Module01.DrawingEditor editor;

    public JHDDropTargetListener(Module01.DrawingEditor drawingEditor ,Module03.DrawingView drawingView) {
        dv = drawingView;
        editor = drawingEditor;
    }

    protected Module03.DrawingView view() {
        return dv;
    }

    protected Module01.DrawingEditor editor() {
        return editor;
    }

    public void dragEnter(java.awt.dnd.DropTargetDragEvent dtde) {
        Module06.JHDDropTargetListener.log("DropTargetDragEvent-dragEnter");
        supportDropTargetDragEvent(dtde);
        if ((fLastX) == 0) {
            fLastX = dtde.getLocation().x;
        } 
        if ((fLastY) == 0) {
            fLastY = dtde.getLocation().y;
        } 
    }

    public void dragExit(java.awt.dnd.DropTargetEvent dte) {
        Module06.JHDDropTargetListener.log("DropTargetEvent-dragExit");
    }

    public void dragOver(java.awt.dnd.DropTargetDragEvent dtde) {
        if ((supportDropTargetDragEvent(dtde)) == true) {
            int x = dtde.getLocation().x;
            int y = dtde.getLocation().y;
            if (((java.lang.Math.abs((x - (fLastX)))) > 0) || ((java.lang.Math.abs((y - (fLastY)))) > 0)) {
                fLastX = x;
                fLastY = y;
            } 
        } 
    }

    public void drop(java.awt.dnd.DropTargetDropEvent dtde) {
        java.lang.System.out.println("DropTargetDropEvent-drop");
        if ((dtde.isDataFlavorSupported(Module03.DNDFiguresTransferable.DNDFiguresFlavor)) == true) {
            Module06.JHDDropTargetListener.log("DNDFiguresFlavor");
            if (((dtde.getDropAction()) & (java.awt.dnd.DnDConstants.ACTION_COPY_OR_MOVE)) != 0) {
                Module06.JHDDropTargetListener.log("copy or move");
                if ((dtde.isLocalTransfer()) == false) {
                    java.lang.System.err.println("Intra-JVM Transfers not implemented for figures yet.");
                    dtde.rejectDrop();
                    return ;
                } 
                dtde.acceptDrop(dtde.getDropAction());
                try {
                    setTargetUndoActivity(createTargetUndoActivity(view()));
                    Module03.DNDFigures ff = ((Module03.DNDFigures)(Module03.DNDHelper.processReceivedData(Module03.DNDFiguresTransferable.DNDFiguresFlavor, dtde.getTransferable())));
                    getTargetUndoActivity().setAffectedFigures(ff.getFigures());
                    java.awt.Point theO = ff.getOrigin();
                    view().clearSelection();
                    java.awt.Point newP = dtde.getLocation();
                    int dx = (newP.x) - (theO.x);
                    int dy = (newP.y) - (theO.y);
                    Module06.JHDDropTargetListener.log(("mouse at " + newP));
                    Module03.FigureEnumeration fe = view().insertFigures(getTargetUndoActivity().getAffectedFigures(), dx, dy, false);
                    getTargetUndoActivity().setAffectedFigures(fe);
                    if ((dtde.getDropAction()) == (java.awt.dnd.DnDConstants.ACTION_MOVE)) {
                        view().addToSelectionAll(getTargetUndoActivity().getAffectedFigures());
                    } 
                    view().checkDamage();
                    editor().getUndoManager().pushUndo(getTargetUndoActivity());
                    editor().getUndoManager().clearRedos();
                    editor().figureSelectionChanged(view());
                    dtde.dropComplete(true);
                } catch (java.lang.NullPointerException npe) {
                    npe.printStackTrace();
                    dtde.dropComplete(false);
                }
            } else {
                dtde.rejectDrop();
            }
        } else if (dtde.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.stringFlavor)) {
            Module06.JHDDropTargetListener.log("String flavor dropped.");
            dtde.acceptDrop(dtde.getDropAction());
            java.lang.Object o = Module03.DNDHelper.processReceivedData(java.awt.datatransfer.DataFlavor.stringFlavor, dtde.getTransferable());
            if (o != null) {
                Module06.JHDDropTargetListener.log("Received string flavored data.");
                dtde.getDropTargetContext().dropComplete(true);
            } else {
                dtde.getDropTargetContext().dropComplete(false);
            }
        } else if ((dtde.isDataFlavorSupported(Module03.DNDHelper.ASCIIFlavor)) == true) {
            Module06.JHDDropTargetListener.log("ASCII Flavor dropped.");
            dtde.acceptDrop(java.awt.dnd.DnDConstants.ACTION_COPY);
            java.lang.Object o = Module03.DNDHelper.processReceivedData(Module03.DNDHelper.ASCIIFlavor, dtde.getTransferable());
            if (o != null) {
                Module06.JHDDropTargetListener.log("Received ASCII Flavored data.");
                dtde.getDropTargetContext().dropComplete(true);
            } else {
                dtde.getDropTargetContext().dropComplete(false);
            }
        } else if (dtde.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.javaFileListFlavor)) {
            Module06.JHDDropTargetListener.log("Java File List Flavor dropped.");
            dtde.acceptDrop(java.awt.dnd.DnDConstants.ACTION_COPY);
            java.io.File[] fList = ((java.io.File[])(Module03.DNDHelper.processReceivedData(java.awt.datatransfer.DataFlavor.javaFileListFlavor, dtde.getTransferable())));
            if (fList != null) {
                Module06.JHDDropTargetListener.log("Got list of files.");
                for (int x = 0 ; x < (fList.length) ; x++) {
                    java.lang.System.out.println(fList[x].getAbsolutePath());
                }
                dtde.getDropTargetContext().dropComplete(true);
            } else {
                dtde.getDropTargetContext().dropComplete(false);
            }
        } 
        fLastX = 0;
        fLastY = 0;
    }

    public void dropActionChanged(java.awt.dnd.DropTargetDragEvent dtde) {
        Module06.JHDDropTargetListener.log("DropTargetDragEvent-dropActionChanged");
        supportDropTargetDragEvent(dtde);
    }

    protected boolean supportDropTargetDragEvent(java.awt.dnd.DropTargetDragEvent dtde) {
        if ((dtde.isDataFlavorSupported(Module03.DNDFiguresTransferable.DNDFiguresFlavor)) == true) {
            if (((dtde.getDropAction()) & (java.awt.dnd.DnDConstants.ACTION_COPY_OR_MOVE)) != 0) {
                dtde.acceptDrag(dtde.getDropAction());
                return true;
            } else {
                dtde.rejectDrag();
                return false;
            }
        } else if ((dtde.isDataFlavorSupported(Module03.DNDHelper.ASCIIFlavor)) == true) {
            dtde.acceptDrag(dtde.getDropAction());
            return true;
        } else if ((dtde.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.stringFlavor)) == true) {
            dtde.acceptDrag(dtde.getDropAction());
            return true;
        } else if ((dtde.isDataFlavorSupported(java.awt.datatransfer.DataFlavor.javaFileListFlavor)) == true) {
            dtde.acceptDrag(dtde.getDropAction());
            return true;
        } else {
            dtde.rejectDrag();
            return false;
        }
    }

    protected Module06.Undoable createTargetUndoActivity(Module03.DrawingView view) {
        Module06.JHDDropTargetListener.AddUndoActivity addUndoActivity = new Module06.JHDDropTargetListener.AddUndoActivity(view);
        return addUndoActivity;
    }

    protected void setTargetUndoActivity(Module06.Undoable undoable) {
        targetUndoable = undoable;
    }

    protected Module06.Undoable getTargetUndoActivity() {
        return targetUndoable;
    }

    public static class AddUndoActivity extends Module06.UndoableAdapter {
        private boolean undone = false;

        public AddUndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            Module06.JHDDropTargetListener.log(("AddUndoActivity created " + newDrawingView));
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module06.JHDDropTargetListener.log("AddUndoActivity AddUndoActivity undo");
            Module03.DeleteFromDrawingVisitor deleteVisitor = new Module03.DeleteFromDrawingVisitor(getDrawingView().drawing());
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                f.visit(deleteVisitor);
            }
            setAffectedFigures(deleteVisitor.getDeletedFigures());
            getDrawingView().clearSelection();
            undone = true;
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            Module06.JHDDropTargetListener.log("AddUndoActivity redo");
            getDrawingView().clearSelection();
            setAffectedFigures(getDrawingView().insertFigures(getAffectedFigures(), 0, 0, false));
            undone = false;
            return true;
        }

        public void release() {
            if ((undone) == true) {
                Module03.FigureEnumeration fe = getAffectedFigures();
                while (fe.hasNextFigure()) {
                    Module03.Figure f = fe.nextFigure();
                    getDrawingView().drawing().remove(f);
                    f.release();
                }
            } 
            setAffectedFigures(Module03.FigureEnumerator.getEmptyEnumeration());
        }
    }

    private static void log(java.lang.String message) {
    }
}


package Module06;


public interface Cursor {}


package Module06;


public class ReverseListEnumerator implements java.util.Iterator {
    private java.util.List myList;

    private int count;

    public ReverseListEnumerator(java.util.List l) {
        myList = l;
        count = (myList.size()) - 1;
    }

    public boolean hasNext() {
        return (count) >= 0;
    }

    public java.lang.Object next() {
        if ((count) >= 0) {
            return myList.get(((count)--));
        } 
        throw new java.util.NoSuchElementException("ReverseListEnumerator");
    }

    public void remove() {
        myList.remove(count);
        (count)--;
    }
}


package Module06;


public class UndoRedoActivity implements Module06.Undoable {
    private Module06.Undoable myReversedActivity;

    protected UndoRedoActivity(Module06.Undoable newReversedActivity) {
        setReversedActivity(newReversedActivity);
    }

    public boolean undo() {
        if (isRedoable()) {
            Module06.Undoable ra = getReversedActivity();
            return ra.redo();
        } 
        return false;
    }

    public boolean redo() {
        if (isUndoable()) {
            Module06.Undoable ra = getReversedActivity();
            return ra.undo();
        } 
        return false;
    }

    public boolean isUndoable() {
        Module06.Undoable ra = getReversedActivity();
        return ra.isRedoable();
    }

    public void setUndoable(boolean newIsUndoable) {
        Module06.Undoable ra = getReversedActivity();
        ra.setRedoable(newIsUndoable);
    }

    public boolean isRedoable() {
        Module06.Undoable ra = getReversedActivity();
        return ra.isUndoable();
    }

    public void setRedoable(boolean newIsRedoable) {
        Module06.Undoable ra = getReversedActivity();
        ra.setUndoable(newIsRedoable);
    }

    public void setAffectedFigures(Module03.FigureEnumeration newAffectedFigures) {
        Module06.Undoable ra = getReversedActivity();
        ra.setAffectedFigures(newAffectedFigures);
    }

    public Module03.FigureEnumeration getAffectedFigures() {
        return getReversedActivity().getAffectedFigures();
    }

    public int getAffectedFiguresCount() {
        return getReversedActivity().getAffectedFiguresCount();
    }

    public Module03.DrawingView getDrawingView() {
        Module06.Undoable ra = getReversedActivity();
        Module03.DrawingView dv = ra.getDrawingView();
        return dv;
    }

    public void release() {
        getReversedActivity().release();
    }

    protected void setReversedActivity(Module06.Undoable newReversedActivity) {
        myReversedActivity = newReversedActivity;
    }

    public Module06.Undoable getReversedActivity() {
        return myReversedActivity;
    }

    public static Module06.Undoable createUndoRedoActivity(Module06.Undoable toBeReversed) {
        if (toBeReversed instanceof Module06.UndoRedoActivity) {
            return ((Module06.UndoRedoActivity)(toBeReversed)).getReversedActivity();
        } else {
            Module06.Undoable Und = new Module06.UndoRedoActivity(toBeReversed);
            return Und;
        }
    }
}


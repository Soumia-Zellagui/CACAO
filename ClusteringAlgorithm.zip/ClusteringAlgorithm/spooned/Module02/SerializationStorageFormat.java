package Module02;


public class SerializationStorageFormat extends Module02.StandardStorageFormat {
    public SerializationStorageFormat() {
        super();
    }

    protected java.lang.String createFileExtension() {
        return "ser";
    }

    public java.lang.String createFileDescription() {
        return ("Serialization (" + (getFileExtension())) + ")";
    }

    public java.lang.String store(java.lang.String fileName, Module03.Drawing saveDrawing) throws java.io.IOException {
        java.io.FileOutputStream stream = new java.io.FileOutputStream(adjustFileName(fileName));
        java.io.ObjectOutput output = new java.io.ObjectOutputStream(stream);
        output.writeObject(saveDrawing);
        output.close();
        return adjustFileName(fileName);
    }

    public Module03.Drawing restore(java.lang.String fileName) throws java.io.IOException {
        try {
            java.io.FileInputStream stream = new java.io.FileInputStream(fileName);
            java.io.ObjectInput input = new java.io.ObjectInputStream(stream);
            return ((Module03.Drawing)(input.readObject()));
        } catch (java.lang.ClassNotFoundException exception) {
            throw new java.io.IOException((("Could not restore drawing '" + fileName) + "': class not found!"));
        }
    }
}


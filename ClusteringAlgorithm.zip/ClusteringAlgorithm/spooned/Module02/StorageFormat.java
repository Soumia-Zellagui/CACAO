package Module02;


public interface StorageFormat {
    public javax.swing.filechooser.FileFilter getFileFilter();

    public boolean isStoreFormat();

    public boolean isRestoreFormat();

    public java.lang.String store(java.lang.String fileName, Module03.Drawing saveDrawing) throws java.io.IOException;

    public Module03.Drawing restore(java.lang.String fileName) throws java.io.IOException;
}


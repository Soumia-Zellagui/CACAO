package Module02;


public class StandardStorageFormat implements Module02.StorageFormat {
    private javax.swing.filechooser.FileFilter myFileFilter;

    private java.lang.String myFileExtension;

    private java.lang.String myFileDescription;

    public StandardStorageFormat() {
        setFileExtension(createFileExtension());
        setFileDescription(createFileDescription());
        setFileFilter(createFileFilter());
    }

    protected java.lang.String createFileExtension() {
        return myFileExtension = "draw";
    }

    public void setFileExtension(java.lang.String newFileExtension) {
        myFileExtension = newFileExtension;
    }

    public java.lang.String getFileExtension() {
        return myFileExtension;
    }

    public java.lang.String createFileDescription() {
        return ("Internal Format (" + (getFileExtension())) + ")";
    }

    public void setFileDescription(java.lang.String newFileDescription) {
        myFileDescription = newFileDescription;
    }

    public java.lang.String getFileDescription() {
        return myFileDescription;
    }

    protected javax.swing.filechooser.FileFilter createFileFilter() {
        return new javax.swing.filechooser.FileFilter() {
            public boolean accept(java.io.File checkFile) {
                if (checkFile.isDirectory()) {
                    return true;
                } else {
                    return checkFile.getName().endsWith(("." + (getFileExtension())));
                }
            }

            public java.lang.String getDescription() {
                return getFileDescription();
            }
        };
    }

    public void setFileFilter(javax.swing.filechooser.FileFilter newFileFilter) {
        myFileFilter = newFileFilter;
    }

    public javax.swing.filechooser.FileFilter getFileFilter() {
        return myFileFilter;
    }

    public boolean isRestoreFormat() {
        return true;
    }

    public boolean isStoreFormat() {
        return true;
    }

    public java.lang.String store(java.lang.String fileName, Module03.Drawing saveDrawing) throws java.io.IOException {
        java.io.FileOutputStream stream = new java.io.FileOutputStream(adjustFileName(fileName));
        Module06.StorableOutput output = new Module06.StorableOutput(stream);
        output.writeStorable(saveDrawing);
        output.close();
        return adjustFileName(fileName);
    }

    public Module03.Drawing restore(java.lang.String fileName) throws java.io.IOException {
        if (!(hasCorrectFileExtension(fileName))) {
            return null;
        } else {
            java.io.FileInputStream stream = new java.io.FileInputStream(fileName);
            Module06.StorableInput input = new Module06.StorableInput(stream);
            return ((Module03.Drawing)(input.readStorable()));
        }
    }

    public boolean equals(java.lang.Object compareObject) {
        if (compareObject instanceof Module02.StandardStorageFormat) {
            return getFileExtension().equals(((Module02.StandardStorageFormat)(compareObject)).getFileExtension());
        } else {
            return false;
        }
    }

    protected java.lang.String adjustFileName(java.lang.String testFileName) {
        if (!(hasCorrectFileExtension(testFileName))) {
            return (testFileName + ".") + (getFileExtension());
        } else {
            return testFileName;
        }
    }

    protected boolean hasCorrectFileExtension(java.lang.String testFileName) {
        return testFileName.endsWith(("." + (getFileExtension())));
    }
}


package Module02;


public class StorageFormatManager {
    private java.util.List myStorageFormats;

    private Module02.StorageFormat myDefaultStorageFormat;

    public StorageFormatManager() {
        myStorageFormats = new java.util.ArrayList<>();
    }

    public void addStorageFormat(Module02.StorageFormat newStorageFormat) {
        myStorageFormats.add(newStorageFormat);
    }

    public void removeStorageFormat(Module02.StorageFormat oldStorageFormat) {
        myStorageFormats.remove(oldStorageFormat);
    }

    public boolean containsStorageFormat(Module02.StorageFormat checkStorageFormat) {
        return myStorageFormats.contains(checkStorageFormat);
    }

    public void setDefaultStorageFormat(Module02.StorageFormat newDefaultStorageFormat) {
        myDefaultStorageFormat = newDefaultStorageFormat;
    }

    public Module02.StorageFormat getDefaultStorageFormat() {
        return myDefaultStorageFormat;
    }

    public void registerFileFilters(javax.swing.JFileChooser fileChooser) {
        if ((fileChooser.getDialogType()) == (javax.swing.JFileChooser.OPEN_DIALOG)) {
            Module02.StorageFormat sf;
            for (java.util.Iterator e = myStorageFormats.iterator() ; e.hasNext() ; ) {
                sf = ((Module02.StorageFormat)(e.next()));
                if (sf.isRestoreFormat()) {
                    fileChooser.addChoosableFileFilter(sf.getFileFilter());
                } 
            }
            sf = getDefaultStorageFormat();
            if ((sf != null) && (sf.isRestoreFormat())) {
                fileChooser.setFileFilter(sf.getFileFilter());
            } 
        } else if ((fileChooser.getDialogType()) == (javax.swing.JFileChooser.SAVE_DIALOG)) {
            Module02.StorageFormat sf;
            for (java.util.Iterator e = myStorageFormats.iterator() ; e.hasNext() ; ) {
                sf = ((Module02.StorageFormat)(e.next()));
                if (sf.isStoreFormat()) {
                    fileChooser.addChoosableFileFilter(sf.getFileFilter());
                } 
            }
            sf = getDefaultStorageFormat();
            if ((sf != null) && (sf.isStoreFormat())) {
                fileChooser.setFileFilter(sf.getFileFilter());
            } 
        } else {
            Module02.StorageFormat sf;
            for (java.util.Iterator e = myStorageFormats.iterator() ; e.hasNext() ; ) {
                sf = ((Module02.StorageFormat)(e.next()));
                fileChooser.addChoosableFileFilter(sf.getFileFilter());
            }
            sf = getDefaultStorageFormat();
            if (sf != null) {
                fileChooser.setFileFilter(sf.getFileFilter());
            } 
        }
    }

    public Module02.StorageFormat findStorageFormat(javax.swing.filechooser.FileFilter findFileFilter) {
        java.util.Iterator formatsIterator = myStorageFormats.iterator();
        Module02.StorageFormat currentStorageFormat = null;
        while (formatsIterator.hasNext()) {
            currentStorageFormat = ((Module02.StorageFormat)(formatsIterator.next()));
            if (currentStorageFormat.getFileFilter().equals(findFileFilter)) {
                return currentStorageFormat;
            } 
        }
        return null;
    }

    public Module02.StorageFormat findStorageFormat(java.io.File file) {
        java.util.Iterator formatsIterator = myStorageFormats.iterator();
        Module02.StorageFormat currentStorageFormat;
        while (formatsIterator.hasNext()) {
            currentStorageFormat = ((Module02.StorageFormat)(formatsIterator.next()));
            if (currentStorageFormat.getFileFilter().accept(file)) {
                return currentStorageFormat;
            } 
        }
        return null;
    }
}


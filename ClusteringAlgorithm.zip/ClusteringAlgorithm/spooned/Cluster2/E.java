package Cluster2;


public class E extends Cluster1.A {}


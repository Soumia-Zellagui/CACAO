package Cluster2;


public class B {
    public void mB() {
        Cluster2.J f = new Cluster2.J();
        f.k = new Cluster4.K();
        f.mF();
    }
}


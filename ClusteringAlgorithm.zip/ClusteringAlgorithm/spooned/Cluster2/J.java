package Cluster2;


public class J {
    Cluster4.K k;

    public void mF() {
        Cluster1.A a = new Cluster1.A();
    }
}


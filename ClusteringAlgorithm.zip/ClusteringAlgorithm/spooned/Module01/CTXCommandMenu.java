package Module01;


public class CTXCommandMenu extends javax.swing.JMenu implements Module01.CommandListener , java.awt.event.ActionListener {
    public CTXCommandMenu(java.lang.String name) {
        super(name);
    }

    public synchronized void add(Module01.Command command) {
        Module06.CommandMenuItem commandMenuItem = new Module06.CommandMenuItem(command);
        addMenuItem(commandMenuItem);
    }

    public synchronized void add(Module01.Command command, java.awt.MenuShortcut shortcut) {
        Module06.CommandMenuItem commandMenuItem = new Module06.CommandMenuItem(command , shortcut.getKey());
        addMenuItem(commandMenuItem);
    }

    public synchronized void addCheckItem(Module01.Command command) {
        Module06.CommandCheckBoxMenuItem commandCheckBoxMenuItem = new Module06.CommandCheckBoxMenuItem(command);
        addMenuItem(commandCheckBoxMenuItem);
    }

    public synchronized void add(Module06.CommandMenuItem item) {
        addMenuItem(item);
    }

    public synchronized void add(Module06.CommandCheckBoxMenuItem checkItem) {
        addMenuItem(checkItem);
    }

    protected void addMenuItem(javax.swing.JMenuItem m) {
        m.addActionListener(Module01.CTXCommandMenu.this);
        add(m);
        ((Module06.CommandHolder)(m)).getCommand().addCommandListener(Module01.CTXCommandMenu.this);
    }

    public synchronized void remove(Module01.Command command) {
        Module06.JHotDrawRuntimeException JhotdrawRuntimeException = new Module06.JHotDrawRuntimeException("not implemented");
        throw JhotdrawRuntimeException;
    }

    public synchronized void remove(java.awt.MenuItem item) {
        Module06.JHotDrawRuntimeException JhotdrawRuntimeException = new Module06.JHotDrawRuntimeException("not implemented");
        throw JhotdrawRuntimeException;
    }

    public synchronized void enable(java.lang.String name, boolean state) {
        for (int i = 0 ; i < (getItemCount()) ; i++) {
            javax.swing.JMenuItem item = getItem(i);
            if (name.equals(item.getText())) {
                item.setEnabled(state);
                return ;
            } 
        }
    }

    public synchronized void checkEnabled() {
        int j = 0;
        for (int i = 0 ; i < (getMenuComponentCount()) ; i++) {
            javax.swing.JMenuItem currentItem = getItem(i);
            if (currentItem instanceof Module01.CommandMenu) {
                ((Module01.CommandMenu)(currentItem)).checkEnabled();
            } else if (currentItem instanceof Module01.CTXCommandMenu) {
                ((Module01.CTXCommandMenu)(currentItem)).checkEnabled();
            } else if (currentItem instanceof Module06.CommandHolder) {
                currentItem.setEnabled(((Module06.CommandHolder)(currentItem)).getCommand().isExecutable());
            } else if (currentItem instanceof Module01.Command) {
                currentItem.setEnabled(((Module01.Command)(currentItem)).isExecutable());
            } 
            j++;
        }
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
        int j = 0;
        java.lang.Object source = e.getSource();
        for (int i = 0 ; i < (getItemCount()) ; i++) {
            if ((getMenuComponent(i)) instanceof javax.swing.JSeparator) {
                continue;
            } 
            javax.swing.JMenuItem item = getItem(i);
            if (source == item) {
                Module01.Command cmd = ((Module06.CommandHolder)(item)).getCommand();
                cmd.execute();
                break;
            } 
            j++;
        }
    }

    public void commandExecuted(java.util.EventObject commandEvent) {
    }

    public void commandExecutable(java.util.EventObject commandEvent) {
    }

    public void commandNotExecutable(java.util.EventObject commandEvent) {
    }
}


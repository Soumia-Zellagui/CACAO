package Module01;


public class InsertImageCommand extends Module01.AbstractCommand {
    private java.lang.String myImageName;

    public InsertImageCommand(java.lang.String name ,java.lang.String newImageName ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
        myImageName = newImageName;
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        ((Module01.InsertImageCommand.UndoActivity)(getUndoActivity())).insertImage();
        view().checkDamage();
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.InsertImageCommand.UndoActivity(view() , myImageName);
    }

    public class UndoActivity extends Module06.UndoableAdapter {
        java.lang.ref.WeakReference myAffectedImageFigure;

        private java.lang.String myAffectedImageName;

        UndoActivity(Module03.DrawingView newDrawingView ,java.lang.String newAffectedImageName) {
            super(newDrawingView);
            myAffectedImageName = newAffectedImageName;
            setUndoable(true);
            setRedoable(true);
        }

        protected void setImageFigure(Module03.ImageFigure newImageFigure) {
            myAffectedImageFigure = new java.lang.ref.WeakReference(newImageFigure);
        }

        protected Module03.ImageFigure getImageFigure() {
            if (((myAffectedImageFigure) == null) || ((myAffectedImageFigure.get()) == null)) {
                java.awt.Image image = Module01.Iconkit.instance().registerAndLoadImage(((java.awt.Component)(getDrawingView())), myAffectedImageName);
                setImageFigure(new Module03.ImageFigure(image , myAffectedImageName , getDrawingView().lastClick()));
            } 
            return ((Module03.ImageFigure)(myAffectedImageFigure.get()));
        }

        public boolean undo() {
            if (super.undo()) {
                getDrawingView().clearSelection();
                getDrawingView().drawing().orphan(getImageFigure());
                return true;
            } 
            return false;
        }

        public boolean redo() {
            if (isRedoable()) {
                insertImage();
                return true;
            } 
            return false;
        }

        protected void insertImage() {
            getDrawingView().add(getImageFigure());
            getDrawingView().clearSelection();
            getDrawingView().addToSelection(getImageFigure());
        }
    }
}


package Module01;


public class ZoomCommand extends Module01.AbstractCommand {
    protected float scale = 1.0F;

    public ZoomCommand(java.lang.String newSame ,float newScale ,Module01.DrawingEditor newDrawingEditor) {
        super(newSame, newDrawingEditor, true);
        scale = newScale;
    }

    public void execute() {
        super.execute();
        zoomView().zoom(scale);
    }

    public Module03.ZoomDrawingView zoomView() {
        java.lang.Object view = super.view();
        if (view instanceof Module03.ZoomDrawingView) {
            return ((Module03.ZoomDrawingView)(view));
        } 
        Module06.JHotDrawRuntimeException jhotDrawRuntimeException = new Module06.JHotDrawRuntimeException("execute should NOT be getting called when view not instanceof ZoomDrawingView");
        throw jhotDrawRuntimeException;
    }

    public float getScale() {
        return scale;
    }

    public void setScale(float newScale) {
        scale = newScale;
    }

    protected boolean isExecutableWithView() {
        return (view()) instanceof Module03.ZoomDrawingView;
    }
}


package Module01;


public class WindowMenu extends Module01.CommandMenu {
    private Module04.MDIDesktopPane desktop;

    private Module01.Command cascadeCommand;

    private Module01.Command tileCommand;

    public WindowMenu(java.lang.String newText ,Module04.MDIDesktopPane newDesktop ,Module01.DrawingEditor newEditor) {
        super(newText);
        Module01.WindowMenu.this.desktop = newDesktop;
        cascadeCommand = new Module01.AbstractCommand("Cascade", newEditor) {
            public void execute() {
                Module01.WindowMenu.this.desktop.cascadeFrames();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.WindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        };
        tileCommand = new Module01.AbstractCommand("Tile", newEditor) {
            public void execute() {
                Module01.WindowMenu.this.desktop.tileFramesHorizontally();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.WindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        };
        addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent e) {
            }

            public void menuDeselected(javax.swing.event.MenuEvent e) {
                removeAll();
            }

            public void menuSelected(javax.swing.event.MenuEvent e) {
                buildChildMenus();
            }
        });
    }

    private void buildChildMenus() {
        Module01.WindowMenu.ChildMenuItem menu;
        javax.swing.JInternalFrame[] array = desktop.getAllFrames();
        add(new Module06.CommandMenuItem(cascadeCommand));
        add(new Module06.CommandMenuItem(tileCommand));
        if ((array.length) > 0) {
            addSeparator();
        } 
        for (int i = 0 ; i < (array.length) ; i++) {
            menu = new Module01.WindowMenu.ChildMenuItem(array[i]);
            menu.setState((i == 0));
            menu.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent ae) {
                    javax.swing.JInternalFrame frame = ((Module01.WindowMenu.ChildMenuItem)(ae.getSource())).getFrame();
                    frame.moveToFront();
                    try {
                        frame.setSelected(true);
                    } catch (java.beans.PropertyVetoException e) {
                        e.printStackTrace();
                    }
                }
            });
            menu.setIcon(array[i].getFrameIcon());
            add(menu);
        }
    }

    class ChildMenuItem extends javax.swing.JCheckBoxMenuItem {
        private javax.swing.JInternalFrame frame;

        public ChildMenuItem(javax.swing.JInternalFrame newFrame) {
            super(newFrame.getTitle());
            frame = newFrame;
        }

        public javax.swing.JInternalFrame getFrame() {
            return frame;
        }
    }
}


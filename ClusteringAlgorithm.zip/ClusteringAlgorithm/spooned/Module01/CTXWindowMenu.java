package Module01;


public class CTXWindowMenu extends Module01.CTXCommandMenu {
    Module04.MDIDesktopPane desktop;

    private Module06.CommandMenuItem cascadeCommand;

    private Module06.CommandMenuItem tileHCommand;

    private Module06.CommandMenuItem tileVCommand;

    private Module06.CommandMenuItem arrangeHCommand;

    private Module06.CommandMenuItem arrangeVCommand;

    private int staticItems;

    public CTXWindowMenu(java.lang.String newText ,Module04.MDIDesktopPane newDesktop ,Module01.DrawingEditor newEditor) {
        super(newText);
        Module01.CTXWindowMenu.this.desktop = newDesktop;
        cascadeCommand = new Module06.CommandMenuItem(new Module01.AbstractCommand("Cascade", newEditor) {
            public void execute() {
                Module01.CTXWindowMenu.this.desktop.cascadeFrames();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.CTXWindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        });
        tileHCommand = new Module06.CommandMenuItem(new Module01.AbstractCommand("Tile Horizontally", newEditor) {
            public void execute() {
                Module01.CTXWindowMenu.this.desktop.tileFramesHorizontally();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.CTXWindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        });
        tileVCommand = new Module06.CommandMenuItem(new Module01.AbstractCommand("Tile Vertically", newEditor) {
            public void execute() {
                Module01.CTXWindowMenu.this.desktop.tileFramesVertically();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.CTXWindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        });
        arrangeHCommand = new Module06.CommandMenuItem(new Module01.AbstractCommand("Arrange Horizontally", newEditor) {
            public void execute() {
                Module01.CTXWindowMenu.this.desktop.arrangeFramesHorizontally();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.CTXWindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        });
        arrangeVCommand = new Module06.CommandMenuItem(new Module01.AbstractCommand("Arrange Vertically", newEditor) {
            public void execute() {
                Module01.CTXWindowMenu.this.desktop.arrangeFramesVertically();
            }

            public boolean isExecutable() {
                return (super.isExecutable()) && ((Module01.CTXWindowMenu.this.desktop.getAllFrames().length) > 0);
            }
        });
        addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent e) {
            }

            public void menuDeselected(javax.swing.event.MenuEvent e) {
                removeWindowsList();
            }

            public void menuSelected(javax.swing.event.MenuEvent e) {
                buildChildMenus();
            }
        });
        add(cascadeCommand);
        add(tileHCommand);
        add(tileVCommand);
        add(arrangeHCommand);
        add(arrangeVCommand);
        staticItems = 5;
    }

    protected void removeWindowsList() {
        while ((Module01.CTXWindowMenu.this.getItemCount()) > (staticItems)) {
            remove(staticItems);
        }
    }

    void buildChildMenus() {
        javax.swing.JInternalFrame[] array = desktop.getAllFrames();
        cascadeCommand.setEnabled(((array.length) > 0));
        tileHCommand.setEnabled(((array.length) > 0));
        tileVCommand.setEnabled(((array.length) > 0));
        arrangeHCommand.setEnabled(((array.length) > 0));
        arrangeVCommand.setEnabled(((array.length) > 0));
        if ((array.length) == 0) {
            return ;
        } 
        addSeparator();
        for (int i = 0 ; i < (array.length) ; i++) {
            Module01.CTXWindowMenu.ChildMenuItem menu = new Module01.CTXWindowMenu.ChildMenuItem(array[i]);
            menu.setState((i == 0));
            menu.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent ae) {
                    javax.swing.JInternalFrame frame = ((Module01.CTXWindowMenu.ChildMenuItem)(ae.getSource())).getFrame();
                    frame.moveToFront();
                    try {
                        frame.setSelected(true);
                    } catch (java.beans.PropertyVetoException e) {
                        e.printStackTrace();
                    }
                }
            });
            menu.setIcon(array[i].getFrameIcon());
            add(menu);
        }
    }

    class ChildMenuItem extends javax.swing.JCheckBoxMenuItem {
        private javax.swing.JInternalFrame frame;

        public ChildMenuItem(javax.swing.JInternalFrame newFrame) {
            super(newFrame.getTitle());
            frame = newFrame;
        }

        public javax.swing.JInternalFrame getFrame() {
            return frame;
        }
    }
}


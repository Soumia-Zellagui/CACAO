package Module01;


public class DuplicateCommand extends Module01.FigureTransferCommand {
    public DuplicateCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module06.Undoable ua = createUndoActivity();
        setUndoActivity(ua);
        Module03.DrawingView v = view();
        Module03.FigureSelection selection = v.getFigureSelection();
        Module06.Undoable undoac = getUndoActivity();
        Module03.FigureEnumeration figures = ((Module03.FigureEnumeration)(selection.getData(Module03.StandardFigureSelection.TYPE)));
        undoac.setAffectedFigures(figures);
        v.clearSelection();
        Module03.FigureEnumeration afffig = undoac.getAffectedFigures();
        Module03.FigureEnumeration fe = insertFigures(afffig, 10, 10);
        undoac.setAffectedFigures(fe);
        v.checkDamage();
    }

    protected boolean isExecutableWithView() {
        Module03.DrawingView v = view();
        return (v.selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        Module03.DrawingView v = view();
        Module01.PasteCommand.UndoActivity pstu = new Module01.PasteCommand.UndoActivity(v);
        return pstu;
    }
}


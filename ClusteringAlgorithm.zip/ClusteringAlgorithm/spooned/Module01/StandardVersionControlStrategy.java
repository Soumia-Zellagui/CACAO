package Module01;


public class StandardVersionControlStrategy implements Module01.VersionControlStrategy {
    private Module01.VersionRequester myVersionRequester;

    public StandardVersionControlStrategy(Module01.VersionRequester newVersionRequester) {
        setVersionRequester(newVersionRequester);
    }

    public void assertCompatibleVersion() {
        java.lang.String[] requiredVersions = getVersionRequester().getRequiredVersions();
        if ((requiredVersions.length) == 0) {
            return ;
        } 
        for (int i = 0 ; i < (requiredVersions.length) ; i++) {
            if (isCompatibleVersion(requiredVersions[i])) {
                return ;
            } 
        }
        handleIncompatibleVersions();
    }

    protected void handleIncompatibleVersions() {
        java.lang.String[] requiredVersions = getVersionRequester().getRequiredVersions();
        java.lang.StringBuffer expectedVersions = new java.lang.StringBuffer("[");
        for (int i = 0 ; i < ((requiredVersions.length) - 1) ; i++) {
            expectedVersions.append(((requiredVersions[i]) + ", "));
        }
        if ((requiredVersions.length) > 0) {
            expectedVersions.append(requiredVersions[((requiredVersions.length) - 1)]);
        } 
        expectedVersions.append("]");
        throw new Module06.JHotDrawRuntimeException((((("Incompatible version of JHotDraw found: " + (Module06.VersionManagement.getJHotDrawVersion())) + " (expected: ") + expectedVersions) + ")"));
    }

    protected boolean isCompatibleVersion(java.lang.String compareVersionString) {
        return Module06.VersionManagement.isCompatibleVersion(compareVersionString);
    }

    private void setVersionRequester(Module01.VersionRequester newVersionRequester) {
        myVersionRequester = newVersionRequester;
    }

    protected Module01.VersionRequester getVersionRequester() {
        return myVersionRequester;
    }
}


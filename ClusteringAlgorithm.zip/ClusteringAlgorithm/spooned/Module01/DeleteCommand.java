package Module01;


public class DeleteCommand extends Module01.FigureTransferCommand {
    public DeleteCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module06.Undoable u = createUndoActivity();
        setUndoActivity(u);
        Module03.FigureEnumeration fe = view().selection();
        java.util.List affected = Module06.CollectionsFactory.current().createList();
        Module03.Figure f;
        Module03.FigureEnumeration dfe;
        while (fe.hasNextFigure()) {
            f = fe.nextFigure();
            affected.add(0, f);
            dfe = f.getDependendFigures();
            if (dfe != null) {
                while (dfe.hasNextFigure()) {
                    affected.add(0, dfe.nextFigure());
                }
            } 
        }
        fe = new Module03.FigureEnumerator(affected);
        getUndoActivity().setAffectedFigures(fe);
        deleteFigures(getUndoActivity().getAffectedFigures());
        view().checkDamage();
    }

    protected boolean isExecutableWithView() {
        return (view().selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        Module01.DeleteCommand.UndoActivity A = new Module01.DeleteCommand.UndoActivity(Module01.DeleteCommand.this);
        return A;
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private Module01.FigureTransferCommand myCommand;

        public UndoActivity(Module01.FigureTransferCommand newCommand) {
            super(newCommand.view());
            myCommand = newCommand;
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if ((super.undo()) && (getAffectedFigures().hasNextFigure())) {
                getDrawingView().clearSelection();
                setAffectedFigures(myCommand.insertFigures(getAffectedFiguresReversed(), 0, 0));
                return true;
            } 
            return false;
        }

        public boolean redo() {
            if (isRedoable()) {
                myCommand.deleteFigures(getAffectedFigures());
                getDrawingView().clearSelection();
                return true;
            } 
            return false;
        }
    }
}


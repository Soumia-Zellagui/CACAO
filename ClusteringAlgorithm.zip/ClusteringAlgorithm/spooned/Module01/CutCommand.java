package Module01;


public class CutCommand extends Module01.FigureTransferCommand {
    public CutCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        Module03.FigureEnumeration fe = view().selection();
        java.util.List affected = Module06.CollectionsFactory.current().createList();
        Module03.Figure f;
        Module03.FigureEnumeration dfe;
        while (fe.hasNextFigure()) {
            f = fe.nextFigure();
            affected.add(0, f);
            dfe = f.getDependendFigures();
            if (dfe != null) {
                while (dfe.hasNextFigure()) {
                    affected.add(0, dfe.nextFigure());
                }
            } 
        }
        fe = new Module03.FigureEnumerator(affected);
        getUndoActivity().setAffectedFigures(fe);
        Module01.CutCommand.UndoActivity ua = ((Module01.CutCommand.UndoActivity)(getUndoActivity()));
        ua.setSelectedFigures(view().selection());
        copyFigures(ua.getSelectedFigures(), ua.getSelectedFiguresCount());
        deleteFigures(getUndoActivity().getAffectedFigures());
        view().checkDamage();
    }

    public boolean isExecutableWithView() {
        return (view().selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.CutCommand.UndoActivity(Module01.CutCommand.this);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private Module01.FigureTransferCommand myCommand;

        private java.util.List mySelectedFigures;

        public UndoActivity(Module01.FigureTransferCommand newCommand) {
            super(newCommand.view());
            myCommand = newCommand;
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if ((super.undo()) && (getAffectedFigures().hasNextFigure())) {
                getDrawingView().clearSelection();
                myCommand.insertFigures(getAffectedFiguresReversed(), 0, 0);
                return true;
            } 
            return false;
        }

        public boolean redo() {
            if (isRedoable()) {
                myCommand.copyFigures(getSelectedFigures(), getSelectedFiguresCount());
                myCommand.deleteFigures(getAffectedFigures());
                return true;
            } 
            return false;
        }

        public void setSelectedFigures(Module03.FigureEnumeration newSelectedFigures) {
            rememberSelectedFigures(newSelectedFigures);
        }

        protected void rememberSelectedFigures(Module03.FigureEnumeration toBeRemembered) {
            mySelectedFigures = Module06.CollectionsFactory.current().createList();
            while (toBeRemembered.hasNextFigure()) {
                mySelectedFigures.add(toBeRemembered.nextFigure());
            }
        }

        public Module03.FigureEnumeration getSelectedFigures() {
            return new Module03.FigureEnumerator(Module06.CollectionsFactory.current().createList(mySelectedFigures));
        }

        public int getSelectedFiguresCount() {
            return mySelectedFigures.size();
        }

        public void release() {
            super.release();
            Module03.FigureEnumeration fe = getSelectedFigures();
            while (fe.hasNextFigure()) {
                fe.nextFigure().release();
            }
            setSelectedFigures(Module03.FigureEnumerator.getEmptyEnumeration());
        }
    }
}


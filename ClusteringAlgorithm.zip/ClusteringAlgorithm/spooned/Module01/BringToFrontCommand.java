package Module01;


public class BringToFrontCommand extends Module01.AbstractCommand {
    public BringToFrontCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        getUndoActivity().setAffectedFigures(view().selection());
        Module03.FigureEnumeration fe = getUndoActivity().getAffectedFigures();
        while (fe.hasNextFigure()) {
            view().drawing().bringToFront(fe.nextFigure());
        }
        view().checkDamage();
    }

    public boolean isExecutableWithView() {
        return (view().selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.BringToFrontCommand.UndoActivity(view());
    }

    public static class UndoActivity extends Module01.SendToBackCommand.UndoActivity {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
        }

        protected void sendToCommand(Module03.Figure f) {
            getDrawingView().drawing().bringToFront(f);
        }
    }
}


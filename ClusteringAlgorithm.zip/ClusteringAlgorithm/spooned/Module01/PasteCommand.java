package Module01;


public class PasteCommand extends Module01.FigureTransferCommand {
    public PasteCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        java.awt.Point lastClick = view().lastClick();
        Module03.FigureSelection selection = ((Module03.FigureSelection)(Module06.Clipboard.getClipboard().getContents()));
        if (selection != null) {
            setUndoActivity(createUndoActivity());
            getUndoActivity().setAffectedFigures(((Module03.FigureEnumerator)(selection.getData(Module03.StandardFigureSelection.TYPE))));
            if (!(getUndoActivity().getAffectedFigures().hasNextFigure())) {
                setUndoActivity(null);
                return ;
            } 
            java.awt.Rectangle r = getBounds(getUndoActivity().getAffectedFigures());
            view().clearSelection();
            Module03.FigureEnumeration fe = insertFigures(getUndoActivity().getAffectedFigures(), ((lastClick.x) - (r.x)), ((lastClick.y) - (r.y)));
            getUndoActivity().setAffectedFigures(fe);
            view().checkDamage();
        } 
    }

    public boolean isExecutableWithView() {
        return (Module06.Clipboard.getClipboard().getContents()) != null;
    }

    private java.awt.Rectangle getBounds(Module03.FigureEnumeration fe) {
        java.awt.Rectangle r = fe.nextFigure().displayBox();
        while (fe.hasNextFigure()) {
            r.add(fe.nextFigure().displayBox());
        }
        return r;
    }

    protected Module06.Undoable createUndoActivity() {
        Module03.DrawingView v = view();
        Module01.PasteCommand.UndoActivity pua = new Module01.PasteCommand.UndoActivity(v);
        return pua;
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.DrawingView v = getDrawingView();
            Module03.Drawing d = v.drawing();
            Module03.DeleteFromDrawingVisitor deleteVisitor = new Module03.DeleteFromDrawingVisitor(d);
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                fe.nextFigure().visit(deleteVisitor);
            }
            v.clearSelection();
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            Module03.DrawingView v = getDrawingView();
            v.clearSelection();
            setAffectedFigures(v.insertFigures(getAffectedFigures(), 0, 0, false));
            return true;
        }
    }
}


package Module01;


public class ToggleGridCommand extends Module01.AbstractCommand {
    private java.awt.Point fGrid;

    public ToggleGridCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor ,java.awt.Point grid) {
        super(name, newDrawingEditor);
        fGrid = new java.awt.Point(grid.x , grid.y);
    }

    public void execute() {
        super.execute();
        Module03.DrawingView v = view();
        Module06.PointConstrainer grid = v.getConstrainer();
        if (grid != null) {
            v.setConstrainer(null);
        } else {
            Module06.GridConstrainer gridConstrainer = new Module06.GridConstrainer(fGrid.x , fGrid.y);
            v.setConstrainer(gridConstrainer);
        }
    }
}


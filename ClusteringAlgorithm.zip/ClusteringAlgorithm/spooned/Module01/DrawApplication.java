package Module01;


public class DrawApplication extends javax.swing.JFrame implements Module01.DrawingEditor , Module01.PaletteListener , Module01.VersionRequester {
    private Module03.Tool fTool;

    private Module01.Iconkit fIconkit;

    private javax.swing.JTextField fStatusLine;

    private Module03.DrawingView fView;

    private Module03.ToolButton fDefaultToolButton;

    private Module03.ToolButton fSelectedToolButton;

    private java.lang.String fApplicationName;

    private Module02.StorageFormatManager fStorageFormatManager;

    private Module01.UndoManager myUndoManager;

    protected static java.lang.String fgUntitled = "untitled";

    private java.util.List listeners;

    private Module04.DesktopListener fDesktopListener;

    private Module04.Desktop fDesktop;

    private static final java.lang.String fgDrawPath = "/org/jhotdraw/";

    public static final java.lang.String IMAGES = (Module01.DrawApplication.fgDrawPath) + "images/";

    protected static int winCount = 0;

    public static final int FILE_MENU = 0;

    public static final int EDIT_MENU = 1;

    public static final int ALIGNMENT_MENU = 2;

    public static final int ATTRIBUTES_MENU = 3;

    public DrawApplication() {
        this("JHotDraw");
    }

    public DrawApplication(java.lang.String title) {
        super(title);
        listeners = Module06.CollectionsFactory.current().createList();
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setApplicationName(title);
    }

    protected Module01.DrawApplication createApplication() {
        Module01.DrawApplication drawApplication = new Module01.DrawApplication();
        return drawApplication;
    }

    public void newView() {
        if ((view()) == null) {
            return ;
        } 
        Module01.DrawApplication window = createApplication();
        window.openn(view());
        if ((view().drawing().getTitle()) != null) {
            window.setDrawingTitle(((view().drawing().getTitle()) + " (View)"));
        } else {
            window.setDrawingTitle(((getDefaultDrawingTitle()) + " (View)"));
        }
    }

    public void newWindow(Module03.Drawing initialDrawing) {
        Module01.DrawApplication window = createApplication();
        if (initialDrawing == null) {
            window.open();
        } else {
            Module03.DrawingView dv = window.createDrawingVieww(initialDrawing);
            window.openn(dv);
        }
    }

    public final void newWindow() {
        Module03.Drawing drawing = createDrawing();
        newWindow(drawing);
    }

    public void open() {
        Module03.DrawingView drawingview = createInitialDrawingView();
        openn(drawingview);
    }

    protected void openn(final Module03.DrawingView newDrawingView) {
        Module01.VersionControlStrategy versionControlStrategy = getVersionControlStrategy();
        versionControlStrategy.assertCompatibleVersion();
        Module01.UndoManager UndoManager = new Module01.UndoManager();
        setUndoManager(UndoManager);
        Module01.Iconkit iconkit = createIconkit();
        setIconkit(iconkit);
        getContentPane().setLayout(new java.awt.BorderLayout());
        javax.swing.JTextField statusLine = createStatusLine();
        setStatusLine(statusLine);
        getContentPane().add(getStatusLine(), java.awt.BorderLayout.SOUTH);
        Module03.NullTool nullTool = new Module03.NullTool(Module01.DrawApplication.this);
        setTool(nullTool, "");
        setView(newDrawingView);
        javax.swing.JToolBar tools = createToolPalette();
        createTools(tools);
        javax.swing.JPanel activePanel = new javax.swing.JPanel();
        activePanel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        activePanel.setAlignmentY(java.awt.Component.TOP_ALIGNMENT);
        activePanel.setLayout(new java.awt.BorderLayout());
        activePanel.add(tools, java.awt.BorderLayout.NORTH);
        Module04.DesktopListener desktopListener = createDesktopListener();
        setDesktopListener(desktopListener);
        Module04.Desktop desktop = createDesktop();
        setDesktop(desktop);
        activePanel.add(((java.awt.Component)(getDesktop())), java.awt.BorderLayout.CENTER);
        getContentPane().add(activePanel, java.awt.BorderLayout.CENTER);
        javax.swing.JMenuBar mb = new javax.swing.JMenuBar();
        createMenus(mb);
        setJMenuBar(mb);
        java.awt.Dimension d = defaultSize();
        if ((d.width) > (mb.getPreferredSize().width)) {
            setSize(d.width, d.height);
        } else {
            setSize(mb.getPreferredSize().width, d.height);
        }
        addListeners();
        Module02.StorageFormatManager sftm = createStorageFormatManager();
        setStorageFormatManager(sftm);
        setVisible(true);
        java.lang.Runnable r = new java.lang.Runnable() {
            public void run() {
                if (newDrawingView.isInteractive()) {
                    getDesktop().addToDesktop(newDrawingView, Module04.Desktop.PRIMARY);
                } 
                toolDone();
            }
        };
        if ((java.awt.EventQueue.isDispatchThread()) == false) {
            try {
                java.awt.EventQueue.invokeAndWait(r);
            } catch (java.lang.InterruptedException ie) {
                java.lang.System.err.println(ie.getMessage());
                exit();
            } catch (java.lang.reflect.InvocationTargetException ite) {
                java.lang.System.err.println(ite.getMessage());
                exit();
            }
        } else {
            r.run();
        }
        toolDone();
    }

    protected void addListeners() {
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent event) {
                endApp();
            }

            public void windowOpened(java.awt.event.WindowEvent event) {
                (Module01.DrawApplication.winCount)++;
            }

            public void windowClosed(java.awt.event.WindowEvent event) {
                if ((--(Module01.DrawApplication.winCount)) == 0) {
                    java.lang.System.exit(0);
                } 
            }
        });
    }

    protected void createMenus(javax.swing.JMenuBar mb) {
        Module01.CommandMenu fileMenu = createFileMenu();
        addMenuIfPossible(mb, fileMenu);
        Module01.CommandMenu commandMenu = createEditMenu();
        addMenuIfPossible(mb, commandMenu);
        Module01.CommandMenu alignmentMenu = createAlignmentMenu();
        addMenuIfPossible(mb, alignmentMenu);
        javax.swing.JMenu attMenu = createAttributesMenu();
        addMenuIfPossible(mb, attMenu);
        Module01.CommandMenu debugMenu = createDebugMenu();
        addMenuIfPossible(mb, debugMenu);
    }

    protected void addMenuIfPossible(javax.swing.JMenuBar mb, javax.swing.JMenu newMenu) {
        if (newMenu != null) {
            mb.add(newMenu);
        } 
    }

    protected Module01.CommandMenu createFileMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("File");
        Module01.Command cmd = new Module01.AbstractCommand("New", Module01.DrawApplication.this, false) {
            public void execute() {
                promptNew();
            }
        };
        menu.add(cmd, new java.awt.MenuShortcut('n'));
        cmd = new Module01.AbstractCommand("Open...", Module01.DrawApplication.this, false) {
            public void execute() {
                promptOpen();
            }
        };
        menu.add(cmd, new java.awt.MenuShortcut('o'));
        cmd = new Module01.AbstractCommand("Save As...", Module01.DrawApplication.this, true) {
            public void execute() {
                promptSaveAs();
            }
        };
        menu.add(cmd, new java.awt.MenuShortcut('s'));
        menu.addSeparator();
        cmd = new Module01.AbstractCommand("Print...", Module01.DrawApplication.this, true) {
            public void execute() {
                print();
            }
        };
        menu.add(cmd, new java.awt.MenuShortcut('p'));
        menu.addSeparator();
        cmd = new Module01.AbstractCommand("Exit", Module01.DrawApplication.this, true) {
            public void execute() {
                endApp();
            }
        };
        menu.add(cmd);
        return menu;
    }

    protected Module01.CommandMenu createEditMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Edit");
        Module01.SelectAllCommand selectAllCommand = new Module01.SelectAllCommand("Select All" , Module01.DrawApplication.this);
        Module01.UndoableCommand undoableCommand = new Module01.UndoableCommand(selectAllCommand);
        menu.add(undoableCommand, new java.awt.MenuShortcut('a'));
        menu.addSeparator();
        Module01.CutCommand cutCommand = new Module01.CutCommand("Cut" , Module01.DrawApplication.this);
        Module01.UndoableCommand undoCommand = new Module01.UndoableCommand(cutCommand);
        menu.add(undoCommand, new java.awt.MenuShortcut('x'));
        Module01.CopyCommand copyCommand = new Module01.CopyCommand("Copy" , Module01.DrawApplication.this);
        menu.add(copyCommand, new java.awt.MenuShortcut('c'));
        Module01.PasteCommand pasteCommand = new Module01.PasteCommand("Paste" , Module01.DrawApplication.this);
        Module01.UndoableCommand uc = new Module01.UndoableCommand(pasteCommand);
        menu.add(uc, new java.awt.MenuShortcut('v'));
        menu.addSeparator();
        Module01.DuplicateCommand duplicateCommand = new Module01.DuplicateCommand("Duplicate" , Module01.DrawApplication.this);
        Module01.UndoableCommand Undcmd = new Module01.UndoableCommand(duplicateCommand);
        menu.add(Undcmd, new java.awt.MenuShortcut('d'));
        Module01.DeleteCommand deleteCommand = new Module01.DeleteCommand("Delete" , Module01.DrawApplication.this);
        Module01.UndoableCommand Udcmd = new Module01.UndoableCommand(deleteCommand);
        menu.add(Udcmd);
        menu.addSeparator();
        Module01.GroupCommand groupCommand = new Module01.GroupCommand("Group" , Module01.DrawApplication.this);
        Module01.UndoableCommand undcomd = new Module01.UndoableCommand(groupCommand);
        menu.add(undcomd);
        Module01.UngroupCommand ungroupCommand = new Module01.UngroupCommand("Ungroup" , Module01.DrawApplication.this);
        Module01.UndoableCommand uundoableCommand = new Module01.UndoableCommand(ungroupCommand);
        menu.add(uundoableCommand);
        menu.addSeparator();
        Module01.SendToBackCommand sendToBackCommand = new Module01.SendToBackCommand("Send to Back" , Module01.DrawApplication.this);
        Module01.UndoableCommand UCommand = new Module01.UndoableCommand(sendToBackCommand);
        menu.add(UCommand);
        Module01.BringToFrontCommand bringToFrontCommand = new Module01.BringToFrontCommand("Bring to Front" , Module01.DrawApplication.this);
        Module01.UndoableCommand UCmd = new Module01.UndoableCommand(bringToFrontCommand);
        menu.add(UCmd);
        menu.addSeparator();
        Module01.UndoCommand undCommand = new Module01.UndoCommand("Undo Command" , Module01.DrawApplication.this);
        menu.add(undCommand);
        Module01.RedoCommand redoCommand = new Module01.RedoCommand("Redo Command" , Module01.DrawApplication.this);
        menu.add(redoCommand);
        return menu;
    }

    protected Module01.CommandMenu createAlignmentMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Align");
        Module01.ToggleGridCommand toggleGridCommand = new Module01.ToggleGridCommand("Toggle Snap to Grid" , Module01.DrawApplication.this , new java.awt.Point(4 , 4));
        menu.addCheckItem(toggleGridCommand);
        menu.addSeparator();
        Module01.AlignCommand alignCommand = new Module01.AlignCommand(Module01.AlignCommand.Alignment.LEFTS , Module01.DrawApplication.this);
        Module01.UndoableCommand UCmd = new Module01.UndoableCommand(alignCommand);
        menu.add(UCmd);
        Module01.AlignCommand aliCommand = new Module01.AlignCommand(Module01.AlignCommand.Alignment.CENTERS , Module01.DrawApplication.this);
        Module01.UndoableCommand Umd = new Module01.UndoableCommand(aliCommand);
        menu.add(Umd);
        Module01.AlignCommand aliComd = new Module01.AlignCommand(Module01.AlignCommand.Alignment.RIGHTS , Module01.DrawApplication.this);
        Module01.UndoableCommand Ud = new Module01.UndoableCommand(aliComd);
        menu.add(Ud);
        menu.addSeparator();
        Module01.AlignCommand alComd = new Module01.AlignCommand(Module01.AlignCommand.Alignment.TOPS , Module01.DrawApplication.this);
        Module01.UndoableCommand undcmd = new Module01.UndoableCommand(alComd);
        menu.add(undcmd);
        Module01.AlignCommand alCd = new Module01.AlignCommand(Module01.AlignCommand.Alignment.MIDDLES , Module01.DrawApplication.this);
        Module01.UndoableCommand uncmd = new Module01.UndoableCommand(alCd);
        menu.add(uncmd);
        Module01.AlignCommand ald = new Module01.AlignCommand(Module01.AlignCommand.Alignment.BOTTOMS , Module01.DrawApplication.this);
        Module01.UndoableCommand ucmd = new Module01.UndoableCommand(ald);
        menu.add(ucmd);
        return menu;
    }

    protected Module01.CommandMenu createDebugMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Debug");
        Module01.Command cmd = new Module01.AbstractCommand("Simple Update", Module01.DrawApplication.this) {
            public void execute() {
                Module03.SimpleUpdateStrategy simpleUpdateStrategy = new Module03.SimpleUpdateStrategy();
                Module03.DrawingView view = this.view();
                view.setDisplayUpdate(simpleUpdateStrategy);
            }
        };
        menu.add(cmd);
        cmd = new Module01.AbstractCommand("Buffered Update", Module01.DrawApplication.this) {
            public void execute() {
                Module03.BufferedUpdateStrategy bufferedUpdateStrategy = new Module03.BufferedUpdateStrategy();
                Module03.DrawingView view = this.view();
                view.setDisplayUpdate(bufferedUpdateStrategy);
            }
        };
        menu.add(cmd);
        return menu;
    }

    protected javax.swing.JMenu createAttributesMenu() {
        javax.swing.JMenu menu = new javax.swing.JMenu("Attributes");
        menu.add(createColorMenu("Fill Color", Module06.FigureAttributeConstant.FILL_COLOR));
        menu.add(createColorMenu("Pen Color", Module06.FigureAttributeConstant.FRAME_COLOR));
        menu.add(createArrowMenu());
        menu.addSeparator();
        menu.add(createFontMenu());
        menu.add(createFontSizeMenu());
        menu.add(createFontStyleMenu());
        menu.add(createColorMenu("Text Color", Module06.FigureAttributeConstant.TEXT_COLOR));
        return menu;
    }

    protected Module01.CommandMenu createColorMenu(java.lang.String title, Module06.FigureAttributeConstant attribute) {
        Module01.CommandMenu menu = new Module01.CommandMenu(title);
        for (int i = 0 ; i < (Module06.ColorMap.size()) ; i++) {
            Module01.ChangeAttributeCommand changeAttributeCommand = new Module01.ChangeAttributeCommand(Module06.ColorMap.name(i) , attribute , Module06.ColorMap.color(i) , Module01.DrawApplication.this);
            Module01.UndoableCommand undoableCommand = new Module01.UndoableCommand(changeAttributeCommand);
            menu.add(undoableCommand);
        }
        return menu;
    }

    protected Module01.CommandMenu createArrowMenu() {
        Module06.FigureAttributeConstant arrowMode = Module06.FigureAttributeConstant.ARROW_MODE;
        Module01.CommandMenu menu = new Module01.CommandMenu("Arrow");
        Module01.ChangeAttributeCommand changeAttributeCommand = new Module01.ChangeAttributeCommand("none" , arrowMode , new java.lang.Integer(Module03.PolyLineFigure.ARROW_TIP_NONE) , Module01.DrawApplication.this);
        Module01.UndoableCommand undoableCmd = new Module01.UndoableCommand(changeAttributeCommand);
        menu.add(undoableCmd);
        Module01.ChangeAttributeCommand changeAttributeCommd = new Module01.ChangeAttributeCommand("at Start" , arrowMode , new java.lang.Integer(Module03.PolyLineFigure.ARROW_TIP_START) , Module01.DrawApplication.this);
        Module01.UndoableCommand undoaCmd = new Module01.UndoableCommand(changeAttributeCommd);
        menu.add(undoaCmd);
        Module01.ChangeAttributeCommand ChangeAttCmd = new Module01.ChangeAttributeCommand("at End" , arrowMode , new java.lang.Integer(Module03.PolyLineFigure.ARROW_TIP_END) , Module01.DrawApplication.this);
        Module01.UndoableCommand undCmd = new Module01.UndoableCommand(ChangeAttCmd);
        menu.add(undCmd);
        Module01.ChangeAttributeCommand ChangeAttCommand = new Module01.ChangeAttributeCommand("at Both" , arrowMode , new java.lang.Integer(Module03.PolyLineFigure.ARROW_TIP_BOTH) , Module01.DrawApplication.this);
        Module01.UndoableCommand UCommand = new Module01.UndoableCommand(ChangeAttCommand);
        menu.add(UCommand);
        return menu;
    }

    protected Module01.CommandMenu createFontMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Font");
        java.lang.String[] fonts = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (int i = 0 ; i < (fonts.length) ; i++) {
            Module01.ChangeAttributeCommand ChangeAttributeCommand = new Module01.ChangeAttributeCommand(fonts[i] , Module06.FigureAttributeConstant.FONT_NAME , fonts[i] , Module01.DrawApplication.this);
            Module01.UndoableCommand UCommand = new Module01.UndoableCommand(ChangeAttributeCommand);
            menu.add(UCommand);
        }
        return menu;
    }

    protected Module01.CommandMenu createFontStyleMenu() {
        Module06.FigureAttributeConstant fontStyle = Module06.FigureAttributeConstant.FONT_STYLE;
        Module01.CommandMenu menu = new Module01.CommandMenu("Font Style");
        Module01.ChangeAttributeCommand ChangeAttributeCommand = new Module01.ChangeAttributeCommand("Plain" , fontStyle , new java.lang.Integer(java.awt.Font.PLAIN) , Module01.DrawApplication.this);
        Module01.UndoableCommand UCommand = new Module01.UndoableCommand(ChangeAttributeCommand);
        menu.add(UCommand);
        Module01.ChangeAttributeCommand ChangeAttCommand = new Module01.ChangeAttributeCommand("Italic" , fontStyle , new java.lang.Integer(java.awt.Font.ITALIC) , Module01.DrawApplication.this);
        Module01.UndoableCommand undoableCommand = new Module01.UndoableCommand(ChangeAttCommand);
        menu.add(undoableCommand);
        Module01.ChangeAttributeCommand ChangeAttCmd = new Module01.ChangeAttributeCommand("Bold" , fontStyle , new java.lang.Integer(java.awt.Font.BOLD) , Module01.DrawApplication.this);
        Module01.UndoableCommand undoabCommand = new Module01.UndoableCommand(ChangeAttCmd);
        menu.add(undoabCommand);
        return menu;
    }

    protected Module01.CommandMenu createFontSizeMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Font Size");
        int[] sizes = new int[]{ 9 , 10 , 12 , 14 , 18 , 24 , 36 , 48 , 72 };
        for (int i = 0 ; i < (sizes.length) ; i++) {
            Module01.ChangeAttributeCommand changeAttributeCommand = new Module01.ChangeAttributeCommand(java.lang.Integer.toString(sizes[i]) , Module06.FigureAttributeConstant.FONT_SIZE , new java.lang.Integer(sizes[i]) , Module01.DrawApplication.this);
            Module01.UndoableCommand undoableCommand = new Module01.UndoableCommand(changeAttributeCommand);
            menu.add(undoableCommand);
        }
        return menu;
    }

    public Module01.CommandMenu createLookAndFeelMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Look'n'Feel");
        javax.swing.UIManager.LookAndFeelInfo[] lafs = javax.swing.UIManager.getInstalledLookAndFeels();
        for (int i = 0 ; i < (lafs.length) ; i++) {
            final java.lang.String lnfClassName = lafs[i].getClassName();
            Module01.Command cmd = new Module01.AbstractCommand(lafs[i].getName(), Module01.DrawApplication.this) {
                public void execute() {
                    newLookAndFeel(lnfClassName);
                }
            };
            menu.add(cmd);
        }
        return menu;
    }

    protected javax.swing.JToolBar createToolPalette() {
        javax.swing.JToolBar palette = new javax.swing.JToolBar();
        palette.setBackground(java.awt.Color.lightGray);
        return palette;
    }

    protected void createTools(javax.swing.JToolBar palette) {
        Module03.Tool defaultTool = createDefaultTool();
        setDefaultTool(defaultTool);
        palette.add(fDefaultToolButton);
    }

    protected Module03.Tool createSelectionTool() {
        Module03.SelectionTool selectionTool = new Module03.SelectionTool(Module01.DrawApplication.this);
        return selectionTool;
    }

    protected Module03.Tool createDefaultTool() {
        Module03.Tool selectionTool = createSelectionTool();
        return selectionTool;
    }

    protected void setDefaultTool(Module03.Tool newDefaultTool) {
        if (newDefaultTool != null) {
            fDefaultToolButton = createToolButton(((Module01.DrawApplication.IMAGES) + "SEL"), "Selection Tool", newDefaultTool);
        } else {
            fDefaultToolButton = null;
        }
    }

    public Module03.Tool getDefaultTool() {
        if ((fDefaultToolButton) != null) {
            return fDefaultToolButton.tool();
        } else {
            return null;
        }
    }

    protected Module03.ToolButton createToolButton(java.lang.String iconName, java.lang.String toolName, Module03.Tool tool) {
        Module03.ToolButton toolButton = new Module03.ToolButton(Module01.DrawApplication.this , iconName , toolName , tool);
        return toolButton;
    }

    protected Module03.DrawingView createDrawingView() {
        Module03.Drawing drawing = createDrawing();
        Module03.DrawingView createdDrawingView = createDrawingVieww(drawing);
        Module03.Drawing drawg = createdDrawingView.drawing();
        java.lang.String title = getDefaultDrawingTitle();
        drawg.setTitle(title);
        return createdDrawingView;
    }

    protected Module03.DrawingView createDrawingVieww(Module03.Drawing newDrawing) {
        java.awt.Dimension d = getDrawingViewSize();
        Module03.DrawingView newDrawingView = new Module03.StandardDrawingView(Module01.DrawApplication.this , d.width , d.height);
        newDrawingView.setDrawing(newDrawing);
        return newDrawingView;
    }

    protected Module03.DrawingView createInitialDrawingView() {
        Module03.DrawingView drawingView = createDrawingView();
        return drawingView;
    }

    protected java.awt.Dimension getDrawingViewSize() {
        return new java.awt.Dimension(800 , 800);
    }

    protected Module03.Drawing createDrawing() {
        Module03.StandardDrawing standardDrawing = new Module03.StandardDrawing();
        return standardDrawing;
    }

    protected Module04.Desktop createDesktop() {
        Module04.JPanelDesktop jPanelDesktop = new Module04.JPanelDesktop(Module01.DrawApplication.this);
        return jPanelDesktop;
    }

    protected void setDesktop(Module04.Desktop newDesktop) {
        Module04.DesktopListener desktopListener = getDesktopListener();
        newDesktop.addDesktopListener(desktopListener);
        fDesktop = newDesktop;
    }

    public Module04.Desktop getDesktop() {
        return fDesktop;
    }

    public Module02.StorageFormatManager createStorageFormatManager() {
        Module02.StorageFormatManager storageFormatManager = new Module02.StorageFormatManager();
        Module02.StandardStorageFormat standardStorageFormat = new Module02.StandardStorageFormat();
        storageFormatManager.setDefaultStorageFormat(standardStorageFormat);
        Module02.StorageFormat defaultStorageFormat = storageFormatManager.getDefaultStorageFormat();
        storageFormatManager.addStorageFormat(defaultStorageFormat);
        Module02.SerializationStorageFormat serializationStorageFormat = new Module02.SerializationStorageFormat();
        storageFormatManager.addStorageFormat(serializationStorageFormat);
        return storageFormatManager;
    }

    protected final void setStorageFormatManager(Module02.StorageFormatManager newStorageFormatManager) {
        fStorageFormatManager = newStorageFormatManager;
    }

    public Module02.StorageFormatManager getStorageFormatManager() {
        return fStorageFormatManager;
    }

    protected java.awt.Dimension defaultSize() {
        return new java.awt.Dimension(600 , 450);
    }

    protected javax.swing.JTextField createStatusLine() {
        javax.swing.JTextField field = new javax.swing.JTextField("No Tool" , 40);
        field.setBackground(java.awt.Color.white);
        field.setEditable(false);
        return field;
    }

    private void setStatusLine(javax.swing.JTextField newStatusLine) {
        fStatusLine = newStatusLine;
    }

    protected javax.swing.JTextField getStatusLine() {
        return fStatusLine;
    }

    public void paletteUserSelected(Module06.PaletteButton paletteButton) {
        Module03.ToolButton toolButton = ((Module03.ToolButton)(paletteButton));
        Module03.Tool too = toolButton.tool();
        setTool(too, toolButton.name());
        setSelected(toolButton);
    }

    public void paletteUserOver(Module06.PaletteButton paletteButton, boolean inside) {
        Module03.ToolButton toolButton = ((Module03.ToolButton)(paletteButton));
        if (inside) {
            showStatus(toolButton.name());
        } else if ((fSelectedToolButton) != null) {
            showStatus(fSelectedToolButton.name());
        } 
    }

    public Module03.Tool tool() {
        return fTool;
    }

    public Module03.DrawingView view() {
        return fView;
    }

    protected void setView(Module03.DrawingView newView) {
        fView = newView;
        Module03.DrawingView view = view();
        fireViewSelectionChangedEvent(fView, view);
    }

    public Module03.DrawingView[] views() {
        return new Module03.DrawingView[]{ view() };
    }

    public void toolDone() {
        java.lang.System.out.println("ToolDone");
        if ((fDefaultToolButton) != null) {
            Module03.Tool toolButton = fDefaultToolButton.tool();
            setTool(toolButton, fDefaultToolButton.name());
            setSelected(fDefaultToolButton);
        } 
    }

    public void figureSelectionChanged(Module03.DrawingView view) {
        checkCommandMenus();
    }

    protected void checkCommandMenus() {
        javax.swing.JMenuBar mb = getJMenuBar();
        for (int x = 0 ; x < (mb.getMenuCount()) ; x++) {
            javax.swing.JMenu jm = mb.getMenu(x);
            if (Module01.CommandMenu.class.isInstance(jm)) {
                checkCommandMenu(((Module01.CommandMenu)(jm)));
            } 
        }
    }

    protected void checkCommandMenu(Module01.CommandMenu cm) {
        cm.checkEnabled();
        for (int y = 0 ; y < (cm.getItemCount()) ; y++) {
            javax.swing.JMenuItem jmi = cm.getItem(y);
            if (Module01.CommandMenu.class.isInstance(jmi)) {
                checkCommandMenu(((Module01.CommandMenu)(jmi)));
            } 
        }
    }

    public void addViewChangeListener(Module06.ViewChangeListener vsl) {
        listeners.add(vsl);
    }

    public void removeViewChangeListener(Module06.ViewChangeListener vsl) {
        listeners.remove(vsl);
    }

    protected void fireViewSelectionChangedEvent(Module03.DrawingView oldView, Module03.DrawingView newView) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        while (li.hasPrevious()) {
            Module06.ViewChangeListener vsl = ((Module06.ViewChangeListener)(li.previous()));
            vsl.viewSelectionChanged(oldView, newView);
        }
    }

    protected void fireViewCreatedEvent(Module03.DrawingView view) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        while (li.hasPrevious()) {
            Module06.ViewChangeListener vsl = ((Module06.ViewChangeListener)(li.previous()));
            vsl.viewCreated(view);
        }
    }

    protected void fireViewDestroyingEvent(Module03.DrawingView view) {
        java.util.ListIterator li = listeners.listIterator(listeners.size());
        while (li.hasPrevious()) {
            Module06.ViewChangeListener vsl = ((Module06.ViewChangeListener)(li.previous()));
            vsl.viewDestroying(view);
        }
    }

    public void showStatus(java.lang.String string) {
        getStatusLine().setText(string);
    }

    public void setTool(Module03.Tool t, java.lang.String name) {
        if (((tool()) != null) && (tool().isActive())) {
            tool().deactivate();
        } 
        fTool = t;
        if ((tool()) != null) {
            showStatus(name);
            tool().activate();
        } 
    }

    private void setSelected(Module03.ToolButton button) {
        if ((fSelectedToolButton) != null) {
            fSelectedToolButton.reset();
        } 
        fSelectedToolButton = button;
        if ((fSelectedToolButton) != null) {
            fSelectedToolButton.select();
        } 
    }

    public void exit() {
        destroy();
        dispose();
    }

    protected boolean closeQuery() {
        return true;
    }

    protected void endApp() {
        if ((closeQuery()) == true) {
            exit();
        } 
    }

    protected void destroy() {
    }

    public void promptNew() {
        newWindow(createDrawing());
    }

    public void promptOpen() {
        toolDone();
        javax.swing.JFileChooser openDialog = createOpenFileChooser();
        getStorageFormatManager().registerFileFilters(openDialog);
        if ((openDialog.showOpenDialog(Module01.DrawApplication.this)) == (javax.swing.JFileChooser.APPROVE_OPTION)) {
            Module02.StorageFormat foundFormat = getStorageFormatManager().findStorageFormat(openDialog.getFileFilter());
            if (foundFormat == null) {
                Module02.StorageFormatManager storageFormatManager = getStorageFormatManager();
                foundFormat = storageFormatManager.findStorageFormat(openDialog.getSelectedFile());
            } 
            if (foundFormat != null) {
                loadDrawing(foundFormat, openDialog.getSelectedFile().getAbsolutePath());
            } else {
                showStatus(("Not a valid file format: " + (openDialog.getFileFilter().getDescription())));
            }
        } 
    }

    public void promptSaveAs() {
        if ((view()) != null) {
            toolDone();
            javax.swing.JFileChooser saveDialog = createSaveFileChooser();
            Module02.StorageFormatManager storageFormatManager = getStorageFormatManager();
            storageFormatManager.registerFileFilters(saveDialog);
            if ((saveDialog.showSaveDialog(Module01.DrawApplication.this)) == (javax.swing.JFileChooser.APPROVE_OPTION)) {
                Module02.StorageFormat foundFormat = getStorageFormatManager().findStorageFormat(saveDialog.getFileFilter());
                if (foundFormat == null) {
                    foundFormat = getStorageFormatManager().findStorageFormat(saveDialog.getSelectedFile());
                } 
                if (foundFormat != null) {
                    saveDrawing(foundFormat, saveDialog.getSelectedFile().getAbsolutePath());
                } else {
                    showStatus(("Not a valid file format: " + (saveDialog.getFileFilter().getDescription())));
                }
            } 
        } 
    }

    protected javax.swing.JFileChooser createOpenFileChooser() {
        javax.swing.JFileChooser openDialog = new javax.swing.JFileChooser();
        openDialog.setDialogType(javax.swing.JFileChooser.OPEN_DIALOG);
        openDialog.setDialogTitle("Open File...");
        return openDialog;
    }

    protected javax.swing.JFileChooser createSaveFileChooser() {
        javax.swing.JFileChooser saveDialog = new javax.swing.JFileChooser();
        saveDialog.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
        saveDialog.setDialogTitle("Save File...");
        return saveDialog;
    }

    public void print() {
        Module03.Tool tool = tool();
        tool.deactivate();
        java.awt.PrintJob printJob = getToolkit().getPrintJob(Module01.DrawApplication.this, "Print Drawing", null);
        if (printJob != null) {
            java.awt.Graphics pg = printJob.getGraphics();
            if (pg != null) {
                ((Module03.StandardDrawingView)(view())).printAll(pg);
                pg.dispose();
            } 
            printJob.end();
        } 
        tool.activate();
    }

    protected void saveDrawing(Module02.StorageFormat storeFormat, java.lang.String file) {
        if ((view()) == null) {
            return ;
        } 
        try {
            Module03.DrawingView drawinView = view();
            Module03.Drawing drawing = drawinView.drawing();
            java.lang.String name = storeFormat.store(file, drawing);
            drawing.setTitle(name);
            setDrawingTitle(name);
        } catch (java.io.IOException e) {
            showStatus(e.toString());
        }
    }

    protected void loadDrawing(Module02.StorageFormat restoreFormat, java.lang.String file) {
        try {
            Module03.Drawing restoredDrawing = restoreFormat.restore(file);
            if (restoredDrawing != null) {
                restoredDrawing.setTitle(file);
                newWindow(restoredDrawing);
            } else {
                showStatus((("Unknown file type: could not open file '" + file) + "'"));
            }
        } catch (java.io.IOException e) {
            showStatus(("Error: " + e));
        }
    }

    private void newLookAndFeel(java.lang.String landf) {
        try {
            javax.swing.UIManager.setLookAndFeel(landf);
            javax.swing.SwingUtilities.updateComponentTreeUI(Module01.DrawApplication.this);
        } catch (java.lang.Exception e) {
            java.lang.System.err.println(e);
        }
    }

    protected void setDrawingTitle(java.lang.String drawingTitle) {
        if (getDefaultDrawingTitle().equals(drawingTitle)) {
            setTitle(getApplicationName());
        } else {
            setTitle((((getApplicationName()) + " - ") + drawingTitle));
        }
    }

    protected java.lang.String getDrawingTitle() {
        return view().drawing().getTitle();
    }

    public void setApplicationName(java.lang.String applicationName) {
        fApplicationName = applicationName;
    }

    public java.lang.String getApplicationName() {
        return fApplicationName;
    }

    protected void setUndoManager(Module01.UndoManager newUndoManager) {
        myUndoManager = newUndoManager;
    }

    public Module01.UndoManager getUndoManager() {
        return myUndoManager;
    }

    protected Module01.VersionControlStrategy getVersionControlStrategy() {
        Module01.StandardVersionControlStrategy standardVersionControlStrategy = new Module01.StandardVersionControlStrategy(Module01.DrawApplication.this);
        return standardVersionControlStrategy;
    }

    public java.lang.String[] getRequiredVersions() {
        java.lang.String[] requiredVersions = new java.lang.String[1];
        requiredVersions[0] = Module06.VersionManagement.getPackageVersion(Module01.DrawApplication.class.getPackage());
        return requiredVersions;
    }

    public java.lang.String getDefaultDrawingTitle() {
        return Module01.DrawApplication.fgUntitled;
    }

    protected Module04.DesktopListener getDesktopListener() {
        return fDesktopListener;
    }

    protected void setDesktopListener(Module04.DesktopListener desktopPaneListener) {
        fDesktopListener = desktopPaneListener;
    }

    protected Module04.DesktopListener createDesktopListener() {
        Module04.DesktopListener desktopListener = new Module04.DesktopListener() {
            public void drawingViewAdded(Module04.DesktopEvent dpe) {
                Module03.DrawingView dv = dpe.getDrawingView();
                fireViewCreatedEvent(dv);
            }

            public void drawingViewRemoved(Module04.DesktopEvent dpe) {
                Module03.DrawingView dv = dpe.getDrawingView();
                getUndoManager().clearUndos(dv);
                getUndoManager().clearRedos(dv);
                fireViewDestroyingEvent(dv);
                checkCommandMenus();
            }

            public void drawingViewSelected(Module04.DesktopEvent dpe) {
                Module03.DrawingView dv = dpe.getDrawingView();
                if (dv != null) {
                    if ((dv.drawing()) != null)
                        dv.unfreezeView();
                    
                } 
                setView(dv);
            }
        };
        return desktopListener;
    }

    protected Module01.Iconkit createIconkit() {
        Module01.Iconkit iconkit = new Module01.Iconkit(Module01.DrawApplication.this);
        return iconkit;
    }

    protected void setIconkit(Module01.Iconkit newIconkit) {
        fIconkit = newIconkit;
    }

    protected Module01.Iconkit getIconkit() {
        return fIconkit;
    }
}


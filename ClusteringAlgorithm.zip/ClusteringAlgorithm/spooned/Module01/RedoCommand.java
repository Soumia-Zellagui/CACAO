package Module01;


public class RedoCommand extends Module01.AbstractCommand {
    public RedoCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module01.UndoManager um = getDrawingEditor().getUndoManager();
        if ((um == null) || (!(um.isRedoable()))) {
            return ;
        } 
        Module06.Undoable lastRedoable = um.popRedo();
        boolean hasBeenUndone = lastRedoable.redo();
        if (hasBeenUndone && (lastRedoable.isUndoable())) {
            um.pushUndo(lastRedoable);
        } 
        lastRedoable.getDrawingView().checkDamage();
        getDrawingEditor().figureSelectionChanged(lastRedoable.getDrawingView());
    }

    public boolean isExecutableWithView() {
        Module01.UndoManager um = getDrawingEditor().getUndoManager();
        if ((um != null) && ((um.getRedoSize()) > 0)) {
            return true;
        } 
        return false;
    }
}


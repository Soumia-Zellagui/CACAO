package Module01;


public class CommandMenu extends javax.swing.JMenu implements Module01.CommandListener , java.awt.event.ActionListener {
    private java.util.HashMap hm;

    public CommandMenu(java.lang.String name) {
        super(name);
        hm = new java.util.HashMap();
    }

    public synchronized void add(Module01.Command command) {
        addMenuItem(command, new javax.swing.JMenuItem(command.name()));
    }

    public synchronized void add(Module01.Command command, java.awt.MenuShortcut shortcut) {
        addMenuItem(command, new javax.swing.JMenuItem(command.name() , shortcut.getKey()));
    }

    public synchronized void addCheckItem(Module01.Command command) {
        addMenuItem(command, new javax.swing.JCheckBoxMenuItem(command.name()));
    }

    protected void addMenuItem(Module01.Command command, javax.swing.JMenuItem m) {
        m.setName(command.name());
        m.addActionListener(Module01.CommandMenu.this);
        add(m);
        command.addCommandListener(Module01.CommandMenu.this);
        hm.put(m, command);
    }

    public synchronized void remove(Module01.Command command) {
        throw new Module06.JHotDrawRuntimeException("not implemented");
    }

    public synchronized void remove(java.awt.MenuItem item) {
        throw new Module06.JHotDrawRuntimeException("not implemented");
    }

    public synchronized void enable(java.lang.String name, boolean state) {
        for (int i = 0 ; i < (getItemCount()) ; i++) {
            javax.swing.JMenuItem item = getItem(i);
            if (name.equals(item.getText())) {
                item.setEnabled(state);
                return ;
            } 
        }
    }

    public synchronized void checkEnabled() {
        for (int i = 0 ; i < (getMenuComponentCount()) ; i++) {
            java.awt.Component c = getMenuComponent(i);
            Module01.Command cmd = ((Module01.Command)(hm.get(c)));
            if (cmd != null) {
                c.setEnabled(cmd.isExecutable());
            } 
        }
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {
        java.lang.Object source = e.getSource();
        for (int i = 0 ; i < (getItemCount()) ; i++) {
            javax.swing.JMenuItem item = getItem(i);
            if (source == item) {
                Module01.Command cmd = ((Module01.Command)(hm.get(item)));
                if (cmd != null) {
                    cmd.execute();
                } 
                break;
            } 
        }
    }

    public void commandExecuted(java.util.EventObject commandEvent) {
    }

    public void commandExecutable(java.util.EventObject commandEvent) {
    }

    public void commandNotExecutable(java.util.EventObject commandEvent) {
    }
}


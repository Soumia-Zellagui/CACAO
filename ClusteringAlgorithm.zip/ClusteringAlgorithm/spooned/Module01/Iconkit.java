package Module01;


public class Iconkit {
    private java.util.Map fMap;

    private java.util.List fRegisteredImages;

    private java.awt.Component fComponent;

    private static final int ID = 123;

    private static Module01.Iconkit fgIconkit = null;

    private static boolean fgDebug = false;

    public Iconkit(java.awt.Component component) {
        fMap = new java.util.Hashtable(53);
        fRegisteredImages = Module06.CollectionsFactory.current().createList(10);
        fComponent = component;
        Module01.Iconkit.fgIconkit = Module01.Iconkit.this;
    }

    public static Module01.Iconkit instance() {
        return Module01.Iconkit.fgIconkit;
    }

    public void loadRegisteredImages(java.awt.Component component) {
        if ((fRegisteredImages.size()) == 0)
            return ;
        
        java.awt.MediaTracker tracker = new java.awt.MediaTracker(component);
        java.util.Iterator iter = fRegisteredImages.iterator();
        while (iter.hasNext()) {
            java.lang.String fileName = ((java.lang.String)(iter.next()));
            if ((basicGetImage(fileName)) == null) {
                tracker.addImage(loadImage(fileName), Module01.Iconkit.ID);
            } 
        }
        fRegisteredImages.clear();
        try {
            tracker.waitForAll();
        } catch (java.lang.Exception e) {
        }
    }

    public void registerImage(java.lang.String fileName) {
        fRegisteredImages.add(fileName);
    }

    public java.awt.Image registerAndLoadImage(java.awt.Component component, java.lang.String fileName) {
        registerImage(fileName);
        loadRegisteredImages(component);
        return getImage(fileName);
    }

    public java.awt.Image loadImage(java.lang.String filename) {
        if (fMap.containsKey(filename)) {
            return ((java.awt.Image)(fMap.get(filename)));
        } 
        java.awt.Image image = loadImageResource(filename);
        if (image != null) {
            fMap.put(filename, image);
        } 
        return image;
    }

    public java.awt.Image loadImage(java.lang.String filename, boolean waitForLoad) {
        java.awt.Image image = loadImage(filename);
        if ((image != null) && waitForLoad) {
            javax.swing.ImageIcon icon = new javax.swing.ImageIcon(image);
            image = icon.getImage();
        } 
        return image;
    }

    public java.awt.Image loadImageResource(java.lang.String resourcename) {
        java.awt.Toolkit toolkit = java.awt.Toolkit.getDefaultToolkit();
        try {
            java.net.URL url = getClass().getResource(resourcename);
            if (Module01.Iconkit.fgDebug) {
                java.lang.System.out.println(resourcename);
            } 
            return toolkit.createImage(((java.awt.image.ImageProducer)(url.getContent())));
        } catch (java.lang.Exception ex) {
            return null;
        }
    }

    public java.awt.Image getImage(java.lang.String filename) {
        java.awt.Image image = basicGetImage(filename);
        if (image != null) {
            return image;
        } 
        loadRegisteredImages(fComponent);
        return basicGetImage(filename);
    }

    private java.awt.Image basicGetImage(java.lang.String filename) {
        if (fMap.containsKey(filename)) {
            return ((java.awt.Image)(fMap.get(filename)));
        } 
        return null;
    }
}


package Module01;


public class UndoableCommand implements Module01.Command , Module01.CommandListener , Module01.FigureSelectionListener {
    private Module01.Command myWrappedCommand;

    private boolean hasSelectionChanged;

    private Module01.AbstractCommand.EventDispatcher myEventDispatcher;

    public UndoableCommand(Module01.Command newWrappedCommand) {
        setWrappedCommand(newWrappedCommand);
        Module01.Command cmd = getWrappedCommand();
        cmd.addCommandListener(Module01.UndoableCommand.this);
        Module01.AbstractCommand.EventDispatcher evtD = createEventDispatcher();
        setEventDispatcher(evtD);
    }

    public void execute() {
        hasSelectionChanged = false;
        Module03.DrawingView v = view();
        v.addFigureSelectionListener(Module01.UndoableCommand.this);
        Module01.Command wc = getWrappedCommand();
        wc.execute();
        Module06.Undoable undoableCommand = wc.getUndoActivity();
        if ((undoableCommand != null) && (undoableCommand.isUndoable())) {
            Module01.DrawingEditor edit = getDrawingEditor();
            Module01.UndoManager um = edit.getUndoManager();
            um.pushUndo(undoableCommand);
            um.clearRedos();
        } 
        if ((!(hasSelectionChanged)) || ((getDrawingEditor().getUndoManager().getUndoSize()) == 1)) {
            Module01.DrawingEditor edit = getDrawingEditor();
            Module01.UndoManager um = edit.getUndoManager();
            edit.figureSelectionChanged(view());
        } 
        v.removeFigureSelectionListener(Module01.UndoableCommand.this);
    }

    public boolean isExecutable() {
        Module01.Command wcomd = getWrappedCommand();
        return wcomd.isExecutable();
    }

    protected void setWrappedCommand(Module01.Command newWrappedCommand) {
        myWrappedCommand = newWrappedCommand;
    }

    protected Module01.Command getWrappedCommand() {
        return myWrappedCommand;
    }

    public java.lang.String name() {
        return getWrappedCommand().name();
    }

    public Module01.DrawingEditor getDrawingEditor() {
        return getWrappedCommand().getDrawingEditor();
    }

    public Module03.DrawingView view() {
        Module01.DrawingEditor ed = getDrawingEditor();
        Module03.DrawingView v = ed.view();
        return v;
    }

    public void figureSelectionChanged(Module03.DrawingView view) {
        hasSelectionChanged = true;
    }

    public Module06.Undoable getUndoActivity() {
        Module03.DrawingView v = view();
        Module06.Undoable ua = new Module06.UndoableAdapter(v);
        return ua;
    }

    public void setUndoActivity(Module06.Undoable newUndoableActivity) {
    }

    public void addCommandListener(Module01.CommandListener newCommandListener) {
        Module01.AbstractCommand.EventDispatcher ed = getEventDispatcher();
        ed.addCommandListener(newCommandListener);
    }

    public void removeCommandListener(Module01.CommandListener oldCommandListener) {
        Module01.AbstractCommand.EventDispatcher ed = getEventDispatcher();
        ed.removeCommandListener(oldCommandListener);
    }

    private void setEventDispatcher(Module01.AbstractCommand.EventDispatcher newEventDispatcher) {
        myEventDispatcher = newEventDispatcher;
    }

    protected Module01.AbstractCommand.EventDispatcher getEventDispatcher() {
        return myEventDispatcher;
    }

    public Module01.AbstractCommand.EventDispatcher createEventDispatcher() {
        Module01.AbstractCommand.EventDispatcher ed = new Module01.AbstractCommand.EventDispatcher(Module01.UndoableCommand.this);
        return ed;
    }

    public void commandExecuted(java.util.EventObject commandEvent) {
        Module01.AbstractCommand.EventDispatcher ed = getEventDispatcher();
        ed.fireCommandExecutedEvent();
    }

    public void commandExecutable(java.util.EventObject commandEvent) {
        Module01.AbstractCommand.EventDispatcher ed = getEventDispatcher();
        ed.fireCommandExecutableEvent();
    }

    public void commandNotExecutable(java.util.EventObject commandEvent) {
        Module01.AbstractCommand.EventDispatcher ed = getEventDispatcher();
        ed.fireCommandNotExecutableEvent();
    }
}


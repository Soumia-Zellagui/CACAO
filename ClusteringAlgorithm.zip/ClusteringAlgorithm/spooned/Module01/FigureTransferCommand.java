package Module01;


public abstract class FigureTransferCommand extends Module01.AbstractCommand {
    protected FigureTransferCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    protected void deleteFigures(Module03.FigureEnumeration fe) {
        Module03.DrawingView v = view();
        Module03.Drawing d = v.drawing();
        Module03.DeleteFromDrawingVisitor deleteVisitor = new Module03.DeleteFromDrawingVisitor(d);
        while (fe.hasNextFigure()) {
            fe.nextFigure().visit(deleteVisitor);
        }
        v.clearSelection();
    }

    protected void copyFigures(Module03.FigureEnumeration fe, int figureCount) {
        Module03.StandardFigureSelection sss = new Module03.StandardFigureSelection(fe , figureCount);
        Module06.Clipboard.getClipboard().setContents(sss);
    }

    public Module03.FigureEnumeration insertFigures(Module03.FigureEnumeration fe, int dx, int dy) {
        return view().insertFigures(fe, dx, dy, false);
    }
}


package Module01;


public class MDI_DrawApplication extends Module01.DrawApplication {
    public MDI_DrawApplication() {
        this("JHotDraw");
    }

    public MDI_DrawApplication(java.lang.String title) {
        super(title);
    }

    protected Module01.DrawApplication createApplication() {
        Module01.MDI_DrawApplication mdi_DrawApplication = new Module01.MDI_DrawApplication();
        return mdi_DrawApplication;
    }

    protected void createTools(javax.swing.JToolBar palette) {
        super.createTools(palette);
        Module03.Tool tool = new Module03.DragNDropTool(Module01.MDI_DrawApplication.this);
        Module03.ToolButton tb = createToolButton(((Module01.DrawApplication.IMAGES) + "SEL"), "Drag N Drop Tool", tool);
        palette.add(tb);
    }

    public void promptNew() {
        Module03.Drawing drawing = createDrawing();
        newWindow(drawing);
    }

    public void newWindow(Module03.Drawing newDrawing) {
        Module03.DrawingView newView = createDrawingVieww(newDrawing);
        getDesktop().addToDesktop(newView, Module04.Desktop.PRIMARY);
        toolDone();
    }

    protected Module03.DrawingView createInitialDrawingView() {
        Module03.DrawingView drawingview = Module03.NullDrawingView.getManagedDrawingView(Module01.MDI_DrawApplication.this);
        return drawingview;
    }

    public void newView() {
        if (!(view().isInteractive())) {
            return ;
        } 
        Module03.DrawingView view = view();
        Module03.Drawing draw = view.drawing();
        newWindow(draw);
        java.lang.String copyTitle = getDrawingTitle();
        if (copyTitle != null) {
            setDrawingTitle(copyTitle);
        } else {
            setDrawingTitle(getDefaultDrawingTitle());
        }
    }

    protected Module04.MDIDesktopPane createDesktop() {
        Module04.MDIDesktopPane desktop = new Module04.MDIDesktopPane(Module01.MDI_DrawApplication.this);
        return desktop;
    }

    public Module03.DrawingView[] views() {
        return getDesktop().getAllFromDesktop(Module04.Desktop.PRIMARY);
    }

    public java.lang.String getDefaultDrawingTitle() {
        return (super.getDefaultDrawingTitle()) + (views().length);
    }

    protected void setDrawingTitle(java.lang.String drawingTitle) {
        getDesktop().updateTitle(drawingTitle);
    }
}


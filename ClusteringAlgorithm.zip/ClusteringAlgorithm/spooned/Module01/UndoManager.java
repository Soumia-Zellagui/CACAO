package Module01;


public class UndoManager {
    public static final int DEFAULT_BUFFER_SIZE = 20;

    private java.util.List redoStack;

    private java.util.List undoStack;

    private int maxStackCapacity;

    public UndoManager() {
        this(Module01.UndoManager.DEFAULT_BUFFER_SIZE);
    }

    public UndoManager(int newUndoStackSize) {
        maxStackCapacity = newUndoStackSize;
        undoStack = Module06.CollectionsFactory.current().createList(maxStackCapacity);
        redoStack = Module06.CollectionsFactory.current().createList(maxStackCapacity);
    }

    public void pushUndo(Module06.Undoable undoActivity) {
        if (undoActivity.isUndoable()) {
            removeFirstElementInFullList(undoStack);
            undoStack.add(undoActivity);
        } else {
            undoStack = Module06.CollectionsFactory.current().createList(maxStackCapacity);
        }
    }

    public void pushRedo(Module06.Undoable redoActivity) {
        if (redoActivity.isRedoable()) {
            removeFirstElementInFullList(redoStack);
            if (((getRedoSize()) == 0) || ((peekRedo()) != redoActivity)) {
                redoStack.add(redoActivity);
            } 
        } else {
            redoStack = Module06.CollectionsFactory.current().createList(maxStackCapacity);
        }
    }

    private void removeFirstElementInFullList(java.util.List l) {
        if ((l.size()) >= (maxStackCapacity)) {
            Module06.Undoable removedActivity = ((Module06.Undoable)(l.remove(0)));
            removedActivity.release();
        } 
    }

    private Module06.Undoable getLastElement(java.util.List l) {
        if ((l.size()) > 0) {
            return ((Module06.Undoable)(l.get(((l.size()) - 1))));
        } else {
            return null;
        }
    }

    public boolean isUndoable() {
        if ((getUndoSize()) > 0) {
            return getLastElement(undoStack).isUndoable();
        } else {
            return false;
        }
    }

    public boolean isRedoable() {
        if ((getRedoSize()) > 0) {
            return getLastElement(redoStack).isRedoable();
        } else {
            return false;
        }
    }

    protected Module06.Undoable peekUndo() {
        if ((getUndoSize()) > 0) {
            return getLastElement(undoStack);
        } else {
            return null;
        }
    }

    protected Module06.Undoable peekRedo() {
        if ((getRedoSize()) > 0) {
            return getLastElement(redoStack);
        } else {
            return null;
        }
    }

    public int getUndoSize() {
        return undoStack.size();
    }

    public int getRedoSize() {
        return redoStack.size();
    }

    public Module06.Undoable popUndo() {
        Module06.Undoable lastUndoable = peekUndo();
        undoStack.remove(((getUndoSize()) - 1));
        return lastUndoable;
    }

    public Module06.Undoable popRedo() {
        Module06.Undoable lastUndoable = peekRedo();
        redoStack.remove(((getRedoSize()) - 1));
        return lastUndoable;
    }

    public void clearUndos() {
        clearStack(undoStack);
    }

    public void clearRedos() {
        clearStack(redoStack);
    }

    protected void clearStack(java.util.List clearStack) {
        clearStack.clear();
    }

    public void clearUndos(Module03.DrawingView checkDV) {
        java.util.Iterator iter = undoStack.iterator();
        while (iter.hasNext()) {
            Module06.Undoable currentUndo = ((Module06.Undoable)(iter.next()));
            if ((currentUndo.getDrawingView()) == checkDV) {
                iter.remove();
            } 
        }
    }

    public void clearRedos(Module03.DrawingView checkDV) {
        java.util.Iterator iter = redoStack.iterator();
        while (iter.hasNext()) {
            Module06.Undoable currentRedo = ((Module06.Undoable)(iter.next()));
            if ((currentRedo.getDrawingView()) == checkDV) {
                iter.remove();
            } 
        }
    }
}


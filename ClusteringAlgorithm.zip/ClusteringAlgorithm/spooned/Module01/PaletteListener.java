package Module01;


public interface PaletteListener {
    public void paletteUserSelected(Module06.PaletteButton button);

    public void paletteUserOver(Module06.PaletteButton button, boolean inside);
}


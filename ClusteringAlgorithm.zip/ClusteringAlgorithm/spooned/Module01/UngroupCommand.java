package Module01;


public class UngroupCommand extends Module01.AbstractCommand {
    public UngroupCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        getUndoActivity().setAffectedFigures(view().selection());
        view().clearSelection();
        ((Module01.UngroupCommand.UndoActivity)(getUndoActivity())).ungroupFigures();
        view().checkDamage();
    }

    public boolean isExecutableWithView() {
        Module03.FigureEnumeration fe = view().selection();
        while (fe.hasNextFigure()) {
            Module03.Figure currentFigure = fe.nextFigure();
            currentFigure = currentFigure.getDecoratedFigure();
            if (!(currentFigure instanceof Module03.GroupFigure)) {
                return false;
            } 
        }
        return (view().selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.UngroupCommand.UndoActivity(view());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            Module03.FigureEnumeration groupFigures = getAffectedFigures();
            while (groupFigures.hasNextFigure()) {
                Module03.Figure groupFigure = groupFigures.nextFigure();
                getDrawingView().drawing().orphanAll(groupFigure.figures());
                Module03.Figure figure = getDrawingView().drawing().add(groupFigure);
                getDrawingView().addToSelection(figure);
            }
            return true;
        }

        public boolean redo() {
            if (isRedoable()) {
                getDrawingView().drawing().orphanAll(getAffectedFigures());
                getDrawingView().clearSelection();
                ungroupFigures();
                return true;
            } 
            return false;
        }

        protected void ungroupFigures() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure selected = fe.nextFigure();
                Module03.Figure group = getDrawingView().drawing().orphan(selected);
                getDrawingView().drawing().addAll(group.figures());
                getDrawingView().addToSelectionAll(group.figures());
            }
        }
    }
}


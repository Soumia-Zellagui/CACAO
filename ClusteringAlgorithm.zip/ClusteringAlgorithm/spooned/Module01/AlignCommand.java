package Module01;


public class AlignCommand extends Module01.AbstractCommand {
    public abstract static class Alignment {
        public static final Module01.AlignCommand.Alignment LEFTS = new Module01.AlignCommand.Alignment("Lefts") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy(((anchor.x) - (rr.x)), 0);
            }
        };

        public static final Module01.AlignCommand.Alignment CENTERS = new Module01.AlignCommand.Alignment("Centers") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy((((anchor.x) + ((anchor.width) / 2)) - ((rr.x) + ((rr.width) / 2))), 0);
            }
        };

        public static final Module01.AlignCommand.Alignment RIGHTS = new Module01.AlignCommand.Alignment("Rights") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy((((anchor.x) + (anchor.width)) - ((rr.x) + (rr.width))), 0);
            }
        };

        public static final Module01.AlignCommand.Alignment TOPS = new Module01.AlignCommand.Alignment("Tops") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy(0, ((anchor.y) - (rr.y)));
            }
        };

        public static final Module01.AlignCommand.Alignment MIDDLES = new Module01.AlignCommand.Alignment("Middles") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy(0, (((anchor.y) + ((anchor.height) / 2)) - ((rr.y) + ((rr.height) / 2))));
            }
        };

        public static final Module01.AlignCommand.Alignment BOTTOMS = new Module01.AlignCommand.Alignment("Bottoms") {
            public void moveBy(Module03.Figure f, java.awt.Rectangle anchor) {
                java.awt.Rectangle rr = f.displayBox();
                f.moveBy(0, (((anchor.y) + (anchor.height)) - ((rr.y) + (rr.height))));
            }
        };

        private java.lang.String myDescription;

        private Alignment(java.lang.String newDescription) {
            setDescription(newDescription);
        }

        public java.lang.String toString() {
            return getDescription();
        }

        public java.lang.String getDescription() {
            return myDescription;
        }

        private void setDescription(java.lang.String newDescription) {
            myDescription = newDescription;
        }

        public abstract void moveBy(Module03.Figure f, java.awt.Rectangle anchor);
    }

    private Module01.AlignCommand.Alignment myAlignment;

    public AlignCommand(Module01.AlignCommand.Alignment newAlignment ,Module01.DrawingEditor newDrawingEditor) {
        super(newAlignment.getDescription(), newDrawingEditor);
        setAlignment(newAlignment);
    }

    protected boolean isExecutableWithView() {
        return (view().selectionCount()) > 1;
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        getUndoActivity().setAffectedFigures(view().selection());
        ((Module01.AlignCommand.UndoActivity)(getUndoActivity())).alignAffectedFigures(getAlignment());
        view().checkDamage();
    }

    protected void setAlignment(Module01.AlignCommand.Alignment newAlignment) {
        myAlignment = newAlignment;
    }

    public Module01.AlignCommand.Alignment getAlignment() {
        return myAlignment;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.AlignCommand.UndoActivity(view() , getAlignment());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.util.Hashtable myOriginalPoints;

        private Module01.AlignCommand.Alignment myAppliedAlignment;

        public UndoActivity(Module03.DrawingView newView ,Module01.AlignCommand.Alignment newAlignment) {
            super(newView);
            myOriginalPoints = new java.util.Hashtable();
            setAppliedAlignment(newAlignment);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                java.awt.Point originalPoint = getOriginalPoint(f);
                java.awt.Point currentPoint = f.displayBox().getLocation();
                f.moveBy(((-(currentPoint.x)) + (originalPoint.x)), ((-(currentPoint.y)) + (originalPoint.y)));
            }
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            alignAffectedFigures(getAppliedAlignment());
            return true;
        }

        protected void setAppliedAlignment(Module01.AlignCommand.Alignment newAlignment) {
            myAppliedAlignment = newAlignment;
        }

        public Module01.AlignCommand.Alignment getAppliedAlignment() {
            return myAppliedAlignment;
        }

        protected void addOriginalPoint(Module03.Figure f) {
            myOriginalPoints.put(f, f.displayBox().getLocation());
        }

        public java.awt.Point getOriginalPoint(Module03.Figure f) {
            return ((java.awt.Point)(myOriginalPoints.get(f)));
        }

        public void alignAffectedFigures(Module01.AlignCommand.Alignment applyAlignment) {
            Module03.FigureEnumeration fe = getAffectedFigures();
            Module03.Figure anchorFigure = fe.nextFigure();
            java.awt.Rectangle r = anchorFigure.displayBox();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                applyAlignment.moveBy(f, r);
            }
        }

        public void setAffectedFigures(Module03.FigureEnumeration fe) {
            super.setAffectedFigures(fe);
            Module03.FigureEnumeration copyFe = getAffectedFigures();
            while (copyFe.hasNextFigure()) {
                addOriginalPoint(copyFe.nextFigure());
            }
        }
    }
}


package Module01;


public interface Command {
    public void execute();

    public boolean isExecutable();

    public java.lang.String name();

    public Module01.DrawingEditor getDrawingEditor();

    public Module06.Undoable getUndoActivity();

    public void setUndoActivity(Module06.Undoable newUndoableActivity);

    public void addCommandListener(Module01.CommandListener newCommandListener);

    public void removeCommandListener(Module01.CommandListener oldCommandListener);
}


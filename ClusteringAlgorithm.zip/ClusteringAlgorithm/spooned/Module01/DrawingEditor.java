package Module01;


public interface DrawingEditor extends Module01.FigureSelectionListener {
    public Module03.DrawingView view();

    public Module03.DrawingView[] views();

    public Module03.Tool tool();

    public void toolDone();

    public void figureSelectionChanged(Module03.DrawingView view);

    public void addViewChangeListener(Module06.ViewChangeListener vsl);

    public void removeViewChangeListener(Module06.ViewChangeListener vsl);

    public void showStatus(java.lang.String string);

    public Module01.UndoManager getUndoManager();
}


package Module01;


public interface VersionRequester {
    public abstract java.lang.String[] getRequiredVersions();
}


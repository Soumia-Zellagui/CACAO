package Module01;


public class CopyCommand extends Module01.FigureTransferCommand {
    public CopyCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        copyFigures(view().selection(), view().selectionCount());
    }

    protected boolean isExecutableWithView() {
        return (view().selectionCount()) > 0;
    }
}


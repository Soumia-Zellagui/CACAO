package Module01;


public interface FigureSelectionListener {
    public void figureSelectionChanged(Module03.DrawingView view);
}


package Module01;


public class SendToBackCommand extends Module01.AbstractCommand {
    public SendToBackCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module06.Undoable un = createUndoActivity();
        setUndoActivity(un);
        Module03.DrawingView v = view();
        Module03.FigureEnumeration fen = v.selectionZOrdered();
        Module06.Undoable gua = getUndoActivity();
        gua.setAffectedFigures(fen);
        Module03.FigureEnumeration fe = gua.getAffectedFigures();
        while (fe.hasNextFigure()) {
            Module03.Drawing d = v.drawing();
            d.sendToBack(fe.nextFigure());
        }
        v.checkDamage();
    }

    protected boolean isExecutableWithView() {
        Module03.DrawingView v = view();
        return (v.selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        Module03.DrawingView v = view();
        Module01.SendToBackCommand.UndoActivity stu = new Module01.SendToBackCommand.UndoActivity(v);
        return stu;
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.util.Hashtable myOriginalLayers;

        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            myOriginalLayers = new java.util.Hashtable();
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                int currentFigureLayer = getOriginalLayer(currentFigure);
                Module03.DrawingView v = getDrawingView();
                Module03.Drawing d = v.drawing();
                d.sendToLayer(currentFigure, currentFigureLayer);
            }
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                sendToCommand(fe.nextFigure());
            }
            return true;
        }

        protected void sendToCommand(Module03.Figure f) {
            Module03.DrawingView v = getDrawingView();
            Module03.Drawing d = v.drawing();
            d.sendToBack(f);
        }

        protected void addOriginalLayer(Module03.Figure affectedFigure, int newOriginalLayer) {
            myOriginalLayers.put(affectedFigure, new java.lang.Integer(newOriginalLayer));
        }

        protected int getOriginalLayer(Module03.Figure lookupAffectedFigure) {
            return ((java.lang.Integer)(myOriginalLayers.get(lookupAffectedFigure))).intValue();
        }

        public void setAffectedFigures(Module03.FigureEnumeration fe) {
            super.setAffectedFigures(fe);
            Module03.FigureEnumeration copyFe = getAffectedFigures();
            while (copyFe.hasNextFigure()) {
                Module03.Figure f = copyFe.nextFigure();
                int originalLayer = getDrawingView().drawing().getLayer(f);
                addOriginalLayer(f, originalLayer);
            }
        }
    }
}


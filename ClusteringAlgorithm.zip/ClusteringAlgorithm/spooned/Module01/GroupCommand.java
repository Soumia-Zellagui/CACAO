package Module01;


public class GroupCommand extends Module01.AbstractCommand {
    public GroupCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        getUndoActivity().setAffectedFigures(view().selection());
        ((Module01.GroupCommand.UndoActivity)(getUndoActivity())).groupFigures();
        view().checkDamage();
    }

    public boolean isExecutableWithView() {
        return (view().selectionCount()) > 1;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.GroupCommand.UndoActivity(view());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            getDrawingView().drawing().orphanAll(getAffectedFigures());
            java.util.List affectedFigures = Module06.CollectionsFactory.current().createList();
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure currentFigure = fe.nextFigure();
                getDrawingView().drawing().addAll(currentFigure.figures());
                getDrawingView().addToSelectionAll(currentFigure.figures());
                Module03.FigureEnumeration groupedFigures = currentFigure.figures();
                while (groupedFigures.hasNextFigure()) {
                    affectedFigures.add(groupedFigures.nextFigure());
                }
            }
            setAffectedFigures(new Module03.FigureEnumerator(affectedFigures));
            return true;
        }

        public boolean redo() {
            if (isRedoable()) {
                groupFigures();
                return true;
            } 
            return false;
        }

        public void groupFigures() {
            getDrawingView().drawing().orphanAll(getAffectedFigures());
            getDrawingView().clearSelection();
            Module03.GroupFigure group = new Module03.GroupFigure();
            group.addAll(getAffectedFigures());
            Module03.Figure figure = getDrawingView().drawing().add(group);
            getDrawingView().addToSelection(figure);
            java.util.List affectedFigures = Module06.CollectionsFactory.current().createList();
            affectedFigures.add(figure);
            setAffectedFigures(new Module03.FigureEnumerator(affectedFigures));
        }
    }
}


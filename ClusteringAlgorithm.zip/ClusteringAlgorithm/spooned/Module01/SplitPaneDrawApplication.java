package Module01;


public class SplitPaneDrawApplication extends Module01.DrawApplication {
    public SplitPaneDrawApplication() {
        this("JHotDraw");
    }

    public SplitPaneDrawApplication(java.lang.String title) {
        super(title);
    }

    protected Module04.Desktop createDesktop() {
        Module04.SplitPaneDesktop splitPaneDesktop = new Module04.SplitPaneDesktop();
        return splitPaneDesktop;
    }
}


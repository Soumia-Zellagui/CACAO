package Module01;


public interface VersionControlStrategy {
    public void assertCompatibleVersion();
}


package Module01;


public class ChangeAttributeCommand extends Module01.AbstractCommand {
    private Module06.FigureAttributeConstant fAttribute;

    private java.lang.Object fValue;

    public ChangeAttributeCommand(java.lang.String name ,Module06.FigureAttributeConstant attribute ,java.lang.Object value ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
        fAttribute = attribute;
        fValue = value;
    }

    public void execute() {
        super.execute();
        setUndoActivity(createUndoActivity());
        getUndoActivity().setAffectedFigures(view().selection());
        Module03.FigureEnumeration fe = getUndoActivity().getAffectedFigures();
        while (fe.hasNextFigure()) {
            fe.nextFigure().setAttribute(fAttribute, fValue);
        }
        view().checkDamage();
    }

    public boolean isExecutableWithView() {
        return (view().selectionCount()) > 0;
    }

    protected Module06.Undoable createUndoActivity() {
        return new Module01.ChangeAttributeCommand.UndoActivity(view() , fAttribute , fValue);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private Module06.FigureAttributeConstant myUndoAttribute;

        private java.util.Hashtable myOriginalValues;

        private java.lang.Object myUndoValue;

        public UndoActivity(Module03.DrawingView newDrawingView ,Module06.FigureAttributeConstant newUndoAttribute ,java.lang.Object newUndoValue) {
            super(newDrawingView);
            myOriginalValues = new java.util.Hashtable();
            setAttribute(newUndoAttribute);
            setBackupValue(newUndoValue);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                if ((getOriginalValue(f)) != null) {
                    f.setAttribute(getAttribute(), getOriginalValue(f));
                } 
            }
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                Module03.Figure f = fe.nextFigure();
                if ((getBackupValue()) != null) {
                    f.setAttribute(getAttribute(), getBackupValue());
                } 
            }
            return true;
        }

        protected void addOriginalValue(Module03.Figure affectedFigure, java.lang.Object newOriginalValue) {
            myOriginalValues.put(affectedFigure, newOriginalValue);
        }

        protected java.lang.Object getOriginalValue(Module03.Figure lookupAffectedFigure) {
            return myOriginalValues.get(lookupAffectedFigure);
        }

        protected void setAttribute(Module06.FigureAttributeConstant newUndoAttribute) {
            myUndoAttribute = newUndoAttribute;
        }

        public Module06.FigureAttributeConstant getAttribute() {
            return myUndoAttribute;
        }

        protected void setBackupValue(java.lang.Object newUndoValue) {
            myUndoValue = newUndoValue;
        }

        public java.lang.Object getBackupValue() {
            return myUndoValue;
        }

        public void release() {
            super.release();
            myOriginalValues = null;
        }

        public void setAffectedFigures(Module03.FigureEnumeration fe) {
            super.setAffectedFigures(fe);
            Module03.FigureEnumeration copyFe = getAffectedFigures();
            while (copyFe.hasNextFigure()) {
                Module03.Figure f = copyFe.nextFigure();
                java.lang.Object attributeValue = f.getAttribute(getAttribute());
                if (attributeValue != null) {
                    addOriginalValue(f, attributeValue);
                } 
            }
        }
    }
}


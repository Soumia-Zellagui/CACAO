package Module01;


public class JavaDrawViewer extends javax.swing.JApplet implements Module01.DrawingEditor {
    private Module03.Drawing fDrawing;

    private Module03.Tool fTool;

    private Module03.StandardDrawingView fView;

    private transient Module01.UndoManager myUndoManager;

    public void init() {
        setUndoManager(new Module01.UndoManager());
        getContentPane().setLayout(new java.awt.BorderLayout());
        fView = new Module03.StandardDrawingView(Module01.JavaDrawViewer.this , 400 , 370);
        getContentPane().add("Center", fView);
        setTool(new Module03.FollowURLTool(Module01.JavaDrawViewer.this , Module01.JavaDrawViewer.this));
        java.lang.String filename = getParameter("Drawing");
        if (filename != null) {
            loadDrawing(filename);
            fView.setDrawing(fDrawing);
        } else {
            showStatus("Unable to load drawing");
        }
    }

    public void addViewChangeListener(Module06.ViewChangeListener vsl) {
    }

    public void removeViewChangeListener(Module06.ViewChangeListener vsl) {
    }

    private void loadDrawing(java.lang.String filename) {
        try {
            java.net.URL url = new java.net.URL(getCodeBase() , filename);
            java.io.InputStream stream = url.openStream();
            Module06.StorableInput reader = new Module06.StorableInput(stream);
            fDrawing = ((Module03.Drawing)(reader.readStorable()));
        } catch (java.io.IOException e) {
            fDrawing = createDrawing();
            java.lang.System.err.println(("Error when Loading: " + e));
            showStatus(("Error when Loading: " + e));
        }
    }

    protected Module03.Drawing createDrawing() {
        return new Module03.StandardDrawing();
    }

    public Module03.DrawingView view() {
        return fView;
    }

    public Module03.DrawingView[] views() {
        return new Module03.DrawingView[]{ view() };
    }

    public Module03.Drawing drawing() {
        return fDrawing;
    }

    public Module03.Tool tool() {
        return fTool;
    }

    public void setTool(Module03.Tool newTool) {
        fTool = newTool;
    }

    public void toolDone() {
    }

    public void figureSelectionChanged(Module03.DrawingView view) {
    }

    protected void setUndoManager(Module01.UndoManager newUndoManager) {
        myUndoManager = newUndoManager;
    }

    public Module01.UndoManager getUndoManager() {
        return myUndoManager;
    }
}


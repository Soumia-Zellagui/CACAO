package Module01;


public class UndoCommand extends Module01.AbstractCommand {
    public UndoCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module01.UndoManager um = getDrawingEditor().getUndoManager();
        if ((um == null) || (!(um.isUndoable()))) {
            return ;
        } 
        Module06.Undoable lastUndoable = um.popUndo();
        boolean hasBeenUndone = lastUndoable.undo();
        if (hasBeenUndone && (lastUndoable.isRedoable())) {
            um.pushRedo(lastUndoable);
        } 
        lastUndoable.getDrawingView().checkDamage();
        getDrawingEditor().figureSelectionChanged(lastUndoable.getDrawingView());
    }

    public boolean isExecutableWithView() {
        Module01.UndoManager um = getDrawingEditor().getUndoManager();
        if ((um != null) && ((um.getUndoSize()) > 0)) {
            return true;
        } 
        return false;
    }
}


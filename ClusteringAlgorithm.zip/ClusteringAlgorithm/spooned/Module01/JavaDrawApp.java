package Module01;


public class JavaDrawApp extends Module01.MDI_DrawApplication {
    private Module06.Animator fAnimator;

    private static java.lang.String fgSampleImagesPath = "/org/jhotdraw/samples/javadraw/sampleimages";

    private static java.lang.String fgSampleImagesResourcePath = (Module01.JavaDrawApp.fgSampleImagesPath) + "/";

    JavaDrawApp() {
        super("JHotDraw");
    }

    public JavaDrawApp(java.lang.String title) {
        super(title);
    }

    protected Module01.DrawApplication createApplication() {
        Module01.JavaDrawApp jda = new Module01.JavaDrawApp();
        return jda;
    }

    protected Module03.DrawingView createDrawingView(Module03.Drawing newDrawing) {
        java.awt.Dimension d = getDrawingViewSize();
        Module03.DrawingView newDrawingView = new Module03.ZoomDrawingView(Module01.JavaDrawApp.this , d.width , d.height);
        newDrawingView.setDrawing(newDrawing);
        return newDrawingView;
    }

    public void destroy() {
        super.destroy();
        endAnimation();
    }

    protected void createTools(javax.swing.JToolBar palette) {
        super.createTools(palette);
    }

    protected Module03.Tool createSelectionTool() {
        return null;
    }

    protected void createMenus(javax.swing.JMenuBar mb) {
        super.createMenus(mb);
        Module01.CommandMenu animationMenu = createAnimationMenu();
        addMenuIfPossible(mb, animationMenu);
        Module01.CommandMenu imageMenu = createImagesMenu();
        addMenuIfPossible(mb, imageMenu);
        Module01.CommandMenu windowMenu = createWindowMenu();
        addMenuIfPossible(mb, windowMenu);
    }

    protected Module01.CommandMenu createAnimationMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Animation");
        Module01.Command cmd = new Module01.AbstractCommand("Start Animation", Module01.JavaDrawApp.this) {
            public void execute() {
                startAnimation();
            }
        };
        menu.add(cmd);
        cmd = new Module01.AbstractCommand("Stop Animation", Module01.JavaDrawApp.this) {
            public void execute() {
                endAnimation();
            }
        };
        menu.add(cmd);
        return menu;
    }

    protected Module01.CommandMenu createWindowMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Window");
        Module01.Command cmd = new Module01.AbstractCommand("New View", Module01.JavaDrawApp.this) {
            public void execute() {
                newView();
            }
        };
        menu.add(cmd);
        cmd = new Module01.AbstractCommand("New Window", Module01.JavaDrawApp.this, false) {
            public void execute() {
                newWindow(createDrawing());
            }
        };
        menu.add(cmd);
        menu.addSeparator();
        Module04.MDIDesktopPane desktop = ((Module04.MDIDesktopPane)(getDesktop()));
        Module01.WindowMenu windowMenu = new Module01.WindowMenu("Window List" , desktop , Module01.JavaDrawApp.this);
        menu.add(windowMenu);
        return menu;
    }

    protected Module01.CommandMenu createImagesMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Images");
        java.net.URL url = getClass().getResource(Module01.JavaDrawApp.fgSampleImagesPath);
        if (url == null) {
            Module06.JHotDrawRuntimeException jhotDrawRuntimeException = new Module06.JHotDrawRuntimeException(("Could not locate images: " + (Module01.JavaDrawApp.fgSampleImagesPath)));
            throw jhotDrawRuntimeException;
        } 
        java.io.File imagesDirectory = new java.io.File(url.getFile());
        try {
            java.lang.String[] list = imagesDirectory.list();
            for (int i = 0 ; i < (list.length) ; i++) {
                java.lang.String name = list[i];
                java.lang.String path = (Module01.JavaDrawApp.fgSampleImagesResourcePath) + name;
                Module01.InsertImageCommand insertImageCommand = new Module01.InsertImageCommand(name , path , Module01.JavaDrawApp.this);
                Module01.UndoableCommand undoableCmd = new Module01.UndoableCommand(insertImageCommand);
                menu.add(undoableCmd);
            }
        } catch (java.lang.Exception e) {
        }
        return menu;
    }

    protected Module03.Drawing createDrawing() {
        Module03.Drawing dwg = new Module03.BouncingDrawing();
        java.lang.String title = getDefaultDrawingTitle();
        dwg.setTitle(title);
        return dwg;
    }

    public void startAnimation() {
        if (((view().drawing()) instanceof Module03.Animatable) && ((fAnimator) == null)) {
            Module03.DrawingView view = view();
            Module03.Drawing drawing = view.drawing();
            fAnimator = new Module06.Animator(((Module03.Animatable)(drawing)) , view);
            fAnimator.start();
        } 
    }

    public void endAnimation() {
        if ((fAnimator) != null) {
            fAnimator.end();
            fAnimator = null;
        } 
    }

    protected Module01.CommandMenu createDebugMenu() {
        Module01.CommandMenu menu = new Module01.CommandMenu("Debug");
        Module01.Command cmd = new Module01.AbstractCommand("Simple Update", Module01.JavaDrawApp.this) {
            public void execute() {
                Module03.SimpleUpdateStrategy simpleUpdateStrategy = new Module03.SimpleUpdateStrategy();
                Module03.DrawingView view = this.view();
                view.setDisplayUpdate(simpleUpdateStrategy);
            }
        };
        menu.add(cmd);
        cmd = new Module01.AbstractCommand("Buffered Update", Module01.JavaDrawApp.this) {
            public void execute() {
                Module03.BufferedUpdateStrategy bufferedUpdateStrategy = new Module03.BufferedUpdateStrategy();
                Module03.DrawingView view = this.view();
                view.setDisplayUpdate(bufferedUpdateStrategy);
            }
        };
        menu.add(cmd);
        Module01.CommandMenu menuu = menu;
        Module01.Command cmdd = new Module01.AbstractCommand("Clipping Update", Module01.JavaDrawApp.this) {
            public void execute() {
                Module03.ClippingUpdateStrategy clippingUpdateStrategy = new Module03.ClippingUpdateStrategy();
                Module03.DrawingView v = this.view();
                v.setDisplayUpdate(clippingUpdateStrategy);
            }
        };
        menuu.add(cmdd);
        return menuu;
    }

    public static void main(java.lang.String[] args) {
        Module01.JavaDrawApp window = new Module01.JavaDrawApp();
        window.open();
    }
}


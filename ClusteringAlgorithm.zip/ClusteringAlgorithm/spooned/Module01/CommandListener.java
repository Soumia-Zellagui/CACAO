package Module01;


public interface CommandListener {
    public void commandExecuted(java.util.EventObject commandEvent);

    public void commandExecutable(java.util.EventObject commandEvent);

    public void commandNotExecutable(java.util.EventObject commandEvent);
}


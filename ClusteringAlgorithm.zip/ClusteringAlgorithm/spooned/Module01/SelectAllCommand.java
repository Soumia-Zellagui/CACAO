package Module01;


public class SelectAllCommand extends Module01.AbstractCommand {
    public SelectAllCommand(java.lang.String name ,Module01.DrawingEditor newDrawingEditor) {
        super(name, newDrawingEditor);
    }

    public void execute() {
        super.execute();
        Module06.Undoable undo = createUndoActivity();
        setUndoActivity(undo);
        Module03.DrawingView v = view();
        Module06.Undoable unddoo = getUndoActivity();
        Module03.FigureEnumeration sele = v.selection();
        unddoo.setAffectedFigures(sele);
        Module03.Drawing dr = v.drawing();
        Module03.FigureEnumeration t = dr.figures();
        v.addToSelectionAll(t);
        v.checkDamage();
    }

    public boolean isExecutableWithView() {
        Module03.DrawingView v = view();
        Module03.Drawing dr = v.drawing();
        Module03.FigureEnumeration fe = dr.figures();
        if ((fe.hasNextFigure()) && ((fe.nextFigure()) != null)) {
            return true;
        } 
        return false;
    }

    protected Module06.Undoable createUndoActivity() {
        Module03.DrawingView v = view();
        Module01.SelectAllCommand.UndoActivity seua = new Module01.SelectAllCommand.UndoActivity(v);
        return seua;
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        public UndoActivity(Module03.DrawingView newDrawingView) {
            super(newDrawingView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            getDrawingView().clearSelection();
            getDrawingView().addToSelectionAll(getAffectedFigures());
            return true;
        }

        public boolean redo() {
            if (isRedoable()) {
                getDrawingView().addToSelectionAll(getDrawingView().drawing().figures());
                return true;
            } 
            return false;
        }
    }
}


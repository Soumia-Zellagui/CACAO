package Module01;


public abstract class AbstractCommand implements Module01.Command , Module01.FigureSelectionListener {
    private java.lang.String myName;

    private Module06.Undoable myUndoableActivity;

    private boolean myIsViewRequired;

    private Module01.AbstractCommand.EventDispatcher myEventDispatcher;

    private Module01.DrawingEditor myDrawingEditor;

    public AbstractCommand(java.lang.String newName ,Module01.DrawingEditor newDrawingEditor) {
        this(newName, newDrawingEditor, true);
    }

    public AbstractCommand(java.lang.String newName ,Module01.DrawingEditor newDrawingEditor ,boolean newIsViewRequired) {
        setName(newName);
        setDrawingEditor(newDrawingEditor);
        Module01.DrawingEditor d = getDrawingEditor();
        Module06.ViewChangeListener vcl = createViewChangeListener();
        d.addViewChangeListener(vcl);
        myIsViewRequired = newIsViewRequired;
        Module01.AbstractCommand.EventDispatcher ed = createEventDispatcher();
        setEventDispatcher(ed);
    }

    protected void viewSelectionChanged(Module03.DrawingView oldView, Module03.DrawingView newView) {
        if (oldView != null) {
            oldView.removeFigureSelectionListener(Module01.AbstractCommand.this);
        } 
        if (newView != null) {
            newView.addFigureSelectionListener(Module01.AbstractCommand.this);
        } 
        if (isViewRequired()) {
            boolean isOldViewInteractive = (oldView != null) && (oldView.isInteractive());
            boolean isNewViewInteractive = (newView != null) && (newView.isInteractive());
            if ((!isOldViewInteractive) && isNewViewInteractive) {
                getEventDispatcher().fireCommandExecutableEvent();
            } else if (isOldViewInteractive && (!isNewViewInteractive)) {
                getEventDispatcher().fireCommandNotExecutableEvent();
            } 
        } 
    }

    protected void viewCreated(Module03.DrawingView view) {
    }

    protected void viewDestroying(Module03.DrawingView view) {
    }

    public void figureSelectionChanged(Module03.DrawingView view) {
    }

    public Module01.DrawingEditor getDrawingEditor() {
        return myDrawingEditor;
    }

    private void setDrawingEditor(Module01.DrawingEditor newDrawingEditor) {
        myDrawingEditor = newDrawingEditor;
    }

    public Module03.DrawingView view() {
        return getDrawingEditor().view();
    }

    public java.lang.String name() {
        return myName;
    }

    public void setName(java.lang.String newName) {
        myName = newName;
    }

    public void dispose() {
        if ((view()) != null) {
            view().removeFigureSelectionListener(Module01.AbstractCommand.this);
        } 
    }

    public void execute() {
        if ((view()) == null) {
            throw new Module06.JHotDrawRuntimeException("execute should NOT be getting called when view() == null");
        } 
    }

    public boolean isExecutable() {
        if (isViewRequired()) {
            if (((view()) == null) || (!(view().isInteractive()))) {
                return false;
            } 
        } 
        return isExecutableWithView();
    }

    protected boolean isViewRequired() {
        return myIsViewRequired;
    }

    protected boolean isExecutableWithView() {
        return true;
    }

    public Module06.Undoable getUndoActivity() {
        return myUndoableActivity;
    }

    public void setUndoActivity(Module06.Undoable newUndoableActivity) {
        myUndoableActivity = newUndoableActivity;
    }

    public void addCommandListener(Module01.CommandListener newCommandListener) {
        getEventDispatcher().addCommandListener(newCommandListener);
    }

    public void removeCommandListener(Module01.CommandListener oldCommandListener) {
        getEventDispatcher().removeCommandListener(oldCommandListener);
    }

    private void setEventDispatcher(Module01.AbstractCommand.EventDispatcher newEventDispatcher) {
        myEventDispatcher = newEventDispatcher;
    }

    protected Module01.AbstractCommand.EventDispatcher getEventDispatcher() {
        return myEventDispatcher;
    }

    protected Module01.AbstractCommand.EventDispatcher createEventDispatcher() {
        Module01.AbstractCommand.EventDispatcher ed = new Module01.AbstractCommand.EventDispatcher(Module01.AbstractCommand.this);
        return ed;
    }

    protected Module06.ViewChangeListener createViewChangeListener() {
        Module06.ViewChangeListener vcl = new Module06.ViewChangeListener() {
            public void viewSelectionChanged(Module03.DrawingView oldView, Module03.DrawingView newView) {
                Module01.AbstractCommand.this.viewSelectionChanged(oldView, newView);
            }

            public void viewCreated(Module03.DrawingView view) {
                Module01.AbstractCommand.this.viewCreated(view);
            }

            public void viewDestroying(Module03.DrawingView view) {
                Module01.AbstractCommand.this.viewDestroying(view);
            }
        };
        return vcl;
    }

    public static class EventDispatcher {
        private java.util.List myRegisteredListeners;

        private Module01.Command myObservedCommand;

        public EventDispatcher(Module01.Command newObservedCommand) {
            myRegisteredListeners = Module06.CollectionsFactory.current().createList();
            myObservedCommand = newObservedCommand;
        }

        public void fireCommandExecutedEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module01.CommandListener)(iter.next())).commandExecuted(new java.util.EventObject(myObservedCommand));
            }
        }

        public void fireCommandExecutableEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module01.CommandListener)(iter.next())).commandExecutable(new java.util.EventObject(myObservedCommand));
            }
        }

        public void fireCommandNotExecutableEvent() {
            java.util.Iterator iter = myRegisteredListeners.iterator();
            while (iter.hasNext()) {
                ((Module01.CommandListener)(iter.next())).commandNotExecutable(new java.util.EventObject(myObservedCommand));
            }
        }

        public void addCommandListener(Module01.CommandListener newCommandListener) {
            if (!(myRegisteredListeners.contains(newCommandListener))) {
                myRegisteredListeners.add(newCommandListener);
            } 
        }

        public void removeCommandListener(Module01.CommandListener oldCommandListener) {
            if (myRegisteredListeners.contains(oldCommandListener)) {
                myRegisteredListeners.remove(oldCommandListener);
            } 
        }
    }
}


package Module05;


public class RadiusHandle extends Module05.AbstractHandle {
    private static final int OFFSET = 4;

    public RadiusHandle(Module03.RoundRectangleFigure owner) {
        super(owner);
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        setUndoActivity(createUndoActivity(view));
        getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(owner()));
        ((Module05.RadiusHandle.UndoActivity)(getUndoActivity())).setOldRadius(((Module03.RoundRectangleFigure)(owner())).getArc());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        int dx = x - anchorX;
        int dy = y - anchorY;
        Module03.RoundRectangleFigure owner = ((Module03.RoundRectangleFigure)(owner()));
        java.awt.Rectangle r = owner.displayBox();
        java.awt.Point originalRadius = ((Module05.RadiusHandle.UndoActivity)(getUndoActivity())).getOldRadius();
        int rx = Module06.Geom.range(0, r.width, (2 * (((originalRadius.x) / 2) + dx)));
        int ry = Module06.Geom.range(0, r.height, (2 * (((originalRadius.y) / 2) + dy)));
        owner.setArc(rx, ry);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Point currentRadius = ((Module03.RoundRectangleFigure)(owner())).getArc();
        java.awt.Point originalRadius = ((Module05.RadiusHandle.UndoActivity)(getUndoActivity())).getOldRadius();
        if (((currentRadius.x) == (originalRadius.x)) && ((currentRadius.y) == (originalRadius.y))) {
            setUndoActivity(null);
        } 
    }

    public java.awt.Point locate() {
        Module03.RoundRectangleFigure owner = ((Module03.RoundRectangleFigure)(owner()));
        java.awt.Point radius = owner.getArc();
        java.awt.Rectangle r = owner.displayBox();
        return new java.awt.Point((((r.x) + ((radius.x) / 2)) + (Module05.RadiusHandle.OFFSET)) , (((r.y) + ((radius.y) / 2)) + (Module05.RadiusHandle.OFFSET)));
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.yellow);
        g.fillOval(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        return new Module05.RadiusHandle.UndoActivity(newView);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Point myOldRadius;

        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            return resetRadius();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            return resetRadius();
        }

        protected boolean resetRadius() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.RoundRectangleFigure currentFigure = ((Module03.RoundRectangleFigure)(fe.nextFigure()));
            java.awt.Point figureRadius = currentFigure.getArc();
            currentFigure.setArc(getOldRadius().x, getOldRadius().y);
            setOldRadius(figureRadius);
            return true;
        }

        protected void setOldRadius(java.awt.Point newOldRadius) {
            myOldRadius = newOldRadius;
        }

        public java.awt.Point getOldRadius() {
            return myOldRadius;
        }
    }
}


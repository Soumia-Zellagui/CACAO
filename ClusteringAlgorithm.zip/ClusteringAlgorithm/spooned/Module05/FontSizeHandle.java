package Module05;


public class FontSizeHandle extends Module05.LocatorHandle {
    public FontSizeHandle(Module03.Figure owner ,Module03.Locator l) {
        super(owner, l);
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        setUndoActivity(createUndoActivity(view));
        getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(owner()));
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module03.TextFigure textOwner = ((Module03.TextFigure)(owner()));
        Module05.FontSizeHandle.UndoActivity activity = ((Module05.FontSizeHandle.UndoActivity)(getUndoActivity()));
        int newSize = ((activity.getFont().getSize()) + y) - anchorY;
        textOwner.setFont(new java.awt.Font(activity.getFont().getName() , activity.getFont().getStyle() , newSize));
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module03.TextFigure textOwner = ((Module03.TextFigure)(owner()));
        Module05.FontSizeHandle.UndoActivity activity = ((Module05.FontSizeHandle.UndoActivity)(getUndoActivity()));
        if ((textOwner.getFont().getSize()) == (activity.getOldFontSize())) {
            setUndoActivity(null);
        } else {
            activity.setFont(textOwner.getFont());
        }
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.yellow);
        g.fillOval(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        Module03.TextFigure textOwner = ((Module03.TextFigure)(owner()));
        return new Module05.FontSizeHandle.UndoActivity(newView , textOwner.getFont());
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Font myFont;

        private int myOldFontSize;

        public UndoActivity(Module03.DrawingView newView ,java.awt.Font newFont) {
            super(newView);
            setFont(newFont);
            setOldFontSize(getFont().getSize());
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            swapFont();
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            swapFont();
            return true;
        }

        protected void swapFont() {
            setOldFontSize(replaceFontSize());
            Module03.FigureEnumeration fe = getAffectedFigures();
            while (fe.hasNextFigure()) {
                ((Module03.TextFigure)(fe.nextFigure())).setFont(getFont());
            }
        }

        private int replaceFontSize() {
            int tempFontSize = getFont().getSize();
            setFont(new java.awt.Font(getFont().getName() , getFont().getStyle() , getOldFontSize()));
            return tempFontSize;
        }

        protected void setFont(java.awt.Font newFont) {
            myFont = newFont;
        }

        public java.awt.Font getFont() {
            return myFont;
        }

        protected void setOldFontSize(int newOldFontSize) {
            myOldFontSize = newOldFontSize;
        }

        public int getOldFontSize() {
            return myOldFontSize;
        }
    }
}


package Module05;


public class ChangeConnectionEndHandle extends Module05.ChangeConnectionHandle {
    public ChangeConnectionEndHandle(Module03.ConnectionFigure owner) {
        super(owner);
    }

    protected Module03.Connector target() {
        return getConnection().getEndConnector();
    }

    protected void disconnect() {
        getConnection().disconnectEnd();
    }

    protected void connect(Module03.Connector c) {
        getConnection().connectEnd(c);
    }

    protected void setPoint(int x, int y) {
        getConnection().endPoint(x, y);
    }

    public java.awt.Point locate() {
        return getConnection().endPoint();
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        return new Module05.ChangeConnectionEndHandle.UndoActivity(newView);
    }

    public static class UndoActivity extends Module05.ChangeConnectionHandle.UndoActivity {
        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
        }

        protected Module03.Connector replaceConnector(Module03.ConnectionFigure connection) {
            Module03.Connector tempEndConnector = connection.getEndConnector();
            connection.connectEnd(getOldConnector());
            return tempEndConnector;
        }
    }

    protected boolean canConnectTo(Module03.Figure figure) {
        return getConnection().canConnect(source().owner(), figure);
    }
}


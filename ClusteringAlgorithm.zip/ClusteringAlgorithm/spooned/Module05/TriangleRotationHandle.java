package Module05;


public class TriangleRotationHandle extends Module05.AbstractHandle {
    private java.awt.Point fOrigin;

    public TriangleRotationHandle(Module03.TriangleFigure owner) {
        super(owner);
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        fOrigin = getOrigin();
        Module05.TriangleRotationHandle.UndoActivity activity = ((Module05.TriangleRotationHandle.UndoActivity)(createUndoActivity(view)));
        setUndoActivity(activity);
        activity.setAffectedFigures(new Module03.SingleFigureEnumerator(owner()));
        double rotation = ((Module03.TriangleFigure)(owner())).getRotationAngle();
        activity.setRotationAngle(rotation);
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Point fCenter = owner().center();
        double angle = java.lang.Math.atan2(((((fOrigin.y) + y) - anchorY) - (fCenter.y)), ((((fOrigin.x) + x) - anchorX) - (fCenter.x)));
        ((Module03.TriangleFigure)(owner())).rotate(angle);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        fOrigin = null;
    }

    public java.awt.Point locate() {
        return getOrigin();
    }

    java.awt.Point getOrigin() {
        java.awt.Polygon p = ((Module03.TriangleFigure)(owner())).getPolygon();
        java.awt.Point first = new java.awt.Point(p.xpoints[0] , p.ypoints[0]);
        java.awt.Point ctr = owner().center();
        double len = Module06.Geom.length(first.x, first.y, ctr.x, ctr.y);
        if (len == 0) {
            return new java.awt.Point(((first.x) - ((Module05.AbstractHandle.HANDLESIZE) / 2)) , ((first.y) + ((Module05.AbstractHandle.HANDLESIZE) / 2)));
        } 
        double u = (Module05.AbstractHandle.HANDLESIZE) / len;
        if (u > 1.0) {
            return new java.awt.Point(((((first.x) * 3) + (ctr.x)) / 4) , ((((first.y) * 3) + (ctr.y)) / 4));
        } else {
            return new java.awt.Point(((int)(((first.x) * (1.0 - u)) + ((ctr.x) * u))) , ((int)(((first.y) * (1.0 - u)) + ((ctr.y) * u))));
        }
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.yellow);
        g.fillOval(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        return new Module05.TriangleRotationHandle.UndoActivity(newView);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private double myRotationAngle;

        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            return resetRotationAngle();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            return resetRotationAngle();
        }

        protected boolean resetRotationAngle() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.TriangleFigure figure = ((Module03.TriangleFigure)(fe.nextFigure()));
            double backupAngle = figure.getRotationAngle();
            figure.willChange();
            figure.rotate(getRotationAngle());
            figure.changed();
            setRotationAngle(backupAngle);
            return true;
        }

        protected void setRotationAngle(double newRotationAngle) {
            myRotationAngle = newRotationAngle;
        }

        public double getRotationAngle() {
            return myRotationAngle;
        }
    }
}


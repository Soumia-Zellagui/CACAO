package Module05;


public final class GroupHandle extends Module05.NullHandle {
    public GroupHandle(Module03.Figure owner ,Module03.Locator locator) {
        super(owner, locator);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.black);
        g.drawRect(r.x, r.y, r.width, r.height);
        r.grow((-1), (-1));
        g.setColor(java.awt.Color.white);
        g.drawRect(r.x, r.y, r.width, r.height);
    }
}


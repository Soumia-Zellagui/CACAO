package Module05;


public abstract class ChangeConnectionHandle extends Module05.AbstractHandle {
    private Module03.Connector fOriginalTarget;

    private Module03.Figure myTarget;

    private Module03.ConnectionFigure myConnection;

    private java.awt.Point fStart;

    protected ChangeConnectionHandle(Module03.ConnectionFigure owner) {
        super(owner);
        setConnection(owner);
        setTargetFigure(null);
    }

    protected abstract Module03.Connector target();

    protected abstract void disconnect();

    protected abstract void connect(Module03.Connector c);

    protected abstract void setPoint(int x, int y);

    protected Module03.Connector source() {
        if ((target()) == (getConnection().getStartConnector())) {
            return getConnection().getEndConnector();
        } 
        return getConnection().getStartConnector();
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        fOriginalTarget = target();
        fStart = new java.awt.Point(x , y);
        setUndoActivity(createUndoActivity(view));
        ((Module05.ChangeConnectionHandle.UndoActivity)(getUndoActivity())).setOldConnector(target());
        disconnect();
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Point p = new java.awt.Point(x , y);
        Module03.Figure f = findConnectableFigure(x, y, view.drawing());
        if (f != (getTargetFigure())) {
            if ((getTargetFigure()) != null) {
                getTargetFigure().connectorVisibility(false, null);
            } 
            setTargetFigure(f);
            if ((getTargetFigure()) != null) {
                getTargetFigure().connectorVisibility(true, getConnection());
            } 
        } 
        Module03.Connector target = findConnectionTarget(p.x, p.y, view.drawing());
        if (target != null) {
            p = Module06.Geom.center(target.displayBox());
        } 
        setPoint(p.x, p.y);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module03.Connector target = findConnectionTarget(x, y, view.drawing());
        if (target == null) {
            target = fOriginalTarget;
        } 
        setPoint(x, y);
        connect(target);
        getConnection().updateConnection();
        Module03.Connector oldConnector = ((Module05.ChangeConnectionHandle.UndoActivity)(getUndoActivity())).getOldConnector();
        if (((oldConnector == null) || ((target()) == null)) || ((oldConnector.owner()) == (target().owner()))) {
            setUndoActivity(null);
        } else {
            getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(getConnection()));
        }
        if ((getTargetFigure()) != null) {
            getTargetFigure().connectorVisibility(false, null);
            setTargetFigure(null);
        } 
    }

    private Module03.Connector findConnectionTarget(int x, int y, Module03.Drawing drawing) {
        Module03.Figure target = findConnectableFigure(x, y, drawing);
        if (((((target != null) && (target.canConnect())) && (target != (fOriginalTarget))) && (!(target.includes(owner())))) && (canConnectTo(target))) {
            return findConnector(x, y, target);
        } 
        return null;
    }

    protected abstract boolean canConnectTo(Module03.Figure figure);

    protected Module03.Connector findConnector(int x, int y, Module03.Figure f) {
        return f.connectorAt(x, y);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.green);
        g.fillRect(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawRect(r.x, r.y, r.width, r.height);
    }

    private Module03.Figure findConnectableFigure(int x, int y, Module03.Drawing drawing) {
        Module03.FigureEnumeration fe = drawing.figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if ((!(figure.includes(getConnection()))) && (figure.canConnect())) {
                if (figure.containsPoint(x, y)) {
                    return figure;
                } 
            } 
        }
        return null;
    }

    protected void setConnection(Module03.ConnectionFigure newConnection) {
        myConnection = newConnection;
    }

    protected Module03.ConnectionFigure getConnection() {
        return myConnection;
    }

    protected void setTargetFigure(Module03.Figure newTarget) {
        myTarget = newTarget;
    }

    protected Module03.Figure getTargetFigure() {
        return myTarget;
    }

    protected abstract Module06.Undoable createUndoActivity(Module03.DrawingView newView);

    public abstract static class UndoActivity extends Module06.UndoableAdapter {
        private Module03.Connector myOldConnector;

        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            swapConnectors();
            return true;
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            swapConnectors();
            return true;
        }

        private void swapConnectors() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (fe.hasNextFigure()) {
                Module03.ConnectionFigure connection = ((Module03.ConnectionFigure)(fe.nextFigure()));
                setOldConnector(replaceConnector(connection));
                connection.updateConnection();
            } 
        }

        protected abstract Module03.Connector replaceConnector(Module03.ConnectionFigure connection);

        public void setOldConnector(Module03.Connector newOldConnector) {
            myOldConnector = newOldConnector;
        }

        public Module03.Connector getOldConnector() {
            return myOldConnector;
        }
    }
}


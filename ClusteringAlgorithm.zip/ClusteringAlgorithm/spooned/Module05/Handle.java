package Module05;


public interface Handle {
    public static final int HANDLESIZE = 8;

    public java.awt.Point locate();

    public void invokeStart(int x, int y, Module03.DrawingView view);

    public void invokeStart(int x, int y, Module03.Drawing drawing);

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view);

    public void invokeStep(int dx, int dy, Module03.Drawing drawing);

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view);

    public void invokeEnd(int dx, int dy, Module03.Drawing drawing);

    public Module03.Figure owner();

    public java.awt.Rectangle displayBox();

    public boolean containsPoint(int x, int y);

    public void draw(java.awt.Graphics g);

    public Module06.Undoable getUndoActivity();

    public void setUndoActivity(Module06.Undoable newUndoableActivity);

    public Module06.Cursor getCursor();
}


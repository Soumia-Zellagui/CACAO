package Module05;


public class PolygonScaleHandle extends Module05.AbstractHandle {
    private java.awt.Point fCurrent;

    public PolygonScaleHandle(Module03.PolygonFigure owner) {
        super(owner);
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        fCurrent = new java.awt.Point(x , y);
        Module05.PolygonScaleHandle.UndoActivity activity = ((Module05.PolygonScaleHandle.UndoActivity)(createUndoActivity(view)));
        setUndoActivity(activity);
        Module03.Figure figure = owner();
        Module03.SingleFigureEnumerator singleFigureEnumerator = new Module03.SingleFigureEnumerator(figure);
        activity.setAffectedFigures(singleFigureEnumerator);
        activity.setPolygon(((Module03.PolygonFigure)(figure)).getPolygon());
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        fCurrent = new java.awt.Point(x , y);
        java.awt.Polygon polygon = ((Module05.PolygonScaleHandle.UndoActivity)(getUndoActivity())).getPolygon();
        ((Module03.PolygonFigure)(owner())).scaleRotate(new java.awt.Point(anchorX , anchorY), polygon, fCurrent);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        ((Module03.PolygonFigure)(owner())).smoothPoints();
        if (((fCurrent.x) == anchorX) && ((fCurrent.y) == anchorY)) {
            setUndoActivity(null);
        } 
        fCurrent = null;
    }

    public java.awt.Point locate() {
        if ((fCurrent) == null) {
            return getOrigin();
        } else {
            return fCurrent;
        }
    }

    java.awt.Point getOrigin() {
        java.awt.Point outer = ((Module03.PolygonFigure)(owner())).outermostPoint();
        java.awt.Point ctr = ((Module03.PolygonFigure)(owner())).center();
        double len = Module06.Geom.length(outer.x, outer.y, ctr.x, ctr.y);
        if (len == 0) {
            return new java.awt.Point(((outer.x) - ((Module05.AbstractHandle.HANDLESIZE) / 2)) , ((outer.y) + ((Module05.AbstractHandle.HANDLESIZE) / 2)));
        } 
        double u = (Module05.AbstractHandle.HANDLESIZE) / len;
        if (u > 1.0) {
            return new java.awt.Point(((((outer.x) * 3) + (ctr.x)) / 4) , ((((outer.y) * 3) + (ctr.y)) / 4));
        } else {
            return new java.awt.Point(((int)(((outer.x) * (1.0 - u)) + ((ctr.x) * u))) , ((int)(((outer.y) * (1.0 - u)) + ((ctr.y) * u))));
        }
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.yellow);
        g.fillOval(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        Module05.PolygonScaleHandle.UndoActivity po = new Module05.PolygonScaleHandle.UndoActivity(newView);
        return po;
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Polygon myPolygon;

        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            return resetPolygon();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            return resetPolygon();
        }

        protected boolean resetPolygon() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.PolygonFigure figure = ((Module03.PolygonFigure)(fe.nextFigure()));
            java.awt.Polygon backupPolygon = figure.getPolygon();
            figure.willChange();
            figure.setInternalPolygon(getPolygon());
            figure.changed();
            setPolygon(backupPolygon);
            return true;
        }

        protected void setPolygon(java.awt.Polygon newPolygon) {
            myPolygon = newPolygon;
        }

        public java.awt.Polygon getPolygon() {
            return myPolygon;
        }
    }
}


package Module05;


public class LocatorHandle extends Module05.AbstractHandle {
    private Module03.Locator fLocator;

    public LocatorHandle(Module03.Figure owner ,Module03.Locator l) {
        super(owner);
        fLocator = l;
    }

    public Module03.Locator getLocator() {
        return fLocator;
    }

    public java.awt.Point locate() {
        return fLocator.locate(owner());
    }

    public Module06.Cursor getCursor() {
        Module06.Cursor c = super.getCursor();
        if ((getLocator()) instanceof Module03.RelativeLocator) {
            Module03.RelativeLocator rl = ((Module03.RelativeLocator)(getLocator()));
            if (rl.equals(Module03.RelativeLocator.north())) {
                c = new Module06.AWTCursor(java.awt.Cursor.N_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.northEast())) {
                c = new Module06.AWTCursor(java.awt.Cursor.NE_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.east())) {
                c = new Module06.AWTCursor(java.awt.Cursor.E_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.southEast())) {
                c = new Module06.AWTCursor(java.awt.Cursor.SE_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.south())) {
                c = new Module06.AWTCursor(java.awt.Cursor.S_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.southWest())) {
                c = new Module06.AWTCursor(java.awt.Cursor.SW_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.west())) {
                c = new Module06.AWTCursor(java.awt.Cursor.W_RESIZE_CURSOR);
            } else if (rl.equals(Module03.RelativeLocator.northWest())) {
                c = new Module06.AWTCursor(java.awt.Cursor.NW_RESIZE_CURSOR);
            } 
        } 
        return c;
    }
}


package Module05;


public class PolyLineHandle extends Module05.LocatorHandle {
    private int fIndex;

    public PolyLineHandle(Module03.PolyLineFigure owner ,Module03.Locator l ,int index) {
        super(owner, l);
        fIndex = index;
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        setUndoActivity(createUndoActivity(view, fIndex));
        getUndoActivity().setAffectedFigures(new Module03.SingleFigureEnumerator(owner()));
        ((Module05.PolyLineHandle.UndoActivity)(getUndoActivity())).setOldPoint(new java.awt.Point(x , y));
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        int currentIndex = ((Module05.PolyLineHandle.UndoActivity)(getUndoActivity())).getPointIndex();
        myOwner().setPointAt(new java.awt.Point(x , y), currentIndex);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        if ((x == anchorX) && (y == anchorY)) {
            setUndoActivity(null);
        } 
    }

    private Module03.PolyLineFigure myOwner() {
        return ((Module03.PolyLineFigure)(owner()));
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView, int newPointIndex) {
        return new Module05.PolyLineHandle.UndoActivity(newView , newPointIndex);
    }

    public static class UndoActivity extends Module06.UndoableAdapter {
        private java.awt.Point myOldPoint;

        private int myPointIndex;

        public UndoActivity(Module03.DrawingView newView ,int newPointIndex) {
            super(newView);
            setUndoable(true);
            setRedoable(true);
            setPointIndex(newPointIndex);
        }

        public boolean undo() {
            if (!(super.undo())) {
                return false;
            } 
            return movePointToOldLocation();
        }

        public boolean redo() {
            if (!(isRedoable())) {
                return false;
            } 
            return movePointToOldLocation();
        }

        protected boolean movePointToOldLocation() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.PolyLineFigure figure = ((Module03.PolyLineFigure)(fe.nextFigure()));
            java.awt.Point backupPoint = figure.pointAt(getPointIndex());
            figure.setPointAt(getOldPoint(), getPointIndex());
            setOldPoint(backupPoint);
            return true;
        }

        public void setOldPoint(java.awt.Point newOldPoint) {
            myOldPoint = newOldPoint;
        }

        public java.awt.Point getOldPoint() {
            return myOldPoint;
        }

        public void setPointIndex(int newPointIndex) {
            myPointIndex = newPointIndex;
        }

        public int getPointIndex() {
            return myPointIndex;
        }
    }
}


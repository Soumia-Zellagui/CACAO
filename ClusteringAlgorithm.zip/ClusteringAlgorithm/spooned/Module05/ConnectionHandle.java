package Module05;


public class ConnectionHandle extends Module05.LocatorHandle {
    private Module03.ConnectionFigure myConnection;

    private Module03.ConnectionFigure fPrototype;

    private Module03.Figure myTargetFigure;

    public ConnectionHandle(Module03.Figure owner ,Module03.Locator l ,Module03.ConnectionFigure prototype) {
        super(owner, l);
        fPrototype = prototype;
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        Module03.ConnectionFigure connection = createConnection();
        setConnection(connection);
        setUndoActivity(createUndoActivity(view));
        java.util.Vector v = new java.util.Vector();
        Module03.ConnectionFigure connec = getConnection();
        v.add(connec);
        Module03.FigureEnumerator figureEnumerator = new Module03.FigureEnumerator(v);
        Module06.Undoable und = getUndoActivity();
        und.setAffectedFigures(figureEnumerator);
        java.awt.Point p = locate();
        connec.startPoint(p.x, p.y);
        connec.endPoint(p.x, p.y);
        Module03.Drawing drawing = view.drawing();
        drawing.add(connec);
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        java.awt.Point p = new java.awt.Point(x , y);
        Module03.Figure f = findConnectableFigure(x, y, view.drawing());
        if (f != (getTargetFigure())) {
            if ((getTargetFigure()) != null) {
                Module03.Figure ff = getTargetFigure();
                f.connectorVisibility(false, null);
            } 
            setTargetFigure(f);
            if ((getTargetFigure()) != null) {
                Module03.Figure ff = getTargetFigure();
                f.connectorVisibility(true, getConnection());
            } 
        } 
        Module03.Drawing drawing = view.drawing();
        Module03.Connector target = findConnectionTarget(p.x, p.y, drawing);
        if (target != null) {
            p = Module06.Geom.center(target.displayBox());
        } 
        Module03.ConnectionFigure connec = getConnection();
        connec.endPoint(p.x, p.y);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module03.Drawing drawing = view.drawing();
        Module03.Connector target = findConnectionTarget(x, y, drawing);
        if (target != null) {
            Module03.ConnectionFigure connec = getConnection();
            Module03.Connector connector = startConnector();
            connec.connectStart(connector);
            connec.connectEnd(target);
            connec.updateConnection();
        } else {
            drawing.remove(getConnection());
            setUndoActivity(null);
        }
        setConnection(null);
        if ((getTargetFigure()) != null) {
            Module03.Figure figu = getTargetFigure();
            figu.connectorVisibility(false, null);
            setTargetFigure(null);
        } 
    }

    private Module03.Connector startConnector() {
        java.awt.Point p = locate();
        Module03.Figure f = owner();
        Module03.Connector connector = f.connectorAt(p.x, p.y);
        return connector;
    }

    protected Module03.ConnectionFigure createConnection() {
        return ((Module03.ConnectionFigure)(fPrototype.clone()));
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView view) {
        Module01.PasteCommand.UndoActivity undoActivity = new Module01.PasteCommand.UndoActivity(view);
        return undoActivity;
    }

    protected Module03.Connector findConnectionTarget(int x, int y, Module03.Drawing drawing) {
        Module03.Figure target = findConnectableFigure(x, y, drawing);
        Module03.Figure f = owner();
        Module03.ConnectionFigure connec = getConnection();
        if ((((target != null) && (target.canConnect())) && (!(target.includes(owner())))) && (connec.canConnect(f, target))) {
            Module03.Connector connector = findConnector(x, y, target);
            return connector;
        } 
        return null;
    }

    private Module03.Figure findConnectableFigure(int x, int y, Module03.Drawing drawing) {
        Module03.FigureEnumeration fe = drawing.figuresReverse();
        while (fe.hasNextFigure()) {
            Module03.Figure figure = fe.nextFigure();
            if (((!(figure.includes(getConnection()))) && (figure.canConnect())) && (figure.containsPoint(x, y))) {
                return figure;
            } 
        }
        return null;
    }

    protected Module03.Connector findConnector(int x, int y, Module03.Figure f) {
        return f.connectorAt(x, y);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.blue);
        g.drawOval(r.x, r.y, r.width, r.height);
    }

    protected void setConnection(Module03.ConnectionFigure newConnection) {
        myConnection = newConnection;
    }

    protected Module03.ConnectionFigure getConnection() {
        return myConnection;
    }

    protected Module03.Figure getTargetFigure() {
        return myTargetFigure;
    }

    protected void setTargetFigure(Module03.Figure newTargetFigure) {
        myTargetFigure = newTargetFigure;
    }

    public Module06.Cursor getCursor() {
        Module06.AWTCursor awtCursor = new Module06.AWTCursor(java.awt.Cursor.HAND_CURSOR);
        return awtCursor;
    }
}


package Module05;


public abstract class AbstractHandle implements Module05.Handle {
    public static final int HANDLESIZE = 8;

    private Module03.Figure fOwner;

    private Module06.Undoable myUndoableActivity;

    public AbstractHandle(Module03.Figure owner) {
        fOwner = owner;
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        invokeStart(x, y, view.drawing());
    }

    public void invokeStart(int x, int y, Module03.Drawing drawing) {
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        invokeStep((x - anchorX), (y - anchorY), view.drawing());
    }

    public void invokeStep(int dx, int dy, Module03.Drawing drawing) {
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        invokeEnd((x - anchorX), (y - anchorY), view.drawing());
    }

    public void invokeEnd(int dx, int dy, Module03.Drawing drawing) {
    }

    public Module03.Figure owner() {
        return fOwner;
    }

    public java.awt.Rectangle displayBox() {
        java.awt.Point p = locate();
        return new java.awt.Rectangle(((p.x) - ((Module05.AbstractHandle.HANDLESIZE) / 2)) , ((p.y) - ((Module05.AbstractHandle.HANDLESIZE) / 2)) , Module05.AbstractHandle.HANDLESIZE , Module05.AbstractHandle.HANDLESIZE);
    }

    public boolean containsPoint(int x, int y) {
        return displayBox().contains(x, y);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.white);
        g.fillRect(r.x, r.y, r.width, r.height);
        g.setColor(java.awt.Color.black);
        g.drawRect(r.x, r.y, r.width, r.height);
    }

    public Module06.Undoable getUndoActivity() {
        return myUndoableActivity;
    }

    public void setUndoActivity(Module06.Undoable newUndoableActivity) {
        myUndoableActivity = newUndoableActivity;
    }

    public Module06.Cursor getCursor() {
        return new Module06.AWTCursor(Module06.AWTCursor.DEFAULT_CURSOR);
    }
}


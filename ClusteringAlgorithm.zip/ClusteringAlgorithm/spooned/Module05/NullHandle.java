package Module05;


public class NullHandle extends Module05.LocatorHandle {
    protected Module03.Locator fLocator;

    public NullHandle(Module03.Figure owner ,Module03.Locator locator) {
        super(owner, locator);
    }

    public void draw(java.awt.Graphics g) {
        java.awt.Rectangle r = displayBox();
        g.setColor(java.awt.Color.black);
        g.drawRect(r.x, r.y, r.width, r.height);
    }
}


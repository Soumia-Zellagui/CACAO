package Module05;


public class ChangeConnectionStartHandle extends Module05.ChangeConnectionHandle {
    public ChangeConnectionStartHandle(Module03.ConnectionFigure owner) {
        super(owner);
    }

    protected Module03.Connector target() {
        return getConnection().getStartConnector();
    }

    protected void disconnect() {
        getConnection().disconnectStart();
    }

    protected void connect(Module03.Connector c) {
        getConnection().connectStart(c);
    }

    protected void setPoint(int x, int y) {
        getConnection().startPoint(x, y);
    }

    public java.awt.Point locate() {
        return getConnection().startPoint();
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView) {
        return new Module05.ChangeConnectionStartHandle.UndoActivity(newView);
    }

    public static class UndoActivity extends Module05.ChangeConnectionHandle.UndoActivity {
        public UndoActivity(Module03.DrawingView newView) {
            super(newView);
        }

        protected Module03.Connector replaceConnector(Module03.ConnectionFigure connection) {
            Module03.Connector tempStartConnector = connection.getStartConnector();
            connection.connectStart(getOldConnector());
            return tempStartConnector;
        }
    }

    protected boolean canConnectTo(Module03.Figure figure) {
        return getConnection().canConnect(figure, source().owner());
    }
}


package Module05;


public class UndoableHandle implements Module05.Handle {
    private Module05.Handle myWrappedHandle;

    private Module03.DrawingView myDrawingView;

    public UndoableHandle(Module05.Handle newWrappedHandle) {
        setWrappedHandle(newWrappedHandle);
    }

    public UndoableHandle(Module05.Handle newWrappedHandle ,Module03.DrawingView newDrawingView) {
        setWrappedHandle(newWrappedHandle);
        setDrawingView(newDrawingView);
    }

    public java.awt.Point locate() {
        Module05.Handle wrapHandle = getWrappedHandle();
        return wrapHandle.locate();
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeStart(x, y, view);
    }

    public void invokeStart(int x, int y, Module03.Drawing drawing) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeStart(x, y, drawing);
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeStep(x, y, anchorX, anchorY, view);
    }

    public void invokeStep(int dx, int dy, Module03.Drawing drawing) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeStep(dx, dy, drawing);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeEnd(x, y, anchorX, anchorY, view);
        Module06.Undoable undoableActivity = wrapHandle.getUndoActivity();
        if ((undoableActivity != null) && (undoableActivity.isUndoable())) {
            Module01.DrawingEditor editor = view.editor();
            Module01.UndoManager um = editor.getUndoManager();
            um.pushUndo(undoableActivity);
            um.clearRedos();
        } 
    }

    public void invokeEnd(int dx, int dy, Module03.Drawing drawing) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.invokeEnd(dx, dy, drawing);
    }

    public Module03.Figure owner() {
        Module05.Handle wrapHandle = getWrappedHandle();
        Module03.Figure f = wrapHandle.owner();
        return f;
    }

    public java.awt.Rectangle displayBox() {
        Module05.Handle wrapHandle = getWrappedHandle();
        java.awt.Rectangle f = wrapHandle.displayBox();
        return f;
    }

    public boolean containsPoint(int x, int y) {
        Module05.Handle wrapHandle = getWrappedHandle();
        return wrapHandle.containsPoint(x, y);
    }

    public void draw(java.awt.Graphics g) {
        Module05.Handle wrapHandle = getWrappedHandle();
        wrapHandle.draw(g);
    }

    protected void setWrappedHandle(Module05.Handle newWrappedHandle) {
        myWrappedHandle = newWrappedHandle;
    }

    protected Module05.Handle getWrappedHandle() {
        return myWrappedHandle;
    }

    public Module03.DrawingView getDrawingView() {
        return myDrawingView;
    }

    protected void setDrawingView(Module03.DrawingView newDrawingView) {
        myDrawingView = newDrawingView;
    }

    public Module06.Undoable getUndoActivity() {
        Module03.DrawingView v = getDrawingView();
        Module06.Undoable undoable = new Module06.UndoableAdapter(v);
        return undoable;
    }

    public void setUndoActivity(Module06.Undoable newUndoableActivity) {
    }

    public Module06.Cursor getCursor() {
        Module05.Handle wrapHandle = getWrappedHandle();
        Module06.Cursor c = wrapHandle.getCursor();
        return c;
    }
}


package Module05;


public class PolygonHandle extends Module05.AbstractHandle {
    private Module03.Locator fLocator;

    private int fIndex;

    public PolygonHandle(Module03.PolygonFigure owner ,Module03.Locator l ,int index) {
        super(owner);
        fLocator = l;
        fIndex = index;
    }

    public void invokeStart(int x, int y, Module03.DrawingView view) {
        setUndoActivity(createUndoActivity(view, fIndex));
        Module03.Figure figure = owner();
        Module03.SingleFigureEnumerator singleFigureEnumerator = new Module03.SingleFigureEnumerator(figure);
        getUndoActivity().setAffectedFigures(singleFigureEnumerator);
        Module06.Undoable undo = getUndoActivity();
        ((Module05.PolygonHandle.UndoActivity)(undo)).setOldPoint(new java.awt.Point(x , y));
    }

    public void invokeStep(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        Module06.Undoable undo = getUndoActivity();
        int index = ((Module05.PolyLineHandle.UndoActivity)(undo)).getPointIndex();
        myOwner().setPointAt(new java.awt.Point(x , y), index);
    }

    public void invokeEnd(int x, int y, int anchorX, int anchorY, Module03.DrawingView view) {
        myOwner().smoothPoints();
        if ((x == anchorX) && (y == anchorY)) {
            setUndoActivity(null);
        } 
    }

    public java.awt.Point locate() {
        return fLocator.locate(owner());
    }

    private Module03.PolygonFigure myOwner() {
        return ((Module03.PolygonFigure)(owner()));
    }

    protected Module06.Undoable createUndoActivity(Module03.DrawingView newView, int newPointIndex) {
        Module05.PolygonHandle.UndoActivity pu = new Module05.PolygonHandle.UndoActivity(newView , newPointIndex);
        return pu;
    }

    public static class UndoActivity extends Module05.PolyLineHandle.UndoActivity {
        public UndoActivity(Module03.DrawingView newView ,int newPointIndex) {
            super(newView, newPointIndex);
        }

        protected boolean movePointToOldLocation() {
            Module03.FigureEnumeration fe = getAffectedFigures();
            if (!(fe.hasNextFigure())) {
                return false;
            } 
            Module03.PolygonFigure figure = ((Module03.PolygonFigure)(fe.nextFigure()));
            java.awt.Point backupPoint = figure.pointAt(getPointIndex());
            figure.setPointAt(getOldPoint(), getPointIndex());
            figure.smoothPoints();
            setOldPoint(backupPoint);
            return true;
        }
    }
}

